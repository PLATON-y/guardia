#!/usr/bin/env bash
cd "$(dirname "$0")"
# queen_decide — Groq (directives technicien, sans exploit)
QUEEN="${GUARDIA_QUEEN_DECIDE:-$(pwd)/queen_decide}"
if [[ -f "$QUEEN" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$QUEEN"
  set +a
fi
# Garder le DISPLAY de la session Plasma
if [[ -z "${DISPLAY:-}" ]]; then
  export DISPLAY=:0
fi
export PYTHONUNBUFFERED=1

# Premier démarrage : lanceur Bureau Guardia-UI.desktop si absent
python3 - <<'PY' 2>/dev/null || true
try:
    from guardia.core.desktop_launch import ensure_guardia_desktop
    r = ensure_guardia_desktop(force=False)
    if r.get("created"):
        print("Guardia: lanceur Bureau créé →", r.get("path"))
except Exception:
    pass
PY
exec python3 -m guardia ui
