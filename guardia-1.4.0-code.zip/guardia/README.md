# Guardia 1.4.0

Checkup défensif LAN — **Echoes of Hackers** / Platon-Y.

Doctrine : **cartographier, ne pas emprunter**. Lecture seule. Aucun exploit, PoC ni payload.

## Contenu

- Inventaire hôtes / services (CIDR connus + saisie libre)
- Catalogues intégrés : plages d’adresses, ports critiques, AS/FAI français
- Modes d’intervention : **WiFi sur site** (défaut) · **SSH** (clients avec annexe signée)
- Rapports HTML/PDF, documents à signer (ÉOH)
- Directives LLM / Queen : fichier `guardia/engines/llm_groq_directives.py` (**ne pas modifier** — cadrage CNIL / ANSSI)

## Lancement (Kali)

```bash
cd /chemin/vers/guardia
./lancer-ui.sh
# ou
./lancer-cli.sh run -m missions/exemple-complet-wifi.yaml
```

Configurer Groq : copier `queen_decide.example` → `queen_decide` (chmod 600), renseigner `GROQ_API_KEY`.

## Tests catalogues

```bash
python3 -m pytest tests/test_cidr.py tests/test_ports.py tests/test_as_fr.py tests/test_commands.py tests/test_extreme_inventory.py -q
```

## Identifiants association

Echoes of Hackers — RNA W882005217 · SIREN 933496234

Mandat + NDA requis avant toute intervention réelle.
