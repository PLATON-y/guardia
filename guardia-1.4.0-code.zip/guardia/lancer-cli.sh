#!/usr/bin/env bash
cd "$(dirname "$0")"
# queen_decide — Groq (directives technicien, sans exploit)
QUEEN="${GUARDIA_QUEEN_DECIDE:-$(pwd)/queen_decide}"
if [[ -f "$QUEEN" ]]; then
  set -a
  # shellcheck disable=SC1090
  source "$QUEEN"
  set +a
fi
export PYTHONUNBUFFERED=1
exec python3 -m guardia "$@"
