"""Tests d’aptitude et de liasse d’autorisation."""
from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Mission
from guardia.engines.autorisations import build_autorisations
from guardia.engines.passi import ATTESTATION_EXECUTE, ATTESTATION_NON, DISCLAIMER, aptitude
from guardia.engines.programme import get_outil


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertTrue(__version__.startswith("1."))


class Aptitude(unittest.TestCase):
    def test_identite_asso(self) -> None:
        a = aptitude()
        self.assertEqual(a["rna"], "W882005217")
        self.assertFalse(a["passi_qualifie"])
        self.assertFalse(a["certificat"])
        self.assertGreaterEqual(a["n_utiles"], 10)
        self.assertIn("Autorisation écrite", " ".join(a["controles"]))

    def test_documents_sans_demande(self) -> None:
        blob = (DISCLAIMER + ATTESTATION_EXECUTE + ATTESTATION_NON).lower()
        for mot in ("demande", "candidature", "qualification anssi en cours", "étoffe", "envie"):
            self.assertNotIn(mot, blob)
        self.assertIn("certificat", blob)

    def test_whois_catalogue(self) -> None:
        for oid in ("whois", "dig", "host"):
            o = get_outil(oid)
            self.assertIsNotNone(o, oid)
            self.assertEqual(o.scope, "url")


class LiassePassi(unittest.TestCase):
    def test_piece_04_obligatoire(self) -> None:
        m = Mission(client="X", type_structure="foyer", mandat_nda_signes=True)
        st = build_autorisations(m, pour_passi=True)
        p04 = next(p for p in st["pieces"] if p["id"] == "04-autorisation-red-team")
        self.assertTrue(p04["requis"])

    def test_red_example_requires_signed_dossier(self) -> None:
        from guardia.cli import load_mission

        m = load_mission(ROOT / "missions" / "exemple-red.yaml")
        st = build_autorisations(m, pour_passi=True)
        self.assertFalse(st["complet"])
        self.assertTrue(st["manquantes"])


if __name__ == "__main__":
    unittest.main()
