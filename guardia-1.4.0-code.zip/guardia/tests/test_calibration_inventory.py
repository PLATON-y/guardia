"""Tests calibrage et inventaire des capacités locales."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission
from guardia.core.orchestrate import want_calibrage
from guardia.engines.calibrage import PROBES, plan_calibrage, run_calibrage
from guardia.engines.inventaire import build_inventaire, format_txt
from guardia.engines.programme import get_outil, build_programme
from guardia.report.html_report import _build
from guardia.report.recap import build_grandes_lignes, build_journal


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class Calibrage(unittest.TestCase):
    def test_probes_passifs(self) -> None:
        ids = {p.id for p in PROBES}
        self.assertTrue({"smb-shares", "snmp-public", "ldapsearch", "nuclei-info", "smb-sec", "rdp-nla", "testssl"} <= ids)
        for p in PROBES:
            self.assertTrue(p.bins)

    def test_plan_selon_ports(self) -> None:
        h = Host(ip="10.0.0.8", kind="serveur")
        h.ports = [{"port": 445, "state": "open"}, {"port": 389, "state": "open"}]
        jobs = plan_calibrage([h], cidr="10.0.0.0/24")
        ids = {j["id"] for j in jobs}
        self.assertIn("smb-shares", ids)
        self.assertIn("ldapsearch", ids)
        self.assertIn("smb-sec", ids)
        self.assertNotIn("ike-scan", ids)
        self.assertNotIn("rdp-nla", ids)

    def test_plan_rdp_et_tls(self) -> None:
        h = Host(ip="10.0.0.9", kind="pc")
        h.ports = [
            {"port": 3389, "state": "open"},
            {"port": 443, "state": "open"},
        ]
        jobs = plan_calibrage([h], cidr="10.0.0.0/24")
        ids = {j["id"] for j in jobs}
        self.assertIn("rdp-nla", ids)
        self.assertIn("testssl", ids)
        self.assertNotIn("ldapsearch", ids)

    def test_run_sans_binaires_ne_plante_pas(self) -> None:
        h = Host(ip="10.0.0.8")
        h.ports = [{"port": 22, "state": "open"}]
        block = run_calibrage([h], cidr="10.0.0.0/24", timeout_total=8)
        self.assertIn("n_lances", block)
        self.assertIsInstance(block.get("absents"), list)

    def test_want_defaut_off_en_blue(self) -> None:
        m = Mission(client="U")
        args = SimpleNamespace(calibrage=False, no_calibrage=False, equipe="blue", red_pass="")
        self.assertFalse(want_calibrage(args, m))
        args = SimpleNamespace(
            calibrage=True, no_calibrage=False, equipe="red", red_pass="eoh19311936"
        )
        self.assertTrue(want_calibrage(args, m))
        args.no_calibrage = True
        self.assertFalse(want_calibrage(args, m))

    def test_nuclei_auto(self) -> None:
        n = get_outil("nuclei")
        assert n is not None
        self.assertTrue(n.auto)
        self.assertEqual(n.mode, "lecture")
        self.assertIn("etags", n.commande)


class Inventaire(unittest.TestCase):
    def test_format(self) -> None:
        inv = build_inventaire(brut=False)
        txt = format_txt(inv)
        self.assertIn("nmap", txt.lower())
        self.assertIn("inventaire Kali", txt)


class RapportPropre(unittest.TestCase):
    def test_pas_de_on_ne_fait_pas(self) -> None:
        m = Mission(
            client="Atelier Martin",
            mandat_nda_signes=True,
            operateur_signe=True,
            extras={"topo_approx": "On a une box et un NAS."},
        )
        h = Host(ip="192.168.1.12", kind="nas")
        h.findings.append(
            Finding(
                id="cal-smb-shares",
                titre="Partages visibles",
                pourquoi_nuit="Trop large",
                preuve="smbclient -L",
                remede_etapes=["Restreindre les partages."],
                qui_peut="vous",
                priorite="cette_semaine",
                gravite=Gravite.HAUTE,
                hote="192.168.1.12",
            )
        )
        result = CheckupResult(mission=m, hosts=[h], cidr="192.168.1.0/24")
        result.programme = build_programme(m, cidr="192.168.1.0/24")
        recap = build_grandes_lignes(result)
        self.assertTrue(recap.get("perimetre"))
        self.assertNotIn("pas_ceci", recap)
        self.assertIn("box", recap.get("topo_approx", "").lower())
        html = _build(result)
        self.assertIn("Périmètre de cette visite", html)
        self.assertNotIn("Ce que ce papier n'est pas", html)
        self.assertNotIn("Hors moteur", html)
        self.assertNotIn("on ne fait pas", html.lower())
        self.assertNotIn("Ce que nous n'avons pas fait", html)
        self.assertNotIn("YesWeHack", html)
        self.assertNotIn("Burp Suite", html)
        j = build_journal(result)
        self.assertNotIn("hors", j)
        self.assertIn("outils", j)

    def test_yaml_exemples(self) -> None:
        missions = ROOT / "missions"
        for name in (
            "exemple-pme.yaml",
            "exemple-fac.yaml",
            "exemple-caserne.yaml",
            "exemple-industrie.yaml",
            "exemple-association.yaml",
            "exemple-sante.yaml",
            "exemple-collectivite.yaml",
        ):
            p = missions / name
            self.assertTrue(p.is_file(), name)
            text = p.read_text(encoding="utf-8")
            self.assertIn("topo_approx", text)
            self.assertIn("cidr", text)


if __name__ == "__main__":
    unittest.main()
