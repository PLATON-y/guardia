"""OSI map + directives PASSI/CNIL + preuve démo lecture."""
from __future__ import annotations

import json
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.engines.osi_map import (
    attach_host_osi,
    couverture_osi,
    layers_for_host,
    next_layer_propositions,
    tag_events,
)
from guardia.cerveau.directives_passi_cnil import emit_directives, schedule_within_budget
from guardia.cerveau import raisonner
from guardia.engines.preuve_repro import attach_repro, ensure_realisable_repro


class Version128(unittest.TestCase):
    def test_version(self) -> None:
        self.assertEqual(__version__, "1.2.9")


class OsiMap(unittest.TestCase):
    def test_host_layers_tls(self) -> None:
        h = Host(ip="10.0.0.1", mac="AA:BB:CC:DD:EE:FF")
        h.ports = [{"port": 443, "name": "https", "product": "nginx"}]
        layers = layers_for_host(h, iface="eth0", gateway="10.0.0.254", cidr="10.0.0.0/24")
        self.assertIn("L1", layers)
        self.assertIn("L2", layers)
        self.assertIn("L3", layers)
        self.assertIn("L4", layers)
        self.assertIn("L6", layers)
        self.assertIn("L7", layers)

    def test_attach_and_couverture(self) -> None:
        h = Host(ip="10.0.0.2")
        h.ports = [{"port": 445, "name": "microsoft-ds"}]
        attach_host_osi([h], cidr="10.0.0.0/24")
        self.assertTrue(h.osi_layers)
        cov = couverture_osi([h], cidr="10.0.0.0/24")
        self.assertIn("L4", cov["couches_touchees"])
        self.assertIn("Couches touchées", cov["resume"])

    def test_next_props(self) -> None:
        ev = tag_events(
            [
                {"type": "tls_seen", "asset": "10.0.0.1", "port": 443},
                {"type": "smb_seen", "asset": "10.0.0.2", "port": 445},
            ]
        )
        props = next_layer_propositions(ev)
        ids = {p["id"] for p in props}
        self.assertIn("next-tls-web", ids)
        self.assertIn("next-smb", ids)


class Directives(unittest.TestCase):
    def test_emit_passi_rgpd(self) -> None:
        m = Mission(
            client="X",
            mandat_nda_signes=True,
            cidr="192.0.2.0/24",
            operateur_signe=True,
            ton_rapport="vouvoiement",
        )
        m.extras = {
            "passi": True,
            "rgpd": True,
            "site_url": "https://pctamalou.fr",
            "equipe": "red",
        }
        h = Host(ip="192.0.2.10")
        h.ports = [{"port": 443, "name": "https"}]
        events = tag_events(
            [
                {"type": "port_open", "asset": h.ip, "port": 443},
                {"type": "tls_seen", "asset": h.ip, "port": 443},
                {"type": "url_mandatee", "asset": "https://pctamalou.fr", "port": 0},
            ]
        )
        dirs = emit_directives(
            m, hosts=[h], events=events, plan={"passi": True, "rgpd": True, "site_url": m.extras["site_url"]}, mandat_ok=True
        )
        dirs = schedule_within_budget(dirs)
        self.assertTrue(dirs)
        natures = {d.get("nature_action") for d in dirs}
        self.assertTrue(any("démonstration" in (n or "") for n in natures))
        # intrusion bundle blocked as exploitation
        intr = [d for d in dirs if d.get("id") == "passi-intrusion-read"]
        self.assertTrue(intr)
        self.assertEqual(intr[0]["status"], "blocked")
        self.assertIn("exploitation", (intr[0].get("nature_action") or "").lower())

    def test_cerveau_emits_osi_and_dirs(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.0.2.0/24", operateur_signe=True)
        m.extras = {"passi": True, "rgpd": True, "site_url": "https://pctamalou.fr"}
        h = Host(ip="192.0.2.10", hostname="web")
        h.ports = [{"port": 443, "name": "https"}]
        brain = raisonner(m, hosts=[h], plan={"passi": True, "rgpd": True, "site_url": "https://pctamalou.fr"})
        self.assertIn("osi_couverture", brain)
        self.assertTrue(brain["osi_couverture"].get("couches_touchees"))
        self.assertTrue(brain.get("directives_passi_cnil"))
        self.assertFalse(brain.get("passi_qualifie"))
        self.assertFalse(brain.get("certificat"))


class PreuveDemo(unittest.TestCase):
    def test_realisable_has_repro(self) -> None:
        f = Finding(
            id="audit-tls-weak",
            titre="TLS faible — exposition réalisable",
            pourquoi_nuit="Chiffrement faible observable",
            preuve="ssl-enum-ciphers",
            remede_etapes=["Renforcer la configuration TLS"],
            qui_peut="Admin système",
            priorite="cette_semaine",
            gravite=Gravite.HAUTE,
            hote="10.0.0.1",
        )
        ensure_realisable_repro(f, "10.0.0.1")
        self.assertTrue(f.preuve_repro)
        self.assertNotIn("metasploit", f.preuve_repro.lower())
        self.assertIn("démonstration", (f.interpretation or "").lower())

    def test_attach_repro_hosts(self) -> None:
        h = Host(ip="10.0.0.5")
        h.findings = [
            Finding(
                id="smb-open",
                titre="Partage SMB exposé",
                pourquoi_nuit="Accessible sans filtre",
                preuve="port 445",
                remede_etapes=["Restreindre"],
                qui_peut="Admin",
                priorite="tout_de_suite",
                gravite=Gravite.CRITIQUE,
            )
        ]
        info = attach_repro([h], vouvoiement=True)
        self.assertGreaterEqual(info["findings_avec_repro"], 1)
        self.assertTrue(h.findings[0].preuve_repro)
        self.assertIn("plage d'audit", h.findings[0].interpretation or "")


if __name__ == "__main__":
    unittest.main()


class GroqStub(unittest.TestCase):
    def test_stub_without_key(self) -> None:
        import os
        from guardia.engines.llm_groq_directives import available, interrogate

        os.environ.pop("GROQ_API_KEY", None)
        self.assertFalse(available())
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.0.2.0/24")
        m.extras = {"passi": True, "rgpd": True, "llm_groq": True}
        pack = interrogate(
            m,
            hosts=[],
            directives_locales=[{"id": "cnil-rgpd-signal", "status": "proposed", "outil": "rgpd_signal"}],
            plan={"llm_groq": True, "rgpd": True},
        )
        self.assertFalse(pack.get("ok"))
        self.assertIn("GROQ_API_KEY", pack.get("skipped") or "")
        self.assertIn("à valider", (pack.get("validation") or "").lower() + (pack.get("disclaimer") or "").lower())
        self.assertIn("fiche_explication_client", pack)
        self.assertIn("annexe_technicien", pack)
        self.assertIn("hypothese_realisabilite", pack["annexe_technicien"])
        self.assertEqual(pack.get("tone"), "technicien")
        blob = json.dumps(pack, ensure_ascii=False).lower()
        self.assertNotIn("metasploit", blob)
        self.assertNotIn("gsk_", blob)

    def test_sanitize_drops_exploit(self) -> None:
        from guardia.engines.llm_groq_directives import _sanitize_directives

        bad = _sanitize_directives(
            [{"id": "x", "why": "lance metasploit exploit", "status": "proposed"}]
        )
        self.assertEqual(bad, [])

    def test_system_prompt_forbids_exploits(self) -> None:
        from guardia.engines import llm_groq_directives as g

        low = g.SYSTEM_PROMPT.lower()
        self.assertIn("interdiction absolue", low)
        self.assertIn("metasploit", low)
        self.assertIn("annexe_technicien", low)
        self.assertIn("fiche_explication_client", low)
        self.assertIn("knock", low)
        self.assertIn("n'entre pas", low)
        self.assertIn("ceci permettrait", low)
        self.assertIn("pour vous protéger", low)
        self.assertNotIn("fournissez des exploits", low)
