"""Tests des modules complémentaires et de leur orchestration."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia.core.models import Host, Mission
from guardia.core.orchestrate import (
    want_machines,
    want_restructure,
    want_rgpd,
    want_site,
    want_usages,
)
from guardia.engines.rgpd_config import (
    config_is_blank,
    load_rgpd_config,
    normalize_config,
    patch_mission_yaml,
    raw_config_from_mission,
    summary_line,
)
from guardia.engines.rgpd_signal import (
    DISCLAIMER,
    STATUT_DECLARE,
    STATUT_NON_VU,
    build_rgpd_signalement,
)
from guardia.engines.restructure import build_restructure
from guardia.engines.web_audit import header_gaps, parse_trackers_and_cmp
from guardia.core.budget import RunBudget


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        machines=False,
        restructure=False,
        audit_full=False,
        usages=False,
        no_usages=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Orchestrate(unittest.TestCase):
    def test_foyer_n_allume_rien(self) -> None:
        m = Mission(type_structure="foyer", profil_moteur="maison")
        a = _args()
        self.assertIsNone(want_site(a, m))
        self.assertFalse(want_rgpd(a, m))
        self.assertFalse(want_restructure(a, m))
        self.assertFalse(want_machines(a, m))
        self.assertFalse(want_usages(a, m))

    def test_site_prerempli(self) -> None:
        m = Mission()
        a = _args(site="https://example.test")
        self.assertEqual(want_site(a, m), "https://example.test")

    def test_site_yaml(self) -> None:
        m = Mission.from_dict({"client": "X", "site_url": "https://example.test"})
        self.assertEqual(want_site(_args(), m), "https://example.test")

    def test_rgpd_audit_full_mais_no_rgpd_coupe(self) -> None:
        m = Mission.from_dict({"client": "X", "audit_full": True})
        self.assertTrue(want_rgpd(_args(), m))
        self.assertFalse(want_rgpd(_args(no_rgpd=True), m))

    def test_pme_restructure(self) -> None:
        m = Mission(type_structure="pme", profil_moteur="pme")
        self.assertTrue(want_restructure(_args(), m))

    def test_machines_equipement(self) -> None:
        m = Mission.from_dict(
            {"client": "Usine", "equipements_attendus": ["pc", "industriel"]}
        )
        self.assertFalse(want_machines(_args(), m))
        self.assertTrue(want_machines(_args(equipe="red", red_pass="eoh19311936"), m))


class RgpdPasUnCertificat(unittest.TestCase):
    def test_disclaimer(self) -> None:
        low = DISCLAIMER.lower()
        self.assertIn("signalement", low)
        self.assertIn("sur demande", low)
        self.assertIn("n'est pas un certificat", low)
        self.assertNotIn("vous êtes conforme", low)

    def test_rapport_jamais_certificat(self) -> None:
        m = Mission(client="T", profil_moteur="pme", type_structure="pme")
        rep = build_rgpd_signalement(m, website={})
        self.assertFalse(rep["certificat"])
        self.assertEqual(rep["nature"], "signalement_sur_demande")
        self.assertIn("n'est pas un certificat", rep["disclaimer"].lower())
        for it in rep["items"]:
            self.assertNotEqual(it["statut"].lower(), "conforme")
        self.assertTrue(rep["fiche_vide"])
        self.assertTrue(any(i["id"] == "rgpd-fiche-vide" for i in rep["items"]))


class RgpdFicheConfigurable(unittest.TestCase):
    def test_normalize_yes_true(self) -> None:
        c = normalize_config(
            {"registre_tenu": "yes", "dpo_designe": True, "inconnu_key": "x"}
        )
        self.assertEqual(c["registre_tenu"], "oui")
        self.assertEqual(c["dpo_designe"], "oui")
        self.assertNotIn("inconnu_key", c)

    def test_registre_tenu_oui_est_declare_pas_certificat(self) -> None:
        m = Mission.from_dict(
            {
                "client": "TPE Test",
                "profil_moteur": "pme",
                "type_structure": "pme",
                "rgpd_config": {
                    "registre_tenu": "oui",
                    "procedure_72h": "non",
                    "dpo_designe": "non",
                    "contact_droits": "privacy@test.example",
                    "durees_ecrites": "non",
                },
            }
        )
        cfg = load_rgpd_config(m)
        self.assertEqual(cfg["registre_tenu"], "oui")
        self.assertFalse(config_is_blank(raw_config_from_mission(m)))
        rep = build_rgpd_signalement(m, website={})
        self.assertFalse(rep["fiche_vide"])
        ids = {i["id"]: i for i in rep["items"]}
        self.assertEqual(ids["rgpd-registre"]["statut"], STATUT_DECLARE)
        self.assertEqual(ids["rgpd-72h"]["statut"], STATUT_NON_VU)
        self.assertEqual(ids["rgpd-durees"]["statut"], STATUT_NON_VU)
        self.assertGreaterEqual(rep["compteurs"]["declares"], 1)
        self.assertGreaterEqual(rep["compteurs"]["signales"], 1)
        self.assertNotIn("rgpd-fiche-vide", ids)
        for it in rep["items"]:
            self.assertNotEqual(it["statut"].lower(), "conforme")

    def test_ecole_infere_mineurs_mais_fiche_reste_vide(self) -> None:
        m = Mission.from_dict(
            {"client": "Ecole X", "profil_moteur": "ecole", "type_structure": "ecole"}
        )
        self.assertTrue(config_is_blank(raw_config_from_mission(m)))
        self.assertEqual(load_rgpd_config(m)["mineurs"], "oui")
        rep = build_rgpd_signalement(m, website={})
        self.assertTrue(rep["fiche_vide"])
        self.assertTrue(any(i["id"] == "rgpd-fiche-vide" for i in rep["items"]))
        self.assertTrue(any(i["id"] == "rgpd-mineurs" for i in rep["items"]))

    def test_patch_mission_yaml(self) -> None:
        raw = (
            "client: Lab\n"
            "profil_moteur: pme\n"
            "type_structure: pme\n"
            "rgpd: false\n"
        )
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "m.yaml"
            p.write_text(raw, encoding="utf-8")
            patch_mission_yaml(p, {"registre_tenu": "oui", "contact_droits": "a@b.c"})
            text = p.read_text(encoding="utf-8")
            self.assertIn("rgpd: true", text)
            self.assertIn("registre_tenu: oui", text)
            self.assertIn("a@b.c", text)
            self.assertNotIn("conforme", text.lower())
            self.assertIn("client: Lab", text)
            self.assertIn("profil_moteur: pme", text)


    def test_summary_line_vide(self) -> None:
        self.assertIn("vide", summary_line(normalize_config({})))

    def test_exemple_audit_yaml_charge_la_fiche(self) -> None:
        from guardia.cli import load_mission

        m = load_mission(ROOT / "missions" / "exemple-audit.yaml")
        cfg = load_rgpd_config(m)
        self.assertFalse(config_is_blank(raw_config_from_mission(m)))
        self.assertEqual(cfg["registre_tenu"], "oui")
        self.assertEqual(cfg["dpo_designe"], "non")
        self.assertIn("privacy@", cfg["contact_droits"])
        rep = build_rgpd_signalement(m, website={})
        self.assertFalse(rep["fiche_vide"])
        ids = {i["id"]: i for i in rep["items"]}
        self.assertEqual(ids["rgpd-registre"]["statut"], STATUT_DECLARE)
        self.assertNotEqual(ids["rgpd-registre"]["statut"].lower(), "conforme")


class WebParse(unittest.TestCase):
    def test_trackers_sans_cmp(self) -> None:
        html = '<script src="https://www.googletagmanager.com/gtag/js"></script>'
        s = parse_trackers_and_cmp(html)
        self.assertTrue(s["trackers"])
        self.assertFalse(s["cmp"])

    def test_cmp_et_mentions(self) -> None:
        html = (
            "tarteaucitron.init(); "
            '<a href="/mentions-legales">Mentions légales</a> '
            "délégué à la protection des données"
        )
        s = parse_trackers_and_cmp(html)
        self.assertTrue(s["cmp"])
        self.assertTrue(s["legal_link"])
        self.assertTrue(s["dpo_or_rights"])

    def test_header_gaps(self) -> None:
        gaps = header_gaps({"server": "nginx"})
        self.assertTrue(any("HSTS" in g or "Strict" in g for g in gaps))


class Restructure(unittest.TestCase):
    def test_vlan_iot(self) -> None:
        hosts = [
            Host(ip="192.168.1.10", kind="pc", ports=[{"port": 445}]),
            Host(ip="192.168.1.40", kind="camera", ports=[{"port": 554}]),
        ]
        m = Mission(profil_moteur="pme", ton_rapport="vouvoiement")
        out = build_restructure(hosts, m, gateway="192.168.1.1")
        ids = [c.id for c in out["chantiers"]]
        self.assertIn("restr-vlan-iot", ids)

    def test_datastore(self) -> None:
        hosts = [
            Host(
                ip="192.168.1.20",
                kind="pc",
                ports=[{"port": 3306, "name": "mysql"}],
            )
        ]
        m = Mission(profil_moteur="pme")
        out = build_restructure(hosts, m)
        ids = [c.id for c in out["chantiers"]]
        self.assertIn("restr-datastores", ids)


class BudgetMustRun(unittest.TestCase):
    def test_must_run_ne_saute_pas(self) -> None:
        b = RunBudget(limit_sec=0.0)
        ran = []
        with b.phase("rules", must_run=True):
            ran.append("rules")
        self.assertEqual(ran, ["rules"])
        self.assertNotIn("rules", b.skipped)

    def test_sans_must_run_saute(self) -> None:
        b = RunBudget(limit_sec=0.0)
        with b.phase("discover"):
            pass
        self.assertIn("discover", b.skipped)

    def test_llm_hors_budget_scan(self) -> None:
        b = RunBudget(limit_sec=0.0)
        ran = []
        with b.phase("llm", kind="post"):
            ran.append("llm")
        self.assertEqual(ran, ["llm"])
        self.assertNotIn("llm", b.skipped)
        self.assertEqual(b.elapsed_scan(), 0.0)


class HtmlRgpd(unittest.TestCase):
    def test_rapport_contient_le_mot_signalement_pas_certificat_ok(self) -> None:
        from guardia.core.models import CheckupResult
        from guardia.report.html_report import _build

        m = Mission(client="Lab", profil_moteur="pme", type_structure="pme")
        rgpd = build_rgpd_signalement(m, website={"url": "https://example.test", "signals": {}})
        result = CheckupResult(mission=m, hosts=[], rgpd=rgpd)
        html = _build(result)
        self.assertIn("Signalement RGPD", html)
        self.assertIn("Pas un certificat", html)
        self.assertNotIn("certificat de conformité délivré", html.lower())
        self.assertIn("Fiche non configurée", html)

    def test_rapport_fiche_declaree(self) -> None:
        from guardia.core.models import CheckupResult
        from guardia.report.html_report import _build

        m = Mission.from_dict(
            {
                "client": "Lab",
                "profil_moteur": "pme",
                "type_structure": "pme",
                "rgpd_config": {"registre_tenu": "oui", "contact_droits": "p@x.fr"},
            }
        )
        rgpd = build_rgpd_signalement(m, website={})
        html = _build(CheckupResult(mission=m, hosts=[], rgpd=rgpd))
        self.assertIn("déclaré(s) — pas un certificat", html)
        self.assertIn("Fiche déclarée", html)
        self.assertIn("p@x.fr", html)
        self.assertIn(STATUT_DECLARE, html)
        self.assertNotIn("Fiche non configurée", html)


if __name__ == "__main__":
    unittest.main()
