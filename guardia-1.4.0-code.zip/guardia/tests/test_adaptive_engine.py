"""Tests du cerveau adaptatif, de la policy et du graphe."""
from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.cerveau import CAPACITES, autoriser, contexte, raisonner, reprendre
from guardia.cerveau.policy import CAP_BY_ID
from guardia.engines.services import PRIORITY_PORTS, _port_args


def _host(ip: str, ports: list[int], kind: str = "pc") -> Host:
    h = Host(ip=ip, hostname=ip, kind=kind)
    h.ports = [{"port": p, "name": "tcp"} for p in ports]
    return h


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertTrue(__version__.startswith("1."))


class Policy(unittest.TestCase):
    def test_avenant_bloque(self) -> None:
        ctx = contexte(Mission(mandat_nda_signes=True, cidr="192.168.1.0/24"))
        for cid in ("zap_active", "metasploit", "bloodhound", "ffuf", "impacket"):
            d = autoriser(cid, ctx)
            self.assertFalse(d["ok"], cid)
            self.assertEqual(d["etat"], "bloque_policy", cid)

    def test_lecture_sans_mandat(self) -> None:
        ctx = contexte(Mission(mandat_nda_signes=False))
        d = autoriser("nmap_discover", ctx)
        self.assertFalse(d["ok"])

    def test_nuclei_sans_url(self) -> None:
        ctx = contexte(Mission(mandat_nda_signes=True, cidr="192.168.1.0/24"))
        d = autoriser("nuclei_web", ctx)
        self.assertFalse(d["ok"])
        self.assertIn("URL", d["why"])


class Dag(unittest.TestCase):
    def test_prune_sans_smb(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.168.1.0/24", operateur_signe=True)
        h = _host("192.168.1.10", [443], "pc")
        brain = raisonner(m, hosts=[h], equipe="blue")
        etats = {d["cap"]: d["etat"] for d in brain["decisions"]}
        self.assertEqual(etats.get("smb_read"), "prune")
        self.assertEqual(etats.get("tls_assessment"), "ouvre")
        self.assertIn(etats.get("zap_active"), ("bloque_policy", "refuse"))

    def test_admin_ouvre_porte(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.168.1.0/24")
        h = _host("192.168.1.193", [8443], "nas")
        brain = raisonner(m, hosts=[h])
        types = {e["type"] for e in brain["evenements"]}
        self.assertIn("exposed_admin_service", types)
        self.assertTrue(any(p.get("kind") == "approfondir" for p in brain["portes"]))

    def test_pas_simulateur(self) -> None:
        brain = raisonner(Mission(mandat_nda_signes=True, cidr="10.0.0.0/24"))
        blob = (brain.get("nature") or "").lower()
        self.assertIn("pas un simulateur passi", blob)
        self.assertFalse(brain["passi_qualifie"])
        self.assertFalse(brain["certificat"])

    def test_reprendre_saute_deja(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.168.1.0/24")
        h = _host("192.168.1.10", [443])
        first = raisonner(m, hosts=[h])
        second = reprendre(m, hosts=[h], checkpoint={"nodes_done": first["nodes_done"]})
        self.assertGreaterEqual(second["n_repris"], 1)

    def test_evidence_hash(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.168.1.0/24")
        h = _host("192.168.1.10", [443])
        h.findings.append(
            Finding(
                id="tls-weak",
                titre="TLS faible",
                pourquoi_nuit="écoute possible",
                preuve="TLS 1.0",
                remede_etapes=["désactiver TLS 1.0"],
                qui_peut="IT",
                priorite="cette_semaine",
                gravite=Gravite.HAUTE,
                hote="192.168.1.10",
                commande="nmap -p 443 --script ssl-enum-ciphers 192.168.1.10",
            )
        )
        brain = raisonner(m, hosts=[h])
        self.assertTrue(brain["evidence"])
        self.assertTrue(brain["evidence"][0]["sha256"])

    def test_chemin_hypothese(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.168.1.0/24")
        h = _host("192.168.1.193", [8443], "nas")
        brain = raisonner(m, hosts=[h])
        self.assertTrue(brain["chemins"])
        self.assertTrue(brain["chemins"][0]["hypothese"])
        self.assertFalse(brain["chemins"][0]["exploitation"])

    def test_coeur_15_dans_capacites(self) -> None:
        ids = {c["id"] for c in CAPACITES}
        self.assertIn("zap_active", ids)
        self.assertIn("metasploit", ids)
        self.assertTrue(CAP_BY_ID["gvm_read"].get("note"))


class ServicesAdaptatif(unittest.TestCase):
    def test_plus_de_65535(self) -> None:
        args, label = _port_args("standard", False)
        blob = " ".join(args) + label
        self.assertNotIn("65535", blob)
        self.assertNotIn("-p-", args)
        self.assertTrue(PRIORITY_PORTS)

    def test_all_ports_pas_plein_tcp(self) -> None:
        args, label = _port_args("full", True)
        blob = " ".join(args) + label
        self.assertNotIn("-p-", args)
        self.assertNotIn("65535", blob)


if __name__ == "__main__":
    unittest.main()
