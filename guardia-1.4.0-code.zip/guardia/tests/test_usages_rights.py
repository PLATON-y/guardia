"""Tests usages, droits et portes de lecture."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import CheckupResult, Gravite, Host, Mission
from guardia.core.orchestrate import want_usages
from guardia.engines.classify import classify_host
from guardia.engines.parc_roles import detect_serveurs_parc
from guardia.engines.usages import (
    DISCLAIMER,
    build_usages,
    parse_smb_shares,
    disk_shares,
)
from guardia.engines.usages_config import (
    config_is_blank,
    load_usages_config,
    normalize_config,
    patch_mission_yaml,
    raw_config_from_mission,
)
from guardia.report.direction import build_direction_brief
from guardia.report.html_report import _build


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        machines=False,
        restructure=False,
        audit_full=False,
        usages=False,
        no_usages=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class OrchestrateUsages(unittest.TestCase):
    def test_ecole_auto(self) -> None:
        m = Mission(type_structure="ecole", profil_moteur="ecole")
        self.assertTrue(want_usages(_args(), m))
        self.assertFalse(want_usages(_args(no_usages=True), m))

    def test_foyer_off(self) -> None:
        m = Mission(type_structure="foyer", profil_moteur="maison")
        self.assertFalse(want_usages(_args(), m))

    def test_pme_sur_demande(self) -> None:
        m = Mission(type_structure="pme", profil_moteur="pme")
        self.assertFalse(want_usages(_args(), m))
        self.assertTrue(want_usages(_args(usages=True), m))


class Desserte(unittest.TestCase):
    def test_annuaire_est_serveur_parc(self) -> None:
        dc = Host(
            ip="10.0.0.10",
            hostname="srv-ad01",
            kind="pc",
            ports=[{"port": 88}, {"port": 389}, {"port": 445}],
        )
        pc = Host(ip="10.0.0.20", kind="pc", ports=[{"port": 445}])
        classify_host(dc)
        self.assertEqual(dc.kind, "serveur")
        found = detect_serveurs_parc([dc, pc] + [
            Host(ip=f"10.0.0.{i}", kind="pc", ports=[]) for i in range(30, 36)
        ])
        ips = [s["ip"] for s in found]
        self.assertIn("10.0.0.10", ips)
        self.assertNotIn("10.0.0.20", ips)
        self.assertIn("annuaire", found[0]["roles"])

    def test_un_smb_parmi_beaucoup_de_pc(self) -> None:
        nas = Host(ip="10.0.0.5", hostname="files", kind="nas", ports=[{"port": 445}])
        pcs = [Host(ip=f"10.0.0.{i}", kind="pc", ports=[]) for i in range(20, 28)]
        found = detect_serveurs_parc([nas] + pcs)
        self.assertTrue(any(s["ip"] == "10.0.0.5" for s in found))


class PortesSmb(unittest.TestCase):
    def test_parse_nmap_enum_shares(self) -> None:
        out = (
            "account_used: guest\n"
            "\\\\10.0.0.5\\IPC$:\n"
            "  Type: STYPE_IPC_HIDDEN\n"
            "\\\\10.0.0.5\\Documents:\n"
            "  Type: STYPE_DISKTREE\n"
            "\\\\10.0.0.5\\C$:\n"
            "  Type: STYPE_DISKTREE\n"
        )
        names = parse_smb_shares(out)
        self.assertIn("Documents", names)
        self.assertIn("C$", names)
        disks = disk_shares(names)
        self.assertIn("Documents", disks)
        self.assertNotIn("IPC$", [d.upper() if d.lower()=="ipc$" else d for d in disks] or disks)


class UsagesChapitre(unittest.TestCase):
    def test_disclaimer_pas_dump(self) -> None:
        low = DISCLAIMER.lower()
        self.assertIn("porte", low)
        self.assertNotIn("dump d'élèves", DISCLAIMER.lower())
        self.assertIn("n'entre pas", low)

    def test_jamais_conforme(self) -> None:
        m = Mission(client="Ecole X", profil_moteur="ecole", type_structure="ecole")
        rep = build_usages(m, [])
        self.assertFalse(rep["certificat"])
        for it in rep["items"]:
            self.assertNotEqual(it["statut"].lower(), "conforme")

    def test_partage_disque_signale(self) -> None:
        h = Host(
            ip="10.0.0.5",
            kind="nas",
            ports=[
                {
                    "port": 445,
                    "scripts": {
                        "smb-enum-shares": (
                            "account_used: guest\n"
                            "\\\\10.0.0.5\\Notes:\n"
                            "  Type: STYPE_DISKTREE\n"
                        )
                    },
                }
            ],
        )
        m = Mission.from_dict(
            {
                "client": "Ecole X",
                "profil_moteur": "ecole",
                "type_structure": "ecole",
                "usages_config": {"users_admin_local": "oui", "vlan_separes": "non"},
            }
        )
        self.assertFalse(config_is_blank(raw_config_from_mission(m)))
        rep = build_usages(m, [h], pass_done=True)
        ids = {i["id"]: i for i in rep["items"]}
        self.assertEqual(ids["usages-partages"]["statut"], "non observé — signalé")
        fids = [f.id for f in rep["findings"]]
        self.assertIn("usages-partage-disque", fids)
        self.assertTrue(any("nmap" in (f.preuve_repro or "") for f in rep["findings"]))

    def test_admin_local_oui_signale(self) -> None:
        m = Mission.from_dict(
            {
                "client": "Ecole X",
                "profil_moteur": "ecole",
                "usages_config": {"users_admin_local": "oui"},
            }
        )
        rep = build_usages(m, [])
        item = next(i for i in rep["items"] if i["id"] == "usages-admin-local")
        self.assertEqual(item["statut"], "non observé — signalé")

    def test_patch_yaml(self) -> None:
        raw = "client: Lab\nprofil_moteur: ecole\nusages: false\n"
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "m.yaml"
            p.write_text(raw, encoding="utf-8")
            patch_mission_yaml(p, {"vlan_separes": "non", "serveur_central": "oui"})
            text = p.read_text(encoding="utf-8")
            self.assertIn("usages: true", text)
            self.assertIn("vlan_separes: non", text)
            self.assertNotIn("conforme", text.lower())


class DirectionEtHtml(unittest.TestCase):
    def test_these_ecole(self) -> None:
        m = Mission(client="Ecole X", profil_moteur="ecole", type_structure="ecole")
        rgpd = {}
        usages = build_usages(m, [])
        result = CheckupResult(mission=m, hosts=[], usages=usages)
        brief = build_direction_brief(result)
        self.assertIn("session", brief["these"].lower())
        self.assertIn("ESS", brief["ess"])
        html = _build(result)
        self.assertIn("Pour la direction", html)
        self.assertIn("Usages", html)
        self.assertIn("l'ESS", html.replace("&", "&"))
        self.assertIn("pas un dump", DISCLAIMER.lower())

    def test_normalize_tri(self) -> None:
        c = normalize_config({"users_admin_local": "yes", "vlan_separes": False})
        self.assertEqual(c["users_admin_local"], "oui")
        self.assertEqual(c["vlan_separes"], "non")


if __name__ == "__main__":
    unittest.main()
