"""Guardia 1.0 — produit : YAML imbriqué, policy, prune, pas un simulateur."""
from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Host, Mission
from guardia.core.mission_yaml import flatten
from guardia.cli import load_mission
from guardia.cerveau import autoriser, contexte, raisonner
from guardia.cerveau.policy import CAPACITES


class Produit(unittest.TestCase):
    def test_version(self) -> None:
        self.assertTrue(__version__.startswith("1."))

    def test_yaml_imbrique(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-standard.yaml")
        self.assertEqual(m.cidr, "192.168.1.0/24")
        self.assertEqual(m.client, "Structure exemple")
        self.assertTrue(m.mandat_nda_signes)
        self.assertEqual(m.extras.get("site_url"), "https://example.test")
        auth = m.extras.get("authorization") or {}
        self.assertFalse(auth.get("exploitation"))
        self.assertTrue(auth.get("web_readonly"))

    def test_flatten_plat_inchange(self) -> None:
        raw = {"client": "A", "cidr": "10.0.0.0/24", "mandat_nda_signes": True}
        self.assertEqual(flatten(raw)["client"], "A")

    def test_exploitation_jamais_auto(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-standard.yaml")
        ctx = contexte(m, equipe="red")
        self.assertFalse(ctx.get("exploitation"))
        for cid in ("zap_active", "metasploit", "bloodhound", "ffuf", "impacket"):
            d = autoriser(cid, ctx)
            self.assertFalse(d["ok"], cid)

    def test_prune_smb_sans_445(self) -> None:
        m = Mission(client="X", mandat_nda_signes=True, cidr="192.168.1.0/24")
        h = Host(ip="192.168.1.10", hostname="pc", kind="pc")
        h.ports = [{"port": 443, "name": "https"}]
        brain = raisonner(m, hosts=[h])
        etats = {d["cap"]: d["etat"] for d in brain["decisions"]}
        self.assertEqual(etats.get("smb_read"), "prune")
        self.assertEqual(etats.get("tls_assessment"), "ouvre")
        self.assertFalse(brain["passi_qualifie"])

    def test_capacites_yaml(self) -> None:
        text = (ROOT / "modeles" / "capacites.yaml").read_text(encoding="utf-8")
        self.assertIn("tls_assessment", text)
        self.assertIn("metasploit", text)
        self.assertIn("avenant: true", text)
        self.assertIn("human_approval: true", text)
        self.assertGreaterEqual(len(CAPACITES), 10)

    def test_readme_describes_product_not_history(self) -> None:
        readme = (ROOT / "README.md").read_text(encoding="utf-8").lower()
        for mot in ("auparavant", "ancienne version", "prochaine version", "todo historique"):
            self.assertNotIn(mot, readme)
        self.assertIn("ce que fait guardia", readme)
        self.assertIn("orchestration", readme)


if __name__ == "__main__":
    unittest.main()
