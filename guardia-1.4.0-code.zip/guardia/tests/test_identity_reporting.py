"""Tests d’identité opérateur et de traçabilité des rapports."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.identite import (
    STEALTH_FLAGS,
    VISAGE_DECOUVERT,
    assert_nmap_honnete,
    banniere_run,
    bloc_signature,
    identite_dict,
    operateur_a_signe,
    operateur_de,
    user_agent,
)
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission, Posture
from guardia.engines.web_audit import USER_AGENT
from guardia.report.html_report import _build, _finding_block
from guardia.report.recap import build_grandes_lignes, build_journal


class Identite(unittest.TestCase):
    def test_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")

    def test_user_agent(self) -> None:
        ua = user_agent()
        self.assertIn("Guardia/", ua)
        self.assertIn("Echoes of Hackers", ua)
        self.assertIn("operateur identifie", ua.lower())
        self.assertEqual(USER_AGENT, ua)

    def test_operateur_yaml(self) -> None:
        m = Mission.from_dict(
            {
                "client": "U",
                "operateur_nom": "Platon-Y",
                "operateur_signe": True,
            }
        )
        self.assertEqual(operateur_de(m), "Platon-Y")
        self.assertTrue(operateur_a_signe(m))

    def test_operateur_defaut(self) -> None:
        m = Mission(client="X")
        self.assertEqual(operateur_de(m), "Platon-Y")
        self.assertFalse(operateur_a_signe(m))

    def test_nmap_refuse_decoy(self) -> None:
        with self.assertRaises(ValueError) as ctx:
            assert_nmap_honnete(["nmap", "-sV", "-D", "RND:10", "192.168.1.0/24"])
        self.assertIn("furtif", str(ctx.exception).lower())
        for flag in ("--spoof-mac", "-sI", "-f"):
            self.assertIn(flag, STEALTH_FLAGS)
        assert_nmap_honnete(["nmap", "-sn", "-PR", "-T4", "192.168.1.0/24"])

    def test_banniere(self) -> None:
        m = Mission(client="Atelier", cidr="192.168.10.0/24", operateur_signe=True)
        text = banniere_run(m, "192.168.10.0/24")
        self.assertIn("opérateur identifié", text)
        self.assertIn("Atelier", text)
        self.assertIn("W882005217", text)

    def test_identite_dict(self) -> None:
        info = identite_dict()
        self.assertEqual(info["rna"], "W882005217")
        self.assertIn("opérateur identifié", info["visage_decouvert"].lower())


class RapportVisage(unittest.TestCase):
    def _result(self) -> CheckupResult:
        m = Mission(
            client="Atelier Martin",
            personne_commune="Antoine Morel",
            profil_moteur="pme",
            mandat_nda_signes=True,
            operateur_nom="Platon-Y",
            operateur_signe=True,
            cidr="192.168.10.0/24",
        )
        h = Host(ip="192.168.10.41", hostname="accueil", kind="pc", posture=Posture.RISQUE)
        h.findings.append(
            Finding(
                id="rdp-plat",
                titre="Bureau à distance ouvert sur le LAN",
                pourquoi_nuit="On peut prendre la main sur un écran.",
                preuve="nmap -sV -p 3389 192.168.10.41",
                remede_etapes=[
                    "Couper RDP sur ce poste ou le cantonner au VLAN admin.",
                    "Compte à privilège + MFA si le prestataire doit passer.",
                ],
                qui_peut="prestataire / dirigeant",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote="192.168.10.41",
            )
        )
        return CheckupResult(mission=m, hosts=[h], cidr="192.168.10.0/24")

    def test_recap_visage(self) -> None:
        recap = build_grandes_lignes(self._result())
        self.assertIn("opérateur", recap.get("visage_decouvert", "").lower())
        self.assertEqual(recap.get("operateur"), "Platon-Y")
        sig = recap.get("signature") or {}
        self.assertEqual(sig.get("rna"), "W882005217")
        self.assertTrue(sig.get("operateur_signe"))

    def test_html_comment_faire_et_signatures(self) -> None:
        html = _build(self._result())
        self.assertIn("Comment faire", html)
        self.assertIn("Opérateur identifié", html)
        self.assertIn("W882005217", html)
        self.assertIn("signatures-rapport", html)
        self.assertIn("Antoine Morel", html)
        # l'ancien libellé « Remède : » a disparu du finding
        block = _finding_block(self._result().hosts[0].findings[0])
        self.assertIn("Comment faire", block)
        self.assertNotIn("<strong>Remède :</strong>", block)

    def test_journal_ua(self) -> None:
        j = build_journal(self._result())
        self.assertIn("opérateur", (j.get("visage_decouvert") or "").lower())
        self.assertIn("Guardia/", j.get("user_agent") or "")

    def test_bloc_signature(self) -> None:
        m = Mission(client="U", personne_commune="Dirigeant", operateur_signe=True)
        b = bloc_signature(m)
        self.assertEqual(b["habilite"], "Dirigeant")
        self.assertEqual(b["association"], "Echoes of Hackers")


class VisageConstante(unittest.TestCase):
    def test_phrase(self) -> None:
        self.assertIn("Opérateur identifié", VISAGE_DECOUVERT)
        self.assertNotIn("On ne se cache pas", VISAGE_DECOUVERT)


if __name__ == "__main__":
    unittest.main()
