"""Guardia 1.1 — appui PASSI v2.2 : aptitude, cadrage, cinq activités, couverture."""
from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.cli import load_mission
from guardia.engines.passi import JAMAIS_LANCER, orchestrer
from guardia.passi import (
    ACTIVITES,
    CONTROLES,
    PIPELINE,
    POSITION,
    construire_dossier,
    qualifier_aptitude,
)
from guardia.passi.evaluations import evaluer_code, evaluer_configuration


class Version(unittest.TestCase):
    def test_11(self) -> None:
        self.assertTrue(__version__.startswith("1."))


class Activites(unittest.TestCase):
    def test_cinq_natives(self) -> None:
        ids = [a["id"] for a in ACTIVITES]
        self.assertEqual(ids, ["ARCHI", "CONF", "CODE", "INTRUSION", "ORGAPHY"])
        self.assertFalse(next(a for a in ACTIVITES if a["id"] == "CODE")["moteur"])
        self.assertFalse(next(a for a in ACTIVITES if a["id"] == "INTRUSION")["moteur"])

    def test_controles_relies(self) -> None:
        acts = {c["activite"] for c in CONTROLES}
        self.assertEqual(acts, {"ARCHI", "CONF", "CODE", "INTRUSION", "ORGAPHY"})

    def test_pipeline(self) -> None:
        self.assertEqual(PIPELINE[0], "mandat")
        self.assertIn("aptitude_prealable", PIPELINE)
        self.assertEqual(PIPELINE[-1], "rapport")


class Aptitude(unittest.TestCase):
    def test_aucune_sans_mandat(self) -> None:
        m = Mission(client="X")
        apt = qualifier_aptitude(m, autorisations={}, equipe="blue")
        self.assertEqual(apt["verdict"], "aucune")
        self.assertFalse(apt["passi_qualifie"])
        self.assertFalse(apt["certificat"])

    def test_partielle_avec_reserve(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-passi.yaml")
        apt = qualifier_aptitude(
            m,
            autorisations={"complet": True},
            equipe="red",
            outils_etat=[{"nom": "nmap", "present": True}, {"nom": "lynis", "present": False}],
        )
        self.assertIn(apt["verdict"], ("partielle", "complete"))
        self.assertFalse(apt["passi_qualifie"])
        self.assertIn("qualification", apt["etape"])

    def test_pas_une_qualification(self) -> None:
        self.assertNotIn("qualifié PASSI", POSITION.lower().replace("é", "e"))
        self.assertIn("accompagner", POSITION.lower())


class CadrageEtDossier(unittest.TestCase):
    def test_yaml_passi(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-passi.yaml")
        self.assertEqual(m.cidr, "192.168.10.0/24")
        self.assertEqual((m.extras.get("profile") or {}).get("id"), "passi_complet")
        self.assertEqual((m.extras.get("qualification") or {}).get("niveau"), "substantiel")

    def test_dossier_vivant(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-passi.yaml")
        d = construire_dossier(m, autorisations={"complet": True}, equipe="red")
        self.assertFalse(d["passi_qualifie"])
        self.assertTrue(d["cadrage"]["vivante"])
        ids = d["activites_demandees"]
        self.assertEqual(set(ids), {"ARCHI", "CONF", "CODE", "INTRUSION", "ORGAPHY"})
        self.assertIn("globale", d["couverture"])
        self.assertIn("a_valider", d["cockpit"]["alertes"])

    def test_non_verifiable_pas_conforme(self) -> None:
        m = Mission(client="X", cidr="10.0.0.0/24", mandat_nda_signes=True)
        conf = evaluer_configuration(m, hosts=[])
        self.assertEqual(conf["counts"]["conformes"], 0)
        self.assertGreater(conf["counts"]["non_verifiables"], 0)
        self.assertIn("≠", conf["regle"])

    def test_code_pas_sast(self) -> None:
        m = Mission(client="X")
        code = evaluer_code(m)
        self.assertFalse(code["sast_egale_passi"])
        self.assertIn("revue_humaine", code["pipeline"])
        self.assertTrue(all(c["resultat"] == "non_applicable" for c in code["controles"]))

    def test_avenant_jamais_auto(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-passi.yaml")
        d = construire_dossier(m, autorisations={"complet": True}, equipe="red", execute=True)
        intr = d["evaluations"]["intrusion"]
        self.assertTrue(intr["approval_required"])
        self.assertIn("metasploit-framework", intr["avenant"])
        pt004 = next(c for c in intr["controles"] if c["id"] == "PT-004")
        self.assertEqual(pt004["resultat"], "non_autorise")
        for nom in ("metasploit-framework", "zaproxy", "bloodhound", "ffuf"):
            self.assertIn(nom, JAMAIS_LANCER)


class Orchestre(unittest.TestCase):
    def test_orchestrer_attache_v22(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-passi.yaml")
        o = orchestrer(m, autorisations={"complet": True}, equipe="red")
        self.assertFalse(o["passi_qualifie"])
        self.assertIn("aptitude_prealable", o)
        self.assertEqual(len(o.get("matrice") or []), len(o["matrice"]))
        self.assertGreater(len(o["matrice"]), 10)
        self.assertIn("ARCHI", o["activites_demandees"] if "activites_demandees" in o else [a["id"] for a in o["activites"]])

    def test_finding_conf_ecart(self) -> None:
        m = Mission(client="X", cidr="10.0.0.0/24", extras={"site_url": "https://example.test"})
        h = Host(ip="10.0.0.8", hostname="web", kind="serveur")
        h.ports = [{"port": 443, "name": "https"}]
        h.findings = [
            Finding(
                id="tls-faible",
                titre="TLS obsolète",
                pourquoi_nuit="crypto",
                preuve="testssl",
                remede_etapes=["monter TLS"],
                qui_peut="admin",
                priorite="cette_semaine",
                gravite=Gravite.HAUTE,
            )
        ]
        conf = evaluer_configuration(m, hosts=[h])
        crypto = next(c for c in conf["controles"] if c["id"] == "CFG-CRYPTO-001")
        self.assertEqual(crypto["resultat"], "ecart")


class Docs(unittest.TestCase):
    def test_readme_position(self) -> None:
        text = (ROOT / "README.md").read_text(encoding="utf-8").lower()
        self.assertIn("passi v2.2", text)
        self.assertNotIn("demande de qualification", text)
        for mot in ("auparavant", "ancienne version", "prochaine version"):
            self.assertNotIn(mot, text)


if __name__ == "__main__":
    unittest.main()
