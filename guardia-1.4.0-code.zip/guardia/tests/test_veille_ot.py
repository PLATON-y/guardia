"""Tests de veille, structures OT et lecture seule."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import CheckupResult, Host, Mission
from guardia.engines.pistes import CATALOGUE, coerce_piste, catalogue_effectif, build_pistes


def _mission(**kw) -> Mission:
    extras_in = dict(kw.pop("extras", None) or {})
    extras_in.setdefault("taille_parc", "grande")
    m = Mission.from_dict(
        {
            "client": "U",
            "cidr": "192.168.1.0/24",
            "profil_moteur": "pme",
            "type_structure": "pme",
            **kw,
        }
    )
    m.extras = {**dict(m.extras or {}), **extras_in}
    return m


class Veille(unittest.TestCase):
    def test_coerce_refuse_exploit(self) -> None:
        self.assertIsNone(
            coerce_piste(
                {
                    "id": "veille-bad",
                    "titre": "Non",
                    "commande": "msfconsole -x exploit",
                }
            )
        )

    def test_coerce_ok(self) -> None:
        e = coerce_piste(
            {
                "id": "veille-bacnet-gtb",
                "titre": "GTB BACnet",
                "pourquoi": "LAN plat",
                "structures": ["industrie", "pme"],
                "tailles": ["grande"],
                "ports_any": [47808],
                "commande": "nmap -sU -p 47808 {ip}",
                "hors": "Pas d'écriture.",
            }
        )
        self.assertIsNotNone(e)
        assert e is not None
        self.assertEqual(e["id"], "veille-bacnet-gtb")
        self.assertEqual(e["_source"], "veille")
        self.assertIn(47808, e["ports_any"])

    def test_catalogue_interne_intact(self) -> None:
        ids = {c["id"] for c in CATALOGUE}
        self.assertIn("ot-it-plat", ids)
        self.assertIn("desserte-annuaire", ids)

    def test_load_json_et_merge_mission(self) -> None:
        extra = [
            {
                "id": "veille-sip-ipbx",
                "titre": "IPBX SIP sur le LAN",
                "structures": ["pme"],
                "tailles": ["grande"],
                "ports_any": [5060],
                "commande": "nmap -sV -p 5060 {ip}",
                "hors": "Pas de REGISTER.",
            }
        ]
        cat = catalogue_effectif(extra)
        ids = [c["id"] for c in cat]
        self.assertIn("veille-sip-ipbx", ids)
        self.assertIn("ot-it-plat", ids)

    def test_build_pistes_prend_la_veille(self) -> None:
        m = _mission()
        extras = dict(m.extras or {})
        extras["pistes_extra"] = [
            {
                "id": "veille-onvif",
                "titre": "Caméras ONVIF",
                "structures": ["pme"],
                "tailles": ["grande"],
                "ports_any": [80, 554],
                "commande": "nmap -sV -p 80,554 {ip}",
                "hors": "Pas de brute caméra.",
            }
        ]
        m = _mission(extras=extras)
        host = Host(ip="192.168.1.10", hostname="nvr", kind="serveur")
        host.ports = [{"port": 554, "name": "rtsp"}]
        result = CheckupResult(mission=m, hosts=[host])
        block = build_pistes(result)
        ids = [i["id"] for i in block["items"]]
        self.assertIn("veille-onvif", ids)
        self.assertGreaterEqual(block["compteurs"].get("veille", 0), 1)
        item = next(i for i in block["items"] if i["id"] == "veille-onvif")
        self.assertEqual(item["source"], "veille")
        self.assertIn("554", item["indices"])

    def test_industrie_matche_pme(self) -> None:
        m = _mission(type_structure="industrie", profil_moteur="pme")
        host = Host(ip="192.168.10.5", hostname="ihm", kind="ot")
        host.ports = [{"port": 4840, "name": "opcua"}]
        result = CheckupResult(mission=m, hosts=[host])
        block = build_pistes(result)
        ids = [i["id"] for i in block["items"]]
        self.assertIn("ot-it-plat", ids)

    def test_fac_matche_ecole(self) -> None:
        m = Mission.from_dict(
            {
                "client": "U",
                "profil_moteur": "ecole",
                "type_structure": "fac",
            }
        )
        m.extras = {**dict(m.extras or {}), "taille_parc": "moyenne"}
        result = CheckupResult(mission=m, hosts=[])
        block = build_pistes(result)
        ids = [i["id"] for i in block["items"]]
        self.assertEqual(block["structure"], "ecole")
        self.assertIn("comptes-salles", ids)

    def test_veille_catalogue_present(self) -> None:
        p = ROOT / "modeles" / "veille-pistes.yaml"
        self.assertTrue(p.is_file())
        text = p.read_text(encoding="utf-8")
        self.assertIn("pistes:", text)
        self.assertIn("lecture seule", text.lower())

    def test_plus_de_finding_can(self) -> None:
        from guardia.engines.machines import OT_LABEL, apply_machine_rules

        joined = " ".join(OT_LABEL.values()).lower()
        self.assertNotIn("can bus", joined)
        self.assertIn("profinet", joined)
        m = Mission.from_dict({"client": "U"})
        findings = apply_machine_rules([], m)
        ids = [f.id.lower() for f in findings]
        self.assertFalse(any("can" in i and "scan" not in i for i in ids))


if __name__ == "__main__":
    unittest.main()
