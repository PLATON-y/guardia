"""Test extrême : inventaire CIDR / ports / AS / commandes / LLM intact."""
from pathlib import Path
import hashlib
import ipaddress

from guardia.core import cidr, ports, as_fr, commands

ROOT = Path(__file__).resolve().parents[1]
LLM = ROOT / "guardia" / "engines" / "llm_groq_directives.py"


def test_llm_file_exists_untouched_marker():
    """Le fichier LLM doit exister ; on ne le modifie pas dans ce lot."""
    assert LLM.is_file()
    text = LLM.read_text(encoding="utf-8", errors="replace")
    assert "GROQ" in text or "queen" in text.lower()
    # empreinte informative seulement (pas de gel imposé pour l'instant)
    h = hashlib.sha256(LLM.read_bytes()).hexdigest()
    assert len(h) == 64


def test_every_known_cidr_parses():
    for c in cidr.ALL_KNOWN:
        net = ipaddress.ip_network(c, strict=False)
        assert net.num_addresses >= 1


def test_classify_matrix():
    samples = {
        "10.0.0.1": "private",
        "192.168.1.1": "private",
        "172.16.0.1": "private",
        "100.64.1.1": "cgnat",
        "127.0.0.1": "loopback",
        "169.254.1.1": "link_local",
        "224.0.0.251": "multicast",
        "192.0.2.1": "documentation",
        "192.168.56.10": "virtualization",
        "1.1.1.1": "public",
    }
    for ip, want in samples.items():
        assert cidr.classify(ip) == want, (ip, cidr.classify(ip), want)


def test_ports_cover_web_remote_db_ot():
    for cat in ("web", "remote", "database", "ot", "vpn"):
        assert ports.by_category(cat)


def test_commands_format_placeholders():
    for c in commands.COMMANDS:
        assert "{cidr}" in c["cmd"] or "{host}" in c["cmd"] or "{url}" in c["cmd"] or "{iface}" in c["cmd"] or "ss " in c["cmd"] or "lsof" in c["cmd"] or "ufw" in c["cmd"] or "iptables" in c["cmd"] or "ip -" in c["cmd"] or "arp-scan" in c["cmd"]


def test_as_lookup_roundtrip():
    for asn in list(as_fr.FAI_FR)[:3]:
        assert as_fr.lookup_asn(asn)["french_isp"]
