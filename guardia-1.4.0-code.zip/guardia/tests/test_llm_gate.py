from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.engines.llm_gate import candidate_urls, exiger, garde_locale, ligne, probe
from guardia.engines.llm_polish import BUNDLED_MODEL, resolve_model


class LlmGate(unittest.TestCase):
    def test_probe_without_server_is_absent(self) -> None:
        st = probe("http://127.0.0.1:9")
        self.assertFalse(st["ok"])
        self.assertEqual(st["mode"], "absent")

    def test_garde_message_when_no_gguf(self) -> None:
        st = exiger(url="http://127.0.0.1:9", allow_garde=True, start=False)
        self.assertEqual(st["mode"], "garde")
        self.assertIn("garde locale", ligne(st).lower())

    def test_exiger_without_garde_stays_absent(self) -> None:
        st = exiger(url="http://127.0.0.1:9", allow_garde=False, start=False)
        self.assertFalse(st["ok"])

    def test_candidates_include_operator_port(self) -> None:
        urls = candidate_urls()
        self.assertIn("http://127.0.0.1:2443", urls)
        self.assertIn("http://127.0.0.1:18111", urls)
        self.assertEqual(urls[0], "http://127.0.0.1:2443")

    def test_explicit_url_comes_first(self) -> None:
        urls = candidate_urls("http://127.0.0.1:9999")
        self.assertEqual(urls[0], "http://127.0.0.1:9999")

    def test_garde_does_not_invent_finding(self) -> None:
        out = garde_locale(
            {
                "id": "F-1",
                "titre": "TLS 1.0",
                "preuve": "testssl: TLS1_0",
                "pourquoi_nuit": "Protocole obsolète.",
                "remede_etapes": ["Désactiver TLS 1.0"],
                "gravite": "haute",
            }
        )
        self.assertIn("TLS", out["titre"])
        self.assertIn("testssl", out["pourquoi_nuit"])
        self.assertEqual(out["mode"], "garde-locale")

    def test_bundled_gguf_present(self) -> None:
        self.assertTrue(BUNDLED_MODEL.is_file())
        self.assertGreater(BUNDLED_MODEL.stat().st_size, 10_000_000)
        found = resolve_model(None)
        self.assertIsNotNone(found)
        self.assertTrue(str(found).endswith(".gguf"))


if __name__ == "__main__":
    unittest.main()
