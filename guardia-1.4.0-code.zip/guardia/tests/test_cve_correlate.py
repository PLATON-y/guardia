"""Corrélation CVE catalogue local — sans réseau."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import Gravite, Host, Mission
from guardia.engines.cve_correlate import (
    correlate_hosts,
    derive_flags,
    load_catalog,
    want_cve,
)
from guardia.engines.osi_map import (
    next_layer_propositions_full,
    surfaces_non_protegees,
    vision_osi_full,
)


class CveCorrelate(unittest.TestCase):
    def test_catalog_loads(self) -> None:
        entries = load_catalog()
        self.assertGreaterEqual(len(entries), 15)
        ids = {e["id"] for e in entries}
        self.assertIn("smb-v1", ids)
        self.assertIn("telnet-clair", ids)
        self.assertIn("tls-1-0", ids)

    def test_smb_v1_match(self) -> None:
        h = Host(
            ip="192.168.1.20",
            ports=[
                {
                    "port": 445,
                    "name": "microsoft-ds",
                    "product": "Samba",
                    "version": "4.9.0",
                    "scripts": {
                        "smb-security-mode": "SMBv1: True\nMessage signing enabled but not required"
                    },
                }
            ],
        )
        self.assertIn("smb_v1", derive_flags(h))
        m = Mission(client="T", ton_rapport="vouvoiement")
        r = correlate_hosts([h], m)
        self.assertGreaterEqual(r["n_findings"], 1)
        ids = [f.id for f in h.findings if f.id.startswith("cve-")]
        self.assertTrue(any("smb-v1" in i for i in ids))
        f = next(f for f in h.findings if "smb-v1" in f.id)
        self.assertEqual(f.gravite, Gravite.HAUTE)
        self.assertIn("Ceci permettrait", f.interpretation)
        self.assertIn("Pour vous protéger", f.interpretation)
        self.assertIn("Aucune exploitation", f.interpretation)

    def test_telnet_match(self) -> None:
        h = Host(
            ip="192.168.1.30",
            kind="iot",
            ports=[{"port": 23, "name": "telnet", "product": "", "version": ""}],
        )
        m = Mission(client="T", ton_rapport="vouvoiement")
        correlate_hosts([h], m)
        self.assertTrue(any("telnet" in f.id for f in h.findings))
        f = next(f for f in h.findings if "telnet" in f.id)
        self.assertEqual(f.gravite, Gravite.CRITIQUE)

    def test_old_tls_match(self) -> None:
        h = Host(
            ip="192.168.1.40",
            ports=[
                {
                    "port": 443,
                    "name": "https",
                    "product": "nginx",
                    "version": "1.18.0",
                    "scripts": {
                        "ssl-enum-ciphers": "TLSv1.0\n  ciphers:\nTLSv1.1\n  ciphers:\n"
                    },
                }
            ],
        )
        flags = derive_flags(h)
        self.assertIn("tls_1_0", flags)
        self.assertIn("tls_1_1", flags)
        m = Mission(client="T", ton_rapport="vouvoiement")
        correlate_hosts([h], m)
        ids = [f.id for f in h.findings]
        self.assertTrue(any("tls-1-0" in i for i in ids))
        self.assertTrue(any("tls-1-1" in i for i in ids))

    def test_want_cve_full_and_no(self) -> None:
        from argparse import Namespace

        m = Mission(profondeur="full")
        a = Namespace(
            no_cve=False, cve=False, audit=False, audit_full=False, passi=False, full=True
        )
        self.assertTrue(want_cve(a, m))
        a2 = Namespace(
            no_cve=True, cve=True, audit=True, audit_full=True, passi=True, full=True
        )
        self.assertFalse(want_cve(a2, m))

    def test_osi_surfaces_and_vision(self) -> None:
        h = Host(
            ip="10.0.0.8",
            ports=[
                {"port": 23, "name": "telnet"},
                {
                    "port": 445,
                    "name": "microsoft-ds",
                    "scripts": {"smb-security-mode": "SMBv1: True"},
                },
            ],
        )
        surf = surfaces_non_protegees([h])
        self.assertGreaterEqual(len(surf), 1)
        props = next_layer_propositions_full([h], [])
        self.assertTrue(any("cve" in p["id"] for p in props))
        vision = vision_osi_full([h], iface="eth0", cidr="10.0.0.0/24", mode_full=True)
        self.assertIn("L1", vision["couches_touchees"] or vision["couverture"]["couches_touchees"])
        self.assertTrue(vision["mode_full"])
        self.assertIn("lecture", vision["disclaimer"].lower())


if __name__ == "__main__":
    unittest.main()
