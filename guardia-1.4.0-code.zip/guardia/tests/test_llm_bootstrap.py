from __future__ import annotations

import os
import tempfile
import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.engines import llm_bootstrap as boot


class LlmBootstrap(unittest.TestCase):
    def test_default_path_ends_with_gguf(self) -> None:
        p = boot.default_gguf_path()
        self.assertTrue(str(p).endswith("cybersec-assistant-3b-Q4_K_M.gguf"))
        self.assertEqual(p.name, boot.GGUF_NAME)

    def test_url_constant_and_env_override(self) -> None:
        self.assertIn("huggingface.co", boot.GUARDIA_GGUF_URL)
        self.assertIn("cybersec-assistant-3b-Q4_K_M.gguf", boot.GUARDIA_GGUF_URL)
        old = os.environ.get("GUARDIA_GGUF_URL")
        try:
            os.environ["GUARDIA_GGUF_URL"] = "https://example.test/model.gguf"
            self.assertEqual(boot.gguf_url(), "https://example.test/model.gguf")
        finally:
            if old is None:
                os.environ.pop("GUARDIA_GGUF_URL", None)
            else:
                os.environ["GUARDIA_GGUF_URL"] = old

    def test_ensure_noninteractive_skips_download(self) -> None:
        # Force missing + non-interactive: must not download.
        old_model = os.environ.get("GUARDIA_LLM_MODEL")
        old_note = os.environ.get("GUARDIA_LLM_NOTE")
        try:
            os.environ["GUARDIA_LLM_MODEL"] = "/tmp/guardia-missing-nope.gguf"
            os.environ.pop("GUARDIA_LLM_NOTE", None)
            got = boot.ensure_gguf(interactive=False, ui=False)
            self.assertIsNone(got)
            self.assertTrue(os.environ.get("GUARDIA_LLM_NOTE"))
        finally:
            if old_model is None:
                os.environ.pop("GUARDIA_LLM_MODEL", None)
            else:
                os.environ["GUARDIA_LLM_MODEL"] = old_model
            if old_note is None:
                os.environ.pop("GUARDIA_LLM_NOTE", None)
            else:
                os.environ["GUARDIA_LLM_NOTE"] = old_note

    def test_install_existing_symlink_or_copy(self) -> None:
        with tempfile.TemporaryDirectory() as td:
            src = Path(td) / "fake.gguf"
            # > MIN would be huge; install_existing only checks .gguf + is_file
            src.write_bytes(b"GGUF-fake-content-" + b"x" * 100)
            dest = Path(td) / "models" / boot.GGUF_NAME
            dest.parent.mkdir(parents=True)
            out = boot.install_existing(src, dest=dest)
            self.assertTrue(out.exists() or out.is_symlink())
            self.assertEqual(out.resolve(), src.resolve() if out.is_symlink() else out.resolve())


if __name__ == "__main__":
    unittest.main()
