"""Tests catalogue commandes lecture seule."""
from guardia.core.commands import COMMANDS, assert_no_offensive, by_name, safe_only

def test_all_safe():
    assert COMMANDS
    assert all(c.get("safe") for c in COMMANDS)
    assert len(safe_only()) == len(COMMANDS)

def test_no_offensive():
    assert_no_offensive()

def test_nmap_present():
    assert by_name("nmap_discover")
    assert by_name("ssh_keyscan")
