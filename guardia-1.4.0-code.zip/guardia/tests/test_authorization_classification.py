"""Tests autorisations, classification et lexique."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.autorisation import (
    ETAT_ATTESTATION,
    ETAT_NON,
    ETAT_VALIDEE,
    etat,
    limiter_plan,
    phrase_signature,
)
from guardia.core.cadre import PROGRAMME
from guardia.core.identite import VISAGE_DECOUVERT, banniere_run, user_agent
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission, Posture
from guardia.engines.correlation import build_correlation
from guardia.engines.greenbone import etat as gvm_etat
from guardia.engines.lynis import etat as lynis_etat
from guardia.engines.preuve_repro import attach_chaine
from guardia.engines.programme import CATALOGUE, Outil, get_outil
from guardia.report.html_report import _build, _finding_block
from guardia.report.json_report import payload_from_result
from guardia.report.lexique import build_lexique
from guardia.report.recap import build_grandes_lignes, compter_gravites


def _tls_result(*, mandat: bool = True, op: bool = True) -> CheckupResult:
    m = Mission(
        client="Atelier Martin",
        personne_commune="Antoine Morel",
        profil_moteur="pme",
        mandat_nda_signes=mandat,
        operateur_nom="Platon-Y",
        operateur_signe=op,
        cidr="192.168.1.0/24",
    )
    h = Host(ip="192.168.1.254", hostname="box", kind="box", posture=Posture.OK)
    h.findings.append(
        Finding(
            id="audit-tls-weak",
            titre="Suites TLS faibles repérées",
            pourquoi_nuit="La robustesse cryptographique peut être inférieure aux recommandations.",
            preuve="nmap --script ssl-enum-ciphers -p 443 192.168.1.254",
            remede_etapes=["Désactiver les suites obsolètes.", "Retester avec testssl.sh."],
            qui_peut="prestataire / box",
            priorite="cette_semaine",
            gravite=Gravite.MOYENNE,
            hote="192.168.1.254",
        )
    )
    r = CheckupResult(mission=m, hosts=[h], cidr="192.168.1.0/24")
    attach_chaine(h.findings[0], h.ip)
    return r


class Version(unittest.TestCase):
    def test_062(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class Vocabulaire(unittest.TestCase):
    def test_pas_passif(self) -> None:
        self.assertNotIn("checkup passif", PROGRAMME.lower())
        self.assertIn("non intrusive", PROGRAMME.lower())

    def test_pas_enfantin(self) -> None:
        self.assertNotIn("On ne se cache pas", VISAGE_DECOUVERT)
        self.assertIn("Opérateur identifié", VISAGE_DECOUVERT)
        self.assertIn("operateur identifie", user_agent().lower())
        text = banniere_run(Mission(client="U", operateur_signe=True), "192.168.1.0/24")
        self.assertNotIn("ne se cache pas", text.lower())
        self.assertIn("opérateur identifié", text.lower())


class Autorisation(unittest.TestCase):
    def test_non_validee(self) -> None:
        a = etat(Mission(mandat_nda_signes=False))
        self.assertEqual(a["etat"], ETAT_NON)
        self.assertFalse(a["peut_evaluer"])
        self.assertTrue(a["modules_limites"])
        self.assertFalse(a["double_signature"])
        self.assertNotIn("signé des deux côtés", phrase_signature(a).lower())

    def test_attestation(self) -> None:
        m = Mission(mandat_nda_signes=False)
        a = etat(m, SimpleNamespace(yes=True))
        self.assertEqual(a["etat"], ETAT_ATTESTATION)
        self.assertTrue(a["peut_evaluer"])
        self.assertTrue(a["modules_limites"])
        self.assertFalse(a["double_signature"])
        self.assertIn("attestation", phrase_signature(a).lower())
        self.assertNotIn("deux côtés", phrase_signature(a))

    def test_validee_double(self) -> None:
        m = Mission(mandat_nda_signes=True, operateur_signe=True)
        a = etat(m)
        self.assertEqual(a["etat"], ETAT_VALIDEE)
        self.assertTrue(a["double_signature"])
        self.assertFalse(a["modules_limites"])
        self.assertIn("paraphe", phrase_signature(a).lower())

    def test_limiter_plan(self) -> None:
        a = etat(Mission(), SimpleNamespace(yes=True))
        out = limiter_plan(
            {"machines": True, "audit_full": True, "equipe": "red", "lan": True},
            a,
        )
        self.assertFalse(out["machines"])
        self.assertFalse(out["audit_full"])
        self.assertEqual(out["equipe"], "blue")
        self.assertTrue(out["modules_limites"])


class Classification(unittest.TestCase):
    def test_tls_n_est_pas_zero_risque(self) -> None:
        r = _tls_result()
        gv = compter_gravites(r)
        self.assertEqual(gv["critique"], 0)
        self.assertEqual(gv["eleve"], 0)
        self.assertEqual(gv["moyen"], 1)
        recap = build_grandes_lignes(r)
        self.assertEqual(recap["chiffres"]["moyen"], 1)
        html = _build(r)
        self.assertIn("1 moyen", html)
        self.assertNotIn("0 à risque", html)
        self.assertIn("information", html.lower())

    def test_chaine(self) -> None:
        f = _tls_result().hosts[0].findings[0]
        self.assertTrue(f.observation)
        self.assertTrue(f.commande)
        self.assertTrue(f.interpretation)
        block = _finding_block(f)
        self.assertIn("Observation", block)
        self.assertIn("Commande", block)
        self.assertIn("Interprétation", block)

    def test_correlation_tls(self) -> None:
        r = _tls_result()
        c = build_correlation(r)
        self.assertTrue(c["items"])
        self.assertEqual(c["items"][0]["gravite"], "moyenne")
        self.assertIn("TLS", c["items"][0]["titre"])


class LexiqueEtJson(unittest.TestCase):
    def test_lexique(self) -> None:
        items = build_lexique("TLS RGPD ANSSI LAN CIDR")
        sigles = {x["sigle"] for x in items}
        for s in ("ANSSI", "PASSI", "RGPD", "TLS", "LAN", "NDA"):
            self.assertIn(s, sigles)

    def test_html_lexique_et_autorisation(self) -> None:
        html = _build(_tls_result(mandat=True, op=True))
        self.assertIn("id='lexique'", html)
        self.assertIn("id='autorisation'", html)
        self.assertIn("id='piliers'", html)
        self.assertNotIn("signé des deux côtés", html.lower())
        self.assertNotIn("ne se cache pas", html.lower())
        self.assertNotIn("checkup passif", html.lower())

    def test_json_cles(self) -> None:
        r = _tls_result()
        r.autorisation = etat(r.mission)
        r.correlation = build_correlation(r)
        r.lynis = lynis_etat()
        r.greenbone = gvm_etat()
        payload = payload_from_result(r)
        for k in ("autorisation", "correlation", "lynis", "greenbone", "recap", "journal"):
            self.assertIn(k, payload)
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "out.json"
            from guardia.report.json_report import dump_checkup

            ok, err = dump_checkup(r, p)
            self.assertTrue(ok, err)
            self.assertTrue(p.is_file())


class Outils(unittest.TestCase):
    def test_install_field(self) -> None:
        self.assertTrue(hasattr(Outil, "__dataclass_fields__"))
        self.assertIn("install", Outil.__dataclass_fields__)
        g = get_outil("greenbone")
        self.assertIsNotNone(g)
        self.assertIn("gvm", g.install)
        self.assertTrue(g.auto)
        l = get_outil("lynis")
        self.assertEqual(l.scope, "local")
        t = get_outil("trivy")
        self.assertIn("trivy", t.install)
        s = get_outil("snmpwalk")
        self.assertEqual(s.bins, ("snmpwalk",))

    def test_catalogue_a_les_piliers(self) -> None:
        ids = {o.id for o in CATALOGUE}
        for i in ("nmap", "testssl", "sslyze", "nuclei", "whatweb", "nikto", "arp-scan", "snmpwalk", "greenbone", "lynis", "trivy"):
            self.assertIn(i, ids)

    def test_gvm_orchestre(self) -> None:
        st = gvm_etat()
        self.assertTrue(st["orchestre"])
        self.assertIn("apt install gvm", st["install"])

    def test_lynis_pas_distant(self) -> None:
        st = lynis_etat()
        self.assertFalse(st["distant"])
        self.assertIn("apt install lynis", st["install"])


class HtmlSansMandat(unittest.TestCase):
    def test_pas_double_discours(self) -> None:
        r = _tls_result(mandat=False, op=False)
        html = _build(r)
        self.assertIn("NON VALIDÉE", html.upper() + html)
        self.assertNotIn("signé des deux côtés", html)
        self.assertNotIn("Signé des deux côtés", html)


if __name__ == "__main__":
    unittest.main()
