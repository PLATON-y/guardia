"""Tests AS / FAI FR."""
from guardia.core.as_fr import FAI_FR, lookup_asn, is_french_isp

def test_orange():
    assert is_french_isp(3215)
    info = lookup_asn(3215)
    assert info["known"] and "Orange" in info["name"]

def test_unknown():
    u = lookup_asn(1)
    assert not u["known"]

def test_fai_count():
    assert len(FAI_FR) >= 6
