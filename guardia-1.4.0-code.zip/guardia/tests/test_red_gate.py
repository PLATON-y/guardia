"""Porte Red Team — hash local, mapping defensif, attestation."""
from __future__ import annotations

import hashlib
import os
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

os.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    hashlib.sha256(b"eoh19311936").hexdigest(),
)

from guardia.core.red_gate import (
    RED_ACTIONS,
    apply_signed_actions,
    hash_password,
    parse_signed_actions,
    red_ok_attested,
    red_team_requested,
    verifier_red,
    write_password_hash,
)
from guardia.core.models import Mission
from guardia import __version__


class VersionBump(unittest.TestCase):
    def test_128(self) -> None:
        self.assertTrue(__version__.startswith("1.2.9"))


class HashLocal(unittest.TestCase):
    def test_unsalted_env(self) -> None:
        self.assertTrue(verifier_red("eoh19311936"))
        self.assertFalse(verifier_red("wrong"))

    def test_salted_file(self) -> None:
        with tempfile.TemporaryDirectory() as d:
            path = Path(d) / "red.pass"
            write_password_hash("secret-demo", path=path)
            raw = path.read_text(encoding="utf-8")
            stored = [ln for ln in raw.splitlines() if ln and not ln.startswith("#")][0]
            self.assertIn("$", stored)
            self.assertTrue(verifier_red("secret-demo", stored=stored))
            self.assertFalse(verifier_red("nope", stored=stored))


class SignedMapping(unittest.TestCase):
    def test_parse(self) -> None:
        self.assertEqual(
            parse_signed_actions("audit_full, rgpd, ot"),
            ["audit_full", "rgpd", "ot_lecture"],
        )

    def test_apply(self) -> None:
        args = SimpleNamespace(
            audit_full=False,
            audit=False,
            rgpd=False,
            passi=False,
            machines=False,
            all_ports=False,
            calibrage=False,
            site=None,
            red_team=True,
            red_ok=True,
            red_actions_signed="audit_full,rgpd",
        )
        m = Mission()
        m.extras = {}
        applied = apply_signed_actions(args, m, ["audit_full", "rgpd"])
        self.assertIn("audit_full", applied)
        self.assertTrue(args.audit_full)
        self.assertTrue(args.rgpd)
        self.assertTrue(m.extras.get("audit_full"))

    def test_attestation(self) -> None:
        args = SimpleNamespace(red_team=True, red_ok=False, red_actions_signed="")
        m = Mission()
        m.extras = {"red_team": True, "red_actions_signed": ["passi"]}
        self.assertTrue(red_team_requested(args, m))
        self.assertTrue(red_ok_attested(args, m))
        m2 = Mission()
        m2.extras = {"red_team": True}
        self.assertFalse(red_ok_attested(SimpleNamespace(red_team=True, red_ok=False), m2))

    def test_catalogue_defensif(self) -> None:
        for aid, meta in RED_ACTIONS.items():
            self.assertIn("label", meta)
            self.assertIn("maps_to", meta)
            # Pas de mots d'exploit dans le catalogue
            blob = (meta["label"] + meta.get("help", "")).lower()
            for bad in ("metasploit", "mimikatz", "cobalt", "eternalblue", "c2", "brute"):
                self.assertNotIn(bad, blob)


class DocsAndUi(unittest.TestCase):
    def test_doc_exists(self) -> None:
        self.assertTrue((ROOT / "docs" / "RED-TEAM-GATE.md").is_file())

    def test_ui_has_gate(self) -> None:
        src = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn("Actions avancées — autorisation explicite", src)
        self.assertIn("Mode Red Team (avancé)", src)
        self.assertIn("Document signé validé", src)
        self.assertIn("--red-team", src)

    def test_no_hash_in_equipe_source(self) -> None:
        src = (ROOT / "guardia" / "core" / "equipe.py").read_text(encoding="utf-8")
        self.assertNotIn("b621f2e57a455df6", src)
        self.assertNotIn("eoh19311936", src)


if __name__ == "__main__":
    unittest.main()
