"""Tests des exports et de l’interface utilisateur."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.cli import load_mission
from guardia.core.dossier import peut_red_regard, peut_red_test
from guardia.core.equipe import resoudre_equipe
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission
from guardia.core.parc import parc_de
from guardia.report.json_report import dump_checkup, jsonable, payload_from_result


YAML = ROOT / "missions" / "exemple-red.yaml"


def _mission() -> Mission:
    return load_mission(YAML)


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class YamlRed(unittest.TestCase):
    def test_fichier(self) -> None:
        self.assertTrue(YAML.is_file())
        raw = YAML.read_text(encoding="utf-8")
        self.assertNotIn("eoh19311936", raw)
        self.assertNotIn("GUARDIA_RED_PASS:", raw)
        self.assertIn("Structure Exemple Red", raw)
        self.assertIn("example.test", raw)
        self.assertIn("192.0.2.0/24", raw)

    def test_tout_allume(self) -> None:
        m = _mission()
        self.assertEqual(m.client, "Structure Exemple Red")
        self.assertEqual(m.cidr, "192.0.2.0/24")
        self.assertTrue(m.mandat_nda_signes)
        self.assertEqual(parc_de(m), "professionnel")
        self.assertEqual(str(m.extras.get("equipe")), "red")
        self.assertEqual(str(m.extras.get("site_url")), "https://example.test")
        for key in (
            "rgpd",
            "usages",
            "machines",
            "restructure",
            "pistes",
            "audit",
            "audit_full",
            "calibrage",
            "llm",
            "pdf",
            "all_ports",
        ):
            self.assertTrue(m.extras.get(key), msg=key)
        ok, why = peut_red_regard(m)
        self.assertFalse(ok)
        self.assertIn("incomplet", why.lower())
        closed, _ = peut_red_test(m)
        self.assertFalse(closed)

    def test_red_auto_avec_pass(self) -> None:
        m = _mission()
        args = SimpleNamespace(equipe=None, red_pass="eoh19311936")
        self.assertEqual(resoudre_equipe(args, m), "red")
        args2 = SimpleNamespace(equipe=None, red_pass="")
        self.assertEqual(resoudre_equipe(args2, m), "blue")


class JsonExport(unittest.TestCase):
    def test_calibrage_programme_recap(self) -> None:
        m = Mission(client="Structure Exemple Red", type_structure="foyer", mandat_nda_signes=True)
        h = Host(ip="192.168.1.10", kind="pc")
        f = Finding(
            id="cal-ldap-rootdse",
            titre="Annuaire",
            pourquoi_nuit="porte",
            preuve="389",
            remede_etapes=["Segmenter."],
            qui_peut="admin",
            priorite="cette_semaine",
            gravite=Gravite.HAUTE,
            hote="192.168.1.10",
        )
        r = CheckupResult(
            mission=m,
            hosts=[h],
            cidr="192.168.1.0/24",
            programme={"path": Path("/tmp/prog.json"), "outils": [{"nom": "nmap"}]},
            calibrage={"n_lances": 4, "findings": [f], "absents": []},
            timings={"elapsed_sec": 274.01, "limit_sec": 3600, "timings": {"programme": 163.66, "web": 108.69}},
        )
        payload = payload_from_result(r)
        for key in ("calibrage", "programme", "recap", "journal", "identite", "hosts"):
            self.assertIn(key, payload)
        self.assertEqual(payload["calibrage"]["n_lances"], 4)
        self.assertIsInstance(payload["calibrage"]["findings"][0], dict)
        self.assertEqual(payload["programme"]["path"], "/tmp/prog.json")
        self.assertTrue((payload.get("recap") or {}).get("titre"))
        dumped = json.dumps(payload, ensure_ascii=False)
        self.assertNotIn("eoh19311936", dumped)

    def test_ecriture_et_echec_silencieux(self) -> None:
        m = Mission(client="Foyer")
        r = CheckupResult(mission=m, programme={"n": 1}, calibrage={"n_lances": 0})
        with tempfile.TemporaryDirectory() as td:
            path = Path(td) / "out.json"
            ok, err = dump_checkup(r, path)
            self.assertTrue(ok, err)
            data = json.loads(path.read_text(encoding="utf-8"))
            self.assertIn("programme", data)
            self.assertIn("calibrage", data)
            self.assertIn("recap", data)

    def test_jsonable_path_finding(self) -> None:
        f = Finding(
            id="x",
            titre="t",
            pourquoi_nuit="p",
            preuve="1",
            remede_etapes=["a"],
            qui_peut="moi",
            priorite="plus_tard",
            gravite=Gravite.INFO,
        )
        out = jsonable({"p": Path("/tmp/a"), "f": f})
        self.assertEqual(out["p"], "/tmp/a")
        self.assertEqual(out["f"]["id"], "x")
        json.dumps(out)


class Molette(unittest.TestCase):
    def test_source(self) -> None:
        src = (ROOT / "guardia" / "ui" / "sang_scroll.py").read_text(encoding="utf-8")
        self.assertIn("def bind_mousewheel", src)
        self.assertIn("bind_class", src)
        self.assertIn("Button-4", src)
        self.assertIn("winfo_containing", src)
        self.assertIn("return -3", src)


class Gouttes(unittest.TestCase):
    def test_api(self) -> None:
        src = (ROOT / "guardia" / "ui" / "logo_gouttes.py").read_text(encoding="utf-8")
        self.assertIn("def explode", src)
        self.assertIn("def set_equipe", src)
        self.assertIn("ECLAIR_ROUGE", src)
        self.assertIn("#FF1A1A", src)
        self.assertIn("#8B0000", src)
        self.assertIn("#4FA3E0", src)
        self.assertIn("_kind_eclair", src)
        self.assertNotIn('if self._equipe != "blue"', src)
        self.assertNotIn("eoh19311936", src)
        self.assertIn("kick_x", src)


class UiRedPreset(unittest.TestCase):
    def test_preset_dans_app(self) -> None:
        src = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn("exemple-red.yaml", src)
        self.assertIn("_maybe_phase_explode", src)
        self.assertIn("bind_mousewheel", src)
        self.assertNotIn("eoh19311936", src)


if __name__ == "__main__":
    unittest.main()
