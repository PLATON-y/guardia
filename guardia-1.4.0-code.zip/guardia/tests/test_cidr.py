"""Tests plages CIDR Guardia."""
from guardia.core.cidr import (
    ALL_KNOWN,
    PRIVATE_V4_RFC1918,
    classify,
    is_private,
    iterate_hosts,
)


def test_rfc1918_present():
    for c in ("10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16"):
        assert c in PRIVATE_V4_RFC1918


def test_classify_samples():
    assert classify("192.168.1.10") == "private"
    assert classify("10.10.10.5") == "private"
    assert classify("127.0.0.1") == "loopback"
    assert classify("100.64.0.10") == "cgnat"
    assert classify("8.8.8.8") == "public"
    assert classify("not-an-ip") == "invalid"


def test_iterate_hosts():
    hs = list(iterate_hosts("192.168.1.0/30"))
    assert hs == ["192.168.1.1", "192.168.1.2"]


def test_all_known_nonempty():
    assert len(ALL_KNOWN) >= 30
    assert is_private("172.16.5.5")
