"""Tests du catalogue de capacités défensives."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import CheckupResult, Mission
from guardia.core.orchestrate import want_burp
from guardia.engines.programme import get_outil
from guardia.report.html_report import _build


class PlusDeManuel(unittest.TestCase):
    def test_want_burp_toujours_off(self) -> None:
        m = Mission(client="U", mandat_nda_signes=True)
        args = SimpleNamespace(burp=True, no_burp=False)
        self.assertFalse(want_burp(args, m))
        m2 = Mission.from_dict({"client": "U", "avenant_burp": True, "site_url": "https://x.fr"})
        self.assertFalse(want_burp(args, m2))

    def test_catalogue_sans_burp_zap(self) -> None:
        self.assertIsNone(get_outil("burp"))
        self.assertIsNone(get_outil("zap"))
        self.assertIsNotNone(get_outil("nmap"))
        self.assertIsNotNone(get_outil("nuclei"))

    def test_html_sans_burp_ni_yeswehack(self) -> None:
        m = Mission(client="Lab", mandat_nda_signes=True)
        html = _build(CheckupResult(mission=m, hosts=[]))
        self.assertNotIn("YesWeHack", html)
        self.assertNotIn("Burp Suite", html)
        self.assertNotIn("OWASP ZAP", html)
        self.assertNotIn("Hors moteur", html)


if __name__ == "__main__":
    unittest.main()
