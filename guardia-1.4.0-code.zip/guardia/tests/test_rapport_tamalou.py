"""Régressions vues sur le rapport tamalou 1.1.2 — Full ≠ PASSI, TLS honnête."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia.core.models import Host, Mission
from guardia.core.orchestrate import want_passi
from guardia.core.texte import has_weak_cipher, legacy_tls_offered, ssl_cert_expired, strip_ansi
from guardia.engines.calibrage import _parse
from guardia.engines.classify import classify_host
from guardia.rules.audit import apply_audit_rules


class TlsHonnête(unittest.TestCase):
    def test_compresseur_null_pas_une_suite_faible(self) -> None:
        blob = (
            "TLSv1.2:\n"
            "  ciphers:\n"
            "    TLS_ECDHE_RSA_WITH_AES_128_GCM_SHA256 (secp256r1) - A\n"
            "    TLS_ECDHE_RSA_WITH_CHACHA20_POLY1305_SHA256 (secp256r1) - A\n"
            "  compressors:\n"
            "    NULL\n"
        )
        self.assertFalse(has_weak_cipher(blob))
        h = Host(
            ip="192.168.1.254",
            hostname="bbox",
            ports=[{"port": 443, "scripts": {"ssl-enum-ciphers": blob}}],
        )
        apply_audit_rules([h], Mission(client="tamalou", mandat_nda_signes=True))
        self.assertFalse(any(f.id == "audit-tls-weak-ciphers" for f in h.findings))

    def test_rc4_toujours_flag(self) -> None:
        blob = "TLSv1.2:\n  ciphers:\n    TLS_RSA_WITH_RC4_128_SHA - C\n"
        self.assertTrue(has_weak_cipher(blob))

    def test_testssl_disabled_n_est_pas_offert(self) -> None:
        blob = (
            "SSL/TLS Protocols:\n"
            "SSLv2     disabled\n"
            "SSLv3     disabled\n"
            "TLSv1.0   disabled\n"
            "TLSv1.1   disabled\n"
            "TLSv1.2   enabled\n"
            "TLSv1.3   enabled\n"
        )
        self.assertFalse(legacy_tls_offered(blob))
        found = _parse("testssl", "192.168.1.254", blob)
        self.assertFalse(any(f.titre == "TLS trop ancien offert" for f in found))

    def test_tls10_enabled_flag(self) -> None:
        blob = "SSLv3     disabled\nTLSv1.0   enabled\nTLSv1.2   enabled\n"
        self.assertTrue(legacy_tls_offered(blob))


class Ansi(unittest.TestCase):
    def test_strip(self) -> None:
        raw = "Version: \x1b[32m2.1.5\x1b[0m\nOpenSSL"
        self.assertEqual(strip_ansi(raw), "Version: 2.1.5\nOpenSSL")
        from guardia.engines.calibrage import _finding
        from guardia.core.models import Gravite

        f = _finding("x", "t", "n", raw, ["a"], "1.1.1.1", Gravite.INFO)
        self.assertNotIn("\x1b", f.preuve)


class PixelBook(unittest.TestCase):
    def test_pas_un_telephone(self) -> None:
        h = Host(ip="192.168.1.120", hostname="pixel-book.lan")
        self.assertNotEqual(classify_host(h, gateway="192.168.1.254"), "phone")
        self.assertIn(h.kind, ("pc", "inconnu"))

    def test_pixel_phone_reste_phone(self) -> None:
        h = Host(ip="192.168.1.50", hostname="pixel-8")
        self.assertEqual(classify_host(h), "phone")

    def test_pixel_book_est_un_pc(self) -> None:
        h = Host(ip="192.168.1.120", hostname="pixel-book.lan")
        self.assertEqual(classify_host(h, gateway="192.168.1.254"), "pc")

    def test_bouygtel_est_une_tv(self) -> None:
        h = Host(
            ip="192.168.1.193",
            hostname="Bouygtel4K-272021441206361.lan",
            vendor="Ampak Technology",
            ports=[{"port": 8443, "name": "https-alt"}],
        )
        self.assertEqual(classify_host(h, gateway="192.168.1.254"), "tv")


class CertificatCast(unittest.TestCase):
    def test_not_valid_after_n_est_pas_expire(self) -> None:
        blob = (
            "Subject: commonName=-3378034229124875289/organizationName=Google Inc\n"
            "Issuer: commonName=Arcadyan TV HMB9213NW Marvell BG4-CT Cast ICA\n"
            "Not valid before: 2025-10-08T13:06:24\n"
            "Not valid after:  2045-10-08T13:06:24\n"
        )
        self.assertFalse(ssl_cert_expired(blob))
        h = Host(
            ip="192.168.1.193",
            hostname="Bouygtel4K.lan",
            ports=[{"port": 8443, "scripts": {"ssl-cert": blob}}],
        )
        apply_audit_rules([h], Mission(client="tamalou", mandat_nda_signes=True))
        self.assertFalse(any(f.id == "audit-tls-expired" for f in h.findings))

    def test_vraiment_expire(self) -> None:
        blob = "Not valid after:  2020-01-01T00:00:00\n"
        self.assertTrue(ssl_cert_expired(blob))


class AdminCast(unittest.TestCase):
    def test_8443_tv_pas_admin(self) -> None:
        from guardia.rules.universal import check_host

        tv = Host(ip="192.168.1.193", hostname="Bouygtel4K.lan", kind="tv",
                  ports=[{"port": 8443, "name": "https-alt"}])
        box = Host(ip="192.168.1.254", kind="box", ports=[{"port": 80}])
        m = Mission(client="tamalou", profil_moteur="maison", mandat_nda_signes=True)
        found = check_host(tv, m, [tv, box])
        self.assertFalse(any("8443" in (f.id or "") for f in found))

    def test_iphone_pas_iot_plat(self) -> None:
        from guardia.rules.universal import check_host

        phone = Host(ip="192.168.1.108", hostname="iPhone-001.lan", kind="phone")
        box = Host(ip="192.168.1.254", kind="box")
        m = Mission(client="tamalou", profil_moteur="maison", mandat_nda_signes=True)
        found = check_host(phone, m, [phone, box])
        self.assertFalse(any(f.id.startswith("flat-") for f in found))


class PassiExplicite(unittest.TestCase):
    def test_si_allume_il_reste_allume(self) -> None:
        class A:
            passi = True
            offre_passi = False
            audit_full = True
            equipe = "red"
            red_pass = "eoh19311936"

        m = Mission()
        m.extras["passi"] = True
        m.extras["audit_full"] = True
        self.assertTrue(want_passi(A(), m))

    def test_blue_ne_garde_pas_passi(self) -> None:
        class A:
            passi = True
            offre_passi = False
            audit_full = False
            equipe = "blue"
            red_pass = ""

        m = Mission()
        m.extras["passi"] = True
        self.assertFalse(want_passi(A(), m))


class LlmCerveau(unittest.TestCase):
    def test_rejette_hackers_dans_qui_peut(self) -> None:
        from guardia.core.models import Finding, Gravite
        from guardia.engines.llm_polish import _apply

        f = Finding(
            id="x",
            titre="Admin 8443",
            pourquoi_nuit="porte",
            preuve="p",
            remede_etapes=["Vérifie le service"],
            qui_peut="toi-même",
            priorite="cette_semaine",
            gravite=Gravite.MOYENNE,
        )
        _apply(
            {
                "titre": "Admin 8443",
                "pourquoi_nuit": "porte",
                "remede_etapes": ["Installer des firmwares de remplacement"],
                "qui_peut": "Toi-même, hackers réseau local",
            },
            f,
        )
        self.assertEqual(f.qui_peut, "toi-même")
        self.assertEqual(f.remede_etapes, ["Vérifie le service"])


class RapportSansPassiEteint(unittest.TestCase):
    def test_rapport_full_sans_chapitre_passi(self) -> None:
        from guardia.core.models import CheckupResult
        from guardia.report.html_report import _build

        r = CheckupResult(
            mission=Mission(client="tamalou", mandat_nda_signes=True, profondeur="full"),
            passi={"statut": "éteint — red team requis", "execute": False},
            passi_alignment={"summary": {"score_operational": 63}},
        )
        html = _build(r)
        self.assertNotIn('id="passi"', html)
        self.assertNotIn("Couverture PASSI", html)
        self.assertNotIn("63 %", html)


if __name__ == "__main__":
    unittest.main()
