"""Configure GUARDIA_RED_PASSWORD_HASH pour la suite de tests (hash nu, pas de clair produit)."""
from __future__ import annotations

import hashlib
import os

# Mot de passe historique des tests uniquement — le hash va dans l'env, pas dans le produit.
_TEST_RED = "eoh19311936"
os.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    hashlib.sha256(_TEST_RED.encode("utf-8")).hexdigest(),
)
