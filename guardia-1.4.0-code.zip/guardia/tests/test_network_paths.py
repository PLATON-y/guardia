"""Tests réseau, chemins d’exposition et contrôle défensif."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia.core.models import CheckupResult, Gravite, Host, Mission
from guardia.core.open_links import format_checkup, run_checkup, session_user
from guardia.core.orchestrate import want_machines, want_pistes
from guardia.engines.machines import OT_LABEL, apply_machine_rules
from guardia.engines.pistes import CATALOGUE, build_pistes


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        machines=False,
        restructure=False,
        audit_full=False,
        usages=False,
        no_usages=False,
        pistes=False,
        no_pistes=False,
        llm=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Liens(unittest.TestCase):
    def test_checkup_a_une_racine(self) -> None:
        rep = run_checkup(repair=True)
        self.assertTrue(rep["root"])
        self.assertGreaterEqual(rep["ok"], 3)
        text = format_checkup(rep)
        self.assertIn("missions", text.lower())
        self.assertIn("rapports", text.lower())
        sess = session_user()
        self.assertIn("euid", sess)

    def test_cli_liens_existe(self) -> None:
        from guardia.cli import build_parser

        p = build_parser()
        args = p.parse_args(["liens"])
        self.assertEqual(args.func.__name__, "cmd_liens")


class EthernetIndustrielPasCan(unittest.TestCase):
    def test_profinet_et_ethernetip_dans_le_sondage(self) -> None:
        self.assertIn(34962, OT_LABEL)
        self.assertIn(44818, OT_LABEL)
        self.assertIn(502, OT_LABEL)
        self.assertIn(102, OT_LABEL)
        joined = " ".join(OT_LABEL.values()).lower()
        self.assertIn("profinet", joined)
        self.assertIn("ethernet/ip", joined)
        self.assertNotIn("can bus", joined)

    def test_pas_de_finding_can(self) -> None:
        h = Host(ip="10.1.0.8", kind="ot", ports=[{"port": 502, "proto": "tcp"}])
        m = Mission(client="Usine", profil_moteur="pme", type_structure="pme")
        findings = apply_machine_rules([h], m)
        ids = [f.id for f in findings]
        self.assertFalse(any("can" in i for i in ids))
        self.assertTrue(any(i.startswith("ot-502-") for i in ids))
        self.assertEqual(findings[0].gravite, Gravite.HAUTE)

    def test_aucun_port_info_sans_can(self) -> None:
        h = Host(ip="10.1.0.9", kind="pc", ports=[{"port": 445}])
        m = Mission(client="Usine")
        findings = apply_machine_rules([h], m)
        ids = [f.id for f in findings]
        self.assertEqual(ids, ["ot-aucun-port-industriel"])
        self.assertNotIn("ot-can-hors-ip", ids)
        low = findings[0].pourquoi_nuit.lower()
        self.assertIn("ethernet", low)

    def test_equipement_profinet_allume(self) -> None:
        red = _args(equipe="red", red_pass="eoh19311936")
        m = Mission.from_dict({"client": "U", "equipements_attendus": ["profinet"]})
        self.assertTrue(want_machines(red, m))
        m2 = Mission.from_dict({"client": "U", "equipements_attendus": ["can"]})
        self.assertFalse(want_machines(red, m2))
        self.assertFalse(want_machines(_args(), m))


class PistesPasFindings(unittest.TestCase):
    def test_foyer_off_pme_on(self) -> None:
        blue = _args()
        red = _args(equipe="red", red_pass="eoh19311936")
        self.assertFalse(want_pistes(blue, Mission(profil_moteur="maison", type_structure="foyer")))
        self.assertFalse(want_pistes(blue, Mission(profil_moteur="pme", type_structure="pme")))
        self.assertTrue(want_pistes(red, Mission(profil_moteur="pme", type_structure="pme")))
        self.assertFalse(
            want_pistes(_args(equipe="red", red_pass="eoh19311936", no_pistes=True), Mission(profil_moteur="pme", type_structure="pme"))
        )

    def test_grande_annuaire_indices(self) -> None:
        dc = Host(
            ip="10.0.0.10",
            hostname="srv-ad",
            kind="serveur",
            ports=[{"port": 88}, {"port": 389}, {"port": 445}],
        )
        m = Mission.from_dict(
            {
                "client": "Org",
                "profil_moteur": "pme",
                "type_structure": "pme",
                "taille_parc": "grande",
            }
        )
        result = CheckupResult(mission=m, hosts=[dc], plan={"pistes": True})
        block = build_pistes(result)
        self.assertIn("PAS des findings", block["disclaimer"])
        ids = [i["id"] for i in block["items"]]
        self.assertIn("desserte-annuaire", ids)
        item = next(i for i in block["items"] if i["id"] == "desserte-annuaire")
        self.assertEqual(item["statut"], "indices sur le LAN")
        self.assertIn("nmap", item["commande"])
        self.assertNotIn("gravite", item)
        self.assertGreaterEqual(len(CATALOGUE), 12)

    def test_html_chapitre_pistes(self) -> None:
        from guardia.report.html_report import _build

        m = Mission(client="PME X", profil_moteur="pme", type_structure="pme")
        h = Host(ip="10.0.0.5", kind="nas", ports=[{"port": 445}])
        html = _build(CheckupResult(mission=m, hosts=[h], plan={"pistes": True}))
        self.assertIn("Pistes à explorer", html)
        self.assertIn("pas des findings", html.lower())
        self.assertNotIn("ot-can-hors-ip", html)
