"""Tests de posture et de représentation défensive."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.core.equipe import INDICE_RED, PALETTE, resoudre_equipe, verifier_red
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission
from guardia.engines.regard import build_regard
from guardia.report.html_report import _build


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class MotDePasse(unittest.TestCase):
    def test_hash_pas_le_clair_dans_equipe_py(self) -> None:
        src = (ROOT / "guardia" / "core" / "equipe.py").read_text(encoding="utf-8")
        self.assertNotIn("eoh19311936", src)
        self.assertIn("marmelade", INDICE_RED)

    def test_bon_mot(self) -> None:
        self.assertTrue(verifier_red("eoh19311936"))
        self.assertFalse(verifier_red(""))
        self.assertFalse(verifier_red("wrong"))

    def test_resoudre_sans_pass_reste_blue(self) -> None:
        args = SimpleNamespace(equipe="red", red_pass="")
        self.assertEqual(resoudre_equipe(args, Mission()), "blue")

    def test_resoudre_avec_pass(self) -> None:
        args = SimpleNamespace(equipe="red", red_pass="eoh19311936")
        self.assertEqual(resoudre_equipe(args, Mission()), "red")


class Palette(unittest.TestCase):
    def test_deux_equipes(self) -> None:
        self.assertIn("blue", PALETTE)
        self.assertIn("red", PALETTE)
        self.assertNotEqual(PALETTE["blue"]["accent"], PALETTE["red"]["accent"])


class Regard(unittest.TestCase):
    def test_chemins_et_attck(self) -> None:
        m = Mission(client="Lab", mandat_nda_signes=True)
        h = Host(ip="10.0.0.8", kind="pc")
        h.findings.append(
            Finding(
                id="audit-remote-3389",
                titre="RDP ouvert",
                pourquoi_nuit="Prise de poste",
                preuve="3389/tcp",
                remede_etapes=["Couper."],
                qui_peut="admin",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote="10.0.0.8",
            )
        )
        r = CheckupResult(mission=m, hosts=[h], equipe="red")
        block = build_regard(r)
        self.assertTrue(block["lecture_seule"])
        self.assertFalse(block["intrusion"])
        self.assertGreaterEqual(len(block["chemins"]), 1)
        self.assertTrue(any(a["id"].startswith("T") for a in block["attck"]))

    def test_html_red_sans_mot_de_passe(self) -> None:
        m = Mission(client="Lab", mandat_nda_signes=True)
        h = Host(ip="10.0.0.8", kind="serveur")
        h.findings.append(
            Finding(
                id="cal-smb-shares",
                titre="Partages visibles",
                pourquoi_nuit="Fichiers",
                preuve="445",
                remede_etapes=["Restreindre."],
                qui_peut="admin",
                priorite="cette_semaine",
                gravite=Gravite.HAUTE,
                hote="10.0.0.8",
            )
        )
        r = CheckupResult(mission=m, hosts=[h], equipe="red")
        r.regard = build_regard(r)
        html = _build(r)
        self.assertIn("Regard attaquant", html)
        self.assertNotIn("eoh19311936", html)
        self.assertNotIn("marmelade", html)
        self.assertIn("#9B1B1B", html.upper() + html)
        self.assertIn("#2a1010", html)

    def test_html_blue_sans_regard(self) -> None:
        m = Mission(client="Lab", mandat_nda_signes=True)
        html = _build(CheckupResult(mission=m, hosts=[], equipe="blue"))
        self.assertNotIn("Regard attaquant", html)
        self.assertIn("#1E4F8A", html.upper() + html)

    def test_gouttes_pas_recolorees(self) -> None:
        src = (ROOT / "guardia" / "ui" / "logo_gouttes.py").read_text(encoding="utf-8")
        self.assertIn("#8B0000", src)
        app = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn("logo uniquement", app.lower())
        self.assertIn("ne change jamais", app.lower())


if __name__ == "__main__":
    unittest.main()
