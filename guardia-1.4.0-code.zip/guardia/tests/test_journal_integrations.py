"""Tests journal et intégrations orchestrées."""
from __future__ import annotations

import io
import sys
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.cli import load_mission
from guardia.core.models import CheckupResult, Mission
from guardia.core.orchestrate import (
    JournalOrchestre,
    appliquer_yaml,
    brancher_calibrage,
    jouer,
    summarize_plan,
    want_greenbone,
    want_trivy,
)
from guardia.engines.greenbone import etat as gvm_etat, run as gvm_run
from guardia.engines.programme import get_outil
from guardia.engines.trivy import etat as trivy_etat
from guardia.report.html_report import _build
from guardia.report.json_report import payload_from_result


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        usages=False,
        no_usages=False,
        machines=False,
        pistes=False,
        no_pistes=False,
        llm=False,
        pdf=False,
        lynis=False,
        greenbone=False,
        trivy=False,
        audit=False,
        audit_full=False,
        full=False,
        all_ports=False,
        calibrage=False,
        no_calibrage=False,
        lan=False,
        no_lan=False,
        equipe="blue",
        restructure=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class YamlAllume(unittest.TestCase):
    def test_full_orchestre_greenbone_trivy(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-full.yaml")
        args = _args(equipe="red", red_pass="eoh19311936")
        appliquer_yaml(args, m)
        plan = summarize_plan(args, m)
        self.assertTrue(plan["greenbone"])
        self.assertTrue(plan["trivy"])
        self.assertTrue(plan["lynis"])
        self.assertTrue(args.greenbone)
        self.assertTrue(args.trivy)

    def test_red_example_aussi(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-red.yaml")
        plan = summarize_plan(_args(equipe="red", red_pass="eoh19311936"), m)
        self.assertTrue(plan["greenbone"])
        self.assertTrue(plan["trivy"])


class JournalJoue(unittest.TestCase):
    def test_jouer_ok_et_skip(self) -> None:
        j = JournalOrchestre()
        errors: list[str] = []
        buf = io.StringIO()
        with redirect_stdout(buf):
            out = jouer("nmap", lambda: 42, errors, journal=j, cible="192.168.1.0/24")
            none = jouer("boom", lambda: (_ for _ in ()).throw(RuntimeError("ko")), errors, journal=j)
        self.assertEqual(out, 42)
        self.assertIsNone(none)
        self.assertEqual(len(errors), 1)
        d = j.as_dict()
        self.assertGreaterEqual(d["joues"], 1)
        self.assertGreaterEqual(d["absents_ou_sautes"], 1)
        etats = {e.get("nom"): e.get("etat") for e in d["etapes"] if e.get("nom")}
        self.assertEqual(etats.get("nmap"), "ok")
        self.assertEqual(etats.get("boom"), "sauté")

    def test_brancher_calibrage(self) -> None:
        j = JournalOrchestre()
        on = brancher_calibrage(j)
        buf = io.StringIO()
        with redirect_stdout(buf):
            on({"nom": "curl -sI", "cible": "https://example.test", "etat": "ok"})
            on({"nom": "nuclei", "cible": "192.168.1.10", "etat": "absent"})
        noms = [e["nom"] for e in j.etapes]
        self.assertIn("curl -sI", noms)
        self.assertIn("nuclei", noms)


class GreenboneOrchestre(unittest.TestCase):
    def test_etat_orchestre(self) -> None:
        st = gvm_etat()
        self.assertTrue(st["orchestre"])

    def test_run_absent_continue(self) -> None:
        st = gvm_run()
        self.assertTrue(st["orchestre"])
        self.assertFalse(st["lance"] and not st["installe"])
        self.assertIn(st["etat"], ("absent", "present-down", "present-sans-cli", "ok", "present"))

    def test_want_greenbone_yaml(self) -> None:
        m = Mission()
        m.extras["greenbone"] = True
        self.assertTrue(want_greenbone(_args(equipe="red", red_pass="eoh19311936"), m))
        self.assertFalse(want_greenbone(_args(), m))

    def test_want_trivy_yaml(self) -> None:
        m = Mission()
        m.extras["trivy"] = True
        self.assertTrue(want_trivy(_args(equipe="red", red_pass="eoh19311936"), m))
        self.assertFalse(want_trivy(_args(), m))

    def test_trivy_orchestre(self) -> None:
        st = trivy_etat()
        self.assertTrue(st["orchestre"])
        self.assertFalse(st["distant"])

    def test_greenbone_auto_catalogue(self) -> None:
        o = get_outil("greenbone")
        self.assertTrue(o.auto)
        self.assertTrue(get_outil("lynis").auto)
        self.assertTrue(get_outil("trivy").auto)


class RapportOrchestre(unittest.TestCase):
    def test_html_orchestre(self) -> None:
        m = Mission(client="Lab", mandat_nda_signes=True)
        r = CheckupResult(
            mission=m,
            orchestre={
                "prevu": ["lan:allumé", "greenbone:allumé"],
                "n": 2,
                "joues": 1,
                "absents_ou_sautes": 1,
                "etapes": [
                    {"type": "outil", "nom": "nmap discover", "cible": "192.168.1.0/24", "etat": "ok"},
                    {"type": "skip", "nom": "gvm-cli", "etat": "sauté", "why": "absent"},
                ],
            },
            greenbone={"orchestre": True, "installe": False, "lance": False, "etat": "absent", "note": "absent"},
            trivy={"orchestre": True, "installe": False, "lance": False, "etat": "absent"},
        )
        html = _build(r)
        self.assertIn("id='orchestre'", html)
        self.assertIn("nmap discover", html)
        self.assertIn("gvm-cli", html)
        self.assertNotIn("Orchestré par Guardia : non", html)
        p = payload_from_result(r)
        self.assertEqual(p["orchestre"]["joues"], 1)
        self.assertIn("trivy", p)


if __name__ == "__main__":
    unittest.main()
