"""Tests du mode inspiré PASSI, des autorisations et des contrôles."""
from __future__ import annotations

import unittest
from pathlib import Path
from types import SimpleNamespace
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.core.models import Mission
from guardia.core.orchestrate import (
    CLES_ACTION,
    JournalOrchestre,
    appliquer_yaml,
    summarize_plan,
    want_autorisations,
    want_passi,
)
from guardia.engines.passi import (
    DISCLAIMER,
    JAMAIS_LANCER,
    build_offre,
    orchestrer,
)
from guardia.engines.autorisations import build_autorisations


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        usages=False,
        no_usages=False,
        machines=False,
        pistes=False,
        no_pistes=False,
        llm=False,
        pdf=False,
        lynis=False,
        greenbone=False,
        trivy=False,
        passi=False,
        autorisations=False,
        audit=False,
        audit_full=False,
        full=False,
        all_ports=False,
        calibrage=False,
        no_calibrage=False,
        lan=False,
        no_lan=False,
        equipe="blue",
        restructure=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Version(unittest.TestCase):
    def test_070(self) -> None:
        self.assertTrue(__version__.startswith("1."))


class OffrePassi(unittest.TestCase):
    def test_pas_une_qualification(self) -> None:
        o = build_offre(Mission(), autorisations={"complet": True}, equipe="red")
        self.assertFalse(o["passi_qualifie"])
        self.assertFalse(o["certificat"])
        self.assertTrue(o["presentable"])
        self.assertTrue(o["execute"])
        self.assertIn("non qualifié PASSI", o["disclaimer"])
        self.assertNotIn("demande", o["disclaimer"].lower())
        self.assertEqual(o["n_domaines"], 5)
        for nom in ("metasploit-framework", "hydra", "burpsuite", "mimikatz"):
            self.assertIn(nom, JAMAIS_LANCER)

    def test_brouillon_sans_liasse(self) -> None:
        o = build_offre(Mission(), autorisations={"complet": False}, equipe="red")
        self.assertFalse(o["presentable"])
        self.assertFalse(o["execute"])
        self.assertIn("non exécuté", o["statut"])

    def test_blue_eteint(self) -> None:
        o = build_offre(Mission(), autorisations={"complet": True}, equipe="blue")
        self.assertFalse(o["presentable"])
        self.assertIn("red", o["statut"])

    def test_orchestrer_refuse_sans_liasse(self) -> None:
        j = JournalOrchestre()
        o = orchestrer(Mission(), autorisations={"complet": False}, equipe="red", journal=j)
        self.assertTrue(o["orchestre"])
        self.assertFalse(o["execute"])
        self.assertEqual(o["n_joue"], 0)
        blob = " ".join(
            f"{e.get('nom') or ''} {e.get('why') or ''} {e.get('titre') or ''}" for e in j.etapes
        ).lower()
        self.assertIn("non sign", blob)

    def test_orchestrer_execute_si_signe(self) -> None:
        j = JournalOrchestre()
        o = orchestrer(Mission(), autorisations={"complet": True}, equipe="red", journal=j)
        self.assertTrue(o["execute"])
        self.assertIn("exécuté", o["attestation"])
        blob = " ".join(f"{e.get('nom') or ''} {e.get('why') or ''}" for e in j.etapes).lower()
        self.assertIn("avenant", blob)
        self.assertGreaterEqual(o["n_avenant"], 1)

    def test_want_yaml(self) -> None:
        m = Mission()
        m.extras["passi"] = True
        m.extras["autorisations"] = True
        red = _args(equipe="red", red_pass="eoh19311936")
        self.assertTrue(want_passi(red, m))
        self.assertTrue(want_autorisations(red, m))
        self.assertFalse(want_passi(_args(), m))
        self.assertFalse(want_autorisations(_args(), m))

    def test_passi_allume_lynis_gvm(self) -> None:
        m = Mission()
        m.extras["passi"] = True
        args = _args(equipe="red", red_pass="eoh19311936")
        appliquer_yaml(args, m)
        self.assertTrue(args.passi)
        self.assertTrue(args.autorisations)
        self.assertTrue(args.lynis)
        self.assertTrue(args.greenbone)
        self.assertFalse(args.trivy)
        plan = summarize_plan(args, m)
        self.assertTrue(plan["passi"])
        self.assertTrue(plan["autorisations"])

    def test_cles_action(self) -> None:
        self.assertIn("passi", CLES_ACTION)
        self.assertIn("autorisations", CLES_ACTION)

    def test_pas_de_gui_inutile(self) -> None:
        from guardia.engines.passi import OUTILS_UTILES
        self.assertNotIn("zenmap", OUTILS_UTILES)
        self.assertNotIn("wireshark", OUTILS_UTILES)
        self.assertIn("whois", OUTILS_UTILES)
        self.assertIn("dig", OUTILS_UTILES)


class Autorisations(unittest.TestCase):
    def test_joue_les_pieces(self) -> None:
        m = Mission()
        m.client = "Test"
        st = build_autorisations(m, generer_liasse=False)
        self.assertTrue(st["orchestre"])
        self.assertGreaterEqual(len(st["pieces"]), 8)
        self.assertTrue(st["extra"])
        self.assertFalse(st["complet"])


class TkEtYaml(unittest.TestCase):
    def test_run_flags_passi(self) -> None:
        text = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn('flags.append("--passi")', text)
        self.assertIn('flags.append("--autorisations")', text)
        self.assertIn("Offre PASSI", text)
        self.assertIn("Autorisations", text)
        self.assertIn('"passi": True', text)
        self.assertIn('"autorisations": True', text)

    def test_ducros_yaml(self) -> None:
        text = (ROOT / "missions" / "exemple-passi-complet.yaml").read_text(encoding="utf-8")
        self.assertIn("passi: true", text)
        self.assertIn("autorisations: true", text)

    def test_cli_subparser(self) -> None:
        text = (ROOT / "guardia" / "cli.py").read_text(encoding="utf-8")
        self.assertIn("func=cmd_passi", text)
        self.assertIn("want_passi", text)
        self.assertIn("Offre PASSI", text)


class EclairsBleus(unittest.TestCase):
    def test_tk_kind_toujours_bleu(self) -> None:
        src = (ROOT / "guardia" / "ui" / "logo_gouttes.py").read_text(encoding="utf-8")
        self.assertIn("def _kind_eclair", src)
        self.assertNotIn('return "rouge"', src)
        self.assertIn('return "bleu"', src)
        self.assertIn("Plus d'éclairs rouges", src)

    def test_sections(self) -> None:
        text = (ROOT / "guardia" / "report" / "html_report.py").read_text(encoding="utf-8")
        self.assertIn("def _section_passi", text)
        self.assertIn("def _section_pack_autorisations", text)
        self.assertIn("pas un certificat", text.lower())


if __name__ == "__main__":
    unittest.main()
