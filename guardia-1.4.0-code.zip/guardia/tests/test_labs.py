from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.labs.runner import jouer_tous
from guardia.labs.scenarios import SCENARIOS, https_only, sans_mandat


class LabsAdaptatifs(unittest.TestCase):
    def test_all_labs_react_as_expected(self) -> None:
        bundle = jouer_tous()
        kos = [r for r in bundle["labs"] if not r["ok"]]
        detail = "\n".join(
            "{i}: {c}".format(
                i=r["id"],
                c="; ".join(
                    "{n}={d}".format(n=c["nom"], d=c["detail"]) for c in r["checks"] if not c["ok"]
                ),
            )
            for r in kos
        )
        self.assertEqual(kos, [], detail)
        self.assertEqual(bundle["n"], len(SCENARIOS))

    def test_https_opens_tls_prunes_smb(self) -> None:
        from guardia.labs.runner import jouer

        r = jouer(https_only())
        etats = {d["cap"]: d["etat"] for d in r["decisions"]}
        self.assertIn(etats.get("tls_assessment"), ("ouvre", "porte"))
        self.assertEqual(etats.get("smb_read"), "prune")

    def test_sans_mandat_refuse_discover(self) -> None:
        from guardia.labs.runner import jouer

        r = jouer(sans_mandat())
        etats = {d["cap"]: d["etat"] for d in r["decisions"]}
        self.assertEqual(etats.get("nmap_discover"), "refuse")


if __name__ == "__main__":
    unittest.main()
