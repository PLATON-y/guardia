"""Tests parc, dossier et hygiène."""
from __future__ import annotations

import sys
import tempfile
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.core.dossier import PASSI, etat, generer, peut_red_regard, peut_red_test
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission
from guardia.core.parc import parc_de
from guardia.engines.hygiene import build_hygiene
from guardia.engines.identites import build_identites
from guardia.report.html_report import _build


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class Parc(unittest.TestCase):
    def test_foyer_personnel(self) -> None:
        self.assertEqual(parc_de(Mission(type_structure="foyer")), "personnel")

    def test_pme_pro(self) -> None:
        self.assertEqual(parc_de(Mission(type_structure="entreprise")), "professionnel")

    def test_extras(self) -> None:
        m = Mission(type_structure="foyer")
        m.extras["parc"] = "professionnel"
        self.assertEqual(parc_de(m), "professionnel")


class Dossier(unittest.TestCase):
    def test_personnel_mandat_ouvre_regard(self) -> None:
        m = Mission(client="Famille", type_structure="foyer", mandat_nda_signes=True)
        ok, _why = peut_red_regard(m)
        self.assertTrue(ok)

    def test_pro_sans_liasse_ferme(self) -> None:
        m = Mission(client="Atelier", type_structure="entreprise", mandat_nda_signes=True)
        ok, why = peut_red_regard(m)
        self.assertFalse(ok)
        self.assertIn("incomplet", why.lower())

    def test_pro_liasse_ouvre(self) -> None:
        m = Mission(client="Atelier", type_structure="entreprise", mandat_nda_signes=True)
        m.extras["dossier"] = {
            "convention": True,
            "autorisation": True,
            "roe": True,
            "rgpd_annexe": True,
            "confidentialite": True,
            "arret": True,
            "notice": True,
        }
        ok, _why = peut_red_regard(m)
        self.assertTrue(ok)
        self.assertTrue(etat(m)["complet"] or not etat(m)["manquantes"])

    def test_red_test_toujours_ferme(self) -> None:
        m = Mission(mandat_nda_signes=True)
        ok, why = peut_red_test(m)
        self.assertFalse(ok)
        self.assertIn("inerte", why.lower())

    def test_generer_hash(self) -> None:
        m = Mission(client="Famille", type_structure="foyer", mandat_nda_signes=True)
        with tempfile.TemporaryDirectory() as td:
            info = generer(m, Path(td))
        self.assertEqual(len(info["hashes"]), 8)
        self.assertTrue(all(len(h["sha256"]) == 64 for h in info["hashes"]))
        self.assertNotIn("eoh19311936", PASSI.lower())


class Hygiene(unittest.TestCase):
    def test_inventaire_vu(self) -> None:
        m = Mission(client="Lab", type_structure="foyer", mandat_nda_signes=True)
        h = Host(ip="192.168.1.10", kind="pc")
        r = CheckupResult(mission=m, hosts=[h])
        block = build_hygiene(r)
        self.assertIn("certificat", block["limite"].lower())
        self.assertTrue(any(i["id"] == "h-inventaire" for i in block["items"]))
        self.assertNotIn("PASSI certifié", _build(r))


class Identites(unittest.TestCase):
    def test_ldap_porte_sans_login(self) -> None:
        m = Mission(client="Atelier", type_structure="entreprise", mandat_nda_signes=True)
        h = Host(ip="10.0.0.8", kind="serveur")
        h.findings.append(
            Finding(
                id="cal-ldap-rootdse",
                titre="Annuaire rootDSE",
                pourquoi_nuit="namingContexts",
                preuve="389",
                remede_etapes=["Segmenter."],
                qui_peut="admin",
                priorite="cette_semaine",
                gravite=Gravite.HAUTE,
                hote="10.0.0.8",
            )
        )
        r = CheckupResult(mission=m, hosts=[h], equipe="red")
        block = build_identites(r)
        self.assertTrue(block["lecture_seule"])
        self.assertTrue(any("Annuaire" in p["titre"] for p in block["portes"]))
        r.identites = block
        r.hygiene = build_hygiene(r)
        html = _build(r)
        self.assertIn("Identités", html)
        self.assertIn("pas un dump", html.lower() + html)
        self.assertNotIn("eoh19311936", html)


class Referentiel(unittest.TestCase):
    def test_doc_present(self) -> None:
        p = ROOT / "docs" / "REFERENTIEL.md"
        self.assertTrue(p.is_file())
        t = p.read_text(encoding="utf-8")
        self.assertIn("Personnel", t)
        self.assertIn("Professionnel", t)
        self.assertNotIn("Laboratoire", t)
        self.assertIn("PASSI", t)


if __name__ == "__main__":
    unittest.main()
