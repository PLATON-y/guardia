"""Smoke imports + règles sur hôtes fictifs (pas de nmap / pas de scan LAN)."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import Finding, Gravite, Host, Mission, Posture
from guardia.engines.classify import classify_host
from guardia.rules.engine import apply_rules, posture_from_findings


class Smoke(unittest.TestCase):
    def test_imports(self) -> None:
        import guardia
        import guardia.cli
        import guardia.engines.classify
        import guardia.engines.discover
        import guardia.engines.enrich
        import guardia.engines.netinfo
        import guardia.engines.services
        import guardia.report.json_report
        import guardia.report.pdf_report
        import guardia.rules.engine
        import guardia.rules.universal
        import guardia.engines.rgpd_config
        import guardia.engines.rgpd_signal
        import guardia.ui.wizard

        self.assertTrue(guardia.__version__)

    def test_classify_box(self) -> None:
        h = Host(ip="192.168.1.1", hostname="livebox", vendor="Sagemcom")
        self.assertEqual(classify_host(h, gateway="192.168.1.1"), "box")

    def test_classify_switch(self) -> None:
        h = Host(ip="192.168.1.2", hostname="core-switch", vendor="Cisco Systems")
        self.assertEqual(classify_host(h, gateway="192.168.1.1"), "switch")

    def test_classify_ap(self) -> None:
        h = Host(ip="192.168.1.3", hostname="unifi-ap-salon", vendor="Ubiquiti")
        kind = classify_host(h, gateway="192.168.1.1")
        self.assertIn(kind, ("ap", "router", "box"))

    def test_telnet_finding(self) -> None:
        h = Host(
            ip="192.168.1.50",
            kind="iot",
            ports=[{"port": 23, "proto": "tcp", "name": "telnet", "product": "", "version": ""}],
        )
        pc = Host(ip="192.168.1.10", kind="pc", ports=[])
        m = Mission(client="T", mandat_nda_signes=True, profil_moteur="maison")
        apply_rules([h, pc], m, gateway="192.168.1.1")
        self.assertTrue(any(f.gravite == Gravite.CRITIQUE for f in h.findings))
        self.assertIn(h.posture, (Posture.CRITIQUE, Posture.RISQUE))

    def test_second_gateway_finding(self) -> None:
        """2 hôtes typés box/router ≠ gateway unique → finding net-second-gateway."""
        gw = Host(
            ip="192.168.1.1",
            kind="box",
            hostname="livebox",
            ports=[{"port": 80, "proto": "tcp", "name": "http", "product": "", "version": ""}],
        )
        rogue = Host(
            ip="192.168.1.254",
            kind="router",
            hostname="travel-router",
            vendor="GL.iNet",
            ports=[
                {"port": 80, "proto": "tcp", "name": "http", "product": "", "version": ""},
                {"port": 443, "proto": "tcp", "name": "https", "product": "", "version": ""},
            ],
        )
        pc = Host(ip="192.168.1.10", kind="pc", ports=[])
        m = Mission(client="T", mandat_nda_signes=True, profil_moteur="maison")
        apply_rules([gw, rogue, pc], m, gateway="192.168.1.1")
        all_f = [f for h in (gw, rogue, pc) for f in h.findings]
        ids = [f.id for f in all_f]
        self.assertTrue(
            any(i == "net-second-gateway" or i.startswith("net-second") for i in ids),
            f"attendu net-second-gateway, got {ids}",
        )

    def test_finding_fields(self) -> None:
        f = Finding(
            id="x",
            titre="t",
            pourquoi_nuit="p",
            preuve="v",
            remede_etapes=["1"],
            qui_peut="toi",
            priorite="tout_de_suite",
            gravite=Gravite.BASSE,
        )
        d = f.to_dict()
        for k in ("titre", "pourquoi_nuit", "preuve", "remede_etapes", "qui_peut", "priorite", "gravite"):
            self.assertIn(k, d)



    def test_preuve_template_helpers(self) -> None:
        """Template vouvoiement : impact / protection / note lecture seule."""
        from guardia.engines.preuve_repro import (
            NOTE_AUCUNE_EXPLOITATION,
            phrase_impact,
            phrase_protection,
            template_client_finding,
        )

        f = Finding(
            id="audit-tls-demo",
            titre="TLS faible observé",
            pourquoi_nuit="faciliter l'écoute passive d'échanges sensibles",
            preuve="ssl-enum-ciphers: TLS_RSA_WITH_3DES",
            remede_etapes=["Désactiver les suites faibles", "Imposer TLS 1.2+"],
            qui_peut="DSI",
            priorite="cette_semaine",
            gravite=Gravite.HAUTE,
            hote="192.0.2.10",
            observation="Cipher suite faible renvoyée au handshake",
            preuve_repro="nmap -p 443 --script ssl-enum-ciphers 192.0.2.10",
        )
        tpl = template_client_finding(f, vouvoiement=True)
        self.assertIn("observation", tpl)
        self.assertTrue(tpl["impact"].startswith("Ceci permettrait de"))
        self.assertTrue(tpl["protection"].startswith("Pour vous protéger, il faudrait"))
        self.assertIn("Aucune exploitation", tpl["note"])
        self.assertIn("lecture seule", NOTE_AUCUNE_EXPLOITATION.lower())
        self.assertIn("faciliter", phrase_impact(f))
        self.assertIn("Désactiver", phrase_protection(f))
        # HTML finding block doit exposer le template
        from guardia.report.html_report import _finding_block

        html = _finding_block(f)
        self.assertIn("Ceci permettrait de", html)
        self.assertIn("Pour vous protéger, il faudrait", html)
        self.assertIn("Aucune exploitation", html)

if __name__ == "__main__":
    unittest.main()
