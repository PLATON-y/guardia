from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import CheckupResult, Mission
from guardia.engines.autorisations import build_autorisations
from guardia.engines.passi_alignment import CONTROLS, build_alignment, as_markdown


class PassiAlignment(unittest.TestCase):
    def test_has_five_public_activities(self) -> None:
        a = build_alignment(Mission(), CheckupResult(Mission()))
        names = [name for _, name in a["domains"]]
        self.assertEqual(len(names), 5)
        self.assertIn("Audit d'architecture", names)
        self.assertIn("Audit de configuration", names)
        self.assertIn("Audit de code source", names)
        self.assertIn("Tests d'intrusion", names)
        self.assertIn("Audit organisationnel et physique", names)

    def test_controls_are_guardia_ids_not_official_claims(self) -> None:
        self.assertGreaterEqual(len(CONTROLS), 30)
        self.assertTrue(all(c.id.startswith("G-PASSI-") for c in CONTROLS))
        a = build_alignment(Mission(), CheckupResult(Mission()))
        self.assertIn("disclaimer", a)
        self.assertIn("qualification", a["disclaimer"].lower())

    def test_signed_red_mission_unlocks_intrusion_preconditions_but_not_exploit(self) -> None:
        mission = Mission(cidr="192.0.2.0/24", mandat_nda_signes=True, operateur_signe=True)
        authz = build_autorisations(mission, pour_passi=True)
        a = build_alignment(mission, {"equipe": "red", "autorisations": authz, "journal": {"etapes": []}})
        rows = {r["id"]: r for r in a["controls"]}
        self.assertIn(rows["G-PASSI-INTR-01"]["status"], {"supported_with_human_gate", "partial"})
        self.assertEqual(rows["G-PASSI-INTR-05"]["status"], "supported_with_human_gate")

    def test_unrequested_code_is_not_marked_non_conform(self) -> None:
        m = Mission(cidr="192.0.2.0/24")
        a = build_alignment(m, {})
        row = next(r for r in a["controls"] if r["id"] == "G-PASSI-CODE-02")
        self.assertEqual(row["status"], "not_applicable")

    def test_markdown_is_deterministic_and_contains_coverage(self) -> None:
        a = build_alignment(Mission(), {})
        md = as_markdown(a)
        self.assertIn("Matrice d'alignement PASSI v2.2", md)
        self.assertIn("G-PASSI-PRE-01", md)
        self.assertIn("Couverture par activité", md)


if __name__ == "__main__":
    unittest.main()
