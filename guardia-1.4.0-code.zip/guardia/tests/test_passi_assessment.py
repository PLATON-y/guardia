from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import Mission
from guardia.engines.passi_assessment import CONTROLS, build_assessment, build_execution_plan, requested_activities
import guardia.cli as cli


class PassiAssessment(unittest.TestCase):
    def test_control_catalog(self) -> None:
        self.assertGreaterEqual(len(CONTROLS), 50)
        self.assertTrue(all(c.id.startswith("P-") for c in CONTROLS))
        self.assertEqual({"architecture", "configuration"}, set(requested_activities(Mission())))

    def test_full_mission_has_all_five_activities(self) -> None:
        m = Mission(cidr="192.0.2.0/24")
        m.extras["passi"] = True
        self.assertEqual(set(requested_activities(m)), {"organisationnel_physique", "architecture", "configuration", "code_source", "intrusion"})
        plan = build_execution_plan(m)
        ids = {x["id"] for x in plan}
        self.assertIn("passi-code-sast", ids)
        self.assertIn("passi-pentest-blackbox", ids)

    def test_no_global_qualification_score(self) -> None:
        a = build_assessment(Mission(cidr="192.0.2.0/24"), {})
        self.assertNotIn("score_operational", a["summary"])
        self.assertIn("verified", a["summary"])
        self.assertIn("pending_human", a["summary"])

    def test_nested_yaml_without_pyyaml(self) -> None:
        path = ROOT / "missions" / "exemple-passi-complet.yaml"
        saved = cli.yaml
        cli.yaml = None
        try:
            m = cli.load_mission(path)
        finally:
            cli.yaml = saved
        self.assertEqual(m.cidr, "192.0.2.0/24")
        self.assertEqual((m.extras or {}).get("site_url"), "https://pctamalou.fr")
        self.assertEqual(set((m.extras or {}).get("passi_activities") or []), {"organisationnel_physique", "architecture", "configuration", "code_source", "intrusion"})


if __name__ == "__main__":
    unittest.main()
