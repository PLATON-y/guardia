from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import Host, Mission
from guardia.core.poste import doit_retirer, est_poste_operateur, partitionner, resume


class PosteOperateur(unittest.TestCase):
    def test_ip_locale_sortie_du_parc(self) -> None:
        op = Host(ip="192.168.1.120", hostname="pixel-book.lan", kind="pc")
        box = Host(ip="192.168.1.254", hostname="bbox.lan", kind="box")
        phone = Host(ip="192.168.1.108", hostname="iPhone-001.lan", kind="phone")
        m = Mission(client="tamalou", type_structure="parc_particulier", profil_moteur="maison")
        parc, oper = partitionner(
            [op, box, phone],
            ips={"192.168.1.120"},
            noms={"pixel-book"},
            mission=m,
        )
        self.assertEqual([h.ip for h in parc], ["192.168.1.254", "192.168.1.108"])
        self.assertEqual([h.ip for h in oper], ["192.168.1.120"])
        rec = resume(oper, m)
        self.assertTrue(rec["retire"])
        self.assertIn("192.168.1.120", rec["resume"])

    def test_nom_court_sans_ip(self) -> None:
        op = Host(ip="10.0.0.9", hostname="Pixel-Book.lan")
        other = Host(ip="10.0.0.2", hostname="nas-1")
        parc, oper = partitionner([op, other], ips=set(), noms={"pixel-book"})
        self.assertEqual([h.ip for h in oper], ["10.0.0.9"])
        self.assertEqual([h.ip for h in parc], ["10.0.0.2"])

    def test_nom_generique_ne_matche_pas(self) -> None:
        h = Host(ip="10.0.0.3", hostname="kali.lan")
        parc, oper = partitionner([h], ips=set(), noms={"kali"})
        self.assertEqual(oper, [])
        self.assertEqual(parc, [h])

    def test_inclure_si_demande(self) -> None:
        op = Host(ip="192.168.1.120", hostname="pixel-book.lan")
        m = Mission()
        m.extras["inclure_poste_operateur"] = True
        self.assertFalse(doit_retirer(m))
        parc, oper = partitionner([op], ips={"192.168.1.120"}, mission=m)
        self.assertEqual(parc, [op])
        self.assertEqual(oper, [])

    def test_ips_yaml(self) -> None:
        h = Host(ip="192.168.1.50", hostname="autre")
        m = Mission()
        m.extras["ips_operateur"] = ["192.168.1.50"]
        parc, oper = partitionner([h], ips=set(), mission=m)
        self.assertEqual([x.ip for x in oper], ["192.168.1.50"])

    def test_pas_de_faux_positif_voisin(self) -> None:
        self.assertFalse(
            est_poste_operateur(
                Host(ip="192.168.1.193", hostname="Bouygtel4K.lan"),
                ips={"192.168.1.120"},
                noms={"pixel-book"},
            )
        )
