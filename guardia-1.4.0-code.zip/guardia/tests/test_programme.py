"""Tests du programme de visite et des capacités prévues."""
from __future__ import annotations

import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.cadre import HORS_MOTEUR, PROGRAMME, SOUS_AVENANT
from guardia.core.models import CheckupResult, Mission
from guardia.engines.programme import (
    CATALOGUE,
    build_programme,
    commande_encadree,
    ecrire_programme,
    get_outil,
)
from guardia.report.html_report import _build


class ProgrammePassif(unittest.TestCase):
    def test_analogie(self) -> None:
        self.assertNotIn("YesWeHack", PROGRAMME)
        self.assertIn("non intrusive", PROGRAMME.lower())
        self.assertEqual(HORS_MOTEUR, ())
        self.assertEqual(SOUS_AVENANT, ())

    def test_catalogue_lecture_seule(self) -> None:
        ids = {o.id for o in CATALOGUE}
        self.assertGreaterEqual(ids, {"testssl", "whatweb", "nuclei", "nmap"})
        self.assertNotIn("burp", ids)
        self.assertNotIn("zap", ids)
        for o in CATALOGUE:
            self.assertTrue(o.auto)
            self.assertEqual(o.mode, "lecture")
            self.assertTrue(o.aide)

    def test_nuclei_commande_sans_exploit(self) -> None:
        o = get_outil("nuclei")
        assert o is not None
        cmd = commande_encadree(o, "https://example.test")
        self.assertIn("example.test", cmd)
        self.assertIn("-etags", cmd)
        self.assertIn("exploit", cmd)

    def test_json_et_html(self) -> None:
        m = Mission(client="Lab", mandat_nda_signes=True, cidr="192.168.0.0/24")
        block = build_programme(m, cidr="192.168.0.0/24", url="https://example.test")
        self.assertNotIn("hors", block)
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "programme.json"
            out = ecrire_programme(block, dest=p)
            data = json.loads(out.read_text(encoding="utf-8"))
            self.assertTrue(data["encadre"])
            self.assertNotIn("YesWeHack", data["analogie"])
        html = _build(CheckupResult(mission=m, hosts=[], programme=block))
        self.assertIn("Outils de cette visite", html)
        self.assertNotIn("YesWeHack", html)
        self.assertNotIn("Burp Suite", html)
        self.assertNotIn("OWASP ZAP", html)
        self.assertIn("Aide", html)


if __name__ == "__main__":
    unittest.main()
