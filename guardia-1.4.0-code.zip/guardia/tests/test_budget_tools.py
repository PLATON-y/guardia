"""Tests budget de scan, outils et comportement de l’orchestrateur."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.core.budget import RunBudget
from guardia.core.models import Host, Mission
from guardia.core.orchestrate import summarize_plan, want_lan
from guardia.engines.calibrage import PROBES
from guardia.engines.programme import CATALOGUE, get_outil, run_lecture_ciblee


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        usages=False,
        no_usages=False,
        machines=False,
        pistes=False,
        no_pistes=False,
        llm=False,
        calibrage=False,
        no_calibrage=False,
        audit=False,
        audit_full=False,
        full=False,
        no_lan=False,
        lan=False,
        all_ports=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class LanOptionnel(unittest.TestCase):
    def test_defaut_lan(self) -> None:
        m = Mission(cidr="192.168.1.0/24", mandat_nda_signes=True)
        self.assertTrue(want_lan(_args(), m))

    def test_no_lan(self) -> None:
        m = Mission(cidr="192.168.1.0/24", mandat_nda_signes=True)
        self.assertFalse(want_lan(_args(no_lan=True, site="https://example.test"), m))

    def test_yaml_lan_false(self) -> None:
        m = Mission(cidr="192.168.1.0/24", extras={"lan": False})
        self.assertFalse(want_lan(_args(), m))

    def test_plan_site_sans_lan(self) -> None:
        m = Mission(mandat_nda_signes=True, extras={"lan": False, "site_url": "https://example.test"})
        plan = summarize_plan(_args(site="https://example.test", full=True), m)
        self.assertFalse(plan["lan"])
        self.assertEqual(plan["site_url"], "https://example.test")
        self.assertFalse(plan["profond"])
        plan_red = summarize_plan(
            _args(site="https://example.test", full=True, equipe="red", red_pass="eoh19311936"), m
        )
        self.assertTrue(plan_red["profond"])
        self.assertFalse(plan["calibrage"])
        self.assertFalse(plan["machines"])


class BudgetScan(unittest.TestCase):
    def test_post_ne_compte_pas(self) -> None:
        b = RunBudget(limit_sec=1.0)
        with b.phase("discover"):
            pass
        with b.phase("llm", kind="post"):
            pass
        s = b.summary()
        self.assertIn("discover", s["timings"])
        self.assertEqual(s["kinds"]["llm"], "post")
        self.assertGreaterEqual(s["elapsed_post_sec"], 0.0)
        self.assertEqual(s["kinds"]["discover"], "scan")

    def test_llm_tourne_budget_scan_zero(self) -> None:
        b = RunBudget(limit_sec=0.0)
        ran = []
        with b.phase("llm", kind="post"):
            ran.append(1)
        self.assertEqual(ran, [1])
        self.assertNotIn("llm", b.skipped)


class Outils(unittest.TestCase):
    def test_probes_ajoutees(self) -> None:
        ids = {p.id for p in PROBES}
        self.assertTrue({"ssl-enum", "dns-axfr", "smbmap", "sslyze", "vnc-info"} <= ids)

    def test_catalogue_sslyze(self) -> None:
        o = get_outil("sslyze")
        self.assertIsNotNone(o)
        self.assertTrue(o.aide)
        ids = {x.id for x in CATALOGUE}
        self.assertIn("onesixtyone", ids)

    def test_lecture_vide(self) -> None:
        self.assertEqual(run_lecture_ciblee(""), [])

    def test_ui_no_lan_flag(self) -> None:
        src = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn("--no-lan", src)
        self.assertIn("LAN — nmap", src)
        self.assertIn("hors horloge", src)


class Rapport(unittest.TestCase):
    def test_site_only_html(self) -> None:
        from guardia.core.models import CheckupResult
        from guardia.report.html_report import _build

        m = Mission(client="Lab", mandat_nda_signes=True)
        r = CheckupResult(
            mission=m,
            hosts=[],
            plan={"lan": False, "site_url": "https://example.test"},
            website={"url": "https://example.test", "ok": True, "findings": []},
        )
        html = _build(r)
        self.assertIn("example.test", html)
        self.assertNotIn("Hors moteur", html)


if __name__ == "__main__":
    unittest.main()
