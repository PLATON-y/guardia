"""Tests ports exhaustifs."""
from guardia.core.ports import CATEGORIES, all_ports, by_category, critical, service_of

def test_categories_nonempty():
    assert len(CATEGORIES) >= 12
    for name, ports in CATEGORIES.items():
        assert ports, name

def test_critical_subset():
    c = critical()
    assert 80 in c and 443 in c and 22 in c

def test_service_of():
    assert "HTTP" in service_of(80)
    assert service_of(99999) == "inconnu"

def test_all_ports_count():
    assert len(all_ports()) >= 80
