"""Tests du chargement YAML et de l’orchestration."""
from __future__ import annotations

import io
import sys
import unittest
from contextlib import redirect_stdout
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia import __version__
from guardia.cli import load_mission
from guardia.core.models import Gravite, Host, Mission
from guardia.core.orchestrate import (
    annoncer_plan,
    appliquer_yaml,
    summarize_plan,
    want_audit,
    want_llm,
    want_lynis,
)
from guardia.engines.calibrage import PROBES, _parse, plan_calibrage
from guardia.engines.programme import CATALOGUE, get_outil
from guardia.report.json_report import payload_from_result
from guardia.core.models import CheckupResult


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        usages=False,
        no_usages=False,
        machines=False,
        pistes=False,
        no_pistes=False,
        llm=False,
        pdf=False,
        lynis=False,
        audit=False,
        audit_full=False,
        full=False,
        all_ports=False,
        calibrage=False,
        no_calibrage=False,
        lan=False,
        no_lan=False,
        equipe="blue",
        restructure=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class YamlAllume(unittest.TestCase):
    def test_red_example_plan_tout_allume(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-red.yaml")
        args = _args(equipe="red", red_pass="eoh19311936")
        appliquer_yaml(args, m)
        plan = summarize_plan(args, m)
        self.assertTrue(plan["lan"])
        self.assertTrue(plan["calibrage"])
        self.assertEqual(plan["site_url"], "https://example.test")
        self.assertTrue(plan["rgpd"])
        self.assertTrue(plan["usages"])
        self.assertTrue(plan["machines"])
        self.assertTrue(plan["restructure"])
        self.assertTrue(plan["pistes"])
        self.assertEqual(plan["audit"], "full")
        self.assertTrue(plan["llm"])
        self.assertTrue(plan["pdf"])
        self.assertTrue(plan["profond"])
        self.assertEqual(plan["equipe_demandee"], "red")
        self.assertTrue(args.llm)
        self.assertTrue(args.pdf)
        self.assertTrue(args.audit_full)

    def test_annoncer_plan_imprime(self) -> None:
        m = Mission(type_structure="foyer", mandat_nda_signes=True)
        buf = io.StringIO()
        with redirect_stdout(buf):
            lignes = annoncer_plan(summarize_plan(_args(), m))
        text = buf.getvalue()
        self.assertIn("Plan de visite", text)
        self.assertTrue(any(x.startswith("lan:") for x in lignes))

    def test_lynis_yaml(self) -> None:
        m = Mission()
        m.extras["lynis"] = True
        self.assertTrue(want_lynis(_args(), m))
        self.assertFalse(want_lynis(_args(), Mission()))

    def test_no_rgpd_coupe_yaml(self) -> None:
        m = Mission()
        m.extras["rgpd"] = True
        args = _args(no_rgpd=True)
        appliquer_yaml(args, m)
        plan = summarize_plan(args, m)
        self.assertFalse(plan["rgpd"])


class Sondes(unittest.TestCase):
    def test_curl_dans_calibrage(self) -> None:
        self.assertTrue(any(p.id == "curl-headers" for p in PROBES))

    def test_curl_dans_catalogue(self) -> None:
        o = get_outil("curl")
        self.assertIsNotNone(o)
        self.assertEqual(o.scope, "url")

    def test_greenbone_auto(self) -> None:
        o = get_outil("greenbone")
        self.assertTrue(o.auto)

    def test_parse_sslscan(self) -> None:
        found = _parse("sslscan", "192.168.1.1", "SSLv3 enabled\nTLSv1.0 enabled\n")
        self.assertTrue(found)
        self.assertEqual(found[0].id, "cal-tls")

    def test_parse_snmpwalk(self) -> None:
        found = _parse(
            "snmpwalk-system",
            "192.168.1.1",
            "SNMPv2-MIB::sysDescr.0 = Linux box 5.10",
        )
        self.assertTrue(found)
        self.assertEqual(found[0].gravite, Gravite.HAUTE)

    def test_plan_http_inclut_curl(self) -> None:
        h = Host(ip="192.168.1.10", kind="pc")
        h.ports = [{"port": 80, "state": "open"}]
        jobs = plan_calibrage([h], cidr="192.168.1.0/24", site_url="https://example.test")
        ids = {j["id"] for j in jobs}
        self.assertIn("curl-headers", ids)


class JsonOrchestre(unittest.TestCase):
    def test_payload_orchestre(self) -> None:
        m = Mission(client="Structure Exemple Red", mandat_nda_signes=True)
        r = CheckupResult(mission=m, orchestre={"prevu": ["lan:allumé"]})
        p = payload_from_result(r)
        self.assertIn("orchestre", p)
        self.assertEqual(p["orchestre"]["prevu"], ["lan:allumé"])


class Audit(unittest.TestCase):
    def test_audit_full_yaml(self) -> None:
        m = Mission()
        m.extras["audit_full"] = True
        self.assertEqual(want_audit(_args(equipe="red", red_pass="eoh19311936"), m), "full")
        self.assertIsNone(want_audit(_args(), m))
        self.assertTrue(want_llm(_args(llm=True), Mission()))


if __name__ == "__main__":
    unittest.main()
