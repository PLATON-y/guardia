"""Tests des paramètres transmis par l’interface."""
from __future__ import annotations

import unittest
from pathlib import Path
from types import SimpleNamespace
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Mission
from guardia.core.orchestrate import (
    CLES_ACTION,
    JournalOrchestre,
    summarize_plan,
)
from guardia.engines.lynis import etat as lynis_etat


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        usages=False,
        no_usages=False,
        machines=False,
        pistes=False,
        no_pistes=False,
        llm=False,
        pdf=False,
        lynis=False,
        greenbone=False,
        trivy=False,
        audit=False,
        audit_full=False,
        full=False,
        all_ports=False,
        calibrage=False,
        no_calibrage=False,
        lan=False,
        no_lan=False,
        equipe="blue",
        restructure=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class Version(unittest.TestCase):
    def test_065(self) -> None:
        self.assertTrue(__version__.startswith("1."))


class FiletOrchestre(unittest.TestCase):
    def test_couvrir_complete_les_trous(self) -> None:
        j = JournalOrchestre()
        j.phase("Plan de visite")
        plan = summarize_plan(_args(no_lan=True), Mission())
        plan["lan"] = False
        j.couvrir(plan)
        d = j.as_dict()
        self.assertGreater(d["n"], 1)
        self.assertGreaterEqual(d["absents_ou_sautes"], 1)
        # Rien d'allumé n'est resté sans trace
        j2 = JournalOrchestre()
        j2.outil("nmap discover", "1", "ok")
        j2.outil("calibrage", "", "ok")
        j2.outil("curl", "https://x", "ok")
        j2.outil("rgpd", "", "ok")
        j2.outil("usages", "", "ok")
        j2.outil("restructure", "", "ok")
        j2.outil("machines", "", "ok")
        j2.outil("pistes", "", "ok")
        j2.outil("audit", "", "ok")
        j2.outil("llm", "", "ok")
        j2.outil("pdf", "", "ok")
        j2.outil("lynis", "", "ok")
        j2.outil("gvm-cli", "", "ok")
        j2.outil("trivy", "", "ok")
        j2.outil("programme", "", "ok")
        j2.outil("passi", "", "ok")
        j2.outil("autorisations", "", "ok")
        before = len(j2.etapes)
        allume = {k: True for k in CLES_ACTION}
        allume["site_url"] = "https://example.test"
        allume["audit"] = "standard"
        j2.couvrir(allume)
        self.assertEqual(len(j2.etapes), before)

    def test_lynis_orchestre(self) -> None:
        st = lynis_etat()
        self.assertTrue(st["orchestre"])
        self.assertFalse(st["distant"])


class TkPasseLesFlags(unittest.TestCase):
    def test_run_flags_greenbone_lynis_trivy(self) -> None:
        text = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn('flags.append("--greenbone")', text)
        self.assertIn('flags.append("--lynis")', text)
        self.assertIn('flags.append("--trivy")', text)
        self.assertIn('flags.append("--pistes")', text)
        self.assertIn("Greenbone (red)", text)
        self.assertIn("Lynis opérateur", text)
        self.assertIn("Trivy (red)", text)
        self.assertIn("_sync_equipe_caps", text)
        self.assertIn("_clip_blue_vars", text)
        self.assertIn("Actions avancées — autorisation explicite", text)
        self.assertIn("--red-team", text)

    def test_preset_full_allume(self) -> None:
        text = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        # Preset full / red allument les piliers opérateur
        self.assertIn('"full": {', text)
        self.assertRegex(text, r'"full": \{[^}]*"greenbone": True')
        self.assertRegex(text, r'"red": \{[^}]*"greenbone": True')

    def test_passi_separe_du_full(self) -> None:
        text = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn("Mode PASSI", text)
        self.assertIn("Mode Full", text)
        self.assertIn("--passi-activites", text)
        self.assertIn('"passi": {', text)
        self.assertRegex(text, r'"passi": \{[^}]*"full": False')
        self.assertRegex(text, r'"passi": \{[^}]*"audit_full": False')
        # combobox n'offre plus un profil red qui mélange les deux
        self.assertIn('values=("maison", "pme", "ecole")', text)
        self.assertIn('_sync_equipe_caps', text)

    def test_budget_7200(self) -> None:
        text = (ROOT / "guardia" / "core" / "budget.py").read_text(encoding="utf-8")
        self.assertIn("DEFAULT_LIMIT_SEC = 7200", text)
        ui = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn('value="7200"', ui)

    def test_new_mission_yaml(self) -> None:
        text = (ROOT / "guardia" / "ui" / "new_mission.py").read_text(encoding="utf-8")
        self.assertIn('"greenbone"', text)
        self.assertIn('"lynis"', text)
        self.assertIn('"trivy"', text)


if __name__ == "__main__":
    unittest.main()
