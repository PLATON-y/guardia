"""Tests du cadre légal et des synthèses de rapport."""
from __future__ import annotations

import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.cadre import BANNER_COURT, HORS_MOTEUR, IDENTITE_BARRE, RGPD_32, SOUS_AVENANT
from guardia.core.models import CheckupResult, Finding, Gravite, Host, Mission
from guardia.report.html_report import _build
from guardia.report.recap import build_grandes_lignes, build_journal, phrase_metier


class Cadre(unittest.TestCase):
    def test_banner_cite_323(self) -> None:
        self.assertIn("323-1", BANNER_COURT)
        self.assertIn("mandat", BANNER_COURT.lower())
        self.assertIn("32", RGPD_32)

    def test_identite_barre_pas_l_article(self) -> None:
        self.assertIn("Évaluation défensive LAN", IDENTITE_BARRE)
        self.assertIn("Platon-Y", IDENTITE_BARRE)
        self.assertNotIn("323-1", IDENTITE_BARRE)
        ui = (ROOT / "guardia" / "ui" / "app.py").read_text(encoding="utf-8")
        self.assertIn("IDENTITE_BARRE", ui)
        self.assertNotIn("BANNER_COURT", ui)
        self.assertIn("LogoGouttes", ui)

    def test_listes_vides(self) -> None:
        self.assertEqual(HORS_MOTEUR, ())
        self.assertEqual(SOUS_AVENANT, ())


class Recap(unittest.TestCase):
    def test_phrase_partage(self) -> None:
        f = Finding(
            id="usages-admin-share",
            titre="Partage ADMIN$ visible",
            pourquoi_nuit="Session trop large",
            preuve="smb-enum-shares",
            remede_etapes=["Restreindre le partage."],
            qui_peut="admin",
            priorite="tout_de_suite",
            gravite=Gravite.HAUTE,
            hote="10.0.0.2",
        )
        self.assertIn("fichiers", phrase_metier(f).lower())

    def test_grandes_lignes_en_tete(self) -> None:
        m = Mission(
            client="PME X",
            profil_moteur="pme",
            type_structure="pme",
            mandat_nda_signes=True,
        )
        h = Host(ip="10.0.0.8", hostname="pc-accueil", kind="pc")
        h.findings.append(
            Finding(
                id="audit-remote-3389",
                titre="RDP ouvert sur le LAN",
                pourquoi_nuit="Prise de poste",
                preuve="3389/tcp open",
                remede_etapes=["Couper RDP ou le cantonner au VPN admin."],
                qui_peut="prestataire",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote="10.0.0.8",
            )
        )
        result = CheckupResult(mission=m, hosts=[h])
        recap = build_grandes_lignes(result)
        self.assertTrue(recap["mandat"])
        self.assertGreaterEqual(len(recap["actions"]), 1)
        joined = " ".join(recap["risques"]).lower()
        self.assertTrue("écran" in joined or "main" in joined or "rdp" in joined)
        html = _build(result)
        pos_gl = html.find("Grandes lignes")
        pos_fiches = html.find("Fiches par appareil")
        pos_legal = html.find("323-1")
        self.assertGreaterEqual(pos_gl, 0)
        self.assertGreater(pos_fiches, pos_gl)
        self.assertGreaterEqual(pos_legal, 0)
        self.assertLess(pos_legal, pos_gl)
        self.assertIn("Page à lire en premier", html)
        self.assertIn("Journal d'actions", html)
        self.assertIn("Périmètre de cette visite", html)
        self.assertNotIn("Hors moteur", html)
        self.assertNotIn("YesWeHack", html)
        self.assertNotIn("Ce que ce papier n'est pas", html)
        self.assertNotIn("certificat de conformité délivré", html.lower())

    def test_journal_outils(self) -> None:
        m = Mission(client="U", mandat_nda_signes=True, cidr="192.168.1.0/24")
        j = build_journal(CheckupResult(mission=m, hosts=[], cidr="192.168.1.0/24"))
        self.assertTrue(j["mandat"])
        self.assertEqual(j["cidr"], "192.168.1.0/24")
        self.assertNotIn("hors", j)
        self.assertNotIn("sous_avenant", j)
        self.assertTrue(any("nmap" in o.lower() for o in j["outils"]))


if __name__ == "__main__":
    unittest.main()
