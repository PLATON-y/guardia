"""Tests de périmètre et de traçabilité."""
from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia import __version__
from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.engines.autorisations import build_autorisations
from guardia.engines.passi import (
    ATTESTATION_EXECUTE,
    ATTESTATION_NON,
    BRIQUES,
    COEUR,
    DISCLAIMER,
    JAMAIS_LANCER,
    QUALIF_ORGA,
    aptitude,
    attacher_traces,
    build_offre,
    orchestrer,
    perimetre,
    tracer,
)
from guardia.cli import load_mission


class Version(unittest.TestCase):
    def test_current_version(self) -> None:
        self.assertRegex(__version__, r"^\d+\.")


class Architecture(unittest.TestCase):
    def test_six_briques(self) -> None:
        ids = [b["id"] for b in BRIQUES]
        self.assertEqual(ids, ["recon", "vulns", "web", "systeme", "reseau", "forensics"])
        self.assertEqual(len(COEUR), 15)

    def test_avenant_jamais_auto(self) -> None:
        for nom in (
            "zaproxy",
            "burpsuite",
            "bloodhound",
            "impacket-scripts",
            "metasploit-framework",
            "ffuf",
            "masscan",
        ):
            self.assertIn(nom, JAMAIS_LANCER, nom)

    def test_offre_porte_briques(self) -> None:
        o = build_offre(Mission(), autorisations={"complet": True}, equipe="red")
        self.assertEqual(o["n_briques"], 6)
        self.assertFalse(o["passi_qualifie"])
        self.assertIn("qualification", (o.get("qualification_organisationnelle") or "").lower())
        noms = {b["id"] for b in o["briques"]}
        self.assertEqual(noms, {"recon", "vulns", "web", "systeme", "reseau", "forensics"})

    def test_orchestrer_skip_avenant(self) -> None:
        o = orchestrer(Mission(), autorisations={"complet": True}, equipe="red")
        self.assertTrue(o["execute"])
        blob = " ".join(
            str(a.get("nom") or "")
            for p in (o.get("play_briques") or [])
            for a in (p.get("actions") or [])
        ).lower()
        for nom in ("zaproxy", "burpsuite", "bloodhound", "impacket-scripts", "ghidra"):
            self.assertIn(nom, blob, nom)
        etats = [
            a.get("etat")
            for p in (o.get("play_briques") or [])
            for a in (p.get("actions") or [])
            if a.get("nom") in ("zaproxy", "burpsuite", "bloodhound", "impacket-scripts", "ffuf")
        ]
        self.assertTrue(etats)
        self.assertTrue(all(e == "avenant" for e in etats), etats)

    def test_sans_liasse_pas_de_lancement(self) -> None:
        o = orchestrer(Mission(), autorisations={"complet": False}, equipe="red")
        self.assertFalse(o["execute"])
        self.assertEqual(o["n_joue"], 0)
        etats = [
            a.get("etat")
            for p in (o.get("play_briques") or [])
            for a in (p.get("actions") or [])
        ]
        self.assertTrue(etats)
        self.assertTrue(all(e in ("pret", "absent", "avenant") for e in etats), set(etats))


class PerimetreTraces(unittest.TestCase):
    def test_red_example_perimetre(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-red.yaml")
        p = perimetre(m)
        self.assertEqual(p["cidr"], "192.0.2.0/24")
        self.assertIn("example.test", p["url"])
        self.assertTrue(p["signe"])
        self.assertIn("exploitation", p["exclusions"])

    def test_chaine_trace(self) -> None:
        f = Finding(
            id="t-1",
            titre="SMB ouvert",
            pourquoi_nuit="Partage visible",
            preuve="port 445",
            remede_etapes=["fermer 445"],
            qui_peut="IT",
            priorite="cette_semaine",
            gravite=Gravite.HAUTE,
            hote="192.168.1.10",
            commande="nmap -p 445 192.168.1.10",
            observation="SMB vu",
        )
        t = tracer(f, Mission(client="Structure Exemple Red"), "192.168.1.10")
        for k in ("mission", "actif", "test", "resultat", "preuve", "constat", "reco", "statut_auditeur"):
            self.assertIn(k, t)
        self.assertEqual(t["statut_auditeur"], "a_investiguer")
        self.assertEqual(t["mission"], "Structure Exemple Red")
        self.assertIn("nmap", t["test"])

    def test_attacher_traces(self) -> None:
        f = Finding(
            id="t-2",
            titre="TLS faible",
            pourquoi_nuit="Chiffrement trop vieux",
            preuve="TLS 1.0",
            remede_etapes=["passer en 1.2"],
            qui_peut="IT",
            priorite="cette_semaine",
            gravite=Gravite.MOYENNE,
        )
        h = Host(ip="192.168.1.1", findings=[f])
        offre: dict = {}
        attacher_traces(offre, [h], Mission(client="X"))
        self.assertEqual(offre["n_traces"], 1)
        self.assertEqual(offre["validation"]["a_investiguer"], 1)


class Documents(unittest.TestCase):
    def test_pas_de_demande(self) -> None:
        blob = (DISCLAIMER + ATTESTATION_EXECUTE + ATTESTATION_NON + QUALIF_ORGA).lower()
        for mot in ("demande", "candidature", "étoffe", "envie"):
            self.assertNotIn(mot, blob)
        self.assertIn("certificat", blob)
        self.assertIn("organisationnelle", blob)

    def test_aptitude_capacites(self) -> None:
        a = aptitude()
        self.assertFalse(a["passi_qualifie"])
        self.assertGreaterEqual(len(a["capacites_logicielles"]), 5)
        self.assertEqual(len(a["briques"]), 6)
        self.assertIn("Validation humaine", " ".join(a["controles"]))

    def test_red_example_execute(self) -> None:
        m = load_mission(ROOT / "missions" / "exemple-red.yaml")
        st = build_autorisations(m, pour_passi=True)
        self.assertFalse(st["complet"])
        o = orchestrer(m, autorisations=st, equipe="red")
        self.assertFalse(o["execute"])
        self.assertEqual(o["perimetre"]["cidr"], "192.0.2.0/24")


if __name__ == "__main__":
    unittest.main()
