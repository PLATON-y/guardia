from __future__ import annotations

import sys
import unittest
from pathlib import Path
from types import SimpleNamespace

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
import hashlib as _hashlib_red
import os as _os_red
_os_red.environ.setdefault(
    "GUARDIA_RED_PASSWORD_HASH",
    _hashlib_red.sha256(b"eoh19311936").hexdigest(),
)

from guardia.core.equipe import RED_ONLY, est_red, restreindre_blue, resoudre_equipe
from guardia.core.models import Mission
from guardia.core.orchestrate import (
    summarize_plan,
    want_audit,
    want_calibrage,
    want_greenbone,
    want_machines,
    want_passi,
    want_pistes,
)

RED_PASS = "eoh19311936"


def _args(**kw):
    base = dict(
        site=None,
        rgpd=False,
        no_rgpd=False,
        usages=False,
        no_usages=False,
        machines=False,
        pistes=False,
        no_pistes=False,
        llm=False,
        pdf=False,
        lynis=False,
        greenbone=False,
        trivy=False,
        audit=False,
        audit_full=False,
        full=False,
        all_ports=False,
        calibrage=False,
        no_calibrage=False,
        lan=False,
        no_lan=False,
        equipe="blue",
        red_pass="",
        passi=False,
        autorisations=False,
        restructure=False,
    )
    base.update(kw)
    return SimpleNamespace(**base)


class BlueNeFaitPasRed(unittest.TestCase):
    def test_mot_de_passe_requis(self) -> None:
        self.assertEqual(resoudre_equipe(_args(equipe="red"), Mission()), "blue")
        self.assertEqual(
            resoudre_equipe(_args(equipe="red", red_pass=RED_PASS), Mission()), "red"
        )

    def test_yaml_red_sans_pass_reste_blue(self) -> None:
        m = Mission()
        m.extras["equipe"] = "red"
        m.extras["passi"] = True
        m.extras["audit_full"] = True
        m.extras["all_ports"] = True
        self.assertFalse(est_red(_args(), m))
        coupes = restreindre_blue(_args(passi=True, audit_full=True), m)
        self.assertIn("passi", coupes)
        self.assertFalse(m.extras["passi"])

    def test_plan_blue_coupe_tout_le_red(self) -> None:
        m = Mission(profondeur="full", profil_moteur="pme", type_structure="pme")
        m.extras.update(
            {
                "passi": True,
                "audit_full": True,
                "all_ports": True,
                "greenbone": True,
                "pistes": True,
                "machines": True,
                "calibrage": True,
                "parc_inconnu": True,
            }
        )
        args = _args(
            equipe="blue",
            passi=True,
            audit_full=True,
            full=True,
            all_ports=True,
            greenbone=True,
            pistes=True,
            machines=True,
        )
        restreindre_blue(args, m)
        plan = summarize_plan(args, m)
        for key in (
            "passi",
            "autorisations",
            "calibrage",
            "greenbone",
            "trivy",
            "machines",
            "pistes",
            "profond",
        ):
            self.assertFalse(plan.get(key), key)
        self.assertIsNone(plan.get("audit"))
        self.assertEqual(plan.get("equipe"), "blue")
        self.assertFalse(want_passi(args, m))
        self.assertFalse(want_calibrage(args, m))
        self.assertFalse(want_pistes(args, m))
        self.assertFalse(want_machines(args, m))
        self.assertFalse(want_greenbone(args, m))
        self.assertIsNone(want_audit(args, m))

    def test_red_garde_les_modules(self) -> None:
        m = Mission(profil_moteur="pme", type_structure="pme")
        args = _args(
            equipe="red",
            red_pass=RED_PASS,
            passi=True,
            calibrage=True,
            pistes=True,
            audit_full=True,
            full=True,
        )
        self.assertEqual(restreindre_blue(args, m), [])
        plan = summarize_plan(args, m)
        self.assertTrue(plan["passi"])
        self.assertTrue(plan["calibrage"])
        self.assertTrue(plan["pistes"])
        self.assertEqual(plan["audit"], "full")
        self.assertTrue(plan["profond"])
        self.assertEqual(plan["equipe"], "red")

    def test_red_only_liste(self) -> None:
        for flag in ("passi", "audit_full", "all_ports", "greenbone", "pistes"):
            self.assertIn(flag, RED_ONLY)
