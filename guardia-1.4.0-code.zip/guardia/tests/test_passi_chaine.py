from __future__ import annotations

import unittest
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from guardia.core.models import Host, Mission
from guardia.engines.passi_assessment import build_assessment
from guardia.engines.passi_chaine import LIENS, attacher_chaines


def _host(ip: str, ports: list[int]) -> Host:
    h = Host(ip=ip, hostname=ip)
    h.ports = [{"port": p} for p in ports]
    return h


class ChainePassi(unittest.TestCase):
    def test_every_control_has_a_link(self) -> None:
        from guardia.engines.passi_assessment import CONTROLS

        missing = [c.id for c in CONTROLS if c.id not in LIENS]
        self.assertEqual(missing, [])

    def test_observations_feed_arch06(self) -> None:
        m = Mission(cidr="192.0.2.0/24", mandat_nda_signes=True)
        m.extras["passi"] = True
        m.extras["passi_activities"] = ["architecture"]
        a = build_assessment(
            m,
            {
                "hosts": [_host("192.0.2.10", [443])],
                "journal": {"etapes": [{"id": "nmap"}]},
            },
        )
        row = next(r for r in a["controls"] if r["id"] == "P-ARCH-06")
        self.assertEqual(row["status"], "verified")
        ch = next(c for c in a["chaines"] if c["controle"] == "P-ARCH-06")
        self.assertTrue(ch["preuve"])
        self.assertEqual(ch["action"], "passi-archi-observe")
        self.assertEqual(ch["outil"], "nmap")
        self.assertIn("#", ch["rapport"])

    def test_human_gate_stays_pending(self) -> None:
        m = Mission(cidr="192.0.2.0/24")
        m.extras["passi"] = True
        m.extras["architecture_docs"] = {"l2_l3": "doc.pdf"}
        a = build_assessment(m, {"evidence_data": {"architecture_docs": {"l2_l3": "doc.pdf"}}})
        row = next(r for r in a["controls"] if r["id"] == "P-ARCH-01")
        self.assertEqual(row["status"], "pending_human")

    def test_chain_length_matches_controls(self) -> None:
        a = build_assessment(Mission(cidr="192.0.2.0/24"), {})
        self.assertEqual(len(a["chaines"]), len(a["controls"]))
        self.assertGreater(a["summary"]["chaines_alimentees"], 0)


if __name__ == "__main__":
    unittest.main()
