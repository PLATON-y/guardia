"""Moteur de règles : applique les contrôles → findings + posture."""
from __future__ import annotations

import logging

from guardia.core.models import Gravite, Host, Mission, Posture
from guardia.rules import universal

log = logging.getLogger("guardia.rules")

_GRAV_ORDER = {
    Gravite.INFO: 0,
    Gravite.BASSE: 1,
    Gravite.MOYENNE: 2,
    Gravite.HAUTE: 3,
    Gravite.CRITIQUE: 4,
}


def posture_from_findings(host: Host) -> Posture:
    if not host.findings:
        return Posture.OK if host.ports is not None else Posture.INCONNU
    worst = max((_GRAV_ORDER.get(f.gravite, 0) for f in host.findings), default=0)
    if worst >= 4:
        return Posture.CRITIQUE
    if worst >= 3:
        return Posture.RISQUE
    if worst >= 2:
        return Posture.SURVEILLANCE
    if worst >= 1:
        return Posture.SURVEILLANCE
    return Posture.OK


def apply_rules(
    hosts: list[Host],
    mission: Mission,
    gateway: str = "",
) -> list[str]:
    """Enrichit chaque host avec findings + posture. Retourne erreurs soft.

    gateway: IP de la gateway officielle (netinfo) pour détecter 2e routeur / relais.
    """
    errors: list[str] = []
    for host in hosts:
        try:
            host.findings = universal.check_host(host, mission, hosts)
            host.posture = posture_from_findings(host)
        except Exception as exc:  # noqa: BLE001
            msg = f"règles {host.ip}: {exc}"
            log.warning(msg)
            errors.append(msg)
            host.errors.append(msg)
            host.posture = Posture.INCONNU
    try:
        net_f = universal.network_level_findings(hosts, mission, gateway=gateway)
        # rattache au premier host box/router ou au premier host
        anchor = next(
            (h for h in hosts if h.kind in ("box", "router")),
            hosts[0] if hosts else None,
        )
        if anchor and net_f:
            for f in net_f:
                if f.hote == "*":
                    f.hote = anchor.ip
            anchor.findings.extend(net_f)
            anchor.posture = posture_from_findings(anchor)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"règles réseau: {exc}")
    return errors
