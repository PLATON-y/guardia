"""Règles défensives universelles → Findings."""
from __future__ import annotations

import logging
import re
from typing import Iterable

from guardia.core.models import Finding, Gravite, Host, Mission

log = logging.getLogger("guardia.rules.universal")

ADMIN_PORTS = {
    22: "SSH",
    23: "Telnet",
    135: "RPC Windows",
    139: "NetBIOS",
    445: "SMB",
    3389: "RDP",
    5900: "VNC",
    5901: "VNC",
    8291: "WinBox",
    8080: "HTTP-alt / admin",
    8443: "HTTPS-alt / admin",
    9443: "HTTPS admin",
}

OBSOLETE = {
    21: "FTP",
    23: "Telnet",
    69: "TFTP",
    111: "RPC portmap",
}

IOT_KINDS = {"iot", "tv", "console", "camera", "phone"}
SENSITIVE_KINDS = {"pc", "nas", "box"}


def _ports_open(host: Host) -> dict[int, dict]:
    out: dict[int, dict] = {}
    for p in host.ports:
        try:
            out[int(p.get("port", 0))] = p
        except (TypeError, ValueError):
            continue
    return out


def _fid(prefix: str, host: Host, extra: str = "") -> str:
    base = f"{prefix}-{host.ip.replace('.', '_')}"
    return f"{base}-{extra}" if extra else base


def check_host(host: Host, mission: Mission, all_hosts: list[Host]) -> list[Finding]:
    findings: list[Finding] = []
    try:
        findings.extend(_admin_ports(host, mission))
        findings.extend(_obsolete(host, mission))
        findings.extend(_iot_flat(host, mission, all_hosts))
        findings.extend(_printer_exposure(host, mission))
        findings.extend(_nas_exposure(host, mission))
        findings.extend(_many_services(host, mission))
        findings.extend(_no_hostname(host, mission))
        findings.extend(_indices_faibles(host, mission, all_hosts))
    except Exception as exc:  # noqa: BLE001
        log.warning("règles %s: %s", host.ip, exc)
        host.errors.append(f"rules: {exc}")
    return findings


def _tu(mission: Mission) -> bool:
    return mission.ton_rapport == "tutoiement"


def _admin_ports(host: Host, mission: Mission) -> list[Finding]:
    out: list[Finding] = []
    openp = _ports_open(host)
    for port, label in ADMIN_PORTS.items():
        if port not in openp:
            continue
        if port in (8080, 8443, 9443) and host.kind in {"tv", "console", "phone", "camera", "iot"}:
            continue
        # SSH sur PC/NAS ok-ish en surveillance ; Telnet/RDP/VNC plus grave
        if port == 23:
            grav, prio = Gravite.CRITIQUE, "tout_de_suite"
        elif port in (3389, 5900, 5901, 445, 139):
            grav, prio = Gravite.HAUTE, "tout_de_suite"
        elif port in (8080, 8443, 9443) and host.kind in IOT_KINDS | {"imprimante", "camera"}:
            grav, prio = Gravite.HAUTE, "cette_semaine"
        else:
            grav, prio = Gravite.MOYENNE, "cette_semaine"
        toi = "toi" if _tu(mission) else "vous"
        out.append(
            Finding(
                id=_fid("admin", host, str(port)),
                titre=f"Service d'administration ouvert : {label} (port {port})",
                pourquoi_nuit=(
                    f"Sur le réseau local, n'importe quel appareil compromis peut tenter "
                    f"d'accéder à ce service. {label} mal protégé = porte d'entrée."
                ),
                preuve=f"{host.ip} port {port}/tcp ouvert"
                + (f" ({openp[port].get('product','')} {openp[port].get('version','')})".rstrip()
                   if openp[port].get("product") or openp[port].get("version") else ""),
                remede_etapes=[
                    f"Vérifie si {toi} as vraiment besoin de {label} sur cet appareil.",
                    "Si non : désactive le service dans les réglages de l'équipement.",
                    "Si oui : mot de passe fort unique, mises à jour, idéalement VLAN / réseau invité séparé.",
                    "Sur une box : active l'isolation Wi‑Fi / réseau invité pour les appareils sensibles.",
                ],
                qui_peut="toi-même" if _tu(mission) else "vous-même / prestataire IT",
                priorite=prio,
                gravite=grav,
                hote=host.ip,
            )
        )
    return out


def _obsolete(host: Host, mission: Mission) -> list[Finding]:
    out: list[Finding] = []
    openp = _ports_open(host)
    for port, label in OBSOLETE.items():
        if port not in openp:
            continue
        out.append(
            Finding(
                id=_fid("obs", host, str(port)),
                titre=f"Protocole fragile détecté : {label}",
                pourquoi_nuit=(
                    f"{label} est ancien, souvent sans chiffrement moderne. "
                    "Sur un LAN plat, un voisin réseau peut espionner ou abuser du service."
                ),
                preuve=f"{host.ip}:{port} ({label}) ouvert",
                remede_etapes=[
                    f"Désactive {label} si possible.",
                    "Remplace par une alternative chiffrée (SFTP/SSH, HTTPS, etc.).",
                    "Isolez l'équipement sur un réseau invité si vous devez le garder.",
                ],
                qui_peut="vous-même / prestataire",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote=host.ip,
            )
        )
    return out


def _iot_flat(host: Host, mission: Mission, all_hosts: list[Host]) -> list[Finding]:
    # Un téléphone perso va sur le LAN principal (le remède le dit). Pas un finding.
    if host.kind not in (IOT_KINDS - {"phone"}):
        return []
    sensitive = [h for h in all_hosts if h.kind in SENSITIVE_KINDS and h.ip != host.ip]
    if not sensitive and mission.profil_moteur == "maison":
        # même sans PC classé : signaler le risque de réseau plat pour IoT
        sensitive_note = "d'autres appareils du foyer"
    elif not sensitive:
        return []
    else:
        sensitive_note = ", ".join(f"{h.kind}:{h.ip}" for h in sensitive[:5])
    return [
        Finding(
            id=_fid("flat", host),
            titre=f"Appareil « {host.kind} » sur le même réseau que des postes sensibles",
            pourquoi_nuit=(
                "Les TV, consoles, caméras et objets connectés sont souvent moins à jour. "
                "Sur un réseau plat, une compromission IoT peut viser PC / NAS / box."
            ),
            preuve=f"{host.ip} typé {host.kind} ; voisins sensibles : {sensitive_note}",
            remede_etapes=[
                "Crée un Wi‑Fi invité (ou VLAN IoT) sur la box.",
                "Place TV / console / caméras / IoT sur ce réseau séparé.",
                "Garde PC, téléphones « perso/pro » et NAS sur le réseau principal.",
                "Désactive le Wi‑Fi direct entre invités si l'option existe (isolation client).",
            ],
            qui_peut="toi-même (réglages box) ou ÉOH en option",
            priorite="plus_tard" if mission.profil_moteur == "maison" else "cette_semaine",
            gravite=Gravite.INFO if mission.profil_moteur == "maison" else Gravite.MOYENNE,
            hote=host.ip,
        )
    ]


def _printer_exposure(host: Host, mission: Mission) -> list[Finding]:
    if host.kind != "imprimante" and not any(
        int(p.get("port", 0)) in (9100, 515, 631) for p in host.ports
    ):
        return []
    openp = _ports_open(host)
    interesting = [p for p in (80, 443, 631, 9100, 515, 23) if p in openp]
    if not interesting:
        return []
    return [
        Finding(
            id=_fid("print", host),
            titre="Imprimante exposée sur le LAN",
            pourquoi_nuit=(
                "Les imprimantes stockent parfois des documents, ont des interfaces d'admin "
                "faibles, et servent de pont si quelqu'un s'y connecte."
            ),
            preuve=f"{host.ip} ports {interesting}",
            remede_etapes=[
                "Change le mot de passe admin de l'imprimante (plus le défaut usine).",
                "Désactive les protocoles inutiles (Telnet, FTP, WSD si non utilisés).",
                "Mets à jour le firmware depuis le site du constructeur.",
                "Idéalement : VLAN imprimantes ou accès restreint.",
            ],
            qui_peut="toi-même / prestataire IT",
            priorite="cette_semaine",
            gravite=Gravite.MOYENNE,
            hote=host.ip,
        )
    ]


def _nas_exposure(host: Host, mission: Mission) -> list[Finding]:
    if host.kind != "nas" and not any(
        int(p.get("port", 0)) in (445, 139, 548, 5000, 5001, 2049) for p in host.ports
    ):
        return []
    if host.kind not in ("nas", "inconnu", "pc"):
        return []
    openp = _ports_open(host)
    if not (openp.keys() & {445, 139, 548, 5000, 5001, 2049}):
        return []
    # Only emit strong finding if clearly NAS-like or many share ports
    if host.kind != "nas" and not (openp.keys() & {5000, 5001, 548, 2049}):
        return []
    return [
        Finding(
            id=_fid("nas", host),
            titre="Stockage / NAS avec partages visibles",
            pourquoi_nuit=(
                "Un NAS concentre photos, sauvegardes, documents. Des partages trop ouverts "
                "sur le LAN = risque de lecture ou chiffrement ransomware latéral."
            ),
            preuve=f"{host.ip} services {sorted(openp.keys())}",
            remede_etapes=[
                "Compte admin fort + 2FA si disponible.",
                "Partages : droits minimaux, pas d'accès anonyme / guest.",
                "Mises à jour DSM/QTS/firmware à jour.",
                "Sauvegardes 3-2-1 ; idéalement snapshot + copie hors ligne.",
            ],
            qui_peut="toi-même / prestataire / ÉOH option",
            priorite="tout_de_suite",
            gravite=Gravite.HAUTE,
            hote=host.ip,
        )
    ]


def _many_services(host: Host, mission: Mission) -> list[Finding]:
    n = len(host.ports)
    seuil = 8 if mission.profondeur != "doux" else 12
    if n < seuil:
        return []
    return [
        Finding(
            id=_fid("surface", host),
            titre=f"Large surface d'exposition ({n} ports ouverts)",
            pourquoi_nuit=(
                "Plus il y a de services joignables, plus il y a de portes à surveiller. "
                "Souvent des services inutiles tournent « par défaut »."
            ),
            preuve=f"{host.ip}: {n} ports — "
            + ", ".join(f"{p.get('port')}/{p.get('name') or '?'}" for p in host.ports[:12]),
            remede_etapes=[
                "Liste les services vraiment utiles au quotidien.",
                "Coupe le reste (pare-feu local ou réglages de l'OS / firmware).",
                "Documente ce qui doit rester ouvert pour le prochain checkup.",
            ],
            qui_peut="prestataire IT / toi-même si à l'aise",
            priorite="plus_tard" if n < 15 else "cette_semaine",
            gravite=Gravite.BASSE if n < 15 else Gravite.MOYENNE,
            hote=host.ip,
        )
    ]


def _no_hostname(host: Host, mission: Mission) -> list[Finding]:
    if host.hostname or mission.profondeur == "doux":
        return []
    return [
        Finding(
            id=_fid("name", host),
            titre="Appareil sans nom lisible",
            pourquoi_nuit=(
                "Sans hostname, l'inventaire et le support deviennent pénibles — "
                "on ne sait plus quel téléphone / TV / PC c'est."
            ),
            preuve=f"{host.ip} hostname vide ; MAC={host.mac or 'n/a'} vendor={host.vendor or 'n/a'}",
            remede_etapes=[
                "Renomme l'appareil dans ses réglages réseau (ex. « TV-salon », « PC-Leo »).",
                "Sur la box : réserve DHCP + libellé si l'option existe.",
            ],
            qui_peut="toi-même",
            priorite="plus_tard",
            gravite=Gravite.INFO,
            hote=host.ip,
        )
    ]


# Ports souvent liés à une exposition accidentelle (pas une preuve d'attaque)
INDICE_PORTS = {
    5555: "ADB Android (port de debug) — souvent oublié sur un téléphone / box TV",
    2375: "Docker API non chiffrée — accès conteneurs possible depuis le LAN",
    2376: "Docker API TLS — vérifier qui y a accès sur le LAN",
    9200: "Elasticsearch — données souvent exposées sans auth sur labo/NAS",
    9300: "Elasticsearch transport",
    27017: "MongoDB — souvent sans auth sur install bricolée",
    6379: "Redis — souvent sans mot de passe en local",
    11211: "Memcached",
    5432: "PostgreSQL joignable sur le LAN",
    3306: "MySQL/MariaDB joignable sur le LAN",
    1433: "MSSQL joignable sur le LAN",
    5900: "VNC",
    5901: "VNC",
    3389: "RDP",
    1883: "MQTT (IoT) — parfois sans auth",
    8883: "MQTT TLS",
    502: "Modbus — automates / IoT industriel",
}


def _indices_faibles(host: Host, mission: Mission, all_hosts: list[Host]) -> list[Finding]:
    """Indices *faibles* : à vérifier humainement. Jamais « attaque confirmée »."""
    out: list[Finding] = []
    openp = _ports_open(host)
    tu = _tu(mission)

    for port, label in INDICE_PORTS.items():
        if port not in openp:
            continue
        # RDP/VNC déjà couverts en admin plus grave — ici on cible surtout les surprises
        if port in (3389, 5900, 5901) and host.kind in ("pc", "nas"):
            continue
        out.append(
            Finding(
                id=_fid("indice", host, str(port)),
                titre=f"Indice à vérifier : {label.split('—')[0].strip()} (port {port})",
                pourquoi_nuit=(
                    ("Ce service est joignable sur le LAN. Ça ne prouve "
                     "pas une attaque : ça peut être voulu, un oubli, ou un labo. "
                     "À confirmer avec l'occupant.")
                    if tu
                    else (
                        "Ce service est joignable sur le LAN. Cela ne prouve "
                        "pas une attaque : usage légitime, oubli ou labo possibles. "
                        "À confirmer avec le responsable."
                    )
                ),
                preuve=f"port {port}/tcp open — {label}",
                remede_etapes=[
                    "Confirme si ce service doit rester ouvert sur le LAN.",
                    "Sinon : coupe-le, mets une auth forte, ou isole l'appareil (Wi‑Fi invité / VLAN).",
                    "Regarde les journaux de la box / de l'appareil si tu cherches des traces d'abus (hors scope Guardia auto).",
                ],
                qui_peut="toi-même / admin local ; ÉOH en relecture",
                priorite="cette_semaine",
                gravite=Gravite.INFO,
                hote=host.ip,
            )
        )

    # Beaucoup de services ouverts sur un IoT / TV
    if host.kind in IOT_KINDS and len(openp) >= 8:
        out.append(
            Finding(
                id=_fid("indice-surface", host),
                titre="Surface réseau large pour un objet connecté",
                pourquoi_nuit=(
                    "Un IoT / TV / console avec beaucoup de ports ouverts augmente "
                    "la surface d'abus si l'appareil est faible — ce n'est pas une "
                    "preuve d'intrusion, juste un signal d'hygiène."
                ),
                preuve=f"{len(openp)} ports ouverts sur type={host.kind}",
                remede_etapes=[
                    "Isole l'appareil sur un Wi‑Fi invité / VLAN IoT.",
                    "Désactive les options « contrôle distant » inutiles.",
                ],
                qui_peut="toi-même (box)",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote=host.ip,
            )
        )

    # SMB / NetBIOS sur téléphone ou TV = bizarre
    if host.kind in {"phone", "tv", "console", "iot", "camera"} and (445 in openp or 139 in openp):
        out.append(
            Finding(
                id=_fid("indice-smb", host),
                titre="Partage de fichiers (SMB) sur un appareil non-PC",
                pourquoi_nuit=(
                    "SMB sur téléphone / TV / IoT est inhabituel à la maison. "
                    "Peut être une appli légitime — ou un service oublié. "
                    "Pas une preuve d'attaque."
                ),
                preuve=f"ports {[p for p in (139,445) if p in openp]} sur kind={host.kind}",
                remede_etapes=[
                    "Identifie l'appli qui ouvre le partage.",
                    "Désactive le partage s'il n'est pas nécessaire.",
                ],
                qui_peut="toi-même",
                priorite="cette_semaine",
                gravite=Gravite.INFO,
                hote=host.ip,
            )
        )

    return out



RELAY_KINDS = {"box", "router", "ap"}
SWITCH_KINDS = {"switch"}
SWITCH_VENDORS = re.compile(
    r"cisco|ubiquiti|unifi|mikrotik|netgear|hewlett|hpe|procurve|hp.?enterprise|"
    r"d-?link|tp-?link|zyxel|aruba|juniper",
    re.I,
)


def network_level_findings(
    hosts: list[Host],
    mission: Mission,
    gateway: str = "",
) -> list[Finding]:
    """Findings globaux (réseau plat, 2e gateway, switch mgmt, etc.)."""
    out: list[Finding] = []
    try:
        out.append(
            Finding(
                id="net-pas-detection-attaque",
                titre="Guardia ne détecte pas les attaques passées",
                pourquoi_nuit=(
                    "Ce checkup voit l'inventaire et l'exposition *aujourd'hui*. "
                    "Il ne lit pas l'historique des attaques, ni les virus, ni le trafic chiffré. "
                    "Des « indices à vérifier » peuvent apparaître : ce ne sont pas des preuves d'intrusion."
                ),
                preuve="périmètre défensif Guardia — pas de SOC / IDS / forensics",
                remede_etapes=[
                    "Pour chercher des traces d'abus : journaux de la box, postes, antivirus dédié, prestataire.",
                    "Traite chaque « indice » comme une question à poser, pas comme un verdict.",
                ],
                qui_peut="lecture commune ÉOH + client",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote="*",
            )
        )
        kinds = {h.kind for h in hosts}
        if kinds & IOT_KINDS and kinds & {"pc", "nas"}:
            out.append(
                Finding(
                    id="net-flat-lan",
                    titre="Réseau local plat (IoT et postes mélangés)",
                    pourquoi_nuit=(
                        "Tout le monde sur le même LAN : un objet connecté faible peut "
                        "devenir le point d'entrée vers les PC et le NAS."
                    ),
                    preuve=f"types vus: {', '.join(sorted(kinds))}",
                    remede_etapes=[
                        "Active un réseau / Wi‑Fi invité pour IoT et visiteurs.",
                        "Sépare admin / élèves si profil école.",
                        "Vérifie l'isolation client Wi‑Fi.",
                    ],
                    qui_peut="toi-même (box) / prestataire / ÉOH",
                    priorite="cette_semaine",
                    gravite=Gravite.MOYENNE,
                    hote="*",
                )
            )
        out.extend(_second_gateway(hosts, mission, gateway))
        out.extend(_forwarders(hosts, mission, gateway))
        out.extend(_switch_management(hosts, mission, gateway))
        out.extend(_pme_ecole_extra(hosts, mission, kinds))
    except Exception as exc:  # noqa: BLE001
        log.warning("network_level: %s", exc)
    return out


def _second_gateway(hosts: list[Host], mission: Mission, gateway: str) -> list[Finding]:
    """Plusieurs box/router/ap avec IP ≠ gateway unique → indice 2e routeur / relais."""
    relay = [h for h in hosts if h.kind in RELAY_KINDS]
    if gateway:
        others = [h for h in relay if h.ip != gateway]
    else:
        others = relay[1:] if len(relay) > 1 else []
    if not others:
        # aussi : 2+ hôtes typés box/router même sans gateway connue
        if len(relay) < 2:
            return []
        others = [h for h in relay if h.ip != (gateway or relay[0].ip)]
        if not others:
            return []
    ips = ", ".join(f"{h.ip}({h.kind})" for h in others[:6])
    gw_note = gateway or "(gateway non détectée)"
    return [
        Finding(
            id="net-second-gateway",
            titre="Indice : second routeur / relais / AP en plus de la gateway",
            pourquoi_nuit=(
                "Plusieurs équipements typés box, routeur ou AP avec une IP différente "
                "de la gateway officielle. Ça peut être un répéteur légitime, un double NAT, "
                "ou un relais non inventorié. Ce n'est pas une preuve d'attaque — à inventaire."
            ),
            preuve=f"gateway={gw_note} ; autres={ips}",
            remede_etapes=[
                "Vérifie si ces IP sont des répéteurs / AP connus (Ubiquiti, Freebox player, etc.).",
                "Si inconnu : isole-les, coupe le DHCP secondaire, évite le double NAT.",
                "Documente le matériel réseau officiel (switch, AP, box) pour le prochain checkup.",
            ],
            qui_peut="toi-même (box / inventaire) / prestataire",
            priorite="cette_semaine",
            gravite=Gravite.MOYENNE,
            hote="*",
        )
    ]


def _forwarders(hosts: list[Host], mission: Mission, gateway: str) -> list[Finding]:
    """Ports 53+80+443 sur non-gateway → possible forwarder / proxy (INFO prudent)."""
    out: list[Finding] = []
    # PME / école : un peu plus sensible ; maison aussi en INFO
    for h in hosts:
        if gateway and h.ip == gateway:
            continue
        if h.kind in RELAY_KINDS:
            # déjà couvert par second-gateway si ≠ gw
            continue
        openp = _ports_open(h)
        if not ({53, 80, 443} <= set(openp.keys())):
            continue
        out.append(
            Finding(
                id=_fid("forwarder", h),
                titre="Indice : hôte non-gateway avec DNS + HTTP/S (possible forwarder)",
                pourquoi_nuit=(
                    "DNS (53) et web (80/443) ouverts sur une machine qui n'est pas la "
                    "gateway officielle. Peut être un proxy, un Pi-hole, un labo — ou un "
                    "relais applicatif oublié. Indice INFO, pas un verdict."
                ),
                preuve=f"{h.ip} ports 53+80+443 ; kind={h.kind} ; gw={gateway or '?'}",
                remede_etapes=[
                    "Confirme le rôle de cette machine (DNS local, reverse-proxy, labo).",
                    "Si non voulu : coupe les services ou isole l'hôte.",
                    "En PME : documente les reverse-proxies et DNS internes autorisés.",
                ],
                qui_peut="toi-même / admin local",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote=h.ip,
            )
        )
    return out


def _switch_management(hosts: list[Host], mission: Mission, gateway: str) -> list[Finding]:
    """SNMP / admin web sur vendor switch → finding management."""
    out: list[Finding] = []
    for h in hosts:
        openp = _ports_open(h)
        is_switch = h.kind in SWITCH_KINDS or (
            SWITCH_VENDORS.search(f"{h.vendor} {h.hostname}") is not None
            and h.kind not in ("pc", "phone", "imprimante", "nas", "camera", "tv", "console", "iot")
        )
        if not is_switch and not (161 in openp and openp.keys() & {22, 80, 443, 8080, 8443}):
            continue
        mgmt = sorted(p for p in (161, 22, 80, 443, 8080, 8443) if p in openp)
        if not mgmt:
            continue
        if gateway and h.ip == gateway and h.kind == "box":
            continue
        grav = Gravite.MOYENNE if 161 in openp else Gravite.INFO
        out.append(
            Finding(
                id=_fid("switch-mgmt", h),
                titre="Interface d'administration de switch / équipement réseau",
                pourquoi_nuit=(
                    "Un switch ou équipement réseau avec SNMP / SSH / web admin joignable "
                    "sur le LAN élargit la surface si le mot de passe est faible. "
                    "Indice d'inventaire L2 — pas une preuve d'intrusion."
                ),
                preuve=f"{h.ip} kind={h.kind} vendor={h.vendor or 'n/a'} ports={mgmt}",
                remede_etapes=[
                    "Change le mot de passe admin (plus le défaut usine).",
                    "Désactive SNMP v1/v2c community « public » ; préfère SNMPv3 ou coupe SNMP.",
                    "Restreins l'admin (VLAN management / IP source) si possible.",
                    "Ajoute cet équipement à l'inventaire matériel officiel.",
                ],
                qui_peut="toi-même / prestataire IT",
                priorite="cette_semaine",
                gravite=grav,
                hote=h.ip,
            )
        )
    return out


def _pme_ecole_extra(hosts: list[Host], mission: Mission, kinds: set[str]) -> list[Finding]:
    """Renforce légèrement les règles PME / école existantes."""
    out: list[Finding] = []
    profil = mission.profil_moteur
    if profil == "ecole":
        out.append(
            Finding(
                id="net-ecole-seg",
                titre="Parc scolaire : vérifier la segmentation élèves / admin",
                pourquoi_nuit=(
                    "Sur un parc scolaire, mélanger élèves et administration expose "
                    "notes, dossiers et comptes enseignants."
                ),
                preuve="profil moteur=ecole ; checkup défensif — segmentation à confirmer humainement",
                remede_etapes=[
                    "VLAN ou SSID séparés : élèves / enseignants / admin / invités.",
                    "Comptes partagés : à bannir sur les postes admin.",
                    "IoT de classe sur le SSID élèves ou IoT, jamais admin.",
                    "Inventorie switches / AP : pas d'admin ouvert vers le SSID élèves.",
                ],
                qui_peut="DSI / prestataire IT établissement ; ÉOH en accompagnement",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote="*",
            )
        )
        # RDP / SMB visibles côté école
        rdp_smb = [
            h for h in hosts
            if any(int(p.get("port", 0)) in (3389, 445, 139) for p in h.ports)
        ]
        if rdp_smb:
            ips = ", ".join(h.ip for h in rdp_smb[:8])
            out.append(
                Finding(
                    id="net-ecole-rdp-smb",
                    titre="École : RDP / SMB visibles sur le LAN",
                    pourquoi_nuit=(
                        "Bureau à distance ou partages Windows joignables depuis le même "
                        "réseau que d'éventuels postes élèves : surface latérale élevée."
                    ),
                    preuve=f"hôtes avec 3389/445/139 : {ips}",
                    remede_etapes=[
                        "Restreins RDP/SMB au VLAN admin.",
                        "Désactive les partages inutiles ; comptes individuels.",
                    ],
                    qui_peut="DSI / prestataire",
                    priorite="tout_de_suite",
                    gravite=Gravite.HAUTE,
                    hote="*",
                )
            )
    if profil == "pme":
        out.append(
            Finding(
                id="net-pme-hygiene",
                titre="PME : vérifier partages, RDP et matériel réseau inventorié",
                pourquoi_nuit=(
                    "En PME, RDP ouvert, partages trop larges et switches / AP non inventoriés "
                    "sont des causes fréquentes d'abus latéral — sans être une preuve d'attaque."
                ),
                preuve=f"profil=pme ; types={', '.join(sorted(kinds)) or 'n/a'}",
                remede_etapes=[
                    "Inventorie box, switches, AP, NAS (IP + rôle).",
                    "RDP : VPN ou IP source restreinte ; pas d'exposition « tout le LAN » si évitable.",
                    "Partages SMB : droits minimaux, pas de guest.",
                    "Wi‑Fi invité séparé pour visiteurs / IoT.",
                ],
                qui_peut="toi-même / prestataire IT / ÉOH",
                priorite="cette_semaine",
                gravite=Gravite.MOYENNE,
                hote="*",
            )
        )
        # SMB/RDP count
        exposed = [
            h for h in hosts
            if any(int(p.get("port", 0)) in (3389, 445) for p in h.ports)
            and h.kind in ("pc", "nas", "inconnu")
        ]
        if len(exposed) >= 2:
            out.append(
                Finding(
                    id="net-pme-multi-rdp-smb",
                    titre="PME : plusieurs postes avec RDP ou SMB ouverts",
                    pourquoi_nuit=(
                        "Plusieurs machines exposent RDP ou SMB sur le même LAN plat : "
                        "si un poste tombe, le voisinage est à portée."
                    ),
                    preuve=", ".join(f"{h.ip}({h.kind})" for h in exposed[:8]),
                    remede_etapes=[
                        "Centralise les partages sur un NAS / serveur dédié.",
                        "Coupe RDP là où il n'est pas nécessaire.",
                        "Segmentes admin / utilisateurs si possible.",
                    ],
                    qui_peut="prestataire IT / toi-même",
                    priorite="cette_semaine",
                    gravite=Gravite.MOYENNE,
                    hote="*",
                )
            )
    return out
