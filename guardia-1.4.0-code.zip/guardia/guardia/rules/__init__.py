"""Règles défensives Guardia."""
