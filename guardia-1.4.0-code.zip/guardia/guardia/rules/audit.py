"""Règles « audit warning » — findings différenciants, toujours défensifs."""
from __future__ import annotations

from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.core.texte import has_weak_cipher, ssl_cert_expired, strip_ansi

# Mots-clés suites TLS faibles (ssl-enum-ciphers, informatif)
# « null » seul matche le compresseur NULL de nmap — ce n'est pas une suite faible.


def _port_nums(host: Host) -> set[int]:
    out: set[int] = set()
    for p in host.ports or []:
        try:
            out.add(int(p.get("port", -1)))
        except (TypeError, ValueError):
            pass
    return out


def _scripts(host: Host) -> dict[str, str]:
    merged: dict[str, str] = {}
    for p in host.ports or []:
        sc = p.get("scripts") or {}
        if isinstance(sc, dict):
            merged.update({str(k): str(v) for k, v in sc.items()})
    return merged


def _scripts_joined(host: Host, script_id: str) -> str:
    chunks: list[str] = []
    for p in host.ports or []:
        sc = p.get("scripts") or {}
        if isinstance(sc, dict) and script_id in sc:
            chunks.append(str(sc[script_id]))
    return "\n".join(chunks)


def check_audit_host(host: Host, mission: Mission) -> list[Finding]:
    """Findings audit (préfixe id audit-)."""
    findings: list[Finding] = []
    ports = _port_nums(host)
    scripts = _scripts(host)
    tut = mission.ton_rapport == "tutoiement"
    toi = "tu" if tut else "vous"
    poss = "pourras" if tut else "pourrez"

    # Surface d'attaque élargie
    if len(ports) >= 8:
        findings.append(
            Finding(
                id="audit-surface-large",
                titre="(audit) Surface de services élevée",
                pourquoi_nuit=(
                    f"Beaucoup de ports ouverts ({len(ports)}) augmentent la chance "
                    "qu'un service oublié soit faible ou exposé."
                ),
                preuve=f"{host.ip} ports={sorted(ports)[:20]}{'…' if len(ports)>20 else ''}",
                remede_etapes=[
                    "Lister chaque service encore utile métier / foyer.",
                    "Fermer ou filtrer (firewall box) ce qui n'est plus nécessaire.",
                    "Documenter les ports restants dans l'inventaire client.",
                ],
                qui_peut="Admin réseau / prestataire",
                priorite="cette_semaine",
                gravite=Gravite.MOYENNE,
                hote=host.ip,
            )
        )

    # RDP / VNC exposés
    for p, name in ((3389, "RDP"), (5900, "VNC")):
        if p in ports:
            findings.append(
                Finding(
                    id=f"audit-remote-{p}",
                    titre=f"(audit) {name} détecté — à verrouiller",
                    pourquoi_nuit=(
                        f"Un accès distant ({name}) sur le LAN peut être abusé "
                        "si un poste est compromis ou mal segmenté."
                    ),
                    preuve=f"{host.ip}:{p}/{name}",
                    remede_etapes=[
                        f"Réserver {name} aux comptes qui en ont besoin.",
                        "MFA / mots de passe longs ; pas d'exposition Internet.",
                        "VLAN / réseau invité séparé si possible.",
                    ],
                    qui_peut="Admin système",
                    priorite="tout_de_suite",
                    gravite=Gravite.HAUTE,
                    hote=host.ip,
                )
            )

    # Bases de données
    for p, name in (
        (3306, "MySQL/MariaDB"),
        (5432, "PostgreSQL"),
        (27017, "MongoDB"),
        (6379, "Redis"),
        (1433, "MSSQL"),
    ):
        if p in ports:
            findings.append(
                Finding(
                    id=f"audit-db-{p}",
                    titre=f"(audit) Base / datastore {name} visible",
                    pourquoi_nuit="Un datastore joignable depuis le LAN élargit l'impact d'un poste infecté.",
                    preuve=f"{host.ip}:{p}/{name}",
                    remede_etapes=[
                        "Binder le service sur localhost ou VLAN admin.",
                        "Auth forte ; pas de compte anonyme.",
                        "Sauvegardes chiffrées testées.",
                    ],
                    qui_peut="Admin / DevOps",
                    priorite="cette_semaine",
                    gravite=Gravite.HAUTE,
                    hote=host.ip,
                )
            )

    # SMB signing
    smb = scripts.get("smb-security-mode") or ""
    if smb and (
        "message_signing: disabled" in smb.lower()
        or "message signing is disabled" in smb.lower()
    ):
        findings.append(
            Finding(
                id="audit-smb-signing",
                titre="(audit) SMB sans signature de messages",
                pourquoi_nuit=(
                    "Sans signing, un attaquant local peut plus facilement "
                    "relayer / altérer des sessions SMB."
                ),
                preuve=f"{host.ip} smb-security-mode: {smb[:180]}",
                remede_etapes=[
                    "Activer « Require Security Signature » côté serveur / poste.",
                    "Retirer SMBv1 si encore présent.",
                    "Limiter les partages aux comptes nécessaires.",
                ],
                qui_peut="Admin Windows",
                priorite="cette_semaine",
                gravite=Gravite.MOYENNE,
                hote=host.ip,
            )
        )

    # Certificat SSL infos
    ssl = scripts.get("ssl-cert") or ""
    low = ssl.lower()
    if ssl and ssl_cert_expired(ssl):
        findings.append(
            Finding(
                id="audit-tls-expired",
                titre="(audit) Certificat TLS expiré / invalide",
                pourquoi_nuit=(
                    "Un certificat pourri casse la confiance et masque "
                    "parfois un service mal maintenu."
                ),
                preuve=strip_ansi(f"{host.ip} ssl-cert: {ssl[:200]}"),
                remede_etapes=[
                    "Renouveler le certificat (Let's Encrypt / PKI interne).",
                    "Vérifier la date système de l'hôte.",
                    "Surveiller l'expiration (alerte J-30).",
                ],
                qui_peut="Admin web / box",
                priorite="cette_semaine",
                gravite=Gravite.MOYENNE,
                hote=host.ip,
            )
        )
    elif ssl and ("commonname" in low or "subject:" in low):
        findings.append(
            Finding(
                id="audit-tls-present",
                titre="(audit) Service TLS présent — à inventorier",
                pourquoi_nuit="Utile pour la cartographie : savoir quel service HTTPS tourne où.",
                preuve=strip_ansi(f"{host.ip} ssl-cert: {ssl[:160]}"),
                remede_etapes=[
                    f"Noter le CN / SANs dans l'inventaire ({toi} {poss} suivre les renouvellements).",
                    "S'assurer que ce n'est pas une page admin exposée sans besoin.",
                ],
                qui_peut="Opérateur ÉOH / client",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote=host.ip,
            )
        )

    # http-title admin-ish
    title = scripts.get("http-title") or ""
    if title:
        tlow = title.lower()
        if any(k in tlow for k in ("admin", "login", "router", "management", "webui", "nas")):
            findings.append(
                Finding(
                    id="audit-http-admin",
                    titre="(audit) Interface web d'admin / login repérée",
                    pourquoi_nuit=(
                        "Une console d'admin sur le LAN est une cible privilégiée "
                        "si le Wi‑Fi est partagé."
                    ),
                    preuve=f"{host.ip} http-title: {title[:160]}",
                    remede_etapes=[
                        "Mot de passe unique fort ; désactiver comptes par défaut.",
                        "Restreindre l'accès (IP admin / VLAN).",
                        "Mettre à jour le firmware / l'appli.",
                    ],
                    qui_peut="Admin box / NAS",
                    priorite="tout_de_suite",
                    gravite=Gravite.MOYENNE,
                    hote=host.ip,
                )
            )

    # http-headers — bannières Server / X-Powered-By (hygiène)
    headers = _scripts_joined(host, "http-headers") or scripts.get("http-headers") or ""
    if headers:
        hlow = headers.lower()
        noisy = any(
            k in hlow
            for k in (
                "server:",
                "x-powered-by:",
                "x-aspnet-version:",
                "x-generator:",
            )
        )
        outdatedish = any(
            k in hlow
            for k in (
                "apache/2.2",
                "apache/2.4.1",
                "nginx/1.1",
                "nginx/1.0",
                "iis/6",
                "iis/7",
                "php/5.",
                "openssl/0.",
                "openssl/1.0",
            )
        )
        if outdatedish:
            findings.append(
                Finding(
                    id="audit-http-banner-old",
                    titre="(audit) Bannière HTTP / stack potentiellement datée",
                    pourquoi_nuit=(
                        "Une version exposée dans Server/X-Powered-By facilite le "
                        "ciblage et signale souvent un manque de maintenance."
                    ),
                    preuve=f"{host.ip} http-headers: {headers[:220]}",
                    remede_etapes=[
                        "Mettre à jour le serveur web / runtime (Apache, nginx, PHP…).",
                        "Masquer ou minimiser les en-têtes Server / X-Powered-By.",
                        "Vérifier le support éditeur et planifier les patchs.",
                    ],
                    qui_peut="Admin web",
                    priorite="cette_semaine",
                    gravite=Gravite.MOYENNE,
                    hote=host.ip,
                )
            )
        elif noisy:
            findings.append(
                Finding(
                    id="audit-http-headers-info",
                    titre="(audit) En-têtes HTTP bavards (hygiène INFO)",
                    pourquoi_nuit=(
                        "Server / X-Powered-By renseignent inutilement la stack — "
                        "hygiène d'exposition, pas une faille à elle seule."
                    ),
                    preuve=f"{host.ip} http-headers: {headers[:200]}",
                    remede_etapes=[
                        "Réduire les en-têtes (server_tokens / ServerSignature / "
                        "remove Server header).",
                        "Documenter la stack dans l'inventaire interne plutôt qu'en clair.",
                    ],
                    qui_peut="Admin web",
                    priorite="plus_tard",
                    gravite=Gravite.INFO,
                    hote=host.ip,
                )
            )

    # ssh-hostkey — inventaire
    ssh_hk = _scripts_joined(host, "ssh-hostkey") or scripts.get("ssh-hostkey") or ""
    if ssh_hk.strip():
        findings.append(
            Finding(
                id="audit-ssh-hostkey",
                titre="(audit) Empreinte SSH hostkey — inventaire",
                pourquoi_nuit=(
                    "Conserver les fingerprints permet de détecter un changement "
                    "inattendu (usurpation / réinstall non documentée)."
                ),
                preuve=f"{host.ip} ssh-hostkey: {ssh_hk[:200]}",
                remede_etapes=[
                    "Noter les fingerprints SHA256 dans l'inventaire sécurisé.",
                    "Alerter l'équipe si une clé change sans maintenance prévue.",
                    "Désactiver SSH password-only ; clés + MFA jump host si possible.",
                ],
                qui_peut="Admin système / opérateur ÉOH",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote=host.ip,
            )
        )

    # ssl-enum-ciphers — suites faibles
    ciphers = _scripts_joined(host, "ssl-enum-ciphers") or scripts.get("ssl-enum-ciphers") or ""
    if ciphers and has_weak_cipher(ciphers):
        findings.append(
            Finding(
                id="audit-tls-weak-ciphers",
                titre="(audit) Suites TLS faibles repérées",
                pourquoi_nuit=(
                    "Des suites RC4 / DES / NULL / export affaiblissent le "
                    "canal et signalent une config TLS négligée."
                ),
                preuve=strip_ansi(f"{host.ip} ssl-enum-ciphers: {ciphers[:240]}"),
                    remede_etapes=[
                        "Désactiver RC4, DES, NULL, export et suites SSL2/SSL3.",
                        "Imposer TLS 1.2+ (idéalement TLS 1.3) côté service / reverse-proxy.",
                        "Retester après durcissement (Qualys SSL Labs / testssl en labo).",
                    ],
                    qui_peut="Admin web / infra",
                    priorite="cette_semaine",
                    gravite=Gravite.MOYENNE,
                    hote=host.ip,
                )
            )

    # Imprimante JetDirect 9100
    if 9100 in ports:
        findings.append(
            Finding(
                id="audit-printer-9100",
                titre="(audit) Port imprimante 9100 (JetDirect) ouvert",
                pourquoi_nuit=(
                    "Le port 9100 accepte souvent des jobs bruts sans auth — "
                    "risque de spam impression / fuite latérale sur le LAN."
                ),
                preuve=f"{host.ip}:9100",
                remede_etapes=[
                    "Segmenter les imprimantes sur un VLAN print dédié.",
                    "Couper 9100 si l'impression passe déjà par IPP/SMB authentifié.",
                    "Désactiver les protocoles inutiles sur le firmware imprimante.",
                ],
                qui_peut="Admin réseau / parc",
                priorite="cette_semaine",
                gravite=Gravite.MOYENNE,
                hote=host.ip,
            )
        )

    # FTP cleartext
    if 21 in ports:
        findings.append(
            Finding(
                id="audit-ftp-cleartext",
                titre="(audit) FTP (21) en clair",
                pourquoi_nuit=(
                    "FTP circule sans chiffrement — identifiants et fichiers "
                    "interceptables sur le LAN."
                ),
                preuve=f"{host.ip}:21",
                remede_etapes=[
                    "Remplacer par SFTP ou FTPS.",
                    "Désactiver FTP anonyme et comptes par défaut.",
                    "Filtrer le port 21 sur le firewall si le service n'est plus utile.",
                ],
                qui_peut="Admin système",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote=host.ip,
            )
        )

    # Telnet / cleartext
    if 23 in ports:
        findings.append(
            Finding(
                id="audit-telnet",
                titre="(audit) Telnet ouvert",
                pourquoi_nuit="Telnet circule en clair — credentials et sessions récupérables sur le LAN.",
                preuve=f"{host.ip}:23",
                remede_etapes=[
                    "Remplacer par SSH.",
                    "Couper le service Telnet sur l'équipement.",
                    "Vérifier qu'aucun script métier ne dépend encore de Telnet.",
                ],
                qui_peut="Admin réseau",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote=host.ip,
            )
        )

    return findings


def apply_audit_rules(hosts: list[Host], mission: Mission) -> list[str]:
    """Ajoute les findings audit et recalcule la posture."""
    from guardia.rules.engine import posture_from_findings

    errors: list[str] = []
    for host in hosts:
        try:
            extra = check_audit_host(host, mission)
            # évite doublons d'id
            existing = {f.id for f in host.findings}
            for f in extra:
                if f.id not in existing:
                    host.findings.append(f)
            host.posture = posture_from_findings(host)
        except Exception as exc:  # noqa: BLE001
            errors.append(f"audit-rules {host.ip}: {exc}")
    return errors
