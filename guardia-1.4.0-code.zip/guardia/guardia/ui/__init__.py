"""Interfaces utilisateur Guardia (wizard CLI + UI Tk)."""
