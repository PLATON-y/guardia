"""Popup Tk : créer une mission.yaml (mêmes questions que le wizard CLI)."""
from __future__ import annotations

from datetime import date
from pathlib import Path
from typing import Any
import tkinter as tk
from tkinter import messagebox, ttk

from guardia.core.paths import MISSIONS
from guardia.ui.wizard import _dump_mission

STRUCTURES = [
    ("foyer", "Particulier / foyer"),
    ("pme", "Entreprise / PME"),
    ("association", "Association"),
    ("ecole", "École / parc scolaire"),
    ("organisme", "Autre organisme / collectivité"),
    ("parc_entreprise", "Parc informatique d'entreprise"),
    ("parc_particulier", "Parc multi-appareils particulier"),
]

TAILLES = [
    ("xs", "Quelques appareils (1–5)"),
    ("s", "Une petite dizaine"),
    ("m", "Quelques dizaines"),
    ("l", "Gros parc"),
    ("inconnu", "Parc inconnu → full"),
]

ENJEUX = [
    ("perso", "Vie privée / données perso"),
    ("metier", "Activité / facturation / pro"),
    ("mineurs", "Élèves / mineurs"),
    ("eleves", "Élèves (alias)"),
    ("image", "Réputation / confiance"),
    ("continuite", "Continuité de service"),
    ("donnees", "Données métier"),
]

EQUIP = [
    ("pc", "PC / portables"),
    ("box", "Box / routeur / Wi-Fi"),
    ("tv", "TV connectée"),
    ("console", "Console de jeu"),
    ("phone", "Téléphones / tablettes"),
    ("imprimante", "Imprimantes"),
    ("nas", "NAS / stockage"),
    ("camera", "Caméras / IoT"),
    ("serveur", "Serveurs"),
    ("invite", "Wi-Fi invité / bornes"),
    ("iot", "IoT divers"),
    ("industriel", "Machines industrielles / automates"),
]

PROFONDEURS = [
    ("doux", "Doux — inventaire + alertes évidentes"),
    ("standard", "Standard — équilibre démo"),
    ("approfondi", "Approfondi — plus long"),
    ("full", "Full — parc inconnu + top-200 ports"),
]

PROFIL_MAP = {
    "foyer": "maison",
    "parc_particulier": "maison",
    "pme": "pme",
    "parc_entreprise": "pme",
    "association": "pme",
    "ecole": "ecole",
    "organisme": "pme",
}


class NewMissionDialog(tk.Toplevel):
    """Formulaire mission → écrit un YAML dans missions/ et retourne le chemin."""

    def __init__(self, master: tk.Misc) -> None:
        super().__init__(master)
        self.title("Nouvelle mission Guardia")
        self.resizable(True, True)
        try:
            from guardia.ui.app import BG
            self.configure(bg=BG)
        except Exception:
            pass
        self.result_path: Path | None = None
        self.transient(master)
        self.grab_set()

        outer = ttk.Frame(self, padding=12)
        outer.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            outer,
            text="Fiche mission (pas de scan ici) — réponses → fichier YAML",
            wraplength=520,
        ).pack(anchor=tk.W, pady=(0, 8))

        # Zone de formulaire défilable : la fenêtre s'adapte à l'écran sans
        # perdre les options lorsque la hauteur disponible est réduite.
        canvas = tk.Canvas(outer, highlightthickness=0, bg=BG)
        scroll = ttk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview)
        form = ttk.Frame(canvas, padding=4)
        form.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        window_id = canvas.create_window((0, 0), window=form, anchor=tk.NW)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _resize_form(event: tk.Event) -> None:  # type: ignore[type-arg]
            canvas.itemconfigure(window_id, width=max(event.width, 1))

        canvas.bind("<Configure>", _resize_form)

        def _on_mousewheel(event: tk.Event) -> None:  # type: ignore[type-arg]
            delta = getattr(event, "delta", 0) or 0
            if delta:
                canvas.yview_scroll(int(-delta / 120), "units")

        def _on_linux_scroll(event: tk.Event) -> None:  # type: ignore[type-arg]
            canvas.yview_scroll(-1 if event.num == 4 else 1, "units")

        def _bind_wheel(_event: tk.Event | None = None) -> None:  # type: ignore[type-arg]
            canvas.bind_all("<MouseWheel>", _on_mousewheel)
            canvas.bind_all("<Button-4>", _on_linux_scroll)
            canvas.bind_all("<Button-5>", _on_linux_scroll)

        def _unbind_wheel(_event: tk.Event | None = None) -> None:  # type: ignore[type-arg]
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                try:
                    canvas.unbind_all(seq)
                except tk.TclError:
                    pass

        self._unbind_wheel = _unbind_wheel
        canvas.bind("<Enter>", _bind_wheel)
        canvas.bind("<Leave>", _unbind_wheel)

        self.var_client = tk.StringVar(value="Client")
        self.var_personne = tk.StringVar(value="")
        self.var_cidr = tk.StringVar(value="192.168.1.0/24")
        self.var_structure = tk.StringVar(value="foyer")
        self.var_taille = tk.StringVar(value="xs")
        self.var_profondeur = tk.StringVar(value="standard")
        self.var_mandat = tk.BooleanVar(value=False)
        self.var_llm = tk.BooleanVar(value=False)
        self.var_pdf = tk.BooleanVar(value=False)
        self.var_all_ports = tk.BooleanVar(value=False)
        self.var_max_time = tk.StringVar(value="7200")
        self.var_site = tk.BooleanVar(value=False)
        self.var_site_url = tk.StringVar(value="https://example.test")
        self.var_rgpd = tk.BooleanVar(value=False)
        self.var_usages = tk.BooleanVar(value=False)
        self.var_machines = tk.BooleanVar(value=False)
        self.var_greenbone = tk.BooleanVar(value=False)
        self.var_lynis = tk.BooleanVar(value=False)
        self.var_trivy = tk.BooleanVar(value=False)
        self.var_pistes = tk.BooleanVar(value=False)
        self.var_passi = tk.BooleanVar(value=False)
        self.var_autorisations = tk.BooleanVar(value=False)
        self._rgpd_cfg: dict[str, Any] | None = None
        self._usages_cfg: dict[str, Any] | None = None

        r = 0
        ttk.Label(form, text="Client / foyer / structure").grid(row=r, column=0, sticky=tk.W, pady=2)
        ttk.Entry(form, textvariable=self.var_client, width=42).grid(row=r, column=1, sticky=tk.EW, pady=2)
        r += 1
        ttk.Label(form, text="Personne commune (rapport)").grid(row=r, column=0, sticky=tk.W, pady=2)
        ttk.Entry(form, textvariable=self.var_personne, width=42).grid(row=r, column=1, sticky=tk.EW, pady=2)
        r += 1
        ttk.Label(form, text="CIDR autorisé").grid(row=r, column=0, sticky=tk.W, pady=2)
        ttk.Entry(form, textvariable=self.var_cidr, width=42).grid(row=r, column=1, sticky=tk.EW, pady=2)
        r += 1

        ttk.Label(form, text="Pour qui ?").grid(row=r, column=0, sticky=tk.NW, pady=2)
        self.cb_struct = ttk.Combobox(
            form,
            textvariable=self.var_structure,
            values=[c for c, _ in STRUCTURES],
            state="readonly",
            width=40,
        )
        self.cb_struct.grid(row=r, column=1, sticky=tk.EW, pady=2)
        r += 1

        ttk.Label(form, text="Taille du parc").grid(row=r, column=0, sticky=tk.W, pady=2)
        ttk.Combobox(
            form,
            textvariable=self.var_taille,
            values=[c for c, _ in TAILLES],
            state="readonly",
            width=40,
        ).grid(row=r, column=1, sticky=tk.EW, pady=2)
        r += 1

        ttk.Label(form, text="Profondeur").grid(row=r, column=0, sticky=tk.W, pady=2)
        ttk.Combobox(
            form,
            textvariable=self.var_profondeur,
            values=[c for c, _ in PROFONDEURS],
            state="readonly",
            width=40,
        ).grid(row=r, column=1, sticky=tk.EW, pady=2)
        r += 1

        # Enjeux
        ttk.Label(form, text="Enjeux (priorités)").grid(row=r, column=0, sticky=tk.NW, pady=2)
        enf = ttk.Frame(form)
        enf.grid(row=r, column=1, sticky=tk.W, pady=2)
        self._enjeux_vars: dict[str, tk.BooleanVar] = {}
        for i, (code, label) in enumerate(ENJEUX):
            if code == "eleves":
                continue  # alias optionnel, skip clutter
            v = tk.BooleanVar(value=(code == "perso"))
            self._enjeux_vars[code] = v
            ttk.Checkbutton(enf, text=label, variable=v).grid(row=i // 2, column=i % 2, sticky=tk.W)
        r += 1

        # Équipements
        ttk.Label(form, text="Équipements attendus").grid(row=r, column=0, sticky=tk.NW, pady=2)
        eqf = ttk.Frame(form)
        eqf.grid(row=r, column=1, sticky=tk.W, pady=2)
        self._equip_vars: dict[str, tk.BooleanVar] = {}
        defaults = {"pc", "box", "phone"}
        for i, (code, label) in enumerate(EQUIP):
            v = tk.BooleanVar(value=(code in defaults))
            self._equip_vars[code] = v
            ttk.Checkbutton(eqf, text=label, variable=v).grid(row=i // 2, column=i % 2, sticky=tk.W)
        r += 1

        opts = ttk.LabelFrame(form, text="Options d'analyse (extras YAML)", padding=6)
        opts.grid(row=r, column=0, columnspan=2, sticky=tk.EW, pady=8)
        ttk.Checkbutton(opts, text="Mandat + NDA signés", variable=self.var_mandat).pack(anchor=tk.W)
        ttk.Checkbutton(opts, text="LLM polish (--llm)", variable=self.var_llm).pack(anchor=tk.W)
        ttk.Checkbutton(opts, text="Export PDF (--pdf)", variable=self.var_pdf).pack(anchor=tk.W)
        ttk.Checkbutton(opts, text="Tous les ports (--all-ports)", variable=self.var_all_ports).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Site web (prérempli example.test)",
            variable=self.var_site,
        ).pack(anchor=tk.W)
        row_site = ttk.Frame(opts)
        row_site.pack(anchor=tk.W, pady=2)
        ttk.Label(row_site, text="URL site").pack(side=tk.LEFT)
        ttk.Entry(row_site, textvariable=self.var_site_url, width=36).pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(
            opts,
            text="Signalement RGPD sur demande (PAS un certificat)",
            variable=self.var_rgpd,
        ).pack(anchor=tk.W)
        ttk.Button(opts, text="Configurer la fiche RGPD…", command=self._do_rgpd_fiche).pack(
            anchor=tk.W, pady=2
        )
        self._lbl_rgpd = ttk.Label(opts, text="Fiche RGPD : non remplie")
        self._lbl_rgpd.pack(anchor=tk.W, pady=(0, 4))
        ttk.Checkbutton(
            opts,
            text="Usages & droits (ce que les gens peuvent faire — pas un dump)",
            variable=self.var_usages,
        ).pack(anchor=tk.W)
        ttk.Button(opts, text="Configurer la fiche usages…", command=self._do_usages_fiche).pack(
            anchor=tk.W, pady=2
        )
        self._lbl_usages = ttk.Label(opts, text="Fiche usages : non remplie")
        self._lbl_usages.pack(anchor=tk.W, pady=(0, 4))
        ttk.Checkbutton(
            opts,
            text="Machines / OT (Ethernet industriel, lecture — pas CAN)",
            variable=self.var_machines,
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Pistes (catalogue, pas des findings)",
            variable=self.var_pistes,
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Greenbone / GVM — lecture GMP (pas Full and Fast)",
            variable=self.var_greenbone,
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Lynis — poste opérateur (pas le LAN client)",
            variable=self.var_lynis,
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Trivy — FS opérateur (pas le CIDR)",
            variable=self.var_trivy,
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Offre PASSI (red) — pas une qualification ANSSI",
            variable=self.var_passi,
        ).pack(anchor=tk.W)
        ttk.Checkbutton(
            opts,
            text="Autorisations red — huit pièces jouées",
            variable=self.var_autorisations,
        ).pack(anchor=tk.W)
        row_mt = ttk.Frame(opts)
        row_mt.pack(anchor=tk.W, pady=2)
        ttk.Label(row_mt, text="max_time (s)").pack(side=tk.LEFT)
        ttk.Entry(row_mt, textvariable=self.var_max_time, width=8).pack(side=tk.LEFT, padx=6)
        r += 1

        form.columnconfigure(1, weight=1)

        btns = ttk.Frame(outer)
        btns.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(btns, text="Annuler", command=self._cancel).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btns, text="Enregistrer la mission", command=self._save).pack(side=tk.RIGHT, padx=4)

        self.bind("<Escape>", lambda _e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.update_idletasks()

        # Taille initiale responsive : confortable sur un grand écran, mais
        # bornée à la surface réellement disponible sur un petit écran.
        try:
            screen_w = self.winfo_screenwidth()
            screen_h = self.winfo_screenheight()
            width = min(760, max(560, screen_w - 80))
            height = min(760, max(500, screen_h - 120))
            x = max(20, (screen_w - width) // 2)
            y = max(20, (screen_h - height) // 2)
            self.geometry(f"{width}x{height}+{x}+{y}")
        except tk.TclError:
            self.geometry("680x700")
        self.minsize(520, 460)

    def _cancel(self) -> None:
        self.result_path = None
        self.destroy()

    def _do_rgpd_fiche(self) -> None:
        from guardia.engines.rgpd_config import empty_config, summary_line
        from guardia.ui.rgpd_dialog import ask_rgpd_config

        cfg = ask_rgpd_config(self, initial=self._rgpd_cfg or empty_config())
        if cfg is None:
            return
        self._rgpd_cfg = cfg
        self.var_rgpd.set(True)
        self._lbl_rgpd.configure(text="Fiche RGPD : " + summary_line(cfg))

    def _do_usages_fiche(self) -> None:
        from guardia.engines.usages_config import empty_config, summary_line
        from guardia.ui.usages_dialog import ask_usages_config

        cfg = ask_usages_config(self, initial=self._usages_cfg or empty_config())
        if cfg is None:
            return
        self._usages_cfg = cfg
        self.var_usages.set(True)
        self._lbl_usages.configure(text="Fiche usages : " + summary_line(cfg))

    def _build_dict(self) -> dict[str, Any]:
        typ = self.var_structure.get().strip() or "foyer"
        taille = self.var_taille.get().strip() or "xs"
        profondeur = self.var_profondeur.get().strip() or "standard"
        if taille == "inconnu" and profondeur != "full":
            profondeur = "full"
        client = self.var_client.get().strip() or "Client"
        personne = self.var_personne.get().strip() or client
        cidr = self.var_cidr.get().strip() or None
        profil = PROFIL_MAP.get(typ, "maison")
        ton = "tutoiement" if typ in ("foyer", "parc_particulier") else "vouvoiement"
        enjeux = [c for c, v in self._enjeux_vars.items() if v.get()]
        equip = [c for c, v in self._equip_vars.items() if v.get()]
        try:
            max_time = int(self.var_max_time.get().strip() or "7200")
        except ValueError:
            max_time = 7200
        parc_inconnu = profondeur == "full" and not bool(self.var_passi.get())
        data: dict[str, Any] = {
            "guardia": "1.0",
            "signature": "Platon-Y / Echoes of Hackers",
            "checkup": "universel",
            "date": date.today().isoformat(),
            "client": client,
            "personne_commune": personne,
            "type_structure": typ,
            "profil_moteur": profil,
            "taille_parc": taille,
            "enjeux": enjeux,
            "equipements_attendus": equip,
            "profondeur": profondeur,
            "ton_rapport": ton,
            "cidr": cidr,
            "mandat_nda_signes": bool(self.var_mandat.get()),
            "operateur_nom": "Platon-Y",
            "operateur_signe": bool(self.var_mandat.get()),
            "parc_inconnu": parc_inconnu,
            "all_ports": bool(self.var_all_ports.get()),
            "llm": bool(self.var_llm.get()),
            "pdf": bool(self.var_pdf.get()),
            "max_time": max_time,
            "site_url": (self.var_site_url.get().strip() or "https://example.test")
            if self.var_site.get()
            else None,
            "rgpd": bool(self.var_rgpd.get()),
            "usages": bool(self.var_usages.get()),
            "machines": bool(self.var_machines.get()),
            "pistes": bool(self.var_pistes.get()),
            "greenbone": bool(self.var_greenbone.get()),
            "lynis": bool(self.var_lynis.get()),
            "trivy": bool(self.var_trivy.get()),
            "passi": bool(self.var_passi.get()),
            "autorisations": bool(self.var_autorisations.get()) or bool(self.var_passi.get()),
            "complement_antimalware": False,
            "regles_rapport": {
                "chaque_finding_inclut": [
                    "titre_clair",
                    "pourquoi_ca_nuit",
                    "preuve_courte",
                    "comment_resoudre_etapes",
                    "qui_peut_le_faire",
                    "priorite",
                ],
                "synthese": "top5_actions_plus_offre_suite_eoh",
                "ne_pas_laisser_sans_remede": True,
            },
            "couverture": "tous_hotes_du_cidr_mandate",
            "bilan_par_hote": "securise_ou_non_plus_remede",
            "interdit": ["exploitation", "malware_hunting", "hors_perimetre"],
            "notes": "Créée depuis l'UI Guardia (popup Nouvelle mission).",
        }
        if self._rgpd_cfg:
            data["rgpd_config"] = self._rgpd_cfg
            data["rgpd"] = True
        elif not data.get("rgpd"):
            data.pop("rgpd_config", None)
        if self._usages_cfg:
            data["usages_config"] = self._usages_cfg
            data["usages"] = True
        elif not data.get("usages"):
            data.pop("usages_config", None)
        return data

    def _save(self) -> None:
        mission = self._build_dict()
        MISSIONS.mkdir(parents=True, exist_ok=True)
        client = str(mission.get("client") or "mission")
        slug = "".join(c if c.isalnum() else "-" for c in client.lower())[:40].strip("-") or "mission"
        path = MISSIONS / f"{date.today().isoformat()}-{slug}.yaml"
        if path.exists():
            path = MISSIONS / f"{date.today().isoformat()}-{slug}-{date.today().strftime('%H%M%S')}.yaml"
        try:
            _dump_mission(mission, path)
        except OSError as exc:
            messagebox.showerror("Mission", f"Écriture impossible :\n{exc}", parent=self)
            return
        self.result_path = path
        if not mission.get("mandat_nda_signes"):
            messagebox.showinfo(
                "Mission enregistrée",
                f"Fichier :\n{path}\n\n"
                "Mandat/NDA non confirmés : en prod, signe avant le scan.\n"
                "En labo : coche « Confirmer mandat » / --yes.",
                parent=self,
            )
        else:
            messagebox.showinfo("Mission enregistrée", f"Fichier :\n{path}", parent=self)
        self.destroy()


def ask_new_mission(master: tk.Misc) -> Path | None:
    dlg = NewMissionDialog(master)
    master.wait_window(dlg)
    return dlg.result_path
