"""Interface graphique Tk (ttk) pour Guardia — checkup defensif."""
from __future__ import annotations

import os
import queue
import re
import subprocess
import sys
import threading
import tkinter as tk
from pathlib import Path
from tkinter import filedialog, messagebox, ttk
from typing import Any, Callable

from guardia import __signature__, __version__
from guardia.core.paths import MISSIONS, RAPPORTS, ROOT

# --- Palette (fond sombre ; accent = équipe ; gouttes toujours sang) ---
BG = "#1A1513"
BG_CARD = "#241E1B"
BG_INPUT = "#2E2622"
FG = "#E8DED6"
FG_MUTED = "#A8988C"
SANG = "#9B1B1B"          # logo uniquement — ne change jamais
SANG_CLAIR = "#C62828"
BLEU = "#1E4F8A"
BLEU_CLAIR = "#2B6CB0"
BORDER = "#3D342F"
LOG_BG = "#100D0C"
LOG_FG = "#E8DED6"

HELP_TEXTS: dict[str, str] = {
    "red_team_gate": (
        "Porte Red Team : mot de passe operateur + attestation document signe. "
        "ROE / avenant requis. Moteurs defensifs seulement — jamais d'exploit."
    ),
    "mission": "YAML de la visite. Nouvelle mission : questionnaire → fichier.",
    "cidr": "Plage autorisée. Vide = catalogue de plages. La fenêtre prime sur le YAML.",
    "profil": "Preset : foyer / PME / école / full / PASSI. Full = scan approfondi. PASSI = prestation d'audit (pas un certificat). Les deux modes sont séparés.",
    "yes": "Attestation opérateur si le mandat n'est pas coché. CIDR local seulement.",
    "lan": "nmap + calibrage sur le CIDR. Décoche pour un site / RGPD seul.",
    "full": "Mode Full : scan approfondi (LAN patient, tous les ports, audit large). Distinct du mode PASSI.",
    "all_ports": "LAN : nmap -p- (1–65535). Long. Inutile sans LAN.",
    "llm": "Reformule les findings en français. Hors budget scan. N'invente rien.",
    "pdf": "PDF du rapport (weasyprint). Hors budget scan.",
    "max_time": "Plafond du SCAN en secondes. LLM / HTML / JSON ne comptent pas.",
    "verbose": "Logs détaillés dans le journal.",
    "llm_model": "Chemin GGUF. Vide = défaut local.",
    "llm_url": "llama-server, défaut http://127.0.0.1:2443 (sinon 18111).",
    "ngl": "Couches GPU. 0 = CPU (décocher Forcer GPU).",
    "skip_phase": "Tronque la phase en cours, enchaîne, note l'arrêt. SIGUSR1.",
    "audit": "LAN : re-cible les hôtes flagués (ports admin, scripts info).",
    "audit_full": "Audit large + site. Mandat audit-full.",
    "cve": "Corrélation CVE catalogue local (lecture). Auto en full/audit-full/passi.",
    "site": "URL du mandat. Seul + approfondir = revue TLS/HTTP, sans nmap parc.",
    "rgpd": "Signalement observé / déclaré. Pas un certificat. Configurer la fiche.",
    "usages": "Ce que les sessions peuvent atteindre. Pas un dump. Configurer la fiche.",
    "calibrage": "Après nmap : outils Kali présents selon les portes. Absent = on continue.",
    "machines": "Ethernet industriel en lecture (Modbus, S7, OPC-UA…). Pas d'écriture.",
    "pistes": "Catalogue de familles à explorer. Pas des findings.",
    "greenbone": "Lecture GMP (version, feeds). Pas un Full and Fast auto. Absent = on continue.",
    "lynis": "Durcissement du poste opérateur. Pas le LAN client. Absent = on continue.",
    "trivy": "FS / image du poste opérateur. Pas le CIDR. Absent = on continue.",
    "passi": "Mode PASSI : dossier de prestation (5 activités, plan, preuves, revue humaine). Distinct du mode Full. Outil d'appui, pas une qualification ANSSI.",
    "autorisations": "Huit pièces + opérateur / mandat / CIDR, signées. La case ne suffit pas. Incomplet = mode PASSI non exécuté. Red team seulement.",
    "liens": "Vérifie lanceurs, nmap, Thunar, Firefox.",
    "force_gpu": "GPU NVIDIA → ngl>0. Décoche = CPU. nmap reste CPU.",
    "workers": "Parallélisme empreinte ports. auto = cpu/2 max 4.",
}


# Profil UI → mission d'exemple + options cohérentes
# Note : CLI --profile n'accepte que maison|pme|ecole ;
# le preset « full » charge exemple-full.yaml + cases, sans --profile full.
PROFILE_PRESETS: dict[str, dict] = {
    "maison": {
        "mission": "exemple-foyer.yaml",
        "cidr": "192.168.1.0/24",
        "full": False,
        "all_ports": False,
        "llm": False,
        "pdf": False,
        "max_time": 7200,
        "label": "Foyer / particulier",
        "site": False,
        "rgpd": False,
        "usages": False,
        "machines": False,
        "audit": False,
        "audit_full": False,
        "lan": True,
        "greenbone": False,
        "lynis": False,
        "trivy": False,
        "pistes": False,
    },
    "pme": {
        "mission": "exemple-pme.yaml",
        "cidr": "192.168.0.0/24",
        "full": False,
        "all_ports": False,
        "llm": False,
        "pdf": False,
        "max_time": 7200,
        "label": "PME / association",
        "site": False,
        "rgpd": False,
        "usages": False,
        "machines": False,
        "audit": False,
        "audit_full": False,
        "lan": True,
        "greenbone": False,
        "lynis": False,
        "trivy": False,
        "pistes": True,
    },
    "ecole": {
        "mission": "exemple-ecole.yaml",
        "cidr": "10.0.0.0/24",
        "full": True,
        "all_ports": False,
        "llm": False,
        "pdf": False,
        "max_time": 7200,
        "label": "École / parc scolaire",
        "site": False,
        "rgpd": False,
        "usages": True,
        "machines": False,
        "audit": False,
        "audit_full": False,
        "lan": True,
        "greenbone": False,
        "lynis": False,
        "trivy": False,
        "pistes": True,
    },
    "full": {
        "mission": "exemple-full.yaml",
        "cidr": "192.168.1.0/24",
        "full": True,
        "all_ports": True,
        "llm": True,
        "pdf": True,
        "max_time": 7200,
        "cve": True,
        "label": "Tout analyser (full options)",
        "site": True,
        "rgpd": True,
        "usages": True,
        "machines": False,
        "audit": True,
        "audit_full": True,
        "lan": True,
        "greenbone": True,
        "lynis": True,
        "trivy": True,
        "pistes": True,
    },
    "red": {
        "mission": "exemple-red.yaml",
        "cidr": "192.168.1.0/24",
        "full": True,
        "all_ports": True,
        "llm": True,
        "pdf": True,
        "max_time": 7200,
        "label": "Red team — exemple / maison",
        "site": True,
        "rgpd": True,
        "usages": True,
        "machines": True,
        "audit": True,
        "audit_full": True,
        "lan": True,
        "calibrage": True,
        "equipe": "red",
        "greenbone": True,
        "lynis": True,
        "trivy": True,
        "pistes": True,
        "passi": False,
        "autorisations": False,
    },
    "passi": {
        "mission": "exemple-passi-complet.yaml",
        "cidr": "192.0.2.0/24",
        "full": False,
        "all_ports": False,
        "llm": True,
        "pdf": True,
        "max_time": 7200,
        "label": "PASSI — prestation d'audit (appui, pas une qualification)",
        "site": True,
        "rgpd": False,
        "usages": False,
        "machines": False,
        "audit": False,
        "audit_full": False,
        "lan": True,
        "calibrage": True,
        "equipe": "red",
        "greenbone": True,
        "lynis": True,
        "trivy": False,
        "pistes": False,
        "passi": True,
        "autorisations": True,
    },
}


def _python() -> str:
    return sys.executable or "python3"


def _base_cmd() -> list[str]:
    """Commande de base pour invoquer Guardia (module depuis ROOT)."""
    return [_python(), "-m", "guardia"]


class GuardiaApp(tk.Tk):
    def __init__(self) -> None:
        super().__init__()
        self.title(f"Guardia UI {__version__} — {__signature__}")
        self.configure(bg=BG)
        self.minsize(800, 720)
        self.geometry("1040x900")

        self._proc: subprocess.Popen[str] | None = None
        self._log_q: queue.Queue[str] = queue.Queue()
        self._running = False
        self._last_html: str | None = None
        self._last_pdf: str | None = None
        self._spawn_kind: str | None = None
        self._equipe = "blue"
        self._red_unlocked = False
        self._red_pass = ""
        self._red_action_vars: dict[str, tuple] = {}
        self.var_red_mode_avance = None  # set in _build
        self._last_explode = 0.0
        self._accent = BLEU
        self._accent_clair = BLEU_CLAIR
        self._ui_log_path = ROOT / "rapports" / "ui-session.log"
        try:
            RAPPORTS.mkdir(parents=True, exist_ok=True)
            with self._ui_log_path.open("a", encoding="utf-8") as fh:
                from datetime import datetime

                fh.write(f"\n=== Guardia UI {__version__} {datetime.now().isoformat()} uid={os.getuid()} ===\n")
        except OSError:
            self._ui_log_path = None

        self._setup_styles()
        self._build()
        self.after(80, self._drain_log)
        self.after(250, self._startup_liens)
        self.after(600, self._maybe_ask_queen_api)
        self.protocol("WM_DELETE_WINDOW", self._on_close)

    # ------------------------------------------------------------------ styles
    def _setup_styles(self) -> None:
        style = ttk.Style(self)
        try:
            style.theme_use("clam")
        except tk.TclError:
            pass

        style.configure(".", background=BG, foreground=FG, font=("Segoe UI", 10))
        style.configure("TFrame", background=BG)
        style.configure("Card.TFrame", background=BG_CARD)
        style.configure("TLabel", background=BG, foreground=FG)
        style.configure("Muted.TLabel", background=BG, foreground=FG_MUTED, font=("Segoe UI", 9))
        style.configure("Title.TLabel", background=BG, foreground=FG, font=("Segoe UI", 16, "bold"))
        style.configure("Sub.TLabel", background=BG, foreground=FG_MUTED, font=("Segoe UI", 9))
        style.configure("Card.TLabel", background=BG_CARD, foreground=FG)
        style.configure("CardMuted.TLabel", background=BG_CARD, foreground=FG_MUTED, font=("Segoe UI", 9))

        style.configure(
            "TEntry",
            fieldbackground=BG_INPUT,
            foreground=FG,
            insertcolor=FG,
            bordercolor=BORDER,
            lightcolor=BORDER,
            darkcolor=BORDER,
            padding=6,
        )
        style.configure(
            "TCombobox",
            fieldbackground=BG_INPUT,
            foreground=FG,
            padding=4,
        )
        style.map(
            "TCombobox",
            fieldbackground=[("readonly", BG_INPUT)],
            selectbackground=[("readonly", self._accent_clair)],
        )

        style.configure(
            "TCheckbutton",
            background=BG_CARD,
            foreground=FG,
            focuscolor=BG_CARD,
            padding=10,
        )
        style.map("TCheckbutton", background=[("active", BG_CARD)])

        style.configure(
            "Accent.TButton",
            background=self._accent,
            foreground="#FFFFFF",
            bordercolor=self._accent,
            lightcolor=self._accent_clair,
            darkcolor=self._accent,
            focuscolor=self._accent_clair,
            padding=(18, 12),
            font=("Segoe UI", 10, "bold"),
        )
        style.map(
            "Accent.TButton",
            background=[("active", self._accent_clair), ("disabled", "#4A3030")],
            foreground=[("disabled", "#888")],
        )

        style.configure(
            "Soft.TButton",
            background=BG_CARD,
            foreground=FG,
            bordercolor=BORDER,
            lightcolor=BG_INPUT,
            darkcolor=BORDER,
            padding=(16, 10),
        )
        style.map("Soft.TButton", background=[("active", BORDER)])

        style.configure(
            "Help.TButton",
            background=BG_CARD,
            foreground=self._accent,
            bordercolor=BORDER,
            padding=(4, 2),
            font=("Segoe UI", 9, "bold"),
            width=2,
        )
        style.map("Help.TButton", background=[("active", BORDER)], foreground=[("active", self._accent_clair)])

        style.configure("TLabelframe", background=BG_CARD, foreground=self._accent, bordercolor=BORDER, relief="flat")
        style.configure("TLabelframe.Label", background=BG_CARD, foreground=self._accent, font=("Segoe UI", 10, "bold"))
        style.configure("TSeparator", background=BORDER)
        style.configure(
            "Vertical.TScrollbar",
            background=BG_CARD,
            troughcolor=BG,
            bordercolor=BORDER,
            arrowcolor=FG_MUTED,
        )
        style.configure(
            "TPanedwindow",
            background=BG,
        )

    # ------------------------------------------------------------------ build
    def _build(self) -> None:
        # Barre d'identité FIXE (ne défile pas) : gouttes + checkup défensif LAN.
        # L'article 323-1 est dans les docs et le rapport, pas ici.
        self.columnconfigure(0, weight=1)
        self.rowconfigure(0, weight=0)
        self.rowconfigure(1, weight=1)

        from guardia.core.cadre import IDENTITE_BARRE
        from guardia.ui.logo_gouttes import LogoGouttes
        from guardia.ui.sang_scroll import SangScrollbar, bind_mousewheel

        ident = tk.Frame(self, bg=BG, highlightthickness=0)
        ident.grid(row=0, column=0, sticky="ew")
        ident.columnconfigure(1, weight=1)

        self._logo = LogoGouttes(ident, width=128, height=108, bg=BG)
        self._logo.grid(row=0, column=0, padx=(18, 16), pady=(14, 12), sticky="nw")

        titles = tk.Frame(ident, bg=BG)
        titles.grid(row=0, column=1, sticky="ew", pady=(14, 12), padx=(0, 12))
        tk.Label(
            titles,
            text="Guardia",
            bg=BG,
            fg=FG,
            font=("Segoe UI", 22, "bold"),
            anchor="w",
        ).pack(anchor=tk.W)
        tk.Label(
            titles,
            text=f"{IDENTITE_BARRE}  ·  v{__version__}",
            bg=BG,
            fg=FG,
            font=("Segoe UI", 11),
            anchor="w",
        ).pack(anchor=tk.W)
        self._equipe_label = tk.Label(
            titles,
            text="Blue team · lecture seule",
            bg=BG,
            fg=FG_MUTED,
            font=("Segoe UI", 9),
            anchor="w",
        )
        self._equipe_label.pack(anchor=tk.W, pady=(8, 0))

        teams = tk.Frame(ident, bg=BG)
        teams.grid(row=0, column=2, padx=(0, 18), pady=(14, 12), sticky="ne")
        # Blue / Red empilés (inchangé) — rond Nouveau client à côté (pas au-dessus)
        stack = tk.Frame(teams, bg=BG)
        stack.pack(side=tk.RIGHT, anchor="n")
        self._btn_blue = ttk.Button(stack, text="Blue team", style="Accent.TButton", command=lambda: self._set_equipe("blue"))
        self._btn_blue.pack(side=tk.TOP, fill=tk.X, pady=(0, 8))
        self._btn_red = ttk.Button(stack, text="Red team", style="Soft.TButton", command=lambda: self._set_equipe("red"))
        self._btn_red.pack(side=tk.TOP, fill=tk.X)
        self._btn_nouveau_client = tk.Canvas(
            teams, width=96, height=96, bg=BG, highlightthickness=0, bd=0, cursor="hand2"
        )
        self._btn_nouveau_client.pack(side=tk.LEFT, padx=(0, 12), anchor="n")
        self._draw_nouveau_client_btn()
        def _nc_click(_e=None):
            try:
                self._do_nouveau_client()
            except Exception as exc:  # noqa: BLE001
                try:
                    messagebox.showerror("Nouveau client", str(exc), parent=self)
                except Exception:
                    pass
                self._append_log(f"Nouveau client erreur : {exc}\n", "err")
        self._btn_nouveau_client.bind("<Button-1>", _nc_click)
        self._btn_nouveau_client.tag_bind("all", "<Button-1>", _nc_click)
        self._btn_nouveau_client.bind("<Enter>", lambda _e: self._draw_nouveau_client_btn(hover=True))
        self._btn_nouveau_client.bind("<Leave>", lambda _e: self._draw_nouveau_client_btn(hover=False))

        self._ident_filet = tk.Frame(ident, bg=self._accent, height=3)
        self._ident_filet.grid(row=1, column=0, columnspan=3, sticky="ew")

        # Coque scrollable : contenu + barre rouge latérale (centre clair)
        shell = ttk.Frame(self)
        shell.grid(row=1, column=0, sticky="nsew")
        shell.columnconfigure(0, weight=1)
        shell.rowconfigure(0, weight=1)

        self._scroll_canvas = tk.Canvas(
            shell,
            bg=BG,
            highlightthickness=0,
            bd=0,
        )
        self._scroll_canvas.grid(row=0, column=0, sticky="nsew")
        self._sang_scroll = SangScrollbar(shell, width=16)
        self._sang_scroll.grid(row=0, column=1, sticky="ns")
        self._sang_scroll.configure(command=self._scroll_canvas.yview)
        self._scroll_canvas.configure(yscrollcommand=self._sang_scroll.set)
        from guardia.core.equipe import PALETTE as _PAL

        self._sang_scroll.set_palette(_PAL["blue"])

        outer = ttk.Frame(self._scroll_canvas, padding=26)
        self._outer_win = self._scroll_canvas.create_window((0, 0), window=outer, anchor="nw")
        outer.columnconfigure(0, weight=1)
        # rows: 0 opts, 1 adv, 2 actions, 3 timings, 4 log (min height)
        outer.rowconfigure(7, weight=1)

        def _sync_scroll(_event=None) -> None:
            self._scroll_canvas.configure(scrollregion=self._scroll_canvas.bbox("all"))
            # largeur du frame = largeur canvas
            cw = self._scroll_canvas.winfo_width()
            if cw > 20:
                self._scroll_canvas.itemconfigure(self._outer_win, width=cw)

        outer.bind("<Configure>", _sync_scroll)
        self._scroll_canvas.bind("<Configure>", _sync_scroll)
        bind_mousewheel(self, self._scroll_canvas)

        # Mission
        opts = ttk.LabelFrame(outer, text="  Mission  ", padding=22)
        opts.grid(row=0, column=0, sticky="ew", pady=(12, 14))
        opts.columnconfigure(0, weight=1)

        self.var_mission = tk.StringVar(value=str(MISSIONS / "exemple-foyer.yaml"))
        self.var_cidr = tk.StringVar(value="")
        self.var_profil = tk.StringVar(value="maison")
        self.var_yes = tk.BooleanVar(value=False)
        self.var_full = tk.BooleanVar(value=False)
        self.var_all_ports = tk.BooleanVar(value=False)
        self.var_llm = tk.BooleanVar(value=False)
        self.var_pdf = tk.BooleanVar(value=False)
        self.var_verbose = tk.BooleanVar(value=False)
        self.var_audit = tk.BooleanVar(value=False)
        self.var_audit_full = tk.BooleanVar(value=False)
        self.var_cve = tk.BooleanVar(value=True)
        self.var_max_time = tk.StringVar(value="7200")
        self.var_llm_model = tk.StringVar(value="")
        self.var_llm_url = tk.StringVar(value="http://127.0.0.1:2443")
        self.var_ngl = tk.StringVar(value="99")
        self.var_force_gpu = tk.BooleanVar(value=True)
        self.var_workers = tk.StringVar(value="auto")
        self.var_site = tk.BooleanVar(value=False)
        self.var_site_url = tk.StringVar(value="https://example.test")
        self.var_rgpd = tk.BooleanVar(value=False)
        self.var_usages = tk.BooleanVar(value=False)
        self.var_machines = tk.BooleanVar(value=False)
        self.var_calibrage = tk.BooleanVar(value=True)
        self.var_lan = tk.BooleanVar(value=True)
        self.var_greenbone = tk.BooleanVar(value=False)
        self.var_lynis = tk.BooleanVar(value=False)
        self.var_trivy = tk.BooleanVar(value=False)
        self.var_pistes = tk.BooleanVar(value=False)
        self.var_passi = tk.BooleanVar(value=False)
        self.var_autorisations = tk.BooleanVar(value=False)

        r = 0
        self._row_file(opts, r, "Mission", self.var_mission, "mission", self._browse_mission)
        r += 1
        self._row_entry(opts, r, "CIDR", self.var_cidr, "cidr", placeholder="192.168.1.0/24")
        r += 1

        fr = ttk.Frame(opts, style="Card.TFrame")
        fr.grid(row=r, column=0, sticky="ew", pady=6)
        fr.columnconfigure(1, weight=1)
        ttk.Label(fr, text="Profil", style="Card.TLabel", width=18).grid(row=0, column=0, sticky="w")
        cb = ttk.Combobox(
            fr,
            textvariable=self.var_profil,
            values=("maison", "pme", "ecole"),
            state="readonly",
            width=16,
        )
        self._profil_cb = cb
        cb.grid(row=0, column=1, sticky="w", padx=8)
        self._help_btn(fr, "profil").grid(row=0, column=2, sticky="w", padx=4)
        cb.bind("<<ComboboxSelected>>", lambda _e: self._apply_profile_preset())
        r += 1
        yesf = ttk.Frame(opts, style="Card.TFrame")
        yesf.grid(row=r, column=0, sticky="w", pady=(8, 2))
        ttk.Checkbutton(yesf, text="Mandat / attestation (--yes)", variable=self.var_yes).pack(side=tk.LEFT)
        self._help_btn(yesf, "yes").pack(side=tk.LEFT, padx=6)

        # Actions — une ou plusieurs, indépendantes
        acts = ttk.LabelFrame(outer, text="  Actions  ", padding=22)
        acts.grid(row=1, column=0, sticky="ew", pady=(0, 14))
        acts.columnconfigure(1, weight=1)

        row_lan = ttk.Frame(acts, style="Card.TFrame")
        row_lan.grid(row=0, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Checkbutton(row_lan, text="LAN — nmap", variable=self.var_lan).pack(side=tk.LEFT)
        self._help_btn(row_lan, "lan").pack(side=tk.LEFT, padx=6)
        self._chk_calibrage = ttk.Checkbutton(row_lan, text="Calibrage Kali (red)", variable=self.var_calibrage)
        self._chk_calibrage.pack(side=tk.LEFT, padx=(16, 0))
        self._help_btn(row_lan, "calibrage").pack(side=tk.LEFT, padx=6)

        row_s = ttk.Frame(acts, style="Card.TFrame")
        row_s.grid(row=1, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Checkbutton(row_s, text="Site web", variable=self.var_site).pack(side=tk.LEFT)
        self._help_btn(row_s, "site").pack(side=tk.LEFT, padx=6)
        ttk.Entry(row_s, textvariable=self.var_site_url, width=42).pack(side=tk.LEFT, padx=8, fill=tk.X, expand=True)

        row_m = ttk.Frame(acts, style="Card.TFrame")
        row_m.grid(row=2, column=0, columnspan=2, sticky="ew", pady=8)
        ttk.Checkbutton(row_m, text="RGPD", variable=self.var_rgpd).pack(side=tk.LEFT)
        self._help_btn(row_m, "rgpd").pack(side=tk.LEFT, padx=6)
        ttk.Button(row_m, text="Fiche RGPD", style="Soft.TButton", command=self._do_rgpd_config).pack(side=tk.LEFT, padx=8)
        ttk.Checkbutton(row_m, text="Usages", variable=self.var_usages).pack(side=tk.LEFT, padx=(20, 0))
        self._help_btn(row_m, "usages").pack(side=tk.LEFT, padx=6)
        ttk.Button(row_m, text="Fiche usages", style="Soft.TButton", command=self._do_usages_config).pack(side=tk.LEFT, padx=8)

        row_ot = ttk.Frame(acts, style="Card.TFrame")
        row_ot.grid(row=3, column=0, columnspan=2, sticky="ew", pady=8)
        self._chk_machines = ttk.Checkbutton(row_ot, text="Machines / OT (red)", variable=self.var_machines)
        self._chk_machines.pack(side=tk.LEFT)
        self._help_btn(row_ot, "machines").pack(side=tk.LEFT, padx=6)
        self._chk_pistes = ttk.Checkbutton(row_ot, text="Pistes (red)", variable=self.var_pistes)
        self._chk_pistes.pack(side=tk.LEFT, padx=(20, 0))
        self._help_btn(row_ot, "pistes").pack(side=tk.LEFT, padx=6)
        ttk.Button(row_ot, text="Outils Kali", style="Soft.TButton", command=self._do_voir_programme).pack(side=tk.LEFT, padx=16)

        row_op = ttk.Frame(acts, style="Card.TFrame")
        row_op.grid(row=4, column=0, columnspan=2, sticky="ew", pady=8)
        self._chk_greenbone = ttk.Checkbutton(row_op, text="Greenbone (red)", variable=self.var_greenbone)
        self._chk_greenbone.pack(side=tk.LEFT)
        self._help_btn(row_op, "greenbone").pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(row_op, text="Lynis opérateur", variable=self.var_lynis).pack(side=tk.LEFT, padx=(16, 0))
        self._help_btn(row_op, "lynis").pack(side=tk.LEFT, padx=6)
        self._chk_trivy = ttk.Checkbutton(row_op, text="Trivy (red)", variable=self.var_trivy)
        self._chk_trivy.pack(side=tk.LEFT, padx=(16, 0))
        self._help_btn(row_op, "trivy").pack(side=tk.LEFT, padx=6)

        self.var_act_org = tk.BooleanVar(value=True)
        self.var_act_arch = tk.BooleanVar(value=True)
        self.var_act_cfg = tk.BooleanVar(value=True)
        self.var_act_code = tk.BooleanVar(value=True)
        self.var_act_int = tk.BooleanVar(value=True)

        # --- Panneaux de mode (un seul visible) ---
        self._visite_box = ttk.LabelFrame(outer, text="  Visite — options de profondeur  ", padding=22)
        vchecks = ttk.Frame(self._visite_box, style="Card.TFrame")
        vchecks.pack(fill=tk.X)
        for i, (label, var, key) in enumerate(
            (
                ("Approfondir (--full)", self.var_full, "full"),
                ("Tous les ports", self.var_all_ports, "all_ports"),
                ("Audit", self.var_audit, "audit"),
            )
        ):
            cell = ttk.Frame(vchecks, style="Card.TFrame")
            cell.pack(side=tk.LEFT, padx=(0, 18), pady=4)
            ttk.Checkbutton(cell, text=label, variable=var).pack(side=tk.LEFT)
            self._help_btn(cell, key).pack(side=tk.LEFT, padx=4)

        self._full_box = ttk.LabelFrame(outer, text="  Mode Full — scan approfondi (pas une prestation PASSI)  ", padding=22)
        ttk.Label(
            self._full_box,
            text="LAN patient, tous les ports, audit large, Greenbone / Lynis / Trivy. Distinct du mode PASSI.",
            style="CardMuted.TLabel",
        ).pack(anchor=tk.W, pady=(0, 8))
        fchecks = ttk.Frame(self._full_box, style="Card.TFrame")
        fchecks.pack(fill=tk.X)
        for label, var, key in (
            ("Approfondir", self.var_full, "full"),
            ("Tous les ports", self.var_all_ports, "all_ports"),
            ("Audit full", self.var_audit_full, "audit_full"),
            ("Corrélation CVE (lecture)", self.var_cve, "cve"),
            ("Greenbone", self.var_greenbone, "greenbone"),
            ("Lynis", self.var_lynis, "lynis"),
            ("Trivy", self.var_trivy, "trivy"),
        ):
            cell = ttk.Frame(fchecks, style="Card.TFrame")
            cell.pack(side=tk.LEFT, padx=(0, 14), pady=4)
            ttk.Checkbutton(cell, text=label, variable=var).pack(side=tk.LEFT)
            self._help_btn(cell, key).pack(side=tk.LEFT, padx=2)

        self._passi_box = ttk.LabelFrame(outer, text="  Mode PASSI — Offre PASSI, appui à une prestation (pas une qualification)  ", padding=22)
        ttk.Label(
            self._passi_box,
            text="Cinq activités PASSI v2.2. Guardia outille le dossier : plan, preuves, contrôles, revue humaine. Il ne qualifie pas le prestataire.",
            style="CardMuted.TLabel",
            wraplength=760,
        ).pack(anchor=tk.W, pady=(0, 8))
        acts_row = ttk.Frame(self._passi_box, style="Card.TFrame")
        acts_row.pack(fill=tk.X, pady=4)
        for label, var in (
            ("Organisationnel & physique", self.var_act_org),
            ("Architecture", self.var_act_arch),
            ("Configuration", self.var_act_cfg),
            ("Code source", self.var_act_code),
            ("Tests d'intrusion", self.var_act_int),
        ):
            ttk.Checkbutton(acts_row, text=label, variable=var).pack(side=tk.LEFT, padx=(0, 12))
        auth_row = ttk.Frame(self._passi_box, style="Card.TFrame")
        auth_row.pack(fill=tk.X, pady=8)
        ttk.Checkbutton(auth_row, text="Autorisations signées (liasse)", variable=self.var_autorisations).pack(side=tk.LEFT)
        self._help_btn(auth_row, "autorisations").pack(side=tk.LEFT, padx=6)
        ttk.Checkbutton(auth_row, text="Lynis opérateur", variable=self.var_lynis).pack(side=tk.LEFT, padx=(16, 0))
        ttk.Checkbutton(auth_row, text="Greenbone lecture", variable=self.var_greenbone).pack(side=tk.LEFT, padx=(16, 0))
        ttk.Label(
            self._passi_box,
            text="Pas de --full, pas d'audit-full : le moteur PASSI décide des contrôles à partir des observations.",
            style="CardMuted.TLabel",
        ).pack(anchor=tk.W, pady=(4, 0))

        self._passi_row = self._passi_box  # compat _sync_passi_row

        # --- Porte Red Team (avancé) : password + document signé ---
        self.var_red_mode_avance = tk.BooleanVar(value=False)
        self._red_gate_box = ttk.LabelFrame(
            outer,
            text="  Actions avancées — autorisation explicite  ",
            padding=22,
        )
        ttk.Label(
            self._red_gate_box,
            text=(
                "Mode Red Team (avancé) : moteurs défensifs seulement. "
                "Chaque action exige « Demander / activer » ET « Document signé validé » "
                "(ROE / avenant). Aucun exploit, C2, brute-force ou évasion."
            ),
            style="CardMuted.TLabel",
            wraplength=760,
        ).pack(anchor=tk.W, pady=(0, 10))
        red_mode_row = ttk.Frame(self._red_gate_box, style="Card.TFrame")
        red_mode_row.pack(fill=tk.X, pady=(0, 8))
        self._chk_red_mode = ttk.Checkbutton(
            red_mode_row,
            text="Mode Red Team (avancé)",
            variable=self.var_red_mode_avance,
            command=self._sync_red_gate_panel,
            state="disabled",
        )
        self._chk_red_mode.pack(side=tk.LEFT)
        self._help_btn(red_mode_row, "red_team_gate").pack(side=tk.LEFT, padx=6)

        self._red_actions_frame = ttk.Frame(self._red_gate_box, style="Card.TFrame")
        self._red_actions_frame.pack(fill=tk.X)
        self._red_action_vars = {}
        try:
            from guardia.core.red_gate import RED_ACTIONS
        except Exception:
            RED_ACTIONS = {}
        for aid, meta in RED_ACTIONS.items():
            row = ttk.Frame(self._red_actions_frame, style="Card.TFrame")
            row.pack(fill=tk.X, pady=3)
            want = tk.BooleanVar(value=False)
            signed = tk.BooleanVar(value=False)
            self._red_action_vars[aid] = (want, signed)
            ttk.Checkbutton(row, text="Demander / activer", variable=want).pack(side=tk.LEFT)
            ttk.Checkbutton(row, text="Document signé validé", variable=signed).pack(
                side=tk.LEFT, padx=(12, 0)
            )
            ttk.Label(row, text=meta.get("label", aid), style="Card.TLabel").pack(
                side=tk.LEFT, padx=(16, 0)
            )

        # Après : LLM / PDF / budget (commun aux trois modes)
        prof = ttk.LabelFrame(outer, text="  Après le scan  ", padding=22)
        prof.grid(row=4, column=0, sticky="ew", pady=(0, 14))
        prof.columnconfigure(0, weight=1)
        checks = ttk.Frame(prof, style="Card.TFrame")
        checks.grid(row=0, column=0, sticky="ew", pady=4)
        for i, (label, var, key) in enumerate(
            (
                ("LLM (hors scan)", self.var_llm, "llm"),
                ("PDF (hors scan)", self.var_pdf, "pdf"),
                ("Verbeux", self.var_verbose, "verbose"),
            )
        ):
            cell = ttk.Frame(checks, style="Card.TFrame")
            cell.grid(row=i // 3, column=i % 3, sticky="w", padx=(0, 16), pady=8)
            ttk.Checkbutton(cell, text=label, variable=var).pack(side=tk.LEFT)
            self._help_btn(cell, key).pack(side=tk.LEFT, padx=4)

        def _sync_audit_full(*_a: object) -> None:
            if self.var_audit_full.get():
                self.var_audit.set(True)
        try:
            self.var_audit_full.trace_add("write", _sync_audit_full)
        except Exception:  # noqa: BLE001
            pass

        fr = ttk.Frame(prof, style="Card.TFrame")
        fr.grid(row=1, column=0, sticky="ew", pady=(10, 2))
        ttk.Label(fr, text="Budget scan (s)", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        _ent_mt = ttk.Entry(fr, textvariable=self.var_max_time, width=10)
        _ent_mt.pack(side=tk.LEFT, padx=8)
        self._bind_entry_context(_ent_mt)
        ttk.Label(fr, text="LLM / HTML / JSON hors horloge", style="CardMuted.TLabel").pack(side=tk.LEFT, padx=8)
        self._help_btn(fr, "max_time").pack(side=tk.LEFT, padx=4)

        # LLM
        adv = ttk.LabelFrame(outer, text="  LLM  ", padding=22)
        adv.grid(row=5, column=0, sticky="ew", pady=(0, 14))
        adv.columnconfigure(0, weight=1)
        self._row_entry(adv, 0, "Modèle GGUF", self.var_llm_model, "llm_model")
        self._row_entry(adv, 1, "URL llama-server", self.var_llm_url, "llm_url")
        fr = ttk.Frame(adv, style="Card.TFrame")
        fr.grid(row=2, column=0, sticky="ew", pady=6)
        ttk.Label(fr, text="Couches GPU", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        _ent_ngl = ttk.Entry(fr, textvariable=self.var_ngl, width=8)
        _ent_ngl.pack(side=tk.LEFT, padx=8)
        self._bind_entry_context(_ent_ngl)
        self._help_btn(fr, "ngl").pack(side=tk.LEFT, padx=4)
        ttk.Checkbutton(fr, text="Forcer GPU", variable=self.var_force_gpu).pack(side=tk.LEFT, padx=12)
        self._help_btn(fr, "force_gpu").pack(side=tk.LEFT, padx=2)

        frw = ttk.Frame(adv, style="Card.TFrame")
        frw.grid(row=3, column=0, sticky="ew", pady=6)
        ttk.Label(frw, text="Workers", style="Card.TLabel", width=18).pack(side=tk.LEFT)
        _ent_w = ttk.Entry(frw, textvariable=self.var_workers, width=8)
        _ent_w.pack(side=tk.LEFT, padx=8)
        self._bind_entry_context(_ent_w)
        self._help_btn(frw, "workers").pack(side=tk.LEFT, padx=4)

        # Boutons — 2 rangées pour rester lisible en fenêtre étroite
        actions = ttk.Frame(outer)
        actions.grid(row=6, column=0, sticky="ew", pady=16)
        actions.columnconfigure(0, weight=1)
        row1 = ttk.Frame(actions)
        row1.grid(row=0, column=0, sticky="ew")
        row2 = ttk.Frame(actions)
        row2.grid(row=1, column=0, sticky="ew", pady=(10, 0))
        for text, style_name, cmd in (
            ("About", "Soft.TButton", self._do_about),
            ("Wizard", "Soft.TButton", self._do_wizard),
            ("Nouvelle mission", "Soft.TButton", self._do_new_mission),
            ("Discover", "Soft.TButton", self._do_discover),
            ("Run checkup", "Accent.TButton", self._do_run),
        ):
            ttk.Button(row1, text=text, style=style_name, command=cmd).pack(side=tk.LEFT, padx=5)
        for text, style_name, cmd in (
            ("Ouvrir rapports/", "Soft.TButton", self._open_rapports),
            ("Ouvrir missions/", "Soft.TButton", self._open_missions),
            ("Ouvrir HTML / PDF", "Soft.TButton", self._open_last_reports),
            ("Checkup des liens", "Soft.TButton", self._do_liens),
        ):
            ttk.Button(row2, text=text, style=style_name, command=cmd).pack(side=tk.LEFT, padx=5)
        self._help_btn(row2, "liens").pack(side=tk.LEFT, padx=2)
        ttk.Button(
            row2,
            text="Passer phase",
            style="Accent.TButton",
            command=self._skip_phase,
        ).pack(side=tk.RIGHT, padx=3)
        self._help_btn(row2, "skip_phase").pack(side=tk.RIGHT, padx=2)
        ttk.Button(row2, text="STOP AUDIT", style="Soft.TButton", command=self._stop_proc).pack(
            side=tk.RIGHT, padx=3
        )

        # Timings
        self.var_timings = tk.StringVar(value="Timings : —")
        ttk.Label(outer, textvariable=self.var_timings, style="Muted.TLabel").grid(
            row=7, column=0, sticky="w"
        )

        # Log — zone qui grandit avec la fenêtre
        log_frame = ttk.LabelFrame(outer, text="  Journal (stdout / stderr)  ", padding=10)
        log_frame.grid(row=8, column=0, sticky="nsew", pady=12)
        log_frame.columnconfigure(0, weight=1)
        log_frame.rowconfigure(0, weight=1)

        self.log = tk.Text(
            log_frame,
            height=16,
            wrap=tk.WORD,
            bg=LOG_BG,
            fg=LOG_FG,
            insertbackground=LOG_FG,
            relief=tk.FLAT,
            padx=8,
            pady=8,
            font=("Consolas", 9),
            highlightthickness=1,
            highlightbackground=BORDER,
            highlightcolor=self._accent,
        )
        from guardia.ui.sang_scroll import SangScrollbar as _SangLog

        scroll = _SangLog(log_frame, width=14)
        self._log_scroll = scroll
        from guardia.core.equipe import PALETTE as _PAL2

        self._log_scroll.set_palette(_PAL2["blue"])
        scroll.configure(command=self.log.yview)
        self.log.configure(yscrollcommand=scroll.set)
        self.log.grid(row=0, column=0, sticky="nsew")
        scroll.grid(row=0, column=1, sticky="ns")
        self.log.tag_configure("err", foreground="#FF8A80")
        self.log.tag_configure("ok", foreground="#A5D6A7")
        self.log.tag_configure("timing", foreground="#FFCC80")

        self._bind_text_context(self.log)
        # Entry : clic droit après construction des champs
        self.after(100, self._bind_all_entries_context)

        self._append_log(
            f"Prêt. Racine : {ROOT}\n"
            f"Mission par défaut : {self.var_mission.get()}\n"
            "Configure les options puis lance Discover ou Run checkup.\n"
            "Red team : mot de passe + exemple prérempli (exemple / maison).\n",
            "ok",
        )
        # Rebind molette une fois tous les widgets posés (ttk avale sinon).
        bind_mousewheel(self, self._scroll_canvas)
        self._sync_mode_panels()
        self._sync_equipe_caps()
        self._sync_red_gate_panel()


    def _bind_all_entries_context(self) -> None:
        """Parcourt les Entry / Combobox pour menus clic droit."""

        def walk(w: tk.Misc) -> None:
            for child in w.winfo_children():
                cls = child.winfo_class()
                if cls in ("TEntry", "Entry"):
                    self._bind_entry_context(child)
                elif cls == "TCombobox":
                    try:
                        self._bind_entry_context(child)
                    except Exception:
                        pass
                walk(child)

        walk(self)

    def _set_equipe(self, equipe: str) -> None:
        from guardia.core.equipe import PALETTE

        if equipe == "red":
            if not self._red_unlocked:
                mot = self._ask_red_pass()
                if not mot:
                    return
                self._red_unlocked = True
                self._red_pass = mot or ""
            pal = PALETTE["red"]
            self._equipe = "red"
            self._accent = pal["accent"]
            self._accent_clair = pal["accent_clair"]
            label = "Red team · regard attaquant · lecture seule"
        else:
            pal = PALETTE["blue"]
            self._equipe = "blue"
            self._accent = pal["accent"]
            self._accent_clair = pal["accent_clair"]
            label = "Blue team · checkup défensif"
        self._setup_styles()
        try:
            self._ident_filet.configure(bg=self._accent)
            self._equipe_label.configure(text=label)
            self._sang_scroll.set_palette(pal)
            if getattr(self, "_log_scroll", None) is not None:
                self._log_scroll.set_palette(pal)
            self.log.configure(highlightcolor=self._accent)
        except Exception:
            pass
        if self._equipe == "red":
            self._btn_red.configure(style="Accent.TButton")
            self._btn_blue.configure(style="Soft.TButton")
        else:
            self._btn_blue.configure(style="Accent.TButton")
            self._btn_red.configure(style="Soft.TButton")
        try:
            if getattr(self, "_logo", None) is not None:
                self._logo.set_equipe(self._equipe)
        except Exception:
            pass
        if self._equipe == "red":
            # Red déverrouille full / PASSI / calibrage / regard.
            pass
        else:
            self._clip_blue_vars()
        self._sync_mode_panels()
        self._sync_equipe_caps()
        self._sync_red_gate_panel()
        self._append_log(f"Équipe : {self._equipe}\n", "ok")

    def _clip_blue_vars(self) -> None:
        """Blue : éteint ce qui est réservé red, sans toucher LAN / site / RGPD / Lynis / LLM."""
        for name in (
            "var_full",
            "var_all_ports",
            "var_audit",
            "var_audit_full",
            "var_calibrage",
            "var_greenbone",
            "var_trivy",
            "var_machines",
            "var_pistes",
            "var_passi",
            "var_autorisations",
        ):
            var = getattr(self, name, None)
            if var is not None:
                var.set(False)
        profil = (self.var_profil.get() or "").strip()
        if profil in ("full", "passi", "red"):
            self.var_profil.set("maison")

    def _sync_equipe_caps(self) -> None:
        """Widgets red actifs seulement après déverrouillage."""
        red = self._equipe == "red"
        state = "normal" if red else "disabled"
        for w in (
            getattr(self, "_chk_calibrage", None),
            getattr(self, "_chk_machines", None),
            getattr(self, "_chk_pistes", None),
            getattr(self, "_chk_greenbone", None),
            getattr(self, "_chk_trivy", None),
            getattr(self, "_chk_red_mode", None),
        ):
            if w is not None:
                try:
                    w.configure(state=state)
                except tk.TclError:
                    pass
        if not red and getattr(self, "var_red_mode_avance", None) is not None:
            try:
                self.var_red_mode_avance.set(False)
            except Exception:
                pass
        cb = getattr(self, "_profil_cb", None)
        if cb is not None:
            cb["values"] = (
                ("maison", "pme", "ecole", "full", "passi") if red else ("maison", "pme", "ecole")
            )

    def _sync_red_gate_panel(self) -> None:
        """Affiche le LabelFrame avance seulement si Red deverrouille."""
        box = getattr(self, "_red_gate_box", None)
        if box is None:
            return
        unlocked = bool(self._red_unlocked and self._equipe == "red")
        if unlocked:
            try:
                box.grid(row=3, column=0, sticky="ew", pady=(0, 14))
            except tk.TclError:
                pass
        else:
            try:
                box.grid_remove()
            except tk.TclError:
                pass
        mode = False
        if getattr(self, "var_red_mode_avance", None) is not None:
            mode = bool(self.var_red_mode_avance.get()) and unlocked
        fr = getattr(self, "_red_actions_frame", None)
        if fr is not None:
            try:
                state = "normal" if mode else "disabled"
                for child in fr.winfo_children():
                    for w in child.winfo_children():
                        try:
                            w.configure(state=state)
                        except tk.TclError:
                            pass
            except tk.TclError:
                pass

    def _red_signed_action_ids(self) -> list[str]:
        """Actions ou Demander ET Document signe sont coches."""
        out: list[str] = []
        for aid, pair in (getattr(self, "_red_action_vars", None) or {}).items():
            want, signed = pair
            if want.get() and signed.get():
                out.append(aid)
        return out

    def _validate_red_gate_or_warn(self) -> bool:
        """Refuse Demander sans Document signe (messagebox)."""
        from guardia.core.red_gate import RED_ACTIONS, gate_message_want_without_signed

        if not (
            self._equipe == "red"
            and getattr(self, "var_red_mode_avance", None) is not None
            and self.var_red_mode_avance.get()
        ):
            return True
        for aid, pair in (getattr(self, "_red_action_vars", None) or {}).items():
            want, signed = pair
            if want.get() and not signed.get():
                label = (RED_ACTIONS.get(aid) or {}).get("label", aid)
                messagebox.showerror(
                    "Red Team — document signe requis",
                    gate_message_want_without_signed(label),
                    parent=self,
                )
                return False
        return True

    def _sync_mode_panels(self) -> None:
        """Un seul panneau : visite / full / PASSI. Jamais les deux modes mélangés."""
        if getattr(self, "_syncing_mode", False):
            return
        profil = (self.var_profil.get() or "").strip()
        visite = getattr(self, "_visite_box", None)
        fullb = getattr(self, "_full_box", None)
        passib = getattr(self, "_passi_box", None)
        if visite is None:
            return
        for box in (visite, fullb, passib):
            if box is not None:
                box.grid_remove()
        if profil == "passi":
            if self._equipe != "red":
                self._syncing_mode = True
                try:
                    self._set_equipe("red")
                finally:
                    self._syncing_mode = False
                if self._equipe != "red":
                    self.var_profil.set("maison")
                    visite.grid(row=2, column=0, sticky="ew", pady=(0, 14))
                    return
            self.var_passi.set(True)
            self.var_autorisations.set(True)
            self.var_full.set(False)
            self.var_audit_full.set(False)
            passib.grid(row=2, column=0, sticky="ew", pady=(0, 14))
        elif profil == "full":
            self.var_passi.set(False)
            self.var_autorisations.set(False)
            fullb.grid(row=2, column=0, sticky="ew", pady=(0, 14))
        else:
            if profil != "red":
                self.var_passi.set(False)
            visite.grid(row=2, column=0, sticky="ew", pady=(0, 14))

    def _sync_passi_row(self) -> None:
        self._sync_mode_panels()

    def _ask_red_pass(self) -> str | None:
        """Demande le mot de passe red ; premier lancement = definition du hash local."""
        from guardia.core.red_gate import has_configured_hash, verifier_red, write_password_hash
        from guardia.core.equipe import INDICE_RED

        first_run = not has_configured_hash()
        win = tk.Toplevel(self)
        win.title("Red team — mot de passe operateur")
        win.configure(bg=BG)
        win.transient(self)
        # pas de grab_set : sous root / multi-fenêtres ça peut bloquer le clic
        title = (
            "Premier lancement : definissez le mot de passe Red Team."
            if first_run
            else "Regard attaquant — lecture seule. Pas d'intrusion."
        )
        tk.Label(win, text=title, bg=BG, fg=FG, font=("Segoe UI", 11)).pack(
            anchor=tk.W, padx=16, pady=(16, 6)
        )
        hint = (
            "Hash stocke dans ~/.config/guardia/red.pass (SHA-256 salt+password). "
            "Jamais de clair en depot. Alt : env GUARDIA_RED_PASSWORD_HASH "
            "ou queen_decide RED_TEAM_PASSWORD_HASH=."
            if first_run
            else f"Indice : {INDICE_RED}"
        )
        tk.Label(
            win, text=hint, bg=BG, fg=FG_MUTED, font=("Segoe UI", 9), wraplength=420, justify=tk.LEFT
        ).pack(anchor=tk.W, padx=16, pady=(0, 8))
        var = tk.StringVar()
        var2 = tk.StringVar()
        ent = ttk.Entry(win, textvariable=var, show="•", width=36)
        ent.pack(fill=tk.X, padx=16, pady=8)
        ent.focus_set()
        if first_run:
            tk.Label(win, text="Confirmer le mot de passe", bg=BG, fg=FG_MUTED, font=("Segoe UI", 9)).pack(
                anchor=tk.W, padx=16
            )
            ttk.Entry(win, textvariable=var2, show="•", width=36).pack(fill=tk.X, padx=16, pady=8)
        got: dict[str, str] = {"v": ""}

        def ok(_e=None) -> None:
            a = (var.get() or "").strip()
            if not a:
                messagebox.showerror("Red team", "Mot de passe vide.", parent=win)
                return
            if first_run:
                if a != (var2.get() or "").strip():
                    messagebox.showerror("Red team", "Les deux saisies ne correspondent pas.", parent=win)
                    return
                try:
                    write_password_hash(a)
                except Exception as exc:  # noqa: BLE001
                    messagebox.showerror("Red team", f"Impossible d'ecrire red.pass :\n{exc}", parent=win)
                    return
                got["v"] = a
                win.destroy()
                return
            if not verifier_red(a):
                messagebox.showerror("Red team", "Mot de passe incorrect.", parent=win)
                return
            got["v"] = a
            win.destroy()

        def cancel() -> None:
            got["v"] = ""
            win.destroy()

        btns = tk.Frame(win, bg=BG)
        btns.pack(fill=tk.X, padx=16, pady=(8, 16))
        ttk.Button(
            btns,
            text="Enregistrer" if first_run else "Entrer",
            style="Accent.TButton",
            command=ok,
        ).pack(side=tk.LEFT)
        ttk.Button(btns, text="Annuler", style="Soft.TButton", command=cancel).pack(side=tk.LEFT, padx=8)
        win.bind("<Return>", ok)
        win.bind("<Escape>", lambda _e: cancel())
        win.wait_window()
        return got["v"] or None


    def _bind_text_context(self, widget: tk.Text) -> None:
        menu = tk.Menu(
            widget,
            tearoff=0,
            bg=BG_CARD,
            fg=FG,
            activebackground=SANG,
            activeforeground="#ffffff",
        )
        menu.add_command(label="Copier", command=lambda: self._text_copy(widget))
        menu.add_command(label="Tout sélectionner", command=lambda: self._text_select_all(widget))
        menu.add_separator()
        menu.add_command(label="Effacer le journal", command=lambda: self._text_clear(widget))

        def popup(event: tk.Event) -> str | None:  # type: ignore[type-arg]
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()
            return "break"

        widget.bind("<Button-3>", popup)
        widget.bind("<Button-2>", popup)

    def _bind_entry_context(self, widget: tk.Misc) -> None:
        menu = tk.Menu(
            widget,
            tearoff=0,
            bg=BG_CARD,
            fg=FG,
            activebackground=SANG,
            activeforeground="#FFFFFF",
            bd=0,
            relief=tk.FLAT,
        )

        def _copy() -> None:
            try:
                widget.event_generate("<<Copy>>")
            except tk.TclError:
                try:
                    sel = widget.selection_get()  # type: ignore[attr-defined]
                except tk.TclError:
                    sel = widget.get()  # type: ignore[attr-defined]
                if not sel:
                    return
                self.clipboard_clear()
                self.clipboard_append(sel)

        def _paste() -> None:
            try:
                widget.event_generate("<<Paste>>")
            except tk.TclError:
                try:
                    clip = self.clipboard_get()
                except tk.TclError:
                    return
                try:
                    if widget.selection_present():  # type: ignore[attr-defined]
                        widget.delete(tk.SEL_FIRST, tk.SEL_LAST)  # type: ignore[attr-defined]
                except tk.TclError:
                    pass
                try:
                    widget.insert(tk.INSERT, clip)  # type: ignore[attr-defined]
                except tk.TclError:
                    pass

        def _select_all() -> None:
            try:
                widget.selection_range(0, tk.END)  # type: ignore[attr-defined]
                widget.icursor(tk.END)  # type: ignore[attr-defined]
                return
            except tk.TclError:
                pass
            try:
                widget.event_generate("<<SelectAll>>")
            except tk.TclError:
                pass

        menu.add_command(label="Copier", command=_copy)
        menu.add_command(label="Coller", command=_paste)
        menu.add_command(label="Tout sélectionner", command=_select_all)

        def popup(event: tk.Event) -> str | None:  # type: ignore[type-arg]
            try:
                menu.tk_popup(event.x_root, event.y_root)
            finally:
                menu.grab_release()
            return "break"

        widget.bind("<Button-3>", popup)
        widget.bind("<Button-2>", popup)

    def _text_copy(self, widget: tk.Text) -> None:
        try:
            sel = widget.get(tk.SEL_FIRST, tk.SEL_LAST)
        except tk.TclError:
            sel = widget.get("1.0", tk.END)
        if not (sel or "").strip():
            return
        self.clipboard_clear()
        self.clipboard_append(sel)

    def _text_select_all(self, widget: tk.Text) -> None:
        widget.tag_add(tk.SEL, "1.0", tk.END)
        widget.mark_set(tk.INSERT, "1.0")
        widget.see(tk.INSERT)

    def _text_clear(self, widget: tk.Text) -> None:
        widget.configure(state=tk.NORMAL)
        widget.delete("1.0", tk.END)
        self._append_log("Journal effacé.\n", "ok")

    def _help_btn(self, parent: tk.Misc, key: str) -> ttk.Button:
        return ttk.Button(
            parent,
            text="?",
            style="Help.TButton",
            command=lambda k=key: self._show_help(k),
        )

    def _row_entry(
        self,
        parent: ttk.LabelFrame | ttk.Frame,
        row: int,
        label: str,
        var: tk.StringVar,
        help_key: str,
        placeholder: str = "",
    ) -> None:
        fr = ttk.Frame(parent, style="Card.TFrame")
        fr.grid(row=row, column=0, sticky="ew", pady=3)
        fr.columnconfigure(1, weight=1)
        ttk.Label(fr, text=label, style="Card.TLabel", width=22).grid(row=0, column=0, sticky="w")
        ent = ttk.Entry(fr, textvariable=var)
        ent.grid(row=0, column=1, sticky="ew", padx=4)
        self._bind_entry_context(ent)
        if placeholder and not var.get():
            pass
        self._help_btn(fr, help_key).grid(row=0, column=2, sticky="e", padx=2)

    def _row_file(
        self,
        parent: ttk.LabelFrame | ttk.Frame,
        row: int,
        label: str,
        var: tk.StringVar,
        help_key: str,
        browse: Callable[[], None],
    ) -> None:
        fr = ttk.Frame(parent, style="Card.TFrame")
        fr.grid(row=row, column=0, sticky="ew", pady=3)
        fr.columnconfigure(1, weight=1)
        ttk.Label(fr, text=label, style="Card.TLabel", width=22).grid(row=0, column=0, sticky="w")
        ent = ttk.Entry(fr, textvariable=var)
        ent.grid(row=0, column=1, sticky="ew", padx=4)
        self._bind_entry_context(ent)
        ttk.Button(fr, text="…", style="Soft.TButton", width=3, command=browse).grid(row=0, column=2, padx=2)
        self._help_btn(fr, help_key).grid(row=0, column=3, sticky="e", padx=2)

    # ------------------------------------------------------------------ helpers
    def _apply_profile_preset(self, skip_equipe: bool = False) -> None:
        """Aligne mission, CIDR et cases selon PROFILE_PRESETS."""
        profil = self.var_profil.get().strip()
        preset = PROFILE_PRESETS.get(profil)
        if not preset:
            return
        needs_red = preset.get("equipe") == "red" or profil in ("full", "passi", "red")
        if needs_red and self._equipe != "red" and not skip_equipe:
            self._set_equipe("red")
            if self._equipe != "red":
                self.var_profil.set("maison")
                self._append_log(
                    "Profil full / PASSI / red : mot de passe red team requis.\n",
                    "err",
                )
                return
        mission_name = preset.get("mission")
        if mission_name:
            self.var_mission.set(str(MISSIONS / mission_name))
        cidr = preset.get("cidr")
        if cidr is not None:
            self.var_cidr.set(str(cidr))
        self.var_full.set(bool(preset.get("full", False)))
        self.var_all_ports.set(bool(preset.get("all_ports", False)))
        self.var_llm.set(bool(preset.get("llm", False)))
        self.var_pdf.set(bool(preset.get("pdf", False)))
        if hasattr(self, "var_audit"):
            self.var_audit.set(bool(preset.get("audit", False)))
        if hasattr(self, "var_audit_full"):
            self.var_audit_full.set(bool(preset.get("audit_full", False)))
            if hasattr(self, "var_cve"):
                self.var_cve.set(bool(preset.get("cve", True)))
            if self.var_audit_full.get():
                self.var_audit.set(True)
        mt = preset.get("max_time", 7200)
        try:
            self.var_max_time.set(str(int(mt)))
        except (TypeError, ValueError):
            self.var_max_time.set("7200")
        if hasattr(self, "var_site"):
            self.var_site.set(bool(preset.get("site", False)))
        if hasattr(self, "var_rgpd"):
            self.var_rgpd.set(bool(preset.get("rgpd", False)))
        if hasattr(self, "var_usages"):
            self.var_usages.set(bool(preset.get("usages", False)))
        if hasattr(self, "var_machines"):
            self.var_machines.set(bool(preset.get("machines", False)))
        if hasattr(self, "var_lan"):
            self.var_lan.set(bool(preset.get("lan", True)))
        if hasattr(self, "var_calibrage"):
            self.var_calibrage.set(bool(preset.get("calibrage", True)))
        if hasattr(self, "var_greenbone"):
            self.var_greenbone.set(bool(preset.get("greenbone", False)))
        if hasattr(self, "var_lynis"):
            self.var_lynis.set(bool(preset.get("lynis", False)))
        if hasattr(self, "var_trivy"):
            self.var_trivy.set(bool(preset.get("trivy", False)))
        if hasattr(self, "var_pistes"):
            self.var_pistes.set(bool(preset.get("pistes", False)))
        if hasattr(self, "var_passi"):
            self.var_passi.set(bool(preset.get("passi", False)))
        if hasattr(self, "var_autorisations"):
            self.var_autorisations.set(bool(preset.get("autorisations", False)))
        self._sync_passi_row()
        if preset.get("site"):
            self.var_site_url.set("https://example.test")
        if not skip_equipe and preset.get("equipe") == "red" and self._equipe != "red":
            self._set_equipe("red")
        if self._equipe != "red":
            self._clip_blue_vars()
        self._sync_equipe_caps()
        label = preset.get("label", profil)
        self._append_log(
            f"Profil « {profil} » → {label} ; mission={mission_name} ; "
            f"full={self.var_full.get()} all_ports={self.var_all_ports.get()} "
            f"llm={self.var_llm.get()} pdf={self.var_pdf.get()} "
            f"max_time={self.var_max_time.get()}\n",
            "ok",
        )

    def _show_help(self, key: str) -> None:
        text = HELP_TEXTS.get(key, "Pas d'aide pour cette option.")
        titles = {
            "mission": "Mission",
            "cidr": "CIDR",
            "profil": "Profil",
            "yes": "--yes",
            "full": "--full",
            "all_ports": "--all-ports",
            "llm": "--llm",
            "pdf": "--pdf",
            "max_time": "--max-time",
            "verbose": "--verbose",
            "llm_model": "--llm-model",
            "llm_url": "--llm-url",
            "ngl": "--ngl",
            "force_gpu": "GPU / --cpu-llm",
            "workers": "--workers",
            "skip_phase": "Passer phase",
            "audit": "--audit",
            "audit_full": "--audit-full / mandat",
            "site": "--site",
            "rgpd": "Signalement RGPD",
            "usages": "Usages & droits",
            "machines": "--machines / Ethernet industriel",
            "pistes": "Pistes à explorer",
            "greenbone": "Greenbone / GVM — lecture GMP",
            "lynis": "Lynis opérateur",
            "trivy": "Trivy opérateur",
            "passi": "Offre PASSI (red) — six briques, pas une qualification",
            "autorisations": "Autorisations red — huit pièces",
            "liens": "Checkup des liens",
        }
        messagebox.showinfo(f"Aide — {titles.get(key, key)}", text, parent=self)

    def _browse_mission(self) -> None:
        path = filedialog.askopenfilename(
            parent=self,
            title="Choisir une mission YAML",
            initialdir=str(MISSIONS),
            filetypes=[("YAML", "*.yaml *.yml"), ("Tous", "*.*")],
        )
        if path:
            self.var_mission.set(path)
            self._sync_ui_from_mission_file(path)

    def _open_rapports(self) -> None:
        RAPPORTS.mkdir(parents=True, exist_ok=True)
        path = str(RAPPORTS)
        ok, msg = self._open_folder(path)
        if ok:
            self._append_log(f"Ouverture : {msg}\n", "ok")
        else:
            messagebox.showinfo(
                "Rapports",
                f"Ouverture dossier échouée : {msg}\n\n"
                f"Ouvre manuellement :\n{path}\n\n"
                "Lance « Checkup des liens » : en root, Thunar a besoin de la session bureau.",
                parent=self,
            )
            self._append_log(f"Dossier rapports (manuel) : {path} — {msg}\n", "err")

    def _open_missions(self) -> None:
        MISSIONS.mkdir(parents=True, exist_ok=True)
        path = str(MISSIONS)
        ok, msg = self._open_folder(path)
        if ok:
            self._append_log(f"Ouverture : {msg}\n", "ok")
        else:
            messagebox.showinfo(
                "Missions",
                f"Ouverture dossier échouée : {msg}\n\nOuvre manuellement :\n{path}",
                parent=self,
            )
            self._append_log(f"Dossier missions (manuel) : {path} — {msg}\n", "err")

    def _open_last_reports(self) -> None:
        """Ouvre le dernier HTML + PDF (ou les plus récents dans rapports/)."""
        html = self._last_html if self._last_html and Path(self._last_html).is_file() else self._newest_rapport("*.html")
        pdf = self._last_pdf if self._last_pdf and Path(self._last_pdf).is_file() else self._newest_rapport("*.pdf")
        opened = False
        for label, path in (("HTML", html), ("PDF", pdf)):
            if path and Path(path).is_file():
                ok, msg = self._open_file(path)
                if ok:
                    self._append_log(f"Ouverture {label} : {msg}\n", "ok")
                    opened = True
                else:
                    self._append_log(f"Impossible d'ouvrir {label} : {msg}\n", "err")
        if not opened:
            messagebox.showinfo(
                "Rapports",
                "Aucun rapport HTML/PDF dans rapports/.\n"
                "Lance d'abord un Run (coche PDF pour l'export).",
                parent=self,
            )

    def _newest_rapport(self, pattern: str) -> str | None:
        try:
            RAPPORTS.mkdir(parents=True, exist_ok=True)
            files = sorted(RAPPORTS.glob(pattern), key=lambda x: x.stat().st_mtime, reverse=True)
            return str(files[0]) if files else None
        except OSError:
            return None

    def _open_folder(self, path: str) -> tuple[bool, str]:
        from guardia.core.open_links import open_path

        return open_path(path, folder=True)

    def _open_file(self, path: str) -> tuple[bool, str]:
        from guardia.core.open_links import open_path

        return open_path(path, folder=False)

    def _startup_liens(self) -> None:
        from guardia.core.open_links import format_checkup, run_checkup

        try:
            rep = run_checkup(repair=True)
        except Exception as exc:  # noqa: BLE001
            self._append_log(f"Checkup des liens : {exc}\n", "err")
            return
        self._liens_rep = rep
        summary = (
            f"Liens : {rep.get('ok', 0)} OK · {rep.get('warn', 0)} warn · {rep.get('ko', 0)} KO"
        )
        self.var_timings.set(summary)
        self._append_log(format_checkup(rep) + "\n", "ok" if not rep.get("ko") else "err")
        if rep.get("ko"):
            messagebox.showwarning(
                "Checkup des liens",
                summary
                + "\n\nLes dossiers / PDF peuvent ne pas s'ouvrir tant que ce n'est pas vert.\n"
                "Détail dans le journal. CLI : python3 -m guardia liens",
                parent=self,
            )

    def _do_liens(self) -> None:
        from guardia.core.open_links import format_checkup, run_checkup

        rep = run_checkup(repair=True)
        self._liens_rep = rep
        text = format_checkup(rep)
        self._append_log(text + "\n", "ok" if not rep.get("ko") else "err")
        messagebox.showinfo("Checkup des liens", text, parent=self)

    def _do_voir_programme(self) -> None:
        from guardia.core.models import Mission
        from guardia.engines.programme import build_programme

        try:
            mission = Mission()
            path = (self.var_mission.get() or "").strip()
            if path:
                from guardia.cli import load_mission

                mission = load_mission(Path(path))
        except Exception as exc:  # noqa: BLE001
            mission = Mission()
            self._append_log(f"outils: mission lue partiellement ({exc})\n", "err")
        url = (self.var_site_url.get() or "").strip() or None
        block = build_programme(mission, cidr=self.var_cidr.get(), url=url)
        lines = [
            "OUTILS DE LA VISITE — lecture, calibrage",
            block.get("analogie") or "",
            "",
            f"Mandat : {'oui' if block.get('mandat') else 'non'}",
            f"CIDR : {(block.get('assets') or {}).get('cidr') or '—'}",
            "URL : " + (", ".join((block.get("assets") or {}).get("urls") or []) or "—"),
            "",
            f"{'outil':24} {'installé':9}  aide",
        ]
        for o in block.get("outils") or []:
            lines.append(
                f"{str(o.get('nom') or '')[:24]:24} "
                f"{'oui' if o.get('installe') else 'non':9}  "
                f"{o.get('aide') or o.get('pourquoi') or ''}"
            )
        lines.append("")
        lines.append("Aide : python3 -m guardia outil list")
        text = "\n".join(lines)
        self._append_log(text + "\n", "ok")
        messagebox.showinfo("Outils Guardia", text, parent=self)

    def _append_log(self, text: str, tag: str | None = None) -> None:
        self.log.configure(state=tk.NORMAL)
        if tag:
            self.log.insert(tk.END, text, tag)
        else:
            self.log.insert(tk.END, text)
        self.log.see(tk.END)
        self.log.configure(state=tk.NORMAL)
        self._maybe_update_timings(text)
        self._maybe_capture_reports(text)
        path = getattr(self, "_ui_log_path", None)
        if path is not None:
            try:
                with path.open("a", encoding="utf-8") as fh:
                    fh.write(text)
            except OSError:
                pass

    def _maybe_update_timings(self, text: str) -> None:
        # Détecte "Timings : ..." dans la sortie CLI
        m = re.search(r"Timings\s*:\s*(.+)", text)
        if m:
            self.var_timings.set(f"Timings : {m.group(1).strip()}")
            return
        m2 = re.search(r"budget mission:\s*(\d+)s", text, re.I)
        if m2:
            self.var_timings.set(f"Timings : budget {m2.group(1)}s")

    def _maybe_capture_reports(self, text: str) -> None:
        m = re.search(r"Rapport HTML\s*:\s*(\S+)", text)
        if m:
            self._last_html = m.group(1).strip()
        m = re.search(r"PDF\s*:\s*(\S+)", text)
        if m:
            cand = m.group(1).strip()
            if not cand.startswith("("):
                self._last_pdf = cand
        if self._spawn_kind == "run" and text.startswith("[exit ") and "exit 0" in text:
            self.after(200, self._auto_open_reports)

    def _auto_open_reports(self) -> None:
        html = self._last_html if self._last_html and Path(self._last_html).is_file() else self._newest_rapport("*.html")
        pdf = self._last_pdf if self._last_pdf and Path(self._last_pdf).is_file() else None
        if self.var_pdf.get() and (not pdf or not Path(pdf).is_file()):
            pdf = self._newest_rapport("*.pdf")
        for label, path in (("HTML", html), ("PDF", pdf)):
            if path and Path(path).is_file():
                ok, msg = self._open_file(path)
                if ok:
                    self._append_log(f"Ouverture auto {label} : {msg}\n", "ok")
                else:
                    self._append_log(f"Ouverture auto {label} échouée : {msg}\n", "err")
        self._spawn_kind = None

    def _drain_log(self) -> None:
        try:
            while True:
                line = self._log_q.get_nowait()
                if line.strip() == "[__proc_done__]":
                    self._set_busy_ui(False)
                    continue
                tag = None
                low = line.lower()
                if "error" in low or "erreur" in low or "échec" in low or "fail" in low:
                    tag = "err"
                elif "timings" in low or "budget" in low:
                    tag = "timing"
                self._append_log(line, tag)
                self._maybe_phase_explode(line)
        except queue.Empty:
            pass
        self.after(80, self._drain_log)


    def _maybe_phase_explode(self, line: str) -> None:
        """Red : explosion des gouttes à chaque phase / action terminée."""
        if self._equipe != "red":
            return
        s = (line or "").strip()
        if not s:
            return
        hit = (
            s.startswith("──")
            or s.startswith("Hôtes :")
            or s.startswith("Regard ")
            or s.startswith("Pistes :")
            or s.startswith("JSON")
            or s.startswith("Rapport HTML")
            or s.startswith("Site :")
            or s.startswith("Machines :")
            or s.startswith("Audit [")
        )
        if not hit:
            return
        import time as _time

        now = _time.monotonic()
        if now - getattr(self, "_last_explode", 0.0) < 0.45:
            return
        self._last_explode = now
        try:
            if getattr(self, "_logo", None) is not None:
                self._logo.explode()
        except Exception:
            pass

    def _mission_cidr_flags(self) -> list[str]:
        """Mission + CIDR : la fenêtre prime toujours sur le YAML.

        CIDR rempli → ``--cidr`` (ignore le cidr du YAML).
        CIDR vide → ``--cidr-catalog`` (catalogue de plages, ignore YAML).
        """
        flags: list[str] = []
        mission = self.var_mission.get().strip()
        if mission:
            flags.extend(["--mission", mission])
        cidr = self.var_cidr.get().strip()
        if cidr:
            flags.extend(["--cidr", cidr])
        else:
            flags.append("--cidr-catalog")
        return flags

    def _run_flags(self) -> list[str]:
        """Construit les flags CLI. Les cases de la fenêtre priment sur le YAML.

        Chaque option UI envoie explicitement ``--opt`` ou ``--no-opt`` pour que
        ``appliquer_yaml`` / ``want_*`` ne réactivent pas un module décoché
        (et pour qu'un module coché s'applique même si le YAML ne l'a pas).
        """
        flags = self._mission_cidr_flags()
        profil = self.var_profil.get().strip()
        if profil in ("maison", "pme", "ecole"):
            flags.extend(["--profile", profil])

        if self.var_yes.get():
            flags.append("--yes")
        if self._equipe == "red":
            flags.extend(["--equipe", "red"])

        def on_off(name: str, enabled: bool) -> None:
            flags.append(f"--{name}" if enabled else f"--no-{name}")

        # LAN
        lan_on = bool(getattr(self, "var_lan", None) and self.var_lan.get())
        on_off("lan", lan_on)

        mode = (self.var_profil.get() or "").strip()
        if mode == "passi":
            on_off("passi", True)
            on_off("autorisations", bool(self.var_autorisations.get()))
            acts = []
            if self.var_act_org.get():
                acts.append("organisationnel_physique")
            if self.var_act_arch.get():
                acts.append("architecture")
            if self.var_act_cfg.get():
                acts.append("configuration")
            if self.var_act_code.get():
                acts.append("code_source")
            if self.var_act_int.get():
                acts.append("intrusion")
            if acts:
                flags.extend(["--passi-activites", ",".join(acts)])
            on_off("full", False)
            on_off("all-ports", False)
        else:
            on_off("passi", bool(getattr(self, "var_passi", None) and self.var_passi.get()))
            on_off("autorisations", bool(getattr(self, "var_autorisations", None) and self.var_autorisations.get()))
            on_off("full", bool(self.var_full.get()))
            on_off("all-ports", bool(self.var_all_ports.get()))

        audit_full = bool(getattr(self, "var_audit_full", None) and self.var_audit_full.get())
        audit = bool(getattr(self, "var_audit", None) and self.var_audit.get())
        if audit_full:
            flags.append("--audit-full")
            if "--audit" not in flags:
                flags.append("--audit")
        elif audit:
            flags.append("--audit")
        else:
            flags.append("--no-audit")

        cve_var = getattr(self, "var_cve", None)
        if cve_var is not None:
            on_off("cve", bool(cve_var.get()))

        on_off("pdf", bool(self.var_pdf.get()))

        site_on = bool(getattr(self, "var_site", None) and self.var_site.get())
        if site_on:
            url = (self.var_site_url.get() or "").strip() or "https://example.test"
            flags.extend(["--site", url])
        else:
            flags.append("--no-site")

        on_off("rgpd", bool(getattr(self, "var_rgpd", None) and self.var_rgpd.get()))
        on_off("usages", bool(getattr(self, "var_usages", None) and self.var_usages.get()))
        on_off("machines", bool(getattr(self, "var_machines", None) and self.var_machines.get()))
        on_off("pistes", bool(getattr(self, "var_pistes", None) and self.var_pistes.get()))
        on_off("greenbone", bool(getattr(self, "var_greenbone", None) and self.var_greenbone.get()))
        on_off("lynis", bool(getattr(self, "var_lynis", None) and self.var_lynis.get()))
        on_off("trivy", bool(getattr(self, "var_trivy", None) and self.var_trivy.get()))
        on_off("calibrage", bool(getattr(self, "var_calibrage", None) and self.var_calibrage.get()))
        on_off("llm", bool(self.var_llm.get()))
        if self.var_llm.get():
            model = self.var_llm_model.get().strip()
            if model:
                flags.extend(["--llm-model", model])
            url = self.var_llm_url.get().strip()
            if url:
                flags.extend(["--llm-url", url])

        mt = self.var_max_time.get().strip() or "7200"
        flags.extend(["--max-time", mt])

        # workers / GPU LLM
        if getattr(self, "var_force_gpu", None) is not None and not self.var_force_gpu.get():
            flags.append("--cpu-llm")
        w = (getattr(self, "var_workers", None) and self.var_workers.get() or "").strip()
        if w and w.lower() != "auto":
            try:
                flags.extend(["--workers", str(int(w))])
            except ValueError:
                pass

        return flags


    def _discover_flags(self) -> list[str]:
        flags = self._mission_cidr_flags()
        if self.var_yes.get():
            flags.append("--yes")
        if self._equipe == "red" and self.var_full.get():
            flags.append("--full")
        return flags

    def _set_busy_ui(self, busy: bool) -> None:
        """Logo header : accélère pendant le run, rythme normal à la fin."""
        try:
            if getattr(self, "_logo", None) is not None:
                self._logo.set_busy(busy)
        except Exception:  # noqa: BLE001
            pass

    def _spawn(self, argv: list[str], title: str, *, kind: str | None = None) -> None:
        if self._running:
            messagebox.showwarning("Busy", "Une commande est déjà en cours. Arrête-la d'abord.")
            return
        cmd = _base_cmd() + argv
        self._append_log(f"\n── {title} ──\n$ {' '.join(cmd)}\n", "ok")
        self._running = True
        self._spawn_kind = kind
        if kind == "run":
            self._last_html = None
            self._last_pdf = None
        self._set_busy_ui(True)

        def worker() -> None:
            try:
                env = {**os.environ, "PYTHONUNBUFFERED": "1"}
                if self._equipe == "red" and self._red_pass:
                    env["GUARDIA_RED_PASS"] = self._red_pass
                self._proc = subprocess.Popen(
                    cmd,
                    cwd=str(ROOT),
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    text=True,
                    bufsize=1,
                    env=env,
                )
                assert self._proc.stdout is not None
                for line in self._proc.stdout:
                    self._log_q.put(line)
                code = self._proc.wait()
                self._log_q.put(f"\n[exit {code}]\n")
            except Exception as exc:  # noqa: BLE001
                self._log_q.put(f"\n[erreur lancement] {exc}\n")
            finally:
                self._proc = None
                self._running = False
                self._log_q.put("[__proc_done__]\n")

        threading.Thread(target=worker, daemon=True).start()

    def _skip_phase(self) -> None:
        """SIGUSR1 → passer la phase en cours, continuer le checkup."""
        import signal

        p = self._proc
        if not p or p.poll() is not None:
            self._append_log("Aucune commande en cours à tronquer.\n", "err")
            return
        try:
            p.send_signal(signal.SIGUSR1)
            self._append_log(
                f"Signal Passer phase (SIGUSR1) envoyé au pid {p.pid}.\n"
                "La phase en cours sera tronquée ; le rapport notera l'arrêt opérateur.\n",
                "timing",
            )
        except OSError as exc:
            self._append_log(f"Impossible d'envoyer SIGUSR1 : {exc}\n", "err")

    def _stop_proc(self) -> None:

        p = self._proc
        if p and p.poll() is None:
            p.terminate()
            self._append_log("\n[tout arrêté — process tué]\n", "err")
        else:
            self._append_log("Aucune commande en cours.\n")

    def _do_about(self) -> None:
        # Affiche aussi en popup pour quick view
        try:
            out = subprocess.check_output(
                _base_cmd() + ["about"],
                cwd=str(ROOT),
                text=True,
                timeout=15,
            )
        except Exception as exc:  # noqa: BLE001
            out = f"(échec about) {exc}"
        messagebox.showinfo("About — Guardia", out, parent=self)
        self._append_log(out + ("\n" if not out.endswith("\n") else ""), "ok")


    def _draw_nouveau_client_btn(self, *, hover: bool = False) -> None:
        """Disque « Nouveau client » dans le bandeau."""
        c = getattr(self, "_btn_nouveau_client", None)
        if c is None:
            return
        c.delete("all")
        fill = "#2E86C1" if hover else "#1B4F72"
        outline = "#154360" if hover else "#0E2F44"
        c.create_oval(4, 4, 92, 92, fill=fill, outline=outline, width=3, tags=("nc",))
        c.create_text(
            48,
            38,
            text="Nouveau",
            fill="#FFFFFF",
            font=("Segoe UI", 10, "bold"),
            tags=("nc",),
        )
        c.create_text(
            48,
            58,
            text="client",
            fill="#D6EAF8",
            font=("Segoe UI", 10, "bold"),
            tags=("nc",),
        )

    def _hub_nouveau_client_path(self):
        from pathlib import Path as _P
        from guardia.core.paths import MODELES, ROOT

        candidates = [
            MODELES / "a-signer" / "nouveau-client.html",
            ROOT / "modeles" / "a-signer" / "nouveau-client.html",
            MODELES / "a-signer" / "index.html",
        ]
        for p in candidates:
            if p.is_file():
                return p
        return candidates[0]

    def _do_nouveau_client(self) -> None:
        """Ouvre le hub docs dans Firefox neutre ; dialog de secours si échec."""
        import tkinter as _tk
        from tkinter import ttk as _ttk

        hub = self._hub_nouveau_client_path()
        file_url = hub.resolve().as_uri() if hub.exists() else str(hub)

        def open_hub(*, parent=None) -> bool:
            from guardia.core.firefox_neutre import ensure_neutre_profile, open_html

            rep = ensure_neutre_profile(create_desktop=True)
            self._append_log(
                f"Firefox neutre : {rep.get('detail')}\n",
                "ok" if rep.get("ok") else "err",
            )
            if not hub.is_file():
                messagebox.showwarning(
                    "Nouveau client",
                    f"Hub introuvable :\n{hub}\n\nRégénérez : python3 modeles/build_a_signer.py",
                    parent=parent or self,
                )
                return False
            ok, msg = open_html(hub)
            if ok:
                self._append_log(f"Hub ouvert (Firefox neutre) : {msg}\n", "ok")
                return True
            messagebox.showwarning(
                "Nouveau client",
                f"Ouverture Firefox neutre : {msg}\n\nLien :\n{file_url}\n\n"
                "Script : scripts/install-firefox-neutre.sh",
                parent=parent or self,
            )
            return False

        # Comportement attendu : ouverture directe dans Firefox neutre
        if open_hub(parent=self):
            return

        # Secours : dialog lien / wizard
        win = _tk.Toplevel(self)
        win.title("Nouveau client — Guardia")
        win.transient(self)
        win.configure(bg=BG)
        win.geometry("520x300")
        frm = _ttk.Frame(win, padding=20)
        frm.pack(fill=_tk.BOTH, expand=True)
        _ttk.Label(frm, text="Nouveau client", font=("Segoe UI", 14, "bold")).pack(anchor=_tk.W)
        _ttk.Label(
            frm,
            text=(
                "Firefox neutre n'a pas pu ouvrir le pack. "
                "Réessayez, copiez le lien, ou lancez le wizard mission."
            ),
            wraplength=460,
        ).pack(anchor=_tk.W, pady=(6, 16))

        def retry() -> None:
            if open_hub(parent=win):
                win.destroy()

        def copy_link() -> None:
            try:
                self.clipboard_clear()
                self.clipboard_append(file_url)
                self.update()
                self._append_log(f"Lien copié : {file_url}\n", "ok")
                messagebox.showinfo("Lien copié", file_url, parent=win)
            except _tk.TclError as exc:
                messagebox.showwarning("Presse-papiers", str(exc), parent=win)

        def go_wizard() -> None:
            win.destroy()
            self._do_new_mission()

        btns = _ttk.Frame(frm)
        btns.pack(fill=_tk.X, pady=(8, 0))
        _ttk.Button(
            btns,
            text="Réessayer Firefox neutre",
            style="Accent.TButton",
            command=retry,
        ).pack(fill=_tk.X, pady=4)
        _ttk.Button(btns, text="Copier le lien file://", style="Soft.TButton", command=copy_link).pack(
            fill=_tk.X, pady=4
        )
        _ttk.Button(
            btns,
            text="Nouvelle mission (wizard actuel)",
            style="Soft.TButton",
            command=go_wizard,
        ).pack(fill=_tk.X, pady=4)

    def _maybe_ask_queen_api(self) -> None:
        """Premier lancement / clé absente : demander GROQ_API_KEY + lien console."""
        try:
            from guardia.engines.llm_groq_directives import (
                GROQ_CONSOLE_URL,
                has_queen_api_key,
                write_queen_api_key,
            )
        except Exception as exc:  # noqa: BLE001
            self._append_log(f"Queen setup indisponible : {exc}\n", "err")
            return
        try:
            if has_queen_api_key():
                return
        except Exception:
            return

        import tkinter as _tk
        from tkinter import ttk as _ttk

        win = _tk.Toplevel(self)
        win.title("Queen — clé API Groq")
        win.transient(self)
        win.configure(bg=BG)
        win.geometry("540x340")
        frm = _ttk.Frame(win, padding=20)
        frm.pack(fill=_tk.BOTH, expand=True)
        _ttk.Label(frm, text="Clé API Queen (Groq)", font=("Segoe UI", 14, "bold")).pack(
            anchor=_tk.W
        )
        _ttk.Label(
            frm,
            text=(
                "Premier lancement : pour les directives technicien (lecture seule, "
                "sans exploit), collez votre clé Groq. Elle est enregistrée dans "
                "queen_decide (chmod 600), jamais dans les logs."
            ),
            wraplength=480,
        ).pack(anchor=_tk.W, pady=(8, 12))
        _ttk.Label(frm, text="GROQ_API_KEY", style="Muted.TLabel").pack(anchor=_tk.W)
        var = _tk.StringVar()
        ent = _ttk.Entry(frm, textvariable=var, show="•", width=56)
        ent.pack(fill=_tk.X, pady=(4, 12))
        ent.focus_set()

        def open_console() -> None:
            from guardia.core.firefox_neutre import ensure_neutre_profile, open_html

            ensure_neutre_profile(create_desktop=True)
            ok, msg = open_html(GROQ_CONSOLE_URL)
            self._append_log(
                f"Console Groq (Firefox neutre) : {msg}\n",
                "ok" if ok else "err",
            )
            if not ok:
                try:
                    self.clipboard_clear()
                    self.clipboard_append(GROQ_CONSOLE_URL)
                    self.update()
                except _tk.TclError:
                    pass
                messagebox.showinfo(
                    "Lien console Groq",
                    f"Ouvrez :\n{GROQ_CONSOLE_URL}\n\n(lien copié si possible)",
                    parent=win,
                )

        def save() -> None:
            key = (var.get() or "").strip()
            if not key:
                messagebox.showwarning(
                    "Clé API",
                    "Collez une clé, ou ouvrez le lien pour en créer une, "
                    "ou choisissez « Plus tard ».",
                    parent=win,
                )
                return
            try:
                path = write_queen_api_key(key)
            except Exception as exc:  # noqa: BLE001
                messagebox.showerror("Queen", str(exc), parent=win)
                return
            self._append_log(f"queen_decide enregistré : {path} (clé masquée)\n", "ok")
            messagebox.showinfo(
                "Queen",
                "Clé enregistrée dans queen_decide.\n"
                "Relancez éventuellement l'UI pour sourcer le fichier au démarrage.",
                parent=win,
            )
            win.destroy()

        def later() -> None:
            self._append_log(
                "Queen : clé reportée — directives Groq en stub tant que GROQ_API_KEY manque.\n"
            )
            win.destroy()

        btns = _ttk.Frame(frm)
        btns.pack(fill=_tk.X, pady=(8, 0))
        _ttk.Button(btns, text="Enregistrer", style="Accent.TButton", command=save).pack(
            fill=_tk.X, pady=4
        )
        _ttk.Button(
            btns,
            text="Je n'ai pas de clé — ouvrir console.groq.com (Firefox neutre)",
            style="Soft.TButton",
            command=open_console,
        ).pack(fill=_tk.X, pady=4)
        _ttk.Button(btns, text="Plus tard", style="Soft.TButton", command=later).pack(
            fill=_tk.X, pady=4
        )
        _ttk.Label(
            frm,
            text=GROQ_CONSOLE_URL,
            style="Muted.TLabel",
        ).pack(anchor=_tk.W, pady=(10, 0))

    def _do_new_mission(self) -> None:
        """Popup : questions mission → YAML dans missions/ + charge dans l'UI."""
        from guardia.ui.new_mission import ask_new_mission

        path = ask_new_mission(self)
        if not path:
            self._append_log("Nouvelle mission annulée.\n")
            return
        self.var_mission.set(str(path))
        self._append_log(f"Mission créée : {path}\n", "ok")
        self._sync_ui_from_mission_file(path)

    def _sync_ui_from_mission_file(self, path) -> None:
        """Aligne CIDR / profil / cases sur le YAML chargé."""
        from pathlib import Path as _P

        path = _P(path)
        try:
            import yaml  # type: ignore
            data = yaml.safe_load(path.read_text(encoding="utf-8")) or {}
        except Exception as exc:  # noqa: BLE001
            self._append_log(f"(sync UI) lecture YAML : {exc}\n", "err")
            return
        if not isinstance(data, dict):
            return
        if "cidr" in data:
            cidr = data.get("cidr")
            self.var_cidr.set(str(cidr).strip() if cidr else "")
        profil = str(data.get("profil_moteur") or "")
        if profil in ("maison", "pme", "ecole"):
            # ne pas écraser un preset full volontaire — si profondeur full + extras, affiche full
            pass
        profondeur = str(data.get("profondeur") or "standard")
        fullish = profondeur == "full" or bool(data.get("parc_inconnu"))
        all_ports = bool(data.get("all_ports"))
        llm = bool(data.get("llm"))
        pdf = bool(data.get("pdf"))
        if fullish and all_ports and llm and pdf:
            self.var_profil.set("full")
        elif profil in ("maison", "pme", "ecole"):
            self.var_profil.set(profil)
        self.var_full.set(fullish)
        self.var_all_ports.set(all_ports)
        self.var_llm.set(llm)
        self.var_pdf.set(pdf)
        if data.get("max_time") is not None:
            self.var_max_time.set(str(data.get("max_time")))
        if data.get("mandat_nda_signes"):
            self.var_yes.set(True)
        site = data.get("site_url") or data.get("site")
        if site:
            self.var_site.set(True)
            su = str(site).strip()
            if su.lower() not in ("1", "true", "oui", "yes", "on"):
                self.var_site_url.set(su)
        elif "site_url" in data or "site" in data:
            self.var_site.set(bool(site))
        for key, var in (
            ("rgpd", "var_rgpd"),
            ("usages", "var_usages"),
            ("machines", "var_machines"),
            ("audit", "var_audit"),
            ("audit_full", "var_audit_full"),
            ("greenbone", "var_greenbone"),
            ("lynis", "var_lynis"),
            ("trivy", "var_trivy"),
            ("pistes", "var_pistes"),
            ("passi", "var_passi"),
            ("autorisations", "var_autorisations"),
        ):
            if key in data and hasattr(self, var):
                getattr(self, var).set(bool(data.get(key)))
        if "calibrage" in data and hasattr(self, "var_calibrage"):
            self.var_calibrage.set(bool(data.get("calibrage")))
        want = str(data.get("equipe") or "").strip().lower()
        if want in ("red", "rouge", "redteam", "red-team"):
            if self._red_unlocked:
                if self._equipe != "red":
                    self._set_equipe("red")
            elif self.var_profil.get() != "red":
                self.var_profil.set("red")
        self._append_log(
            f"UI alignée sur YAML : profil={self.var_profil.get()} "
            f"full={self.var_full.get()} all_ports={self.var_all_ports.get()} "
            f"llm={self.var_llm.get()} pdf={self.var_pdf.get()} "
            f"site={self.var_site.get()} rgpd={self.var_rgpd.get()} "
            f"equipe yaml={want or 'blue'}\n",
            "ok",
        )

    def _do_rgpd_config(self) -> None:
        """Ouvre la fiche RGPD et l'écrit dans la mission courante."""
        from guardia.cli import load_mission
        from guardia.engines.rgpd_config import load_rgpd_config, patch_mission_yaml
        from guardia.ui.rgpd_dialog import ask_rgpd_config

        mission_s = (self.var_mission.get() or "").strip()
        if not mission_s:
            messagebox.showinfo(
                "RGPD",
                "Choisis d'abord un fichier mission, ou crée-en une (Nouvelle mission).",
                parent=self,
            )
            return
        path = Path(mission_s)
        if not path.is_file():
            messagebox.showerror("RGPD", f"Mission introuvable :\n{path}", parent=self)
            return
        try:
            mission = load_mission(path)
            initial = load_rgpd_config(mission)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("RGPD", f"Lecture mission :\n{exc}", parent=self)
            return
        cfg = ask_rgpd_config(self, initial=initial)
        if cfg is None:
            self._append_log("Fiche RGPD : annulée.\n")
            return
        try:
            patch_mission_yaml(path, cfg)
        except OSError as exc:
            messagebox.showerror("RGPD", f"Écriture impossible :\n{exc}", parent=self)
            return
        self.var_rgpd.set(True)
        from guardia.engines.rgpd_config import summary_line

        self._append_log(
            f"Fiche RGPD enregistrée dans {path}\n"
            f"{summary_line(cfg)}\n"
            "Signalement sur demande — pas un certificat.\n",
            "ok",
        )
        messagebox.showinfo(
            "RGPD",
            "Fiche enregistrée dans la mission.\n"
            f"{summary_line(cfg)}\n\n"
            "Le prochain Run --rgpd l'utilisera.\n"
            "Ce n'est pas un certificat de conformité.",
            parent=self,
        )

    def _do_usages_config(self) -> None:
        from guardia.cli import load_mission
        from guardia.engines.usages_config import (
            load_usages_config,
            patch_mission_yaml,
            summary_line,
        )
        from guardia.ui.usages_dialog import ask_usages_config

        mission_s = (self.var_mission.get() or "").strip()
        if not mission_s:
            messagebox.showinfo(
                "Usages",
                "Choisis d'abord un fichier mission, ou crée-en une (Nouvelle mission).",
                parent=self,
            )
            return
        path = Path(mission_s)
        if not path.is_file():
            messagebox.showerror("Usages", f"Mission introuvable :\n{path}", parent=self)
            return
        try:
            mission = load_mission(path)
            initial = load_usages_config(mission)
        except Exception as exc:  # noqa: BLE001
            messagebox.showerror("Usages", f"Lecture mission :\n{exc}", parent=self)
            return
        cfg = ask_usages_config(self, initial=initial)
        if cfg is None:
            self._append_log("Fiche usages : annulée.\n")
            return
        try:
            patch_mission_yaml(path, cfg)
        except OSError as exc:
            messagebox.showerror("Usages", f"Écriture impossible :\n{exc}", parent=self)
            return
        self.var_usages.set(True)
        self._append_log(
            f"Fiche usages enregistrée dans {path}\n"
            f"{summary_line(cfg)}\n"
            "Portes en lecture seule — pas un dump.\n",
            "ok",
        )
        messagebox.showinfo(
            "Usages",
            "Fiche enregistrée dans la mission.\n"
            f"{summary_line(cfg)}\n\n"
            "Le prochain Run --usages l'utilisera.\n"
            "Ce n'est pas un dump d'annuaire.",
            parent=self,
        )

    def _do_wizard(self) -> None:
        """Lance le wizard CLI dans un terminal externe (interactif)."""
        wizard_cmd = f"cd {ROOT!s} && {_python()} -m guardia wizard; echo; read -p 'Entrée pour fermer…'"
        launched = False
        for term in (
            ["konsole", "--workdir", str(ROOT), "-e", "bash", "-lc", wizard_cmd],
            ["x-terminal-emulator", "-e", "bash", "-lc", wizard_cmd],
            ["xfce4-terminal", "-e", f"bash -lc {wizard_cmd!r}"],
            ["xterm", "-e", "bash", "-lc", wizard_cmd],
        ):
            try:
                subprocess.Popen(term, cwd=str(ROOT))
                launched = True
                self._append_log(f"Wizard lancé via {term[0]}\n", "ok")
                break
            except FileNotFoundError:
                continue
        if not launched:
            messagebox.showinfo(
                "Wizard",
                "Aucun terminal graphique trouvé.\n"
                f"Lance manuellement :\ncd {ROOT}\npython3 -m guardia wizard",
                parent=self,
            )

    def _do_discover(self) -> None:
        pre = ["--verbose"] if self.var_verbose.get() else []
        argv = pre + ["discover"] + self._discover_flags()
        self._spawn(argv, "Discover", kind="discover")

    def _do_run(self) -> None:
        if self.var_profil.get() == "red" and self._equipe != "red":
            self._set_equipe("red")
            if self._equipe != "red":
                self._append_log("Red team : mot de passe refuse — on reste blue.\n", "err")
                return
        if not self._validate_red_gate_or_warn():
            self._append_log(
                "Red Team : action demandee sans document signe — run refuse.\n", "err"
            )
            return
        pre = ["--verbose"] if self.var_verbose.get() else []
        argv = pre + ["run"] + self._run_flags()
        self._spawn(argv, "Run checkup", kind="run")

    def _on_close(self) -> None:
        try:
            self._logo.stop()
        except Exception:  # noqa: BLE001
            pass
        self._stop_proc()
        self.destroy()


def check_display() -> str | None:
    """Retourne un message d'erreur si pas de DISPLAY, sinon None."""
    if sys.platform.startswith("linux") and not os.environ.get("DISPLAY") and not os.environ.get("WAYLAND_DISPLAY"):
        return (
            "Aucun affichage graphique (DISPLAY / WAYLAND_DISPLAY absent).\n"
            "Lance Guardia UI depuis une session bureau, ou exporte DISPLAY=:0\n"
            "Exemple : DISPLAY=:1 python3 -m guardia ui"
        )
    return None


def run_app() -> int:
    try:
        from guardia.core.desktop_launch import ensure_guardia_desktop
        ensure_guardia_desktop(force=False)
    except Exception:
        pass
    err = check_display()
    if hasattr(os, "geteuid") and os.geteuid() == 0:
        # Les thèmes KF / xdg-open en root sont bruyants et souvent cassés
        print(
            "Guardia UI en root — OK pour les scans. "
            "Warnings kf.iconthemes / kfmclient = cosmétique (thèmes Plasma).",
            flush=True,
        )

    if err:
        print(err, file=sys.stderr)
        return 2
    try:
        import tkinter as _tk  # noqa: F401
    except ImportError:
        print(
            "tkinter indisponible. Sur Debian/Kali : sudo apt install python3-tk",
            file=sys.stderr,
        )
        return 2
    from guardia.engines.llm_gate import exiger, ligne, ressources
    from guardia.engines.llm_bootstrap import ensure_gguf

    # Une seule fois au démarrage UI : si GGUF absent → dialogue opérateur.
    try:
        if not ressources().get("model_ok"):
            ensure_gguf(ui=True, parent=None)
    except Exception as exc:  # noqa: BLE001
        print("LLM bootstrap UI : {e}".format(e=exc), flush=True)

    llm = exiger(allow_garde=True, start=True)
    print(ligne(llm), flush=True)
    if llm.get("mode") == "garde":
        if llm.get("server") and not llm.get("model"):
            print("  binaire OK : {s}".format(s=llm.get("server")), flush=True)
            print("  GGUF manquant — pose un .gguf (>10 Mo) dans models/", flush=True)
        elif llm.get("model") and not llm.get("server"):
            print("  GGUF OK : {m}".format(m=llm.get("model")), flush=True)
            print("  llama-server manquant — PATH ou ~/Bureau/bot_y/moteur/llama-server", flush=True)
        else:
            print("  astuce : llama-server --port 2443  (GGUF dans models/)", flush=True)
    app = GuardiaApp()
    try:
        app._llm_status = llm  # type: ignore[attr-defined]
        if llm.get("url"):
            app.var_llm_url.set(str(llm["url"]))
        if llm.get("mode") in ("llama", "openai-compat", "ollama"):
            app.var_llm.set(True)
        if llm.get("model") and not (app.var_llm_model.get() or "").strip():
            app.var_llm_model.set(str(llm["model"]))
        try:
            app._append_log(ligne(llm) + "\n", "ok" if llm.get("mode") != "garde" else None)
        except Exception:
            pass
    except Exception:
        pass
    app.mainloop()
    return 0


def main() -> int:
    return run_app()


if __name__ == "__main__":
    raise SystemExit(main())
