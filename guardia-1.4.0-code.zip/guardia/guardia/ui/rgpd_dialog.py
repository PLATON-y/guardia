"""Dialogue Tk : configurer la fiche RGPD d'une mission.

Déclarations opérateur / client. Pas un certificat.
"""
from __future__ import annotations

from typing import Any
import tkinter as tk
from tkinter import ttk

from guardia.engines.rgpd_config import (
    RGPD_FIELDS,
    empty_config,
    normalize_config,
)

TRI = ("inconnu", "oui", "non")


class RgpdConfigDialog(tk.Toplevel):
    """Retourne la fiche via .result (dict) ou None si annulé."""

    def __init__(self, master: tk.Misc, initial: dict[str, Any] | None = None) -> None:
        super().__init__(master)
        self.title("Configurer le signalement RGPD")
        self.resizable(True, True)
        self.result: dict[str, Any] | None = None
        try:
            from guardia.ui.app import BG, BG_CARD, FG, SANG

            self.configure(bg=BG)
        except Exception:
            BG = "#1A1513"
            self.configure(bg=BG)
        self.transient(master)
        self.grab_set()

        cfg = normalize_config(initial or empty_config())

        outer = ttk.Frame(self, padding=12)
        outer.pack(fill=tk.BOTH, expand=True)

        ttk.Label(
            outer,
            text="Fiche RGPD — déclarations sur demande. Pas un certificat CNIL, "
            "pas un tampon « conforme ». Oui / non / inconnu.",
            wraplength=560,
        ).pack(anchor=tk.W, pady=(0, 8))

        canvas = tk.Canvas(outer, highlightthickness=0, bg=BG, height=420)
        scroll = ttk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview)
        form = ttk.Frame(canvas, padding=4)
        form.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=form, anchor=tk.NW)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_mousewheel(event: tk.Event) -> None:  # type: ignore[type-arg]
            delta = getattr(event, "delta", 0) or 0
            if delta:
                canvas.yview_scroll(int(-1 * (delta / 120)), "units")

        def _on_linux_scroll(event: tk.Event) -> None:  # type: ignore[type-arg]
            canvas.yview_scroll(-1 if event.num == 4 else 1, "units")

        def _bind_wheel(_e: tk.Event | None = None) -> None:  # type: ignore[type-arg]
            canvas.bind_all("<MouseWheel>", _on_mousewheel)
            canvas.bind_all("<Button-4>", _on_linux_scroll)
            canvas.bind_all("<Button-5>", _on_linux_scroll)

        def _unbind_wheel(_e: tk.Event | None = None) -> None:  # type: ignore[type-arg]
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                try:
                    canvas.unbind_all(seq)
                except tk.TclError:
                    pass

        self._unbind_wheel = _unbind_wheel
        canvas.bind("<Enter>", _bind_wheel)
        canvas.bind("<Leave>", _unbind_wheel)

        self._vars: dict[str, tk.StringVar] = {}
        r = 0
        for f in RGPD_FIELDS:
            key = f["key"]
            ttk.Label(form, text=f["label"], wraplength=340).grid(
                row=r, column=0, sticky=tk.NW, pady=4, padx=(0, 8)
            )
            var = tk.StringVar(value=str(cfg.get(key) or ("inconnu" if f["kind"] == "tri" else "")))
            self._vars[key] = var
            if f["kind"] == "tri":
                cb = ttk.Combobox(form, textvariable=var, values=list(TRI), state="readonly", width=16)
                cb.grid(row=r, column=1, sticky=tk.W, pady=4)
            else:
                ent = ttk.Entry(form, textvariable=var, width=42)
                ent.grid(row=r, column=1, sticky=tk.EW, pady=4)
            ttk.Label(form, text=f.get("help") or "", wraplength=340).grid(
                row=r + 1, column=0, columnspan=2, sticky=tk.W, pady=(0, 6)
            )
            r += 2
        form.columnconfigure(1, weight=1)

        btns = ttk.Frame(outer)
        btns.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(btns, text="Annuler", command=self._cancel).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btns, text="Enregistrer la fiche", command=self._ok).pack(side=tk.RIGHT, padx=4)

        self.bind("<Escape>", lambda _e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.update_idletasks()
        try:
            screen_w = self.winfo_screenwidth()
            screen_h = self.winfo_screenheight()
            width = min(700, max(520, screen_w - 100))
            height = min(620, max(440, screen_h - 140))
            x = max(20, (screen_w - width) // 2)
            y = max(20, (screen_h - height) // 2)
            self.geometry(f"{width}x{height}+{x}+{y}")
        except tk.TclError:
            self.geometry("640x560")
        self.minsize(480, 420)

    def _collect(self) -> dict[str, Any]:
        raw = {k: v.get() for k, v in self._vars.items()}
        return normalize_config(raw)

    def _ok(self) -> None:
        self.result = self._collect()
        self._unbind_wheel()
        self.destroy()

    def _cancel(self) -> None:
        self.result = None
        self._unbind_wheel()
        self.destroy()


def ask_rgpd_config(master: tk.Misc, initial: dict[str, Any] | None = None) -> dict[str, Any] | None:
    dlg = RgpdConfigDialog(master, initial=initial)
    master.wait_window(dlg)
    return dlg.result
