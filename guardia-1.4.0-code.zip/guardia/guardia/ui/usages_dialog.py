"""Dialogue Tk : fiche usages & droits."""
from __future__ import annotations

from typing import Any
import tkinter as tk

from guardia.engines.usages_config import USAGES_FIELDS, empty_config, normalize_config
from guardia.ui.fiche_dialog import ask_fiche


def ask_usages_config(
    master: tk.Misc, initial: dict[str, Any] | None = None
) -> dict[str, Any] | None:
    return ask_fiche(
        master,
        title="Configurer usages & droits",
        disclaimer=(
            "Ce que les gens peuvent faire — déclarations, pas un dump d'annuaire. "
            "On ne s'assoit pas à la place de l'élève. Pas un certificat."
        ),
        fields=USAGES_FIELDS,
        initial=initial,
        normalize=normalize_config,
        empty=empty_config,
    )
