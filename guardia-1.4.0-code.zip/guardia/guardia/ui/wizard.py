"""Wizard interactif → mission.yaml (logique issue de bin/guardia-wizard.py)."""
from __future__ import annotations

import logging
from datetime import date
from pathlib import Path
from typing import Any

from guardia.core.paths import MISSIONS

log = logging.getLogger("guardia.wizard")

try:
    import yaml  # type: ignore
except ImportError:  # pragma: no cover
    yaml = None


def ask(prompt: str, default: str = "") -> str:
    suf = f" [{default}]" if default else ""
    r = input(f"{prompt}{suf}: ").strip()
    return r or default


def choose(prompt: str, options: list[tuple[str, str]], default: str = "") -> str:
    print(f"\n{prompt}")
    for i, (code, label) in enumerate(options, 1):
        mark = " ← actuel" if default and code == default else ""
        print(f"  {i}) {label}{mark}")
    hint = "numéro, Entrée = garder" if default else "numéro"
    while True:
        raw = input(f"Choix ({hint}): ").strip()
        if not raw and default:
            return default
        if raw.isdigit() and 1 <= int(raw) <= len(options):
            return options[int(raw) - 1][0]
        print("  → entre un numéro valide.")


def multi(prompt: str, options: list[tuple[str, str]]) -> list[str]:
    print(f"\n{prompt}")
    print("  (numéros séparés par des espaces, ou Entrée = aucun)")
    for i, (_code, label) in enumerate(options, 1):
        print(f"  {i}) {label}")
    raw = input("Choix: ").strip()
    if not raw:
        return []
    out: list[str] = []
    for tok in raw.split():
        if tok.isdigit() and 1 <= int(tok) <= len(options):
            out.append(options[int(tok) - 1][0])
    return out


def build_mission_dict() -> dict[str, Any]:
    print("=" * 60)
    print("GUARDIA — checkup universel (Platon-Y / Echoes of Hackers)")
    print("Aucun scan réseau ici : on prépare seulement la mission.")
    print("=" * 60)

    typ = choose(
        "Pour qui est cette mission ?",
        [
            ("foyer", "Particulier / foyer"),
            ("pme", "Entreprise / PME"),
            ("association", "Association"),
            ("ecole", "École / parc scolaire"),
            ("organisme", "Autre organisme / collectivité"),
            ("parc_entreprise", "Parc informatique d'entreprise"),
            ("parc_particulier", "Parc d'équipements chez un particulier (multi-appareils)"),
        ],
    )
    taille = choose(
        "Taille approximative du parc à regarder ?",
        [
            ("xs", "Quelques appareils (1–5)"),
            ("s", "Une petite dizaine"),
            ("m", "Quelques dizaines"),
            ("l", "Gros parc (centaines / multi-salles)"),
        ],
    )
    enjeux = multi(
        "Qu'est-ce qui doit être protégé en priorité ? (plusieurs possibles)",
        [
            ("perso", "Vie privée / données personnelles"),
            ("metier", "Activité / facturation / fichiers pro"),
            ("mineurs", "Élèves / mineurs"),
            ("image", "Réputation / confiance des adhérents"),
            ("continuite", "Continuité de service (ne pas planter la boîte)"),
        ],
    )
    equip = multi(
        "Quels équipements tu t'attends à trouver ?",
        [
            ("pc", "PC / portables"),
            ("box", "Box / routeur / Wi-Fi"),
            ("tv", "TV connectée"),
            ("console", "Console de jeu"),
            ("phone", "Téléphones / tablettes"),
            ("imprimante", "Imprimantes"),
            ("nas", "NAS / stockage"),
            ("camera", "Caméras / IoT"),
            ("serveur", "Serveurs"),
            ("invite", "Wi-Fi invité / bornes"),
            ("industriel", "Machines industrielles / automates (OT)"),
        ],
    )
    profondeur = choose(
        "Profondeur souhaitée ? (toujours défensif : pas d'exploit)",
        [
            ("doux", "Aperçu doux — inventaire + alertes évidentes"),
            ("standard", "Standard — bon équilibre pour une démo adhérent"),
            ("approfondi", "Approfondi — plus de contrôles, plus long"),
            ("full", "Full scan — parc inconnu : inventaire large + top-200 ports"),
        ],
    )
    client = ask("Nom du client / foyer / structure", "Client")
    personne = ask("Personne commune destinataire du rapport", client)
    cidr = ask("Plage réseau autorisée (CIDR), si déjà connue", "")
    mandat_ok = ask("Mandat + NDA signés ? (oui/non)", "non").lower().startswith("o")

    site_raw = ask(
        "Site web à contrôler ? (URL, ou Entrée = non ; « oui » = example.test)",
        "",
    )
    site_url = None
    if site_raw:
        low = site_raw.strip().lower()
        if low in ("oui", "o", "yes", "y"):
            site_url = "https://example.test"
        elif low not in ("non", "n", "no"):
            site_url = site_raw.strip()
            if site_url and not site_url.lower().startswith("http"):
                site_url = "https://" + site_url

    rgpd_default = "oui" if typ in ("pme", "ecole", "association", "organisme", "parc_entreprise") else "non"
    rgpd_ok = ask(
        "Signalement RGPD sur demande ? (contrôle selon exigences — PAS un certificat)",
        rgpd_default,
    ).lower().startswith("o")
    rgpd_cfg: dict[str, Any] | None = None
    if rgpd_ok:
        from guardia.engines.rgpd_config import normalize_config

        print("\n— Fiche RGPD (déclarations, pas un certificat) —")
        print("  Entrée = inconnu / laisser vide.")
        rgpd_cfg = normalize_config(
            {
                "responsable": ask("Responsable de traitement", client),
                "contact_droits": ask("Contact droits (e-mail)", ""),
                "dpo_designe": ask("DPO désigné ? (oui/non/inconnu)", "inconnu"),
                "registre_tenu": ask("Registre art. 30 tenu ? (oui/non/inconnu)", "inconnu"),
                "registre_violations": ask("Registre des violations tenu ? (oui/non/inconnu)", "inconnu"),
                "procedure_72h": ask("Procédure notification 72 h ? (oui/non/inconnu)", "inconnu"),
                "sous_traitants": ask("Sous-traitants (hébergeur, mail, analytics…)", ""),
                "contrats_art28": ask("Contrats art. 28 ? (oui/non/inconnu)", "inconnu"),
                "transferts_hors_ue": ask("Transferts hors UE/EEE ? (oui/non/inconnu)", "inconnu"),
                "durees_ecrites": ask("Durées de conservation écrites ? (oui/non/inconnu)", "inconnu"),
                "mineurs": ask(
                    "Traitement de mineurs / élèves ? (oui/non/inconnu)",
                    "oui" if typ == "ecole" else "inconnu",
                ),
                "nis2_concerne": ask("Pensez-vous être NIS2 ? (oui/non/inconnu)", "inconnu"),
                "refus_aussi_simple": ask(
                    "Bandeau cookies : refuser aussi simple qu'accepter ? (oui/non/inconnu)",
                    "inconnu",
                ),
            }
        )
    machines_ok = ask(
        "Scan machines industrielles / OT ? (Ethernet industriel, lecture — pas CAN)",
        "oui" if "industriel" in equip else "non",
    ).lower().startswith("o")

    usages_default = "oui" if typ == "ecole" else "non"
    usages_ok = ask(
        "Chapitre usages & droits ? (ce que les gens peuvent faire — PAS un dump d'annuaire)",
        usages_default,
    ).lower().startswith("o")
    usages_cfg: dict[str, Any] | None = None
    if usages_ok:
        print("\n— Usages & droits (déclarations, pas un dump) —")
        print("  La question n'est pas de passer les PC un par un.")
        print("  C'est ce qu'une session peut atteindre, et quelle machine dessert les autres.")
        from guardia.engines.usages_config import normalize_config as _norm_u

        usages_cfg = _norm_u(
            {
                "public": ask(
                    "Qui utilise le parc ?",
                    "élèves / enseignants / admin" if typ == "ecole" else "équipe",
                ),
                "comptes_individuels": ask("Comptes nominatifs ? (oui/non/inconnu)", "inconnu"),
                "comptes_partages_salles": ask(
                    "Sessions / comptes de salle encore en service ? (oui/non/inconnu)",
                    "inconnu",
                ),
                "users_admin_local": ask(
                    "Les utilisateurs sont-ils admin local de leur poste ? (oui/non/inconnu)",
                    "inconnu",
                ),
                "vlan_separes": ask("VLAN / SSID séparés ? (oui/non/inconnu)", "inconnu"),
                "wifi_invite": ask("Wi‑Fi invité isolé ? (oui/non/inconnu)", "inconnu"),
                "serveur_central": ask(
                    "Une machine dessert-elle les autres (annuaire, fichiers, ENT) ? (oui/non/inconnu)",
                    "inconnu",
                ),
                "serveur_central_role": ask("Rôle de cette machine (si connue)", ""),
                "anciens_comptes": ask(
                    "Comptes des départs désactivés ? (oui/non/inconnu)", "inconnu"
                ),
            }
        )

    profil_map = {
        "foyer": "maison",
        "parc_particulier": "maison",
        "pme": "pme",
        "parc_entreprise": "pme",
        "association": "pme",
        "ecole": "ecole",
        "organisme": "pme",
    }
    profil = profil_map.get(typ, "maison")
    ton = "tutoiement" if typ in ("foyer", "parc_particulier") else "vouvoiement"
    if taille == "inconnu" and profondeur != "full":
        print("  → parc inconnu : profondeur passée en full.")
        profondeur = "full"

    out = {
        "guardia": "1.0",
        "signature": "Platon-Y / Echoes of Hackers",
        "checkup": "universel",
        "date": date.today().isoformat(),
        "client": client,
        "personne_commune": personne,
        "type_structure": typ,
        "profil_moteur": profil,
        "taille_parc": taille,
        "enjeux": enjeux,
        "equipements_attendus": equip,
        "profondeur": profondeur,
        "ton_rapport": ton,
        "cidr": cidr or None,
        "mandat_nda_signes": mandat_ok,
        "operateur_nom": "Platon-Y",
        "operateur_signe": bool(mandat_ok),
        "site_url": site_url,
        "rgpd": rgpd_ok,
        "usages": usages_ok,
        "machines": machines_ok,
        "regles_rapport": {
            "chaque_finding_inclut": [
                "titre_clair",
                "pourquoi_ca_nuit",
                "preuve_courte",
                "comment_resoudre_etapes",
                "qui_peut_le_faire",
                "priorite",
            ],
            "synthese": "top5_actions_plus_offre_suite_eoh",
            "ne_pas_laisser_sans_remede": True,
        },
        "couverture": "tous_hotes_du_cidr_mandate",
        "bilan_par_hote": "securise_ou_non_plus_remede",
        "interdit": ["exploitation", "malware_hunting", "hors_perimetre"],
    }
    if rgpd_ok and rgpd_cfg is not None:
        out["rgpd_config"] = rgpd_cfg
    if usages_ok and usages_cfg is not None:
        out["usages_config"] = usages_cfg
    return out


def _dump_mission(mission: dict[str, Any], path: Path) -> None:
    if yaml:
        path.write_text(
            yaml.dump(mission, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
    else:
        # fallback minimal sans PyYAML
        lines = ["# mission Guardia\n"]
        for k, v in mission.items():
            lines.append(f"{k}: {v!r}\n")
        path.write_text("".join(lines), encoding="utf-8")


def run_wizard(out_dir: Path | None = None) -> Path:
    """Exécute le wizard et retourne le chemin du fichier mission."""
    MISSIONS.mkdir(parents=True, exist_ok=True)
    dest = out_dir or MISSIONS
    dest.mkdir(parents=True, exist_ok=True)
    mission = build_mission_dict()
    client = str(mission.get("client") or "mission")
    slug = "".join(c if c.isalnum() else "-" for c in client.lower())[:40].strip("-") or "mission"
    path = dest / f"{date.today().isoformat()}-{slug}.yaml"
    _dump_mission(mission, path)
    print("\n--- Mission enregistrée ---")
    print(path)
    if not mission.get("mandat_nda_signes"):
        print(
            "\n⚠ Mandat/NDA non confirmés : aucun scan ne doit démarrer "
            "tant que les documents ne sont pas signés."
        )
    else:
        print("\nOK juridique déclaré. Lance : python3 -m guardia run --mission", path)
    if mission.get("rgpd"):
        print(
            "\nRGPD : fiche écrite dans la mission (déclarations, pas un certificat)."
            "\n  Relire / compléter : python3 -m guardia rgpd -m",
            path,
        )
    if mission.get("usages"):
        print(
            "\nUsages & droits : fiche écrite (ce que les gens peuvent faire, pas un dump)."
            "\n  Relire / compléter : python3 -m guardia usages -m",
            path,
        )
    print(
        "\nRappel : chaque faille du rapport aura aussi le mode d'emploi "
        "pour la résoudre — on ne laisse personne dans la panade."
    )
    return path
