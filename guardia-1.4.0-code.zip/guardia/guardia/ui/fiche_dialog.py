"""Dialogue Tk générique : fiche de déclarations (RGPD, usages…).

Pas un certificat. Oui / non / inconnu + texte.
"""
from __future__ import annotations

from typing import Any, Callable
import tkinter as tk
from tkinter import ttk

TRI = ("inconnu", "oui", "non")


class FicheDialog(tk.Toplevel):
    """Retourne la fiche via .result (dict) ou None si annulé."""

    def __init__(
        self,
        master: tk.Misc,
        *,
        title: str,
        disclaimer: str,
        fields: list[dict[str, str]],
        initial: dict[str, Any] | None,
        normalize: Callable[[Any], dict[str, Any]],
        empty: Callable[[], dict[str, Any]],
    ) -> None:
        super().__init__(master)
        self.title(title)
        self.resizable(True, True)
        self.result: dict[str, Any] | None = None
        self._normalize = normalize
        try:
            from guardia.ui.app import BG

            self.configure(bg=BG)
        except Exception:
            BG = "#1A1513"
            self.configure(bg=BG)
        self.transient(master)
        self.grab_set()

        cfg = normalize(initial or empty())

        outer = ttk.Frame(self, padding=12)
        outer.pack(fill=tk.BOTH, expand=True)

        ttk.Label(outer, text=disclaimer, wraplength=560).pack(anchor=tk.W, pady=(0, 8))

        canvas = tk.Canvas(outer, highlightthickness=0, bg=BG, height=420)
        scroll = ttk.Scrollbar(outer, orient=tk.VERTICAL, command=canvas.yview)
        form = ttk.Frame(canvas, padding=4)
        form.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all")),
        )
        canvas.create_window((0, 0), window=form, anchor=tk.NW)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scroll.pack(side=tk.RIGHT, fill=tk.Y)

        def _on_mousewheel(event: tk.Event) -> None:  # type: ignore[type-arg]
            if getattr(event, "delta", 0):
                canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

        def _on_linux(event: tk.Event) -> None:  # type: ignore[type-arg]
            canvas.yview_scroll(-1 if event.num == 4 else 1, "units")

        def _bind_wheel(_e=None) -> None:
            canvas.bind_all("<MouseWheel>", _on_mousewheel)
            canvas.bind_all("<Button-4>", _on_linux)
            canvas.bind_all("<Button-5>", _on_linux)

        def _unbind_wheel(_e=None) -> None:
            for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
                try:
                    canvas.unbind_all(seq)
                except tk.TclError:
                    pass

        self._unbind_wheel = _unbind_wheel
        canvas.bind("<Enter>", _bind_wheel)
        canvas.bind("<Leave>", _unbind_wheel)

        self._vars: dict[str, tk.StringVar] = {}
        r = 0
        for f in fields:
            key = f["key"]
            ttk.Label(form, text=f["label"], wraplength=340).grid(
                row=r, column=0, sticky=tk.NW, pady=4, padx=(0, 8)
            )
            var = tk.StringVar(
                value=str(cfg.get(key) or ("inconnu" if f["kind"] == "tri" else ""))
            )
            self._vars[key] = var
            if f["kind"] == "tri":
                cb = ttk.Combobox(
                    form, textvariable=var, values=list(TRI), state="readonly", width=16
                )
                cb.grid(row=r, column=1, sticky=tk.W, pady=4)
            else:
                ent = ttk.Entry(form, textvariable=var, width=42)
                ent.grid(row=r, column=1, sticky=tk.EW, pady=4)
            ttk.Label(form, text=f.get("help") or "", wraplength=340).grid(
                row=r + 1, column=0, columnspan=2, sticky=tk.W, pady=(0, 6)
            )
            r += 2
        form.columnconfigure(1, weight=1)

        btns = ttk.Frame(outer)
        btns.pack(fill=tk.X, pady=(8, 0))
        ttk.Button(btns, text="Annuler", command=self._cancel).pack(side=tk.RIGHT, padx=4)
        ttk.Button(btns, text="Enregistrer la fiche", command=self._ok).pack(
            side=tk.RIGHT, padx=4
        )

        self.bind("<Escape>", lambda _e: self._cancel())
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.update_idletasks()
        try:
            screen_w = self.winfo_screenwidth()
            screen_h = self.winfo_screenheight()
            width = min(700, max(520, screen_w - 100))
            height = min(620, max(440, screen_h - 140))
            x = max(20, (screen_w - width) // 2)
            y = max(20, (screen_h - height) // 2)
            self.geometry(f"{width}x{height}+{x}+{y}")
        except tk.TclError:
            self.geometry("640x560")
        self.minsize(480, 420)

    def _collect(self) -> dict[str, Any]:
        raw = {k: v.get() for k, v in self._vars.items()}
        return self._normalize(raw)

    def _ok(self) -> None:
        self._unbind_wheel()
        self.result = self._collect()
        self.destroy()

    def _cancel(self) -> None:
        self._unbind_wheel()
        self.result = None
        self.destroy()


def ask_fiche(
    master: tk.Misc,
    *,
    title: str,
    disclaimer: str,
    fields: list[dict[str, str]],
    initial: dict[str, Any] | None,
    normalize: Callable[[Any], dict[str, Any]],
    empty: Callable[[], dict[str, Any]],
) -> dict[str, Any] | None:
    dlg = FicheDialog(
        master,
        title=title,
        disclaimer=disclaimer,
        fields=fields,
        initial=initial,
        normalize=normalize,
        empty=empty,
    )
    master.wait_window(dlg)
    return dlg.result
