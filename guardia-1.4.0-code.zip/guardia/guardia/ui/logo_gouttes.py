"""Logo Guardia — gouttes animées (canvas, rouge sang / bordeaux).

Gouttes : toujours sang (#8B0000). Jamais recolorées blue/red.
Blue : spin actuel + éclairs bleus aléatoires entre la grosse goutte et les autres.
Red  : même spin + éclairs bleus (plus fréquents). Plus d'éclairs rouges, plus d'explosion.

Modes :
  - normal : logo header
  - watermark : grande couche semi-transparente, click-through
"""
from __future__ import annotations

import math
import random
import tkinter as tk
from pathlib import Path
from typing import Any


# Palette sang / bordeaux — gouttes, inchangée
SANG = "#8B0000"
SANG_CLAIR = "#B22222"
BORDEAUX = "#5C0A0A"
BORDEAUX_MOYEN = "#7A1212"
ROUGE_VIF = "#C41E3A"
HIGHLIGHT = "#E8A0A0"

# Éclairs — pas les gouttes
ECLAIR = "#4FA3E0"
ECLAIR_CLAIR = "#B8E0FF"
ECLAIR_GLOW = "#1E4F8A"
ECLAIR_ROUGE = "#FF1A1A"
ECLAIR_ROUGE_CLAIR = "#FF8A70"
ECLAIR_ROUGE_GLOW = "#FF3B2A"

# Palette filigrane (déjà atténuée)
WM_SANG = "#3A1818"
WM_SANG_CLAIR = "#4A2020"
WM_BORDEAUX = "#2A1212"
WM_BORDEAUX_M = "#321616"
WM_ROUGE = "#4A1C22"
WM_HIGHLIGHT = "#5A3030"


class Teardrop:
    """Une goutte avec position, taille, phase et wobble."""

    __slots__ = (
        "x",
        "y",
        "size",
        "phase",
        "speed",
        "wobble",
        "color",
        "alpha_bias",
        "home_x",
        "home_y",
        "kick_x",
        "kick_y",
    )

    def __init__(
        self,
        x: float,
        y: float,
        size: float,
        phase: float,
        speed: float,
        wobble: float,
        color: str,
        alpha_bias: float = 0.0,
    ) -> None:
        self.x = x
        self.y = y
        self.size = size
        self.phase = phase
        self.speed = speed
        self.wobble = wobble
        self.color = color
        self.alpha_bias = alpha_bias
        self.home_x = x
        self.home_y = y
        self.kick_x = 0.0
        self.kick_y = 0.0


def _hex_to_rgb(h: str) -> tuple[int, int, int]:
    h = h.lstrip("#")
    return int(h[0:2], 16), int(h[2:4], 16), int(h[4:6], 16)


def _rgb_to_hex(r: int, g: int, b: int) -> str:
    return f"#{max(0, min(255, r)):02x}{max(0, min(255, g)):02x}{max(0, min(255, b)):02x}"


def blend_hex(fg: str, bg: str, amount: float) -> str:
    """Mélange fg vers bg : amount=0 → fg, amount=1 → bg. Pour filigrane amount≈0.75–0.88."""
    fr, fg_, fb = _hex_to_rgb(fg)
    br, bg_, bb = _hex_to_rgb(bg)
    a = max(0.0, min(1.0, amount))
    return _rgb_to_hex(
        int(fr + (br - fr) * a),
        int(fg_ + (bg_ - fg_) * a),
        int(fb + (bb - fb) * a),
    )


def _teardrop_points(
    cx: float, cy: float, size: float, tip_up: bool = True
) -> list[float]:
    """Polygone lisse en forme de goutte (pointe en haut par défaut)."""
    pts: list[float] = []
    n = 28
    for i in range(n):
        t = 2 * math.pi * i / n
        r = size * (0.55 + 0.45 * abs(math.sin(t * 0.5)))
        if tip_up:
            ox = r * math.sin(t)
            oy = -r * math.cos(t) * (1.15 if math.cos(t) > 0 else 0.85)
            if math.cos(t) > 0.3:
                oy *= 1.25
        else:
            ox = r * math.sin(t)
            oy = r * math.cos(t) * (1.15 if math.cos(t) > 0 else 0.85)
            if math.cos(t) > 0.3:
                oy *= 1.25
        pts.extend([cx + ox, cy + oy])
    return pts


def load_guardia_photo(
    size: int = 320,
    opacity: float = 0.22,
    assets_dir: Path | None = None,
) -> tk.PhotoImage | None:
    """Charge assets/guardia-ui.png en PhotoImage semi-transparent (Pillow)."""
    try:
        from PIL import Image, ImageTk
    except ImportError:
        return None
    roots = []
    if assets_dir:
        roots.append(Path(assets_dir))
    here = Path(__file__).resolve()
    roots.append(here.parents[2] / "assets")
    roots.append(Path.cwd() / "assets")
    src: Path | None = None
    for base in roots:
        for name in ("guardia-ui-128.png", "guardia-ui.png", "guardia-ui-64.png"):
            cand = base / name
            if cand.is_file():
                src = cand
                break
        if src:
            break
    if not src:
        return None
    try:
        im = Image.open(src).convert("RGBA")
        im = im.resize((size, size), Image.Resampling.LANCZOS)
        alpha = im.split()[3]
        factor = max(0.05, min(0.9, opacity))
        alpha = alpha.point(lambda p: int(p * factor))
        im.putalpha(alpha)
        return ImageTk.PhotoImage(im)
    except Exception:  # noqa: BLE001
        return None


def _jagged_bolt(x0: float, y0: float, x1: float, y1: float, seed: float) -> list[float]:
    """Ligne brisée entre deux points (éclair)."""
    pts: list[float] = [x0, y0]
    dx, dy = x1 - x0, y1 - y0
    n = 5
    rng = random.Random(int(seed * 10_000) & 0xFFFF)
    length = math.hypot(dx, dy) or 1.0
    nx, ny = -dy / length, dx / length
    for i in range(1, n):
        t = i / n
        mag = (0.5 - abs(t - 0.5)) * (8.0 + rng.random() * 10.0)
        side = -1.0 if rng.random() < 0.5 else 1.0
        pts.extend([x0 + dx * t + nx * mag * side, y0 + dy * t + ny * mag * side])
    pts.extend([x1, y1])
    return pts


class LogoGouttes(tk.Canvas):
    """Canvas avec plusieurs gouttes qui bougent fluidement."""

    def __init__(
        self,
        master: Any,
        width: int = 120,
        height: int = 100,
        bg: str = "#1A1513",
        *,
        watermark: bool = False,
        fade: float = 0.82,
        **kwargs: Any,
    ) -> None:
        kwargs.setdefault("takefocus", 0)
        super().__init__(
            master,
            width=width,
            height=height,
            bg=bg,
            highlightthickness=0,
            bd=0,
            **kwargs,
        )
        self._cw = width
        self._ch = height
        self._bg = bg
        self._watermark = bool(watermark)
        self._fade_idle = float(fade) if watermark else 0.0
        self._fade_busy = max(0.0, float(fade) - 0.18) if watermark else 0.0
        self._fade = self._fade_idle
        self._running = False
        self._tick_ms = 40 if watermark else 33
        self._t = 0.0
        self._tempo = 1.0
        self._spin = 0.0
        self._busy = False
        self._equipe = "blue"
        self._explode_t = 0.0
        self._shards: list[dict[str, float | str]] = []
        self._bolts: list[dict[str, Any]] = []
        self._next_bolt = 0.6
        self._photo: tk.PhotoImage | None = None
        self._photo_id: int | None = None
        self._drops = self._make_drops()
        self._ids: list[int] = []
        self.bind("<Configure>", self._on_resize)
        if self._watermark:
            self._setup_click_through()
            self._try_asset_underlay()
        self.after(50, self._start)

    def _setup_click_through(self) -> None:
        """Renvoie les clics / molette aux widgets sous le filigrane."""
        for seq in (
            "<Button-1>",
            "<Button-2>",
            "<Button-3>",
            "<ButtonRelease-1>",
            "<ButtonRelease-2>",
            "<ButtonRelease-3>",
            "<B1-Motion>",
            "<Double-Button-1>",
            "<MouseWheel>",
            "<Button-4>",
            "<Button-5>",
            "<Motion>",
        ):
            self.bind(seq, self._forward_event, add="+")

    def _forward_event(self, event: tk.Event) -> str:  # type: ignore[type-arg]
        """Click-through : baisse le canvas, trouve le widget dessous, redispatche."""
        try:
            tk.Misc.lower(self)
        except tk.TclError:
            return "break"
        try:
            under = self.winfo_containing(event.x_root, event.y_root)
        except tk.TclError:
            under = None
        try:
            tk.Misc.lift(self)
        except tk.TclError:
            pass
        if under is None or under is self:
            return "break"
        try:
            rx = event.x_root - under.winfo_rootx()
            ry = event.y_root - under.winfo_rooty()
        except tk.TclError:
            return "break"
        name = str(event.type)
        type_map = {
            "4": "ButtonPress",
            "5": "ButtonRelease",
            "6": "Motion",
            "37": "MouseWheel",
        }
        kind = type_map.get(name, name)
        num = getattr(event, "num", None)
        try:
            if kind in ("ButtonPress", "Button"):
                under.event_generate(
                    f"<Button-{num or 1}>",
                    x=rx,
                    y=ry,
                    rootx=event.x_root,
                    rooty=event.y_root,
                )
            elif kind == "ButtonRelease":
                under.event_generate(
                    f"<ButtonRelease-{num or 1}>",
                    x=rx,
                    y=ry,
                    rootx=event.x_root,
                    rooty=event.y_root,
                )
            elif kind == "Motion" and (getattr(event, "state", 0) & 0x0100):
                under.event_generate(
                    "<B1-Motion>",
                    x=rx,
                    y=ry,
                    rootx=event.x_root,
                    rooty=event.y_root,
                )
            elif kind == "MouseWheel" or num in (4, 5):
                delta = getattr(event, "delta", 0) or (120 if num == 4 else -120)
                under.event_generate(
                    "<MouseWheel>",
                    x=rx,
                    y=ry,
                    delta=delta,
                    rootx=event.x_root,
                    rooty=event.y_root,
                )
                if num == 4:
                    under.event_generate("<Button-4>", x=rx, y=ry)
                elif num == 5:
                    under.event_generate("<Button-5>", x=rx, y=ry)
        except Exception:  # noqa: BLE001
            try:
                under.focus_set()
            except Exception:  # noqa: BLE001
                pass
        return "break"

    def _try_asset_underlay(self) -> None:
        """Optionnel : PNG Guardia semi-transparent sous les gouttes."""
        side = max(self._cw, self._ch)
        op = 0.18
        photo = load_guardia_photo(size=side, opacity=op)
        if photo is None:
            return
        self._photo = photo
        self._photo_id = self.create_image(
            self._cw // 2,
            self._ch // 2,
            image=photo,
            tags=("wm_asset",),
        )
        self.tag_lower("wm_asset")

    def _palette(self) -> list[str]:
        raw = [SANG, SANG_CLAIR, BORDEAUX, BORDEAUX_MOYEN, ROUGE_VIF, SANG]
        if not self._watermark and self._fade <= 0.01:
            return raw
        return [blend_hex(c, self._bg, self._fade) for c in raw]

    def _hi_color(self) -> str:
        if not self._watermark and self._fade <= 0.01:
            return HIGHLIGHT
        return blend_hex(HIGHLIGHT, self._bg, min(0.95, self._fade + 0.05))

    def _make_drops(self) -> list[Teardrop]:
        colors = self._palette()
        drops: list[Teardrop] = []
        cx, cy = self._cw / 2, self._ch / 2 + 4
        scale = min(self._cw, self._ch) / 100.0
        if self._watermark:
            scale = max(scale, 2.2)
        base = 22 * scale
        drops.append(
            Teardrop(cx, cy, size=base, phase=0.0, speed=1.1, wobble=3.5 * scale, color=colors[0])
        )
        layouts = [
            (-28, -8, 11, 1.2, 2.8, 1),
            (30, -6, 10, 2.4, 3.2, 2),
            (-18, 22, 8, 0.7, 2.0, 4),
            (22, 20, 9, 3.1, 2.5, 3),
            (0, -28, 7, 4.0, 2.2, 1),
            (-35, 12, 6, 5.2, 1.8, 0),
            (36, 10, 6.5, 1.8, 2.1, 2),
        ]
        for dx, dy, size, phase, wobble, ci in layouts:
            drops.append(
                Teardrop(
                    cx + dx * scale,
                    cy + dy * scale,
                    size=size * scale,
                    phase=phase,
                    speed=0.8 + random.random() * 0.6,
                    wobble=wobble * scale,
                    color=colors[ci % len(colors)],
                )
            )
        for _ in range(4 if not self._watermark else 6):
            drops.append(
                Teardrop(
                    cx + random.uniform(-40, 40) * scale,
                    cy + random.uniform(-30, 30) * scale,
                    size=random.uniform(3.5, 5.5) * scale,
                    phase=random.uniform(0, 6),
                    speed=random.uniform(1.2, 2.0),
                    wobble=random.uniform(4, 8) * scale,
                    color=random.choice(colors),
                )
            )
        return drops

    def _refresh_drop_colors(self) -> None:
        colors = self._palette()
        for i, d in enumerate(self._drops):
            d.color = colors[i % len(colors)]

    def _on_resize(self, event: tk.Event) -> None:  # type: ignore[type-arg]
        if event.width > 10 and event.height > 10:
            old_w, old_h = self._cw, self._ch
            self._cw, self._ch = event.width, event.height
            if old_w and old_h:
                sx = self._cw / old_w
                sy = self._ch / old_h
                for d in self._drops:
                    d.x *= sx
                    d.y *= sy
                    d.home_x *= sx
                    d.home_y *= sy
            if self._photo_id is not None:
                self.coords(self._photo_id, self._cw // 2, self._ch // 2)

    def _start(self) -> None:
        self._running = True
        self._animate()

    def set_busy(self, busy: bool = True) -> None:
        """Accélère / ralentit l'animation (run en cours). Filigrane : plus présent."""
        self._busy = bool(busy)
        if self._watermark:
            self._tempo = 2.6 if busy else 0.85
            self._tick_ms = 18 if busy else 48
            self._fade = self._fade_busy if busy else self._fade_idle
            self._refresh_drop_colors()
            if busy and self._photo is not None:
                side = max(self._cw, self._ch)
                photo = load_guardia_photo(size=side, opacity=0.32)
                if photo is not None:
                    self._photo = photo
                    if self._photo_id is not None:
                        self.itemconfigure(self._photo_id, image=photo)
            elif not busy and self._photo is not None:
                side = max(self._cw, self._ch)
                photo = load_guardia_photo(size=side, opacity=0.18)
                if photo is not None:
                    self._photo = photo
                    if self._photo_id is not None:
                        self.itemconfigure(self._photo_id, image=photo)
        else:
            self._tempo = 3.2 if busy else 1.0
            self._tick_ms = 16 if busy else 33

    def set_equipe(self, equipe: str) -> None:
        """Blue / red : décor des éclairs / explosions. Les gouttes restent sang."""
        self._equipe = "red" if str(equipe).strip().lower() == "red" else "blue"
        if self._equipe == "blue":
            self._shards = []
            self._explode_t = 0.0
        self._next_bolt = self._t + 0.15

    def explode(self) -> None:
        """Phase : un éclair bleu. Plus d'explosion rouge."""
        if self._watermark:
            return
        self._explode_t = 0.0
        self._shards = []
        if len(self._drops) > 1:
            self._bolts.append(
                {
                    "life": 1.15,
                    "idx": random.randint(1, max(1, len(self._drops) - 1)),
                    "seed": random.random(),
                    "kind": "bleu",
                }
            )

    def stop(self) -> None:
        self._running = False

    def _drop_xy(self, d: Teardrop) -> tuple[float, float]:
        ox = math.sin(self._t * d.speed + d.phase) * d.wobble * (0.7 + 0.3 * self._tempo)
        oy = math.cos(self._t * d.speed * 0.85 + d.phase * 1.3) * (d.wobble * 0.7)
        if self._tempo > 1.5:
            ang = self._spin + d.phase
            ox += math.cos(ang) * (6 + d.size * 0.15)
            oy += math.sin(ang) * (6 + d.size * 0.15)
        if self._explode_t > 0:
            ease = self._explode_t * self._explode_t
            ox += d.kick_x * ease
            oy += d.kick_y * ease
        return d.x + ox, d.y + oy

    def _kind_eclair(self) -> str:
        return "bleu"

    def _spawn_bolt(self, n_pos: int) -> None:
        if n_pos < 2:
            return
        self._bolts.append(
            {
                "life": 1.15 if self._equipe == "red" else 1.0,
                "idx": random.randint(1, n_pos - 1),
                "seed": random.random(),
                "kind": self._kind_eclair(),
            }
        )

    def _maybe_bolt(self, positions: list[tuple[float, float]]) -> None:
        if len(positions) < 2:
            return
        if self._t < self._next_bolt:
            return
        self._spawn_bolt(len(positions))
        if self._equipe == "red" and random.random() < 0.45:
            self._spawn_bolt(len(positions))
        if self._equipe == "red":
            gap = 0.16 if self._busy else 0.55
            span = 0.38 if self._busy else 1.15
        else:
            gap = 0.28 if self._busy else 1.15
            span = 0.55 if self._busy else 2.4
        self._next_bolt = self._t + gap + random.random() * span

    def _draw_bolts(self, positions: list[tuple[float, float]]) -> None:
        if not self._bolts or not positions:
            return
        bx, by = positions[0]
        alive: list[dict[str, Any]] = []
        for b in self._bolts:
            life = float(b["life"])
            idx = int(b["idx"]) % len(positions)
            tx, ty = positions[idx]
            pts = _jagged_bolt(bx, by, tx, ty, float(b["seed"]))
            rouge = str(b.get("kind") or "bleu") == "rouge"
            if rouge:
                glow, core, hi = ECLAIR_ROUGE_GLOW, ECLAIR_ROUGE, ECLAIR_ROUGE_CLAIR
                width = 3.4 if life > 0.55 else 2.0
                halo = 5.5
            else:
                glow, core, hi = ECLAIR_GLOW, ECLAIR, ECLAIR_CLAIR
                width = 2.6 if life > 0.55 else 1.4
                halo = 3.0
            self.create_line(
                pts,
                fill=glow,
                width=width + halo,
                tags="drop",
            )
            self.create_line(
                pts,
                fill=core if life > 0.35 else hi,
                width=width,
                tags="drop",
            )
            b["life"] = life - (0.22 if self._busy else 0.16)
            if b["life"] > 0:
                alive.append(b)
        self._bolts = alive

    def _draw_shards(self) -> None:
        if not self._shards:
            return
        alive: list[dict[str, float | str]] = []
        for s in self._shards:
            life = float(s["life"])
            s["x"] = float(s["x"]) + float(s["vx"])
            s["y"] = float(s["y"]) + float(s["vy"])
            s["vy"] = float(s["vy"]) + 0.18
            s["life"] = life - 0.055
            r = float(s["size"]) * max(0.15, life)
            x, y = float(s["x"]), float(s["y"])
            self.create_oval(
                x - r,
                y - r,
                x + r,
                y + r,
                fill=str(s["color"]),
                outline="",
                tags="drop",
            )
            if s["life"] > 0:
                alive.append(s)
        self._shards = alive

    def _animate(self) -> None:
        if not self._running:
            return
        self._t += 0.045 * self._tempo
        self._spin += 0.08 * self._tempo
        if self._explode_t > 0:
            self._explode_t = max(0.0, self._explode_t - 0.055)
            if self._explode_t == 0:
                for d in self._drops:
                    d.kick_x = 0.0
                    d.kick_y = 0.0
        self.delete("drop")
        hi = self._hi_color()
        positions: list[tuple[float, float]] = []
        sized: list[tuple[Teardrop, float, float, float]] = []
        for d in self._drops:
            x, y = self._drop_xy(d)
            positions.append((x, y))
            pulse = 1.0 + 0.06 * math.sin(self._t * d.speed * 1.4 + d.phase) * self._tempo
            if self._explode_t > 0.55:
                pulse *= 1.0 + 0.35 * self._explode_t
            sized.append((d, x, y, d.size * pulse))
        self._maybe_bolt(positions)
        self._draw_bolts(positions)
        ordered = sorted(sized, key=lambda row: row[0].size)
        for d, x, y, size in ordered:
            pts = _teardrop_points(x, y, size, tip_up=True)
            self.create_polygon(
                pts,
                fill=d.color,
                outline="",
                smooth=True,
                tags="drop",
            )
            if not self._watermark or self._busy:
                hx = x - size * 0.22
                hy = y - size * 0.35
                hr = max(2.0, size * 0.22)
                self.create_oval(
                    hx - hr,
                    hy - hr * 0.7,
                    hx + hr * 0.6,
                    hy + hr * 0.5,
                    fill=hi,
                    outline="",
                    tags="drop",
                )
        self._draw_shards()
        if self._photo_id is not None:
            self.tag_lower("wm_asset")
        self.after(self._tick_ms, self._animate)


def demo() -> None:
    root = tk.Tk()
    root.title("Logo gouttes — démo")
    root.configure(bg="#F5F0EB")
    LogoGouttes(root, width=200, height=160, bg="#F5F0EB").pack(padx=20, pady=20)
    root.mainloop()


if __name__ == "__main__":
    demo()
