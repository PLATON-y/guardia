"""Barre de défilement verticale rouge sang — centre plus clair."""
from __future__ import annotations

import tkinter as tk
from typing import Any, Callable


TROUGH = "#3A1515"
RAIL = "#6B1212"
THUMB_EDGE = "#8B0000"
THUMB_MID = "#E8D5D5"
THUMB_HI = "#F5EEEE"
BORDER = "#9B1B1B"


class SangScrollbar(tk.Canvas):
    """Scrollbar custom : trough + curseur à cœur clair. Couleurs selon l'équipe."""

    def __init__(self, master: Any, width: int = 14, **kwargs: Any) -> None:
        super().__init__(
            master,
            width=width,
            highlightthickness=0,
            bd=0,
            bg=TROUGH,
            **kwargs,
        )
        self._width = width
        self._first = 0.0
        self._last = 1.0
        self._command: Callable[..., Any] | None = None
        self._drag_y0 = 0.0
        self._drag_first = 0.0
        self._trough = TROUGH
        self._rail = RAIL
        self._thumb = THUMB_EDGE
        self._thumb_mid = THUMB_MID
        self._thumb_hi = THUMB_HI
        self._border = BORDER
        self.bind("<Configure>", lambda _e: self._redraw())
        self.bind("<Button-1>", self._on_click)
        self.bind("<B1-Motion>", self._on_drag)
        self.bind("<ButtonRelease-1>", self._on_release)
        self.bind("<MouseWheel>", self._on_wheel)
        self.bind("<Button-4>", lambda e: self._wheel_step(-1))
        self.bind("<Button-5>", lambda e: self._wheel_step(1))

    def set_palette(self, pal: dict[str, str]) -> None:
        self._trough = pal.get("trough", TROUGH)
        self._rail = pal.get("rail", RAIL)
        self._thumb = pal.get("thumb", THUMB_EDGE)
        self._thumb_mid = pal.get("thumb_mid", THUMB_MID)
        self._thumb_hi = pal.get("thumb_hi", THUMB_HI)
        self._border = pal.get("border", BORDER)
        try:
            super().configure(bg=self._trough)
        except tk.TclError:
            pass
        self._redraw()

    def configure(self, cnf=None, **kw):  # type: ignore[override]
        if cnf is None:
            cnf = {}
        if isinstance(cnf, dict):
            kw = {**cnf, **kw}
        if "command" in kw:
            self._command = kw.pop("command")
        if kw:
            return super().configure(**kw)
        return super().configure()

    config = configure  # type: ignore[assignment]

    def set(self, first: str | float, last: str | float) -> None:
        self._first = float(first)
        self._last = float(last)
        self._redraw()

    def _thumb_rect(self) -> tuple[float, float, float, float]:
        h = max(self.winfo_height(), 1)
        w = self._width
        span = max(self._last - self._first, 0.05)
        # Si tout visible, thumb presque pleine hauteur
        if self._first <= 0.001 and self._last >= 0.999:
            y0, y1 = 2.0, h - 2.0
        else:
            y0 = self._first * h
            y1 = self._last * h
            if y1 - y0 < 28:
                mid = (y0 + y1) / 2
                y0 = max(2.0, mid - 14)
                y1 = min(h - 2.0, mid + 14)
        pad = 2.0
        return pad, y0, w - pad, y1

    def _redraw(self) -> None:
        self.delete("all")
        h = max(self.winfo_height(), 1)
        w = self._width
        # trough
        self.create_rectangle(0, 0, w, h, fill=self._trough, outline="")
        self.create_rectangle(3, 2, w - 3, h - 2, fill=self._rail, outline=self._border, width=1)
        x0, y0, x1, y1 = self._thumb_rect()
        self.create_rectangle(x0, y0, x1, y1, fill=self._thumb, outline=self._border, width=1)
        mid_x0 = x0 + (x1 - x0) * 0.28
        mid_x1 = x1 - (x1 - x0) * 0.28
        self.create_rectangle(mid_x0, y0 + 2, mid_x1, y1 - 2, fill=self._thumb_mid, outline="")
        cx = (x0 + x1) / 2
        self.create_line(cx, y0 + 4, cx, y1 - 4, fill=self._thumb_hi, width=2)

    def _frac_from_y(self, y: float) -> float:
        h = max(self.winfo_height(), 1)
        return max(0.0, min(1.0, y / h))

    def _on_click(self, event: tk.Event) -> None:  # type: ignore[type-arg]
        x0, y0, x1, y1 = self._thumb_rect()
        if y0 <= event.y <= y1:
            self._drag_y0 = event.y
            self._drag_first = self._first
            return
        # clic hors curseur → page jump
        span = max(self._last - self._first, 0.1)
        target = self._frac_from_y(event.y) - span / 2
        self._move_to(target)

    def _on_drag(self, event: tk.Event) -> None:  # type: ignore[type-arg]
        h = max(self.winfo_height(), 1)
        dy = (event.y - self._drag_y0) / h
        self._move_to(self._drag_first + dy)

    def _on_release(self, _event: tk.Event) -> None:  # type: ignore[type-arg]
        pass

    def _move_to(self, first: float) -> None:
        span = max(self._last - self._first, 0.05)
        first = max(0.0, min(1.0 - span, first))
        if self._command:
            self._command("moveto", first)

    def _wheel_step(self, direction: int) -> None:
        if self._command:
            self._command("scroll", direction, "units")

    def _on_wheel(self, event: tk.Event) -> None:  # type: ignore[type-arg]
        delta = -1 if getattr(event, "delta", 0) > 0 else 1
        self._wheel_step(delta)


def _wheel_units(event: tk.Event) -> int:  # type: ignore[type-arg]
    """Linux pad = Button-4/5 ; Windows/mac = delta. 3 unités = fluide."""
    num = getattr(event, "num", None)
    if num == 4:
        return -3
    if num == 5:
        return 3
    delta = int(getattr(event, "delta", 0) or 0)
    if delta == 0:
        return 0
    if abs(delta) >= 120:
        return int(-delta / 120) * 3
    return -3 if delta > 0 else 3


def _scrollable_under(event: tk.Event, fallback: tk.Canvas) -> Any:  # type: ignore[type-arg]
    """Text / Listbox sous le pointeur, sinon le canvas principal."""
    w: Any = getattr(event, "widget", None)
    if isinstance(w, str):
        try:
            w = fallback.nametowidget(w)
        except Exception:  # noqa: BLE001
            w = None
    if w is None:
        try:
            w = fallback.winfo_containing(event.x_root, event.y_root)
        except Exception:  # noqa: BLE001
            w = None
    cur = w
    seen = 0
    while cur is not None and seen < 24:
        seen += 1
        try:
            cls = cur.winfo_class()
        except Exception:  # noqa: BLE001
            break
        if cls in ("Text", "Listbox") and hasattr(cur, "yview_scroll"):
            return cur
        if cur is fallback:
            return fallback
        try:
            cur = cur.master
        except Exception:  # noqa: BLE001
            break
    return fallback


def bind_mousewheel(widget: tk.Misc, target: tk.Canvas) -> None:
    """Molette / pad → scroll de la fenêtre entière, pas seulement la barre.

    ttk avale Button-4/5 si on ne bind que le canvas. bind_all + bind_class
    + arbre des enfants. Au-dessus du journal : le Text défile ; sinon le canvas.
    """

    def _on_wheel(event: tk.Event) -> str:  # type: ignore[type-arg]
        units = _wheel_units(event)
        if not units:
            return "break"
        dest = _scrollable_under(event, target)
        try:
            dest.yview_scroll(units, "units")
        except tk.TclError:
            try:
                target.yview_scroll(units, "units")
            except tk.TclError:
                pass
        return "break"

    seqs = ("<MouseWheel>", "<Shift-MouseWheel>", "<Button-4>", "<Button-5>", "<4>", "<5>")
    for seq in seqs:
        try:
            widget.bind_all(seq, _on_wheel, add="+")
        except tk.TclError:
            pass

    classes = (
        "TFrame",
        "TLabel",
        "TCheckbutton",
        "TButton",
        "TEntry",
        "TCombobox",
        "TLabelframe",
        "Labelframe",
        "Frame",
        "Label",
        "Button",
        "Entry",
        "Canvas",
        "Text",
        "Toplevel",
        "TPanedwindow",
        "TSeparator",
        "TScrollbar",
    )
    for cls in classes:
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            try:
                widget.bind_class(cls, seq, _on_wheel, add="+")
            except tk.TclError:
                pass

    def _bind_tree(w: tk.Misc) -> None:
        for seq in ("<MouseWheel>", "<Button-4>", "<Button-5>"):
            try:
                w.bind(seq, _on_wheel, add="+")
            except tk.TclError:
                continue
        try:
            children = w.winfo_children()
        except tk.TclError:
            return
        for child in children:
            _bind_tree(child)

    _bind_tree(widget)
    # Widgets créés après l'appel : on rebind à la volée
    def _later() -> None:
        try:
            _bind_tree(widget)
        except tk.TclError:
            pass

    try:
        widget.after(200, _later)
        widget.after(800, _later)
    except tk.TclError:
        pass
