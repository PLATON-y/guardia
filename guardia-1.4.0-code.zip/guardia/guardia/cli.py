"""CLI Guardia — wizard / ui / run / discover / about."""
from __future__ import annotations

import argparse
import ipaddress
import json
import logging
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from guardia import __signature__, __version__
from guardia.core.errors import GuardiaError, MandateRequiredError, ToolMissingError
from guardia.core.identite import banniere_run, identite_dict, operateur_a_signe, operateur_de
from guardia.core.logging_setup import setup_logging
from guardia.core.models import CheckupResult, Mission
from guardia.core.paths import MISSIONS, RAPPORTS, ROOT

log = logging.getLogger("guardia")

try:
    import yaml  # type: ignore
except ImportError:
    yaml = None


def _parse_scalar(v: str) -> Any:
    v = (v or "").strip()
    if v == "" or v in ("null", "~", "None"):
        return None
    low = v.lower()
    if low in ("true", "yes", "on"):
        return True
    if low in ("false", "no", "off"):
        return False
    if len(v) >= 2 and ((v[0] == v[-1] == '"') or (v[0] == v[-1] == "'")):
        return v[1:-1]
    try:
        return ast_literal(v)
    except Exception:
        return v


def _load_yaml_naive(text: str) -> dict[str, Any]:
    """Petit parseur YAML de secours : mappings/listes imbriqués par indentation.

    Il ne cherche pas à remplacer PyYAML ; il couvre le sous-ensemble utilisé par
    les fichiers de mission Guardia afin qu'une installation stdlib-only ne perde
    pas le périmètre, les activités PASSI ou les autorisations imbriquées.
    """
    lines = []
    for raw in text.splitlines():
        if not raw.strip() or raw.lstrip().startswith("#"):
            continue
        indent = len(raw) - len(raw.lstrip(" "))
        lines.append((indent, raw.strip()))

    def parse_block(pos: int, indent: int) -> tuple[Any, int]:
        if pos >= len(lines) or lines[pos][0] < indent:
            return {}, pos
        is_list = lines[pos][1].startswith("- ") or lines[pos][1] == "-"
        obj: Any = [] if is_list else {}
        while pos < len(lines) and lines[pos][0] == indent:
            raw = lines[pos][1]
            if is_list:
                if not raw.startswith("-"):
                    break
                value = raw[1:].strip()
                if not value:
                    if pos + 1 < len(lines) and lines[pos + 1][0] > indent:
                        child, pos = parse_block(pos + 1, lines[pos + 1][0])
                        obj.append(child)
                    else:
                        obj.append(None); pos += 1
                    continue
                if ":" in value and not value.startswith(("http:", "https:")):
                    k, _, v = value.partition(":")
                    item = {k.strip(): _parse_scalar(v.strip()) if v.strip() else {}}
                    pos += 1
                    if pos < len(lines) and lines[pos][0] > indent:
                        child, pos = parse_block(pos, lines[pos][0])
                        if isinstance(child, dict) and not v.strip():
                            item[k.strip()] = child
                        elif isinstance(child, dict):
                            item.update(child)
                    obj.append(item)
                else:
                    obj.append(_parse_scalar(value)); pos += 1
                continue
            if ":" not in raw:
                pos += 1
                continue
            key, _, value = raw.partition(":")
            key = key.strip(); value = value.strip()
            pos += 1
            if value:
                obj[key] = _parse_scalar(value)
            elif pos < len(lines) and lines[pos][0] > indent:
                child, pos = parse_block(pos, lines[pos][0])
                obj[key] = child
            else:
                obj[key] = {}
        return obj, pos

    value, _ = parse_block(0, lines[0][0] if lines else 0)
    return value if isinstance(value, dict) else {}


def _load_yaml(path: Path) -> dict[str, Any]:
    text = path.read_text(encoding="utf-8")
    if yaml:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise GuardiaError(f"mission invalide (pas un mapping): {path}")
        return data
    return _load_yaml_naive(text)


def ast_literal(v: str) -> Any:
    import ast

    return ast.literal_eval(v)


def load_mission(path: Path | None) -> Mission:
    if path is None:
        return Mission()
    if not path.is_file():
        raise GuardiaError(f"fichier mission introuvable: {path}")
    return Mission.from_dict(_load_yaml(path))


def _is_clearly_local(cidr: str) -> bool:
    try:
        net = ipaddress.ip_network(cidr, strict=False)
    except ValueError:
        return False
    if net.is_private or net.is_loopback or net.is_link_local:
        return True
    return False


def _assert_mandate(
    mission: Mission, cidr: str, yes: bool, *, site_only: bool = False
) -> None:
    if mission.mandat_nda_signes:
        return
    if yes and (site_only or not cidr or _is_clearly_local(cidr)):
        log.warning(
            "--yes : attestation opérateur — mandat non coché dans la mission ; "
            "l'opérateur assume l'autorisation (cidr=%s site_only=%s).",
            cidr or "—",
            site_only,
        )
        return
    raise MandateRequiredError(
        "Mandat + NDA non confirmés (mission.mandat_nda_signes). "
        "Signe les documents, coche-le via le wizard, ou passe --yes "
        "uniquement si le CIDR est clairement local (attestation opérateur)."
    )


def cmd_identite(args: argparse.Namespace) -> int:
    """Qui nous sommes — opérateur identifié."""
    mission = None
    if getattr(args, "mission", None):
        mission = load_mission(Path(args.mission))
    info = identite_dict(mission)
    print(f"Guardia {info['version']}")
    print(f"Association : {info['association']} ({info['sigle']})")
    print(f"Opérateur   : {info['operateur']}")
    print(f"RNA {info['rna']} · SIREN {info['siren']} · NAF {info['naf']}")
    print(f"ESS : {info['ess']}")
    print(f"User-Agent  : {info['user_agent']}")
    print()
    print(info["visage_decouvert"])
    print()
    print(info["nmap_honnete"])
    if mission:
        print()
        print(f"Mission : {mission.client}")
        print(f"Paraphe opérateur : {'oui' if info['operateur_signe'] else 'à parapher'}")
        print(f"Mandat / NDA      : {'oui' if mission.mandat_nda_signes else 'à signer'}")
    return 0


def cmd_dossier(args: argparse.Namespace) -> int:
    """Liasse d'audit — le Red est un contrat."""
    from guardia.core.dossier import PASSI, etat, generer, peut_red_regard, peut_red_test
    from guardia.core.parc import libelle

    mission = load_mission(Path(args.mission))
    st = etat(mission)
    print(f"Parc : {libelle(st['parc'])}")
    print(f"Niveau demandé : {st['niveau']} ({st['niveau_libelle']})")
    print(f"LLM : {'local' if st['llm_local'] else 'externe — Red interdit'}")
    for p in st["pieces"]:
        if p["signe"]:
            mark = "signé"
        elif p["requis"]:
            mark = "manque"
        else:
            mark = "facultatif"
        print(f"  [{mark}] {p['titre']}")
    ok, why = peut_red_regard(mission)
    print(f"Regard : {'ouvert' if ok else 'fermé'} — {why}")
    _ok2, why2 = peut_red_test(mission)
    print(f"Test red : fermé — {why2}")
    print(PASSI)
    if getattr(args, "generer", False):
        slug = "".join(c if c.isalnum() else "-" for c in (mission.client or "client").lower())[:40]
        dest = RAPPORTS / f"dossier-{slug or 'client'}"
        info = generer(mission, dest)
        print(f"Généré : {info['dossier']}")
        for row in info["hashes"]:
            print(f"  {row['sha256'][:12]}  {row['fichier']}")
    return 0


def cmd_passi(args: argparse.Namespace) -> int:
    """Dossier PASSI opérationnel : cadrage, contrôles, preuves et revue."""
    from guardia.engines.autorisations import build_autorisations
    from guardia.engines.passi import DISCLAIMER, orchestrer
    from guardia.engines.passi_alignment import build_alignment
    from guardia.engines.passi_assessment import as_markdown as assessment_markdown, build_assessment, export_assessment

    mission = load_mission(Path(args.mission) if getattr(args, "mission", None) else None)
    mission.extras["passi"] = True
    authz = build_autorisations(
        mission,
        generer_liasse=bool(getattr(args, "generer", False)),
        pour_passi=True,
    )
    from guardia.engines.passi_assessment import requested_activities
    requested = requested_activities(mission)
    team = "red" if "intrusion" in requested else "blue"
    offre = orchestrer(mission, autorisations=authz, equipe=team)
    base_result = {"equipe": team, "autorisations": authz, **offre}
    alignment = build_alignment(mission, base_result)
    evidence_data = {
        "methodology": (mission.extras or {}).get("methodology") or (mission.extras or {}).get("framing"),
        "sampling": (mission.extras or {}).get("sampling") or (mission.extras or {}).get("framing", {}).get("sampling"),
        "prerequisites": (mission.extras or {}).get("prerequisites"),
        "opening_meeting": (mission.extras or {}).get("opening_meeting"),
        "change_log": (mission.extras or {}).get("change_log"),
        "closure_check": (mission.extras or {}).get("closure_check"),
        "architecture_docs": (mission.extras or {}).get("architecture_docs") or {},
        "config": (mission.extras or {}).get("config") or {},
        "code": (mission.extras or {}).get("code") or {},
        "code_scope": (mission.extras or {}).get("code_scope"),
        "code_evidence": (mission.extras or {}).get("code_evidence"),
        "pentest": (mission.extras or {}).get("pentest") or {},
        "org": (mission.extras or {}).get("org") or {},
        "review": (mission.extras or {}).get("review") or {},
        "evidence": (mission.extras or {}).get("evidence") or {},
        "trace": (mission.extras or {}).get("trace") or {},
    }
    assessment = build_assessment(mission, {**base_result, "evidence_data": evidence_data})
    print(DISCLAIMER)
    print()
    print(offre.get("attestation") or "")
    print()
    print(f"Mission : {mission.client}")
    print(f"Activités : {', '.join(assessment['mission']['activities']) or 'aucune'}")
    print(f"Équipe d'exécution : {team}")
    print(f"Autorisations : {'signées' if authz.get('complet') else 'incomplètes'}")
    print(f"Contrôles vérifiés : {assessment['summary']['verified']}/{assessment['summary']['controls']}")
    print(f"Validations humaines en attente : {assessment['summary']['pending_human']}")
    print(f"Chaînes exigence→preuve alimentées : {assessment['summary'].get('chaines_alimentees') or 0}")
    print()
    # Le score global a été retiré du mode CLI : il s'agit d'un état de mission,
    # pas d'un taux de qualification PASSI.
    print("Plan d'exécution PASSI :")
    for step in assessment.get("execution_plan") or []:
        print(f"  - {step['id']} · {step['activity']} · {step['capability']} · autorisation={step['authorization']} · {'auto' if step.get('automatic') else 'humain'}")
    print()
    if getattr(args, "markdown", False):
        print(assessment_markdown(assessment))
    else:
        for aid, data in (assessment.get("by_activity") or {}).items():
            print(
                f"  · {aid}: {data['verified']} vérifié(s), {data['pending_human']} en attente, "
                f"{data['not_covered']} non couvert(s)"
            )
        print()
        print("Prochaines actions :")
        for row in assessment.get("next_actions") or []:
            print(f"  - {row['control']} : {row['action']}")
    if getattr(args, "export", None):
        paths = export_assessment(assessment, Path(args.export))
        print()
        print(f"Dossier PASSI exporté : {paths['json']}")
        print(f"Rapport Markdown       : {paths['markdown']}")
        print(f"Manifest SHA-256       : {paths['manifest']}")
    return 0


def cmd_cerveau(args: argparse.Namespace) -> int:
    """Prévisualise le DAG adaptatif — pas un scan, pas un simulateur PASSI."""
    from guardia.cerveau import CAPACITES, raisonner
    from guardia.engines.autorisations import build_autorisations

    mission = load_mission(Path(args.mission) if getattr(args, "mission", None) else None)
    authz = build_autorisations(mission, pour_passi=bool((mission.extras or {}).get("passi")))
    equipe = str((mission.extras or {}).get("equipe") or "red")
    hosts = []
    ex = mission.extras or {}
    plan = {
        "lynis": bool(ex.get("lynis")),
        "greenbone": bool(ex.get("greenbone")),
        "site_url": ex.get("site_url") or "",
        "machines": bool(ex.get("machines")),
        "passi": bool(ex.get("passi") or ex.get("offre_passi")),
        "rgpd": bool(ex.get("rgpd")),
        "llm_groq": bool(ex.get("llm_groq") or getattr(args, "llm_groq", False)),
    }
    # Prefill URL depuis mission.scope.urls si vide
    if not plan["site_url"]:
        scope = (ex.get("mission") or {}).get("scope") if isinstance(ex.get("mission"), dict) else {}
        urls = (scope or {}).get("urls") or ex.get("urls") or []
        if isinstance(urls, list) and urls:
            plan["site_url"] = str(urls[0])
        elif ex.get("rgpd") or ex.get("passi"):
            plan["site_url"] = plan["site_url"] or "https://pctamalou.fr"
    brain = raisonner(
        mission,
        hosts=hosts,
        plan=plan,
        equipe=equipe,
        autorisations=authz,
    )
    print(brain.get("nature") or "")
    print()
    print(brain.get("synthese") or "")
    print()
    print(f"Policy : mandat={'oui' if brain.get('ctx', {}).get('mandat') else 'non'} · "
          f"CIDR {brain.get('ctx', {}).get('cidr') or '—'} · "
          f"URL {brain.get('ctx', {}).get('url') or '—'}")
    print(f"Budget réseau : {brain.get('budget', {}).get('spent_reseau')}/{brain.get('budget', {}).get('reseau')}")
    cov = brain.get("osi_couverture") or {}
    if cov:
        print("Couverture OSI :", cov.get("resume") or "")
        print("  Touchées :", ", ".join(cov.get("couches_touchees") or []) or "—")
        print("  Lacunes :", ", ".join(cov.get("lacunes") or []) or "—")
    dirs = brain.get("directives_passi_cnil") or []
    if dirs:
        print("Directives PASSI/CNIL (démonstration lecture — pas d'exploit) :")
        for d in dirs:
            print(
                f"  [{d.get('status')}] {d.get('id')} L={d.get('layer')} "
                f"· {d.get('nature_action') or 'démo lecture'} — {d.get('why')}"
            )
    groq = brain.get("llm_groq") or {}
    if groq:
        print("Groq (optionnel, ton technicien) :", groq.get("skipped") or groq.get("model") or "ok")
        fiche = groq.get("fiche_explication_client") or groq.get("fiche_explication") or ""
        if fiche:
            print("Fiche client (vouvoiement, à valider) :", fiche[:400])
        ann = groq.get("annexe_technicien") or {}
        if ann:
            print("Annexe technicien (à valider) :")
            if ann.get("hypothese_realisabilite"):
                print("  hypothèse réalisabilité :", str(ann.get("hypothese_realisabilite"))[:300])
            for ix in (ann.get("indices_techniques") or [])[:4]:
                print("  · indice :", ix)
            if ann.get("risque_residuel"):
                print("  risque résiduel :", str(ann.get("risque_residuel"))[:240])
        for step in (groq.get("procedure_confirmation_lecture") or [])[:5]:
            print("  · confirmation lecture :", step)
    print("Décisions :")
    for d in brain.get("decisions") or []:
        extra = ""
        if d.get("nature_action"):
            extra = f" · {d.get('nature_action')}"
        print(f"  [{d.get('etat')}] {d.get('noeud')} — {d.get('why')}{extra}")
    print()
    print(f"Capacités : {len(CAPACITES)} · avenant jamais auto : "
          + ", ".join(c["id"] for c in CAPACITES if c.get("avenant")))
    return 0


def cmd_about(_args: argparse.Namespace) -> int:
    print(f"Guardia {__version__}")
    print(f"Signature : {__signature__}")
    print("Produit : moteur d'orchestration d'audit défensif (Echoes of Hackers)")
    print()
    print("Que sait-il faire ?")
    print("  Observer un CIDR / une URL mandaté, en lecture. Pas d'exploit.")
    print("Comment décide-t-il ?")
    print("  Mandat → observer → décider → tester le pertinent. Branche inutile = skip.")
    print("Quelles preuves ?")
    print("  Commande, résultat, hash. Observation → constat. Validation humaine.")
    print("Quel résultat ?")
    print("  Rapport : grandes lignes, décisions, graphe, chemins d'exposition (hypothèses),")
    print("  findings corrélés, actions écartées, capacités absentes, recommandations.")
    print()
    print("Règle : autorisation écrite obligatoire — pas d'exploit")
    print("Identité : python3 -m guardia identite")
    print("Cerveau : python3 -m guardia cerveau -m FILE")
    print("PASSI : python3 -m guardia passi -m FILE  (mode, pas un certificat)")
    print("Checkup : python3 -m guardia run -m FILE --cidr …")
    print("UI : python3 -m guardia ui")
    print(f"Racine : {ROOT}")
    from guardia.engines.llm_polish import (
        gpu_nvidia_dispo,
        resolve_model,
        resolve_ngl,
        resolve_server,
    )

    m = resolve_model(None)
    s = resolve_server(None)
    gpu = gpu_nvidia_dispo()
    ngl_eff, mode = resolve_ngl(99, allow_cpu=False)
    print(f"LLM modèle : {m if m else '(absent — place le GGUF dans guardia-models/)'}")
    print(f"LLM serveur : {s if s else '(llama-server introuvable)'}")
    print(f"GPU NVIDIA : {'oui' if gpu else 'non'} — mode LLM défaut : {mode} (ngl={ngl_eff})")
    print("  (avec --llm : GPU obligatoire si détectée ; --cpu-llm pour autoriser CPU)")
    return 0


def cmd_liens(_args: argparse.Namespace) -> int:
    """Checkup des liens (dossiers, lanceurs, Thunar, Firefox) — machine unique ÉOH."""
    from guardia.core.open_links import format_checkup, run_checkup

    rep = run_checkup(repair=True)
    print(format_checkup(rep))
    if rep.get("ko"):
        print("\nKO : corriger avant de compter sur « Ouvrir rapports/ ».")
        return 1
    return 0


def cmd_firefox_neutre(_args: argparse.Namespace) -> int:
    """Crée le profil Firefox ESR « neutre » + raccourci Bureau."""
    from guardia.core.firefox_neutre import ensure_neutre_profile, status_line

    rep = ensure_neutre_profile(create_desktop=True)
    print(status_line())
    print(rep.get("detail") or "")
    if rep.get("desktop"):
        print("desktop:", rep["desktop"])
    return 0 if rep.get("ok") else 1


def cmd_inventaire(args: argparse.Namespace) -> int:
    """Liste les outils Kali présents. Écrit rapports/inventaire-kali.txt."""
    from guardia.engines.inventaire import build_inventaire, ecrire_inventaire, format_txt

    inv = build_inventaire(brut=not getattr(args, "court", False))
    path = ecrire_inventaire(inv)
    print(format_txt(inv))
    print(f"Écrit : {path}")
    return 0


def cmd_programme(args: argparse.Namespace) -> int:
    """Liste les outils de lecture de la visite."""
    from guardia.engines.programme import build_programme, ecrire_programme

    mission = load_mission(Path(args.mission) if getattr(args, "mission", None) else None)
    url = (getattr(args, "url", None) or "").strip() or None
    cidr = (getattr(args, "cidr", None) or mission.cidr or "").strip()
    block = build_programme(mission, cidr=cidr, url=url, args=args)
    print("Guardia — outils de la visite (lecture, calibrage)")
    print(block["analogie"])
    print(f"Mandat : {'oui' if block['mandat'] else 'non'}")
    print(f"CIDR : {block['assets'].get('cidr') or '—'}")
    urls = block["assets"].get("urls") or []
    if urls:
        print("URL :")
        for u in urls:
            print(f"  - {u}")
    print("Outils :")
    for o in block["outils"]:
        inst = "installé" if o["installe"] else "absent"
        print(f"  {o['nom']:24} {inst:9}  {o.get('aide') or o.get('pourquoi')}")
    path = ecrire_programme(block)
    print(f"JSON : {path}")
    print("Aide : python3 -m guardia outil list")
    return 0


def cmd_outil(args: argparse.Namespace) -> int:
    """Liste un outil passif, ou lance une lecture ciblée (--run)."""
    from guardia.engines.programme import (
        CATALOGUE,
        binaire,
        commande_encadree,
        get_outil,
        run_lecture_ciblee,
        urls_du_programme,
    )

    nom = (getattr(args, "nom", None) or "list").strip().lower()
    if nom in ("list", "ls", "catalogue", ""):
        print("Outils de lecture — Guardia lance au calibrage s'ils sont installés")
        print(f"{'id':12} {'installé':12} aide")
        for o in CATALOGUE:
            inst = binaire(o) or "—"
            print(f"{o.id:12} {inst:12.12} {o.aide}")
            if not binaire(o) and getattr(o, "install", ""):
                print(f"{'':12} installer : {o.install}")
        print("Inventaire machine : python3 -m guardia inventaire")
        return 0

    o = get_outil(nom)
    if o is None:
        print(f"Outil inconnu : {nom}. python3 -m guardia outil list")
        return 2

    mission = load_mission(Path(args.mission) if getattr(args, "mission", None) else None)
    url = (getattr(args, "url", None) or "").strip() or None
    urls = urls_du_programme(mission, url)
    cible = urls[0] if urls else (url or "")
    print(f"{o.nom}")
    print(f"Aide : {o.aide}")
    print(f"Commande : {commande_encadree(o, cible, mission.cidr or '')}")
    if not binaire(o):
        hint = getattr(o, "install", "") or o.aide
        print(f"Absent sur cette station. Kali : {hint}")
    if not mission.mandat_nda_signes and not getattr(args, "yes", False):
        print("Mandat non coché. --yes seulement en labo local.")
        return 3

    if getattr(args, "run", False):
        if o.scope == "url":
            rows = run_lecture_ciblee(cible)
            shown = [r for r in rows if r.get("id") == o.id] or rows
            for row in shown:
                print(f"--- {row.get('nom')} ---")
                if not row.get("installe"):
                    print("non installé, passé.")
                    continue
                print((row.get("extrait") or "(vide)")[:2000])
            return 0
        print("Lecture LAN : python3 -m guardia run -m MISSION --yes")
        return 0

    if getattr(args, "open", False):
        print(f"{o.nom} se lance au calibrage. Aide : {o.aide}")
        return 0

    print("Pour lancer : python3 -m guardia run -m MISSION --yes")
    return 0

def cmd_wizard(_args: argparse.Namespace) -> int:
    from guardia.ui.wizard import run_wizard

    try:
        run_wizard()
        return 0
    except KeyboardInterrupt:
        print("\nAnnulé.")
        return 130


def cmd_rgpd(args: argparse.Namespace) -> int:
    """Affiche / remplit la fiche RGPD d'une mission (pas un certificat)."""
    from guardia.engines.rgpd_config import (
        RGPD_FIELDS,
        TRI_CHOICES,
        load_rgpd_config,
        patch_mission_yaml,
        config_is_blank,
        raw_config_from_mission,
        summary_line,
    )
    from guardia.ui.wizard import ask as _ask, choose

    if not args.mission:
        print("Fichier mission requis : python3 -m guardia rgpd -m missions/exemple-audit.yaml", file=sys.stderr)
        return 2
    path = Path(args.mission)
    try:
        mission = load_mission(path)
    except GuardiaError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    cfg = load_rgpd_config(mission)
    raw = raw_config_from_mission(mission)
    print("Guardia — fiche RGPD (signalement sur demande, PAS un certificat)")
    print(f"Mission : {path}")
    print(f"Client  : {mission.client}")
    if config_is_blank(raw):
        print("État    : fiche vide (tout à « inconnu ») — le rapport restera « à confirmer ».")
    else:
        print(f"État    : {summary_line(cfg)}")
    print()
    for f in RGPD_FIELDS:
        print(f"  {f['label']}: {cfg.get(f['key']) or '—'}")
    if getattr(args, "show", False):
        return 0
    if not getattr(args, "edit", False):
        go = input("\nConfigurer maintenant ? (oui/non) [oui]: ").strip().lower()
        if go in ("non", "n", "no"):
            print("OK. Relance avec --edit pour modifier, --show pour afficher seulement.")
            return 0
    print("\n— Déclarations (oui / non / inconnu, ou texte) —")
    print("  Entrée = garder la valeur actuelle. Ce n'est pas un certificat.")
    new = dict(cfg)
    for f in RGPD_FIELDS:
        cur = str(cfg.get(f["key"]) or "")
        if f["kind"] == "tri":
            code = choose(
                f"{f['label']}\n  ({f.get('help','')})",
                [("inconnu", "inconnu"), ("oui", "oui"), ("non", "non")],
                default=cur if cur in TRI_CHOICES else "inconnu",
            )
            new[f["key"]] = code
        else:
            new[f["key"]] = _ask(f["label"], cur)
    try:
        patch_mission_yaml(path, new)
    except OSError as exc:
        print(f"écriture impossible : {exc}", file=sys.stderr)
        return 1
    print(f"\nFiche enregistrée dans {path}")
    print(f"rgpd: true  — {summary_line(new)}")
    print("Ce n'est toujours pas un certificat.")
    return 0


def cmd_usages(args: argparse.Namespace) -> int:
    """Fiche usages & droits (ce que les gens peuvent faire — pas un dump)."""
    from guardia.engines.usages_config import (
        USAGES_FIELDS,
        TRI_CHOICES,
        load_usages_config,
        patch_mission_yaml,
        config_is_blank,
        raw_config_from_mission,
        summary_line,
    )
    from guardia.ui.wizard import ask as _ask, choose

    if not args.mission:
        print("Fichier mission requis : python3 -m guardia usages -m missions/exemple-ecole.yaml", file=sys.stderr)
        return 2
    path = Path(args.mission)
    try:
        mission = load_mission(path)
    except GuardiaError as exc:
        print(str(exc), file=sys.stderr)
        return 1
    cfg = load_usages_config(mission)
    raw = raw_config_from_mission(mission)
    print("Guardia — fiche usages & droits (PAS un dump, PAS un certificat)")
    print(f"Mission : {path}")
    print(f"Client  : {mission.client}")
    if config_is_blank(raw):
        print("État    : fiche vide — le chapitre restera « à confirmer » sur les droits.")
    else:
        print(f"État    : {summary_line(cfg)}")
    print()
    for f in USAGES_FIELDS:
        print(f"  {f['label']}: {cfg.get(f['key']) or '—'}")
    if getattr(args, "show", False):
        return 0
    if not getattr(args, "edit", False):
        go = input("\nConfigurer maintenant ? (oui/non) [oui]: ").strip().lower()
        if go in ("non", "n", "no"):
            print("OK. Relance avec --edit pour modifier, --show pour afficher seulement.")
            return 0
    print("\n— Déclarations (oui / non / inconnu, ou texte) —")
    print("  On ne dump pas l'annuaire. Entrée = garder.")
    new = dict(cfg)
    for f in USAGES_FIELDS:
        cur = str(cfg.get(f["key"]) or "")
        if f["kind"] == "tri":
            code = choose(
                f"{f['label']}\n  ({f.get('help','')})",
                [("inconnu", "inconnu"), ("oui", "oui"), ("non", "non")],
                default=cur if cur in TRI_CHOICES else "inconnu",
            )
            new[f["key"]] = code
        else:
            new[f["key"]] = _ask(f["label"], cur)
    try:
        patch_mission_yaml(path, new)
    except OSError as exc:
        print(f"écriture impossible : {exc}", file=sys.stderr)
        return 1
    print(f"\nFiche enregistrée dans {path}")
    print(f"usages: true  — {summary_line(new)}")
    return 0


def cmd_discover(args: argparse.Namespace) -> int:
    setup_logging(verbose=args.verbose)
    from guardia.engines import classify, discover as disc, netinfo

    errors: list[str] = []
    cidr = args.cidr
    iface = gw = ""
    try:
        if not cidr:
            ctx = netinfo.detect()
            cidr = ctx.cidr
            iface, gw = ctx.iface, ctx.gateway
    except Exception as exc:  # noqa: BLE001
        log.error("netinfo: %s", exc)
        errors.append(str(exc))
        if not cidr:
            print("CIDR requis (--cidr) si la détection échoue.", file=sys.stderr)
            return 2

    mission = load_mission(Path(args.mission) if args.mission else None)
    if getattr(args, "full", False):
        mission.profondeur = "full"
        mission.extras = dict(mission.extras or {})
        mission.extras["parc_inconnu"] = True
    try:
        _assert_mandate(mission, cidr, yes=args.yes)
    except MandateRequiredError as exc:
        print(str(exc), file=sys.stderr)
        return 3

    work = RAPPORTS / f"work-discover-{datetime.now().strftime('%Y%m%d-%H%M%S')}"
    try:
        hosts = disc.discover(cidr, workdir=work, profondeur=getattr(mission, "profondeur", "standard"))
    except ToolMissingError as exc:
        print(str(exc), file=sys.stderr)
        return 4
    except Exception as exc:  # noqa: BLE001
        log.exception("discover")
        print(f"échec découverte: {exc}", file=sys.stderr)
        return 1

    try:
        from guardia.engines import enrich as enrich_mod
        errors.extend(
            enrich_mod.enrich_hosts(
                hosts, workdir=work, profondeur=getattr(mission, "profondeur", "standard")
            )
        )
    except Exception as exc:  # noqa: BLE001
        errors.append(f"enrich: {exc}")
        log.warning("enrich: %s", exc)

    classify.classify_all(hosts, gateway=gw)
    for h in hosts:
        print(f"{h.ip}\t{h.hostname or '-'}\t{h.mac or '-'}\t{h.vendor or '-'}\t{h.kind}")
    print(f"# {len(hosts)} hôte(s) — cidr={cidr} iface={iface} gw={gw}")
    if errors:
        print("# erreurs:", "; ".join(errors))
    return 0


def cmd_run(args: argparse.Namespace) -> int:
    setup_logging(verbose=args.verbose)
    from guardia.core.orchestrate import (
        appliquer_yaml,
        annoncer_plan,
        brancher_calibrage,
        JournalOrchestre,
        summarize_plan,
        want_greenbone,
        want_lynis,
        want_llm,
        want_trivy,
        want_passi,
        want_autorisations,
    )
    from guardia.engines import classify, discover as disc, netinfo, services
    from guardia.report.html_report import render
    from guardia.rules.engine import apply_rules

    mission = load_mission(Path(args.mission) if args.mission else None)
    if args.profile:
        mission.profil_moteur = args.profile
    # Extras issus du YAML : ils allument vraiment les actions, pas un décor.
    mission.extras = dict(mission.extras or {})
    appliquer_yaml(args, mission)
    # Cases UI (--no-*) : éteindre les extras YAML correspondants
    _no_map = (
        ("no_passi", "passi"),
        ("no_lynis", "lynis"),
        ("no_greenbone", "greenbone"),
        ("no_trivy", "trivy"),
        ("no_machines", "machines"),
        ("no_autorisations", "autorisations"),
        ("no_audit", "audit"),
        ("no_llm", "llm"),
        ("no_pdf", "pdf"),
        ("no_full", "parc_inconnu"),
        ("no_all_ports", "all_ports"),
        ("no_rgpd", "rgpd"),
        ("no_usages", "usages"),
        ("no_pistes", "pistes"),
        ("no_calibrage", "calibrage"),
        ("no_cve", "cve"),
        ("no_lan", "lan"),
        ("no_site", "site_url"),
    )
    mission.extras = dict(mission.extras or {})
    for attr, key in _no_map:
        if getattr(args, attr, False):
            if key == "passi":
                mission.extras["passi"] = False
                mission.extras["offre_passi"] = False
            elif key == "site_url":
                mission.extras.pop("site_url", None)
                mission.extras.pop("site", None)
            elif key == "parc_inconnu":
                mission.extras["parc_inconnu"] = False
                if (mission.profondeur or "") == "full":
                    mission.profondeur = "standard"
                mission.extras.pop("mode", None)
            elif key == "audit":
                mission.extras["audit"] = False
                mission.extras["audit_full"] = False
            elif key == "lan":
                mission.extras["lan"] = False
            else:
                mission.extras[key] = False
            try:
                if hasattr(args, key) and key not in ("site_url", "parc_inconnu"):
                    setattr(args, key, False)
            except Exception:
                pass
            if key == "passi":
                try:
                    args.passi = False
                except Exception:
                    pass
            if attr == "no_site":
                try:
                    args.site = None
                except Exception:
                    pass
            if attr == "no_full":
                try:
                    args.full = False
                except Exception:
                    pass
            if attr == "no_all_ports":
                mission.extras["all_ports"] = False
            if attr == "no_audit":
                try:
                    args.audit = False
                    args.audit_full = False
                except Exception:
                    pass
            if attr == "no_llm":
                try:
                    args.llm = False
                except Exception:
                    pass
            if attr == "no_pdf":
                try:
                    args.pdf = False
                except Exception:
                    pass

    acts = getattr(args, "passi_activites", None)
    if acts:
        mission.extras["passi"] = True
        mission.extras["passi_activities"] = [x.strip() for x in str(acts).split(",") if x.strip()]
    passi_seul = (getattr(args, "passi", False) or mission.extras.get("passi")) and not getattr(
        args, "full", False
    )
    if passi_seul:
        mission.extras["mode"] = "passi"
        mission.profondeur = "standard"
        mission.extras.pop("parc_inconnu", None)
    if mission.extras.get("parc_inconnu") or mission.extras.get("all_ports") or mission.extras.get("llm"):
        log.info("extras mission: %s", {k: mission.extras.get(k) for k in ("parc_inconnu", "all_ports", "llm", "pdf", "max_time")})

    if not passi_seul and (
        getattr(args, "full", False) or mission.extras.get("parc_inconnu") or mission.profondeur == "full"
    ):
        mission.profondeur = "full"
        mission.extras["parc_inconnu"] = True
        mission.extras["mode"] = "full"
        log.info("mode full : parc inconnu / profondeur full")
    if getattr(args, "all_ports", False) or mission.extras.get("all_ports"):
        mission.extras["all_ports"] = True
        log.info("mode all-ports : TCP 1-65535 (long)")
    # LLM / PDF depuis YAML si pas déjà sur la ligne de commande
    if mission.extras.get("llm") and not getattr(args, "llm", False):
        args.llm = True
        log.info("LLM activé via mission YAML")
    if mission.extras.get("pdf") and not getattr(args, "pdf", False):
        args.pdf = True
        log.info("PDF activé via mission YAML")
    # audit_full / audit: full → active audit + niveau full
    extras = mission.extras or {}
    audit_val = extras.get("audit")
    want_full = bool(
        getattr(args, "audit_full", False)
        or extras.get("audit_full")
        or (isinstance(audit_val, str) and audit_val.strip().lower() == "full")
    )
    if want_full:
        args.audit = True
        args.audit_full = True
        mission.extras["audit"] = True
        mission.extras["audit_full"] = True
        mission.extras["audit_level"] = "full"
        log.info("Audit FULL activé (CLI --audit-full ou YAML audit_full / audit: full)")
    elif extras.get("audit") and not getattr(args, "audit", False):
        args.audit = True
        mission.extras["audit_level"] = "standard"
        log.info("Audit poussé activé via mission YAML")

    want_audit = bool(
        getattr(args, "audit", False)
        or getattr(args, "audit_full", False)
        or mission.extras.get("audit")
        or mission.extras.get("audit_full")
    )
    audit_level = "standard"
    if getattr(args, "audit_full", False) or mission.extras.get("audit_full"):
        audit_level = "full"
    elif isinstance(mission.extras.get("audit"), str) and str(mission.extras.get("audit")).lower() == "full":
        audit_level = "full"
    elif mission.extras.get("audit_level") == "full":
        audit_level = "full"

    # Porte Red Team : --red-team exige attestation + mappe les actions signees
    from guardia.core.red_gate import (
        apply_signed_actions,
        red_ok_attested,
        red_team_requested,
        signed_actions_from,
    )

    if red_team_requested(args, mission):
        if not red_ok_attested(args, mission):
            print(
                "Red Team : --red-team exige --red-ok (ou GUARDIA_RED_OK=1) "
                "ou YAML red_team: true + red_actions_signed: [...]. "
                "Aucun moteur avance allume.",
                flush=True,
            )
            log.warning("red-team refuse : attestation manquante")
        else:
            signed = signed_actions_from(args, mission)
            if not signed:
                print(
                    "Red Team : attestation OK mais aucune action dans "
                    "red_actions_signed — rien d'avance allume.",
                    flush=True,
                )
            else:
                applied = apply_signed_actions(args, mission, signed)
                for aid in applied:
                    log.info("red-gate action ouverte (signee) : %s", aid)
                    print(f"Red Team (signe) : action {aid} ouverte — defensif seulement", flush=True)

    from guardia.core.equipe import restreindre_blue

    coupes_blue = restreindre_blue(args, mission)
    if coupes_blue:
        print(
            "Blue team : checkup défensif — modules red éteints : "
            + ", ".join(coupes_blue),
            flush=True,
        )
        log.info("blue clip: %s", coupes_blue)
        if (mission.profondeur or "") == "full":
            mission.profondeur = "standard"
        want_audit = bool(
            getattr(args, "audit", False)
            or getattr(args, "audit_full", False)
            or mission.extras.get("audit")
            or mission.extras.get("audit_full")
        )
        audit_level = "standard"

    # max_time : CLI si fourni (--max-time), sinon extras YAML, sinon 7200
    if getattr(args, "max_time", None) is None:
        mt_extra = mission.extras.get("max_time")
        if mt_extra is not None:
            try:
                args.max_time = int(mt_extra)
                log.info("max_time %ss via mission YAML", args.max_time)
            except (TypeError, ValueError):
                args.max_time = 7200
                log.warning("max_time YAML invalide (%r) → défaut 7200", mt_extra)
        else:
            args.max_time = 7200

    from guardia.core.defaults import (
        RESERVE_AFTER_SERVICES_AUDIT_SEC,
        RESERVE_AFTER_SERVICES_SEC,
    )
    from guardia.core.autorisation import etat as etat_auth, limiter_plan

    if getattr(args, "yes", False):
        mission.extras["attestation_operateur"] = True

    plan = summarize_plan(args, mission)
    plan["llm_groq"] = bool(
        getattr(args, "llm_groq", False) or (mission.extras or {}).get("llm_groq")
    )
    auth = etat_auth(mission, args)
    plan = limiter_plan(plan, auth)
    plan["orchestre_prevu"] = annoncer_plan(plan)
    journal = JournalOrchestre()
    for aid in (mission.extras or {}).get("red_actions_opened") or []:
        journal.note(f"Red gate : action avancee ouverte (document signe) — {aid}")
    journal.phase("Plan de visite")
    journal.note("Chaque action prévue sera jouée, sautée ou notée absente.")
    print(auth["bandeau"], flush=True)
    log.info("plan modules : %s", plan)
    lan = bool(plan.get("lan", True))
    profond = bool(plan.get("profond"))
    if lan:
        print("Action LAN : nmap + calibrage")
    else:
        print("Action LAN : off — pas de scan parc")
    if plan.get("site_url"):
        print(f"Action site : {plan['site_url']}" + (" (approfondi)" if profond else ""))
    if plan.get("rgpd"):
        print("Action RGPD : signalement")
    if plan.get("restructure"):
        print("Action parc : restructuration")
    if plan.get("machines"):
        print("Action machines / OT")
    if plan.get("usages"):
        print("Action usages & droits")
    if plan.get("pistes"):
        print("Pistes : catalogue")
    if plan.get("calibrage"):
        print("Calibrage Kali : allumé")
    if plan.get("greenbone"):
        print("Action Greenbone : lecture GMP")
    if plan.get("trivy"):
        print("Action Trivy : FS opérateur")
    if plan.get("lynis"):
        print("Action Lynis : poste opérateur")
    if plan.get("autorisations"):
        print("Action autorisations : liasse red (huit pièces)")
    if plan.get("passi"):
        print("Action offre PASSI : inspirée, pas une qualification")

    try:
        from guardia.engines.inventaire import ecrire_inventaire

        ecrire_inventaire()
        journal.outil("inventaire Kali", "", "ok")
    except Exception as exc:  # noqa: BLE001
        log.warning("inventaire : %s — on continue", exc)
        journal.skip("inventaire Kali", str(exc))

    errors: list[str] = []
    started = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    iface = gw = ""
    # Fenêtre UI prime sur le YAML : --cidr ou --cidr-catalog
    if getattr(args, "cidr_catalog", False):
        from guardia.core.cidr import auto_scan_cidrs
        _cidrs = auto_scan_cidrs()
        cidr = ",".join(_cidrs)
        mission.extras = dict(mission.extras or {})
        mission.extras["cidr_catalog"] = list(_cidrs)
        mission.cidr = ""
        print("CIDR catalogue UI : {n} plages (YAML cidr ignoré)".format(n=len(_cidrs)), flush=True)
    elif getattr(args, "cidr", None) not in (None,):
        cidr = (args.cidr or "").strip()
        mission.cidr = cidr
    else:
        cidr = (mission.cidr or "").strip()
    ctx = None
    local_ip = ""

    try:
        ctx = netinfo.detect()
        iface, gw = ctx.iface, ctx.gateway
        local_ip = ctx.local_ip or ""
        if not cidr and not getattr(args, "cidr_catalog", False) and not (mission.extras or {}).get("cidr_catalog"):
            cidr = ctx.cidr
    except Exception as exc:  # noqa: BLE001
        log.warning("netinfo: %s", exc)
        errors.append(f"netinfo: {exc}")

    if not cidr and lan:
        from guardia.core.cidr import auto_scan_cidrs
        _cidrs = auto_scan_cidrs()
        cidr = ",".join(_cidrs)
        mission.extras = dict(mission.extras or {})
        mission.extras["cidr_catalog"] = list(_cidrs)
        print("CIDR vide : catalogue {n} plages".format(n=len(_cidrs)), flush=True)

    site_only = bool(plan.get("site_url")) and not lan
    try:
        _assert_mandate(mission, cidr, yes=args.yes, site_only=site_only)
    except MandateRequiredError as exc:
        print(str(exc), file=sys.stderr)
        return 3

    print(banniere_run(mission, cidr), flush=True)
    if not operateur_a_signe(mission):
        log.warning(
            "Paraphe opérateur ÉOH absent (operateur_signe). "
            "On continue si le mandat est là — parapher l'attestation pour le dossier."
        )
        print(
            f"⚠ Opérateur {operateur_de(mission)} : paraphe ÉOH manquant — "
            "opérateur identifié, parapher aussi. Voir python3 -m guardia identite",
            flush=True,
        )

    from guardia.core.budget import RunBudget

    max_time = int(getattr(args, "max_time", 7200) or 7200)
    budget = RunBudget(limit_sec=max_time)
    log.info("budget mission: %ss (%.0f min)", max_time, max_time / 60)
    print(f"Budget scan : {max_time}s ({max_time // 60} min) — LLM / HTML / JSON hors horloge")

    from guardia.core.operator import get_operator, install_operator_controls

    install_operator_controls(tty_keys=True)
    op = get_operator()

    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    work = RAPPORTS / f"work-{stamp}"
    work.mkdir(parents=True, exist_ok=True)

    hosts = []
    poste_operateur: dict = {}
    if lan:
        journal.phase("LAN nmap")
        with budget.phase("discover"):
            if "discover" in budget.skipped:
                pass
            else:
                try:
                    to = int(budget.cap(300 if mission.profondeur == "full" else 180, minimum=30))
                    hosts = disc.discover(
                        cidr,
                        workdir=work,
                        profondeur=getattr(mission, "profondeur", "standard"),
                        timeout=to,
                    )
                    journal.outil("nmap discover", cidr, "ok")
                except ToolMissingError as exc:
                    print(str(exc), file=sys.stderr)
                    errors.append(f"discover: {exc} — on enchaîne")
                    log.warning("discover manquant : %s", exc)
                    journal.skip("nmap discover", str(exc))
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"discover: {exc}")
                    log.exception("discover")
                    journal.skip("nmap discover", str(exc))

        if hosts:
            try:
                from guardia.core.poste import (
                    adresses_locales,
                    noms_locaux,
                    partitionner,
                    resume as resume_poste,
                )

                parc, op_hosts = partitionner(
                    hosts,
                    ips=adresses_locales(),
                    noms=noms_locaux(),
                    mission=mission,
                    local_ip=local_ip,
                )
                if op_hosts:
                    hosts = parc
                    poste_operateur = resume_poste(op_hosts, mission)
                    rec = poste_operateur.get("resume") or ""
                    print(f"Poste opérateur hors parc client : {rec}", flush=True)
                    journal.note(f"Poste opérateur retiré du parc : {rec}")
            except Exception as exc:  # noqa: BLE001
                log.warning("poste opérateur: %s", exc)

        with budget.phase("enrich"):
            if hosts and "enrich" not in budget.skipped:
                try:
                    from guardia.engines import enrich as enrich_mod

                    errors.extend(
                        enrich_mod.enrich_hosts(
                            hosts,
                            workdir=work,
                            profondeur=getattr(mission, "profondeur", "standard"),
                            remaining_sec=budget.remaining(),
                        )
                    )
                    journal.outil("enrich DNS/NetBIOS/mDNS", cidr, "ok")
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"enrich: {exc}")
                    log.warning("enrich: %s", exc)
                    journal.skip("enrich DNS/NetBIOS/mDNS", str(exc))
            elif lan:
                journal.skip("enrich DNS/NetBIOS/mDNS", "aucun hôte" if not hosts else "budget")

        with budget.phase("services"):
            if hosts and "services" not in budget.skipped:
                try:
                    w = getattr(args, "workers", None)
                    if w is None:
                        w = mission.extras.get("workers")
                    if w is None:
                        import os as _os
                        w = min(4, max(1, (_os.cpu_count() or 2) // 2))
                    reserve = (
                        RESERVE_AFTER_SERVICES_AUDIT_SEC
                        if want_audit or plan.get("rgpd") or plan.get("site_url") or plan.get("usages")
                        else RESERVE_AFTER_SERVICES_SEC
                    )
                    errors.extend(
                        services.scan_services(
                            hosts,
                            profondeur=mission.profondeur,
                            all_ports=bool(
                                getattr(args, "all_ports", False) or mission.extras.get("all_ports")
                            ),
                            remaining_sec=budget.remaining(),
                            workers=int(w),
                            reserve_sec=reserve,
                        )
                    )
                    journal.outil("nmap -sV services", cidr, "ok")
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"services: {exc}")
                    log.warning("services: %s", exc)
                    journal.skip("nmap -sV services", str(exc))
            elif lan:
                journal.skip("nmap -sV services", "aucun hôte" if not hosts else "budget")
    else:
        log.info("LAN off — discover / enrich / services sautés")
        journal.skip("LAN nmap", "plan éteint")

    with budget.phase("classify", must_run=True, kind="post"):
        if hosts:
            try:
                classify.classify_all(hosts, gateway=gw)
                journal.outil("classify", f"{len(hosts)} hôte(s)", "ok")
            except Exception as exc:  # noqa: BLE001
                errors.append(f"classify: {exc}")
                journal.skip("classify", str(exc))
        elif lan:
            journal.skip("classify", "aucun hôte")

    brain: dict = {}
    try:
        from guardia.cerveau import ecrire_checkpoint, lire_checkpoint, raisonner

        ck = None
        if getattr(args, "reprendre", False):
            ck_path = RAPPORTS / "checkpoint-dernier.json"
            ck = lire_checkpoint(ck_path) or None
            if ck:
                journal.note("Reprise du checkpoint — nœuds déjà joués sautés")
        brain = raisonner(
            mission,
            hosts=hosts,
            plan=plan,
            equipe=getattr(args, "equipe", None) or (mission.extras or {}).get("equipe") or "blue",
            temps=float(max_time),
            checkpoint=ck,
            journal=journal,
        )
        print(f"── Cerveau : {brain.get('synthese')} ──", flush=True)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"cerveau: {exc}")
        log.warning("cerveau: %s", exc)
        journal.skip("Cerveau adaptatif", str(exc))
        brain = {}

    with budget.phase("rules", must_run=True, kind="post"):
        if hosts:
            try:
                errors.extend(apply_rules(hosts, mission, gateway=gw))
                journal.outil("rules hygiène", "", "ok")
            except Exception as exc:  # noqa: BLE001
                errors.append(f"rules: {exc}")
                journal.skip("rules hygiène", str(exc))
        elif lan:
            journal.skip("rules hygiène", "aucun hôte")

    website_result: dict = {}
    cve_result: dict = {}
    rgpd_result: dict = {}
    restructure_result: dict = {}
    machines_result: dict = {}
    usages_result: dict = {}
    direction_result: dict = {}
    burp_result: dict = {}

    if plan.get("machines") and hosts:
        ev_types = {str(e.get("type") or "") for e in (brain.get("evenements") or [])}
        if "ot_seen" not in ev_types:
            journal.skip("Machines / OT", "précondition absente : aucun port OT observé")
            plan["machines"] = False
        else:
            with budget.phase("machines"):
                if "machines" in budget.skipped:
                    journal.skip("Machines / OT", "budget")
                else:
                    try:
                        from guardia.engines.machines import run_machines

                        print("── Machines / OT (sur demande) ──")
                        journal.phase("Machines / OT")
                        machines_result = run_machines(
                            hosts, mission, remaining_sec=budget.remaining()
                        )
                        errors.extend(machines_result.get("warns") or [])
                        extra_f = machines_result.get("findings") or []
                        if extra_f and hosts:
                            anchor = next(
                                (h for h in hosts if h.kind == "ot"),
                                hosts[0],
                            )
                            for f in extra_f:
                                if not f.hote or f.hote == "parc":
                                    f.hote = anchor.ip
                                if f.hote == anchor.ip:
                                    anchor.findings.append(f)
                                else:
                                    tgt = next((h for h in hosts if h.ip == f.hote), anchor)
                                    tgt.findings.append(f)
                        print(
                            f"Machines : {machines_result.get('hotes_ot', 0)} hôte(s) OT, "
                            f"{len(extra_f)} finding(s) — Ethernet industriel, lecture seule"
                        )
                        journal.outil(
                            "lecture Ethernet industriel",
                            f"{machines_result.get('hotes_ot', 0)} OT",
                            "ok",
                        )
                    except Exception as exc:  # noqa: BLE001
                        errors.append(f"machines: {exc}")
                        log.warning("machines: %s", exc)
                        journal.skip("Machines / OT", str(exc))
    elif plan.get("machines"):
        journal.skip("Machines / OT", "aucun hôte")
    else:
        journal.skip("Machines / OT", "plan éteint")

    # Passage audit poussé (après run classique) — --audit / --audit-full / YAML
    if want_audit and hosts:
        with budget.phase("audit"):
            if "audit" in budget.skipped:
                journal.skip("Audit", "budget")
            else:
                try:
                    from guardia.engines.audit_pass import run_audit_pass
                    from guardia.engines.audit_catalog import catalog_for_level
                    from guardia.rules.audit import apply_audit_rules

                    cat = catalog_for_level(audit_level)
                    print(f"── Audit warning [{audit_level}] — {len(cat)} capacités catalogue ──")
                    journal.phase(f"Audit {audit_level}")
                    print(f"   Niveau catalogue : {audit_level} (standard|full)")
                    audited, aw = run_audit_pass(
                        hosts,
                        remaining_sec=budget.remaining(),
                        level=audit_level,
                    )
                    errors.extend(aw)
                    if audited:
                        errors.extend(apply_audit_rules(audited, mission))
                        n_af = sum(1 for h in audited for f in h.findings if f.id.startswith("audit-"))
                        print(
                            f"Audit [{audit_level}] : {len(audited)} hôte(s) approfondi(s), "
                            f"{n_af} finding(s) audit-* (expositions + remèdes)"
                        )
                        journal.outil(f"audit {audit_level}", f"{len(audited)} hôte(s)", "ok")
                    else:
                        journal.skip("Audit", "aucun hôte flagué")
                    mission.extras["audit_done"] = True
                    mission.extras["audit_level"] = audit_level
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"audit: {exc}")
                    log.warning("audit: %s", exc)
                    journal.skip("Audit", str(exc))
    elif want_audit:
        journal.skip("Audit", "aucun hôte")
    else:
        journal.skip("Audit", "plan éteint")

    # Corrélation CVE (catalogue local) — après classify/services/rules/audit
    cve_result: dict = {}
    try:
        from guardia.engines.cve_correlate import correlate_hosts, want_cve as _want_cve

        do_cve = _want_cve(args, mission) or bool(plan.get("cve"))
        # Full / audit-full : lecture max → CVE ON sauf --no-cve
        if getattr(args, "no_cve", False):
            do_cve = False
        elif (
            getattr(args, "full", False)
            or getattr(args, "audit_full", False)
            or (mission.profondeur or "") == "full"
            or mission.extras.get("audit_full")
            or mission.extras.get("parc_inconnu")
        ):
            do_cve = True if not getattr(args, "no_cve", False) else False
        if do_cve and hosts:
            with budget.phase("cve", must_run=False, kind="post"):
                if "cve" in budget.skipped:
                    journal.skip("Corrélation CVE", "budget")
                else:
                    print("── Corrélation CVE (catalogue local, lecture) ──")
                    journal.phase("Corrélation CVE (lecture)")
                    cve_result = correlate_hosts(hosts, mission)
                    n_c = int(cve_result.get("n_findings") or 0)
                    print(
                        f"CVE lecture : {n_c} finding(s) — "
                        f"{cve_result.get('catalogue_entries', 0)} entrée(s) catalogue — "
                        "aucune exploitation"
                    )
                    journal.outil("cve_correlate", f"{n_c} finding(s)", "ok")
                    mission.extras["cve_done"] = True
        elif do_cve:
            journal.skip("Corrélation CVE", "aucun hôte")
        else:
            journal.skip("Corrélation CVE", "plan éteint (--no-cve ou cve: false)")
    except Exception as exc:  # noqa: BLE001
        errors.append(f"cve: {exc}")
        log.warning("cve: %s", exc)
        journal.skip("Corrélation CVE", str(exc))
        cve_result = {}

    if plan.get("site_url"):
        with budget.phase("web"):
            if "web" in budget.skipped:
                errors.append("budget: audit site sauté")
                journal.skip("Site web", "budget")
            else:
                try:
                    from guardia.engines.web_audit import audit_website

                    print(f"── Site web : {plan['site_url']} ──")
                    journal.phase("Site web")
                    to = int(budget.cap(120 if profond else 45, minimum=12))
                    website_result = audit_website(
                        str(plan["site_url"]), mission, timeout=max(8, to)
                    )
                    n_wf = len(website_result.get("findings") or [])
                    print(
                        f"Site : {website_result.get('url')} — {n_wf} finding(s) "
                        f"{'(injoignable)' if not website_result.get('ok') else ''}"
                    )
                    journal.outil("curl/TLS", str(plan["site_url"]), "ok" if website_result.get("ok") else "note")
                    if website_result.get("notes"):
                        errors.extend(str(x) for x in website_result["notes"])
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"web: {exc}")
                    log.warning("web: %s", exc)
                    journal.skip("Site web", str(exc))
    else:
        journal.skip("Site web", "plan éteint")

    burp_result: dict = {}

    programme_result: dict = {}
    with budget.phase("programme", must_run=True, kind="post"):
        try:
            from guardia.engines.programme import (
                build_programme,
                ecrire_programme,
                run_lecture_ciblee,
            )

            lecture: list = []
            site_url = plan.get("site_url")
            if site_url:
                print("── Lecture URL ──")
                journal.phase("Lecture URL")
                to = int(budget.cap(90 if profond else 30, minimum=8))
                lecture = run_lecture_ciblee(
                    str(site_url), timeout=max(8, to), profond=profond
                )
            if website_result is not None:
                website_result["domaine"] = [
                    r for r in lecture if r.get("id") in ("whois", "dig", "host")
                ]
            programme_result = build_programme(
                mission,
                cidr=cidr,
                url=site_url,
                args=args,
                lecture=lecture,
            )
            path = ecrire_programme(programme_result)
            programme_result["path"] = str(path)
            n_ok = sum(1 for o in programme_result.get("outils") or [] if o.get("autorise"))
            print(f"── Outils de la visite : {path} — {n_ok} passif(s) ──")
            journal.outil("programme", "", "ok")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"programme: {exc}")
            log.warning("programme: %s", exc)

    if plan.get("restructure"):
        with budget.phase("restructure", must_run=True, kind="post"):
            try:
                from guardia.engines.restructure import build_restructure

                restructure_result = build_restructure(hosts, mission, gateway=gw)
                n_ch = len(restructure_result.get("chantiers") or [])
                print(f"── Restructuration parc : {n_ch} chantier(s) ──")
                journal.outil("restructure", f"{n_ch} chantier(s)", "ok")
            except Exception as exc:  # noqa: BLE001
                errors.append(f"restructure: {exc}")
                log.warning("restructure: %s", exc)
                journal.skip("Restructuration", str(exc))
    else:
        journal.skip("Restructuration", "plan éteint")

    if plan.get("rgpd"):
        with budget.phase("rgpd", must_run=True, kind="post"):
            try:
                from guardia.engines.rgpd_signal import build_rgpd_signalement

                rgpd_result = build_rgpd_signalement(mission, website=website_result)
                c = rgpd_result.get("compteurs") or {}
                journal.phase("Signalement RGPD")
                journal.outil(
                    "fiche RGPD",
                    f"signalés={c.get('signales', 0)} déclarés={c.get('declares', 0)}",
                    "ok",
                )
                print("── Signalement RGPD (sur demande, pas un certificat) — "
                    f"signalés={c.get('signales', 0)} "
                    f"déclarés={c.get('declares', 0)} "
                    f"à confirmer={c.get('a_confirmer', 0)} ──"
                )
                if rgpd_result.get("fiche_vide"):
                    print(
                        "   Fiche vide : python3 -m guardia rgpd -m <mission.yaml> "
                        "ou UI « Configurer RGPD »"
                    )
            except Exception as exc:  # noqa: BLE001
                errors.append(f"rgpd: {exc}")
                log.warning("rgpd: %s", exc)
                journal.skip("Signalement RGPD", str(exc))
    else:
        journal.skip("Signalement RGPD", "plan éteint")

    usages_pass_done = False
    usages_pass_warns: list[str] = []
    if plan.get("usages") and hosts:
        with budget.phase("usages_pass"):
            if "usages_pass" not in budget.skipped:
                try:
                    from guardia.engines.usages_pass import run_usages_pass

                    _ut, uw = run_usages_pass(
                        hosts, remaining_sec=budget.remaining()
                    )
                    usages_pass_warns.extend(uw)
                    errors.extend(uw)
                    usages_pass_done = True
                    print(f"── Usages : observation des portes ({len(_ut)} hôte(s)) ──")
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"usages_pass: {exc}")
                    log.warning("usages_pass: %s", exc)

    calibrage_result: dict = {}
    if plan.get("calibrage") and hosts:
        with budget.phase("calibrage"):
            if "calibrage" not in budget.skipped:
                try:
                    from guardia.engines.calibrage import run_calibrage

                    print("── Calibrage Kali (ports vus → outils passifs) ──")
                    journal.phase("Calibrage Kali")
                    calibrage_result = run_calibrage(
                        hosts,
                        cidr=cidr,
                        iface=iface,
                        site_url=str(plan.get("site_url") or ""),
                        timeout_total=budget.cap(180, minimum=20),
                        on_job=brancher_calibrage(journal),
                        verbose=False,
                        skip_ids=list(brain.get("skip_sondes") or []),
                    )
                    print(
                        f"   {calibrage_result.get('n_lances', 0)} sonde(s) · "
                        f"{calibrage_result.get('n_findings', 0)} observation(s)"
                    )
                    absents = calibrage_result.get("absents") or []
                    if absents:
                        print("   Non installés : " + ", ".join(absents[:8]))
                except Exception as exc:  # noqa: BLE001
                    errors.append(f"calibrage: {exc}")
                    log.warning("calibrage: %s", exc)
                    journal.skip("Calibrage Kali", str(exc))
            else:
                journal.skip("Calibrage Kali", "budget")
    elif plan.get("calibrage"):
        journal.skip("Calibrage Kali", "aucun hôte")
    else:
        journal.skip("Calibrage Kali", "plan éteint")

    if plan.get("usages"):
        with budget.phase("usages", must_run=True, kind="post"):
            try:
                from guardia.engines.usages import build_usages

                usages_result = build_usages(
                    mission,
                    hosts,
                    pass_done=usages_pass_done,
                    pass_warns=usages_pass_warns,
                )
                extra_uf = usages_result.get("findings") or []
                if extra_uf and hosts:
                    by_ip = {h.ip: h for h in hosts}
                    for f in extra_uf:
                        tgt = by_ip.get(f.hote) or hosts[0]
                        if f not in tgt.findings:
                            tgt.findings.append(f)
                c = usages_result.get("compteurs") or {}
                print(
                    "── Usages & droits (pas un dump, pas un certificat) — "
                    f"signalés={c.get('signales', 0)} "
                    f"desserte={c.get('serveurs', 0)} "
                    f"à confirmer={c.get('a_confirmer', 0)} ──"
                )
                journal.outil("usages & droits", "", "ok")
                if usages_result.get("fiche_vide"):
                    print(
                        "   Fiche vide : python3 -m guardia usages -m <mission.yaml> "
                        "ou UI « Configurer usages »"
                    )
            except Exception as exc:  # noqa: BLE001
                errors.append(f"usages: {exc}")
                log.warning("usages: %s", exc)
                journal.skip("Usages & droits", str(exc))
    else:
        journal.skip("Usages & droits", "plan éteint")

    try:
        from guardia.engines.preuve_repro import attach_repro

        vouvoiement = (mission.ton_rapport or "tutoiement") == "vouvoiement"
        # Rapport client : toujours formuler la démo en vouvoiement si demandé
        attach_repro(hosts, vouvoiement=vouvoiement or bool((mission.extras or {}).get("passi")))
    except Exception as exc:  # noqa: BLE001
        log.warning("preuve_repro: %s", exc)

    try:
        from guardia.cerveau import ecrire_checkpoint, raisonner as _raisonner

        from guardia.core.equipe import normaliser as _norm_eq

        eq = _norm_eq(
            getattr(args, "equipe", None) or (mission.extras or {}).get("equipe") or "blue"
        )
        brain = _raisonner(
            mission,
            hosts=hosts,
            plan=plan,
            equipe=eq,
            autorisations=None,
            temps=float(max_time),
            checkpoint=brain.get("nodes_done") and {"nodes_done": brain.get("nodes_done")},
        )
        ecrire_checkpoint(brain, RAPPORTS / "checkpoint-dernier.json")
    except Exception as exc:  # noqa: BLE001
        log.warning("cerveau (preuves): %s", exc)

    # Notes arrêt opérateur → erreurs / timings
    op = get_operator()
    for ev in op.events:
        errors.append(ev.note)
        print(f"⚠ Rapport : {ev.note}")
    timing_info = budget.summary()
    timing_info.update(op.summary())
    if timing_info.get("budget_hit"):
        errors.append(
            "budget temps atteint — certaines phases ont été tronquées ou sautées "
            f"(timings: {timing_info.get('timings')})"
        )
        print("⚠ Budget 1 h (ou --max-time) atteint : rapport partiel, suite des phases légères.")

    finished = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    result = CheckupResult(
        mission=mission,
        hosts=hosts,
        errors=errors,
        started=started,
        finished=finished,
        cidr=cidr,
        gateway=gw,
        iface=iface,
        timings=timing_info,
        website=website_result,
        rgpd=rgpd_result,
        restructure=restructure_result,
        machines=machines_result,
        usages=usages_result,
        plan=plan,
        burp=burp_result,
        programme=programme_result,
        calibrage=calibrage_result,
        equipe="blue",
        autorisation=auth,
        adaptatif=brain,
        poste_operateur=poste_operateur,
        orchestre={
            "prevu": plan.get("orchestre_prevu") or [],
            "calibrage_lances": (calibrage_result or {}).get("n_lances") or 0,
            "calibrage_absents": (calibrage_result or {}).get("absents") or [],
            "lecture": (programme_result or {}).get("lecture") or [],
            **journal.as_dict(),
        },
    )
    try:
        from guardia.core.equipe import resoudre_equipe

        result.equipe = resoudre_equipe(args, mission)
        plan["equipe"] = result.equipe
        result.plan = plan
        if auth.get("modules_limites") and result.equipe == "red":
            print("Red regard refusé : mandat non coché — attestation opérateur seulement")
            result.equipe = "blue"
            plan["equipe"] = "blue"
            result.plan = plan
            result.regard = {}
            result.identites = {}
        from guardia.core.dossier import etat as _etat_d, peut_red_regard, peut_red_test
        from guardia.core.parc import parc_de

        result.parc = parc_de(mission)
        result.dossier = _etat_d(mission)
        if result.equipe == "red":
            ok, why = peut_red_regard(mission)
            if not ok:
                print(f"Red regard refusé : {why} — on reste blue")
                result.equipe = "blue"
                result.regard = {}
                result.identites = {}
            else:
                from guardia.engines.regard import build_regard
                from guardia.engines.identites import build_identites

                result.regard = build_regard(result)
                result.identites = build_identites(result)
                n_ch = len(result.regard.get("chemins") or [])
                print(f"Regard attaquant : {n_ch} chemin(s) — lecture seule, pas d'intrusion")
                journal.outil("regard attaquant", f"{n_ch} chemin(s)", "ok")
            _ok2, why2 = peut_red_test(mission)
            print(why2)
        else:
            result.regard = {}
            result.identites = {}
            print(f"Équipe : blue team · parc {result.parc}")
        try:
            from guardia.engines.hygiene import build_hygiene

            result.hygiene = build_hygiene(result)
            journal.outil("hygiène ANSSI", "", "ok")
        except Exception as hexc:  # noqa: BLE001
            result.hygiene = {}
            errors.append(f"hygiene: {hexc}")
        if want_autorisations(args, mission) or plan.get("autorisations"):
            journal.phase("Autorisations (red)")
            from guardia.engines.autorisations import build_autorisations

            result.autorisations = build_autorisations(
                mission, generer_liasse=True, pour_passi=bool(want_passi(args, mission) or plan.get("passi"))
            )
            for p in (result.autorisations.get("pieces") or []) + (result.autorisations.get("extra") or []):
                et = p.get("etat")
                titre = str(p.get("titre") or p.get("id") or "pièce")
                if et == "ok":
                    journal.outil(titre, "liasse", "ok")
                elif et == "facultatif":
                    journal.skip(titre, "facultatif")
                else:
                    journal.skip(titre, "manque")
            print(result.autorisations.get("note") or "Autorisations", flush=True)
        else:
            journal.skip("Autorisations (red)", "plan éteint")
            result.autorisations = {}
        if want_passi(args, mission) or plan.get("passi"):
            journal.phase("Offre PASSI")
            if result.equipe != "red":
                journal.skip("Offre PASSI", "red team requis")
                result.passi = {
                    "orchestre": True,
                    "passi_qualifie": False,
                    "presentable": False,
                    "statut": "éteint — red team requis",
                }
            else:
                from guardia.engines.passi import orchestrer

                result.passi = orchestrer(
                    mission,
                    autorisations=result.autorisations,
                    equipe=result.equipe,
                    journal=journal,
                    hosts=hosts,
                )
                from guardia.engines.passi_alignment import build_alignment
                from guardia.engines.passi_assessment import build_assessment

                result.passi_alignment = build_alignment(mission, result)
                ex = mission.extras or {}
                result.passi_assessment = build_assessment(
                    mission,
                    {
                        "equipe": result.equipe,
                        "autorisations": result.autorisations,
                        "journal": result.journal,
                        "hosts": result.hosts,
                        "lynis": result.lynis,
                        "greenbone": result.greenbone,
                        "correlation": result.correlation,
                        "findings": [f.to_dict() for h in result.hosts for f in h.findings],
                        "evidence_data": {
                            "architecture_docs": ex.get("architecture_docs") or {},
                            "config": ex.get("config") or {},
                            "code": ex.get("code") or {},
                            "code_scope": ex.get("code_scope"),
                            "code_evidence": ex.get("code_evidence"),
                            "pentest": ex.get("pentest") or {},
                            "org": ex.get("org") or {},
                            "review": ex.get("review") or {},
                            "evidence": ex.get("evidence") or {},
                            "methodology": ex.get("methodology") or ex.get("framing"),
                            "sampling": ex.get("sampling") or (ex.get("framing") or {}).get("sampling"),
                            "prerequisites": ex.get("prerequisites"),
                            "opening_meeting": ex.get("opening_meeting"),
                            "change_log": ex.get("change_log"),
                            "closure_check": ex.get("closure_check"),
                        },
                        "reviews": ex.get("reviews") or {},
                    },
                )
                print(
                    f"Offre PASSI : {result.passi.get('statut')} — pas un certificat",
                    flush=True,
                )
        else:
            journal.skip("Offre PASSI", "plan éteint")
            result.passi = {}
            result.passi_alignment = {}
            result.passi_assessment = {}
    except Exception as exc:  # noqa: BLE001
        errors.append(f"equipe: {exc}")
        log.warning("equipe: %s", exc)
        result.equipe = "blue"
        result.regard = {}
        result.identites = {}
    try:
        from guardia.core.identite import identite_dict as _idict

        result.identite = _idict(mission)
    except Exception:
        result.identite = {}
    try:
        from guardia.report.direction import build_direction_brief

        result.direction = build_direction_brief(result)
    except Exception as exc:  # noqa: BLE001
        errors.append(f"direction: {exc}")
        log.warning("direction: %s", exc)

    if plan.get("pistes"):
        try:
            from guardia.engines.pistes import build_pistes

            result.pistes = build_pistes(result)
            n_pi = len((result.pistes or {}).get("items") or [])
            print(f"Pistes : {n_pi} famille(s) — catalogue, pas des findings")
            journal.outil("pistes", f"{n_pi} famille(s)", "ok")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"pistes: {exc}")
            log.warning("pistes: %s", exc)
            journal.skip("Pistes", str(exc))
    else:
        journal.skip("Pistes", "plan éteint")

    if want_llm(args, mission):
        from guardia.engines.llm_polish import polish_result

        log.info("polish LLM demandé (hors budget scan)")
        try:
            with budget.phase("llm", kind="post"):
                llm_warns = polish_result(
                    result,
                    model_path=getattr(args, "llm_model", None),
                    server_bin=getattr(args, "llm_server", None),
                    base_url=getattr(args, "llm_url", None) or "http://127.0.0.1:2443",
                    ngl=int(getattr(args, "ngl", 99) or 99),
                    allow_cpu=bool(getattr(args, "cpu_llm", False)),
                )
            errors.extend(llm_warns)
            journal.outil("llm polish", "", "ok")
        except Exception as exc:  # noqa: BLE001
            errors.append(f"llm: {exc} — rapport sans polish")
            log.warning("llm: %s", exc)
            journal.skip("LLM (hors scan)", str(exc))
        result.errors = list(errors)
        result.finished = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
        result.timings = budget.summary()
    else:
        journal.skip("LLM (hors scan)", "plan éteint")

    slug = "".join(c if c.isalnum() else "-" for c in mission.client.lower())[:30].strip("-") or "run"
    html_path = RAPPORTS / f"{stamp}-{slug}.html"
    json_path = RAPPORTS / f"{stamp}-{slug}.json"
    result.timings = budget.summary()
    result.autorisation = auth
    try:
        from guardia.engines.correlation import build_correlation

        result.correlation = build_correlation(result)
        journal.outil("corrélation", "", "ok")
    except Exception as exc:  # noqa: BLE001
        result.correlation = {}
        errors.append(f"correlation: {exc}")
    try:
        result.cve_correlation = cve_result if isinstance(cve_result, dict) else {}
        if result.cve_correlation.get("n_findings"):
            journal.outil(
                "corrélation CVE",
                f"{result.cve_correlation.get('n_findings')} finding(s)",
                "ok",
            )
        # Vision OSI large (full / audit-full)
        mode_full = bool(
            getattr(args, "full", False)
            or getattr(args, "audit_full", False)
            or (mission.profondeur or "") == "full"
            or mission.extras.get("audit_full")
            or mission.extras.get("parc_inconnu")
        )
        if mode_full or result.cve_correlation:
            from guardia.engines.osi_map import vision_osi_full, attach_host_osi

            attach_host_osi(hosts, iface=iface, gateway=gw, cidr=cidr)
            vision = vision_osi_full(
                hosts,
                iface=iface,
                gateway=gw,
                cidr=cidr,
                website=result.website,
                rgpd=result.rgpd,
                cve_correlation=result.cve_correlation,
                events=(result.adaptatif or {}).get("evenements") or [],
                mode_full=mode_full,
            )
            result.cve_correlation = dict(result.cve_correlation or {})
            result.cve_correlation["vision_osi"] = vision
            # Merge into adaptatif couverture if present
            if isinstance(result.adaptatif, dict):
                result.adaptatif = dict(result.adaptatif)
                result.adaptatif["couverture_osi"] = vision.get("couverture") or result.adaptatif.get("couverture_osi")
                result.adaptatif["vision_osi_full"] = vision
    except Exception as exc:  # noqa: BLE001
        errors.append(f"cve_correlation/vision_osi: {exc}")
        log.warning("cve_correlation/vision_osi: %s", exc)
    try:
        from guardia.engines import lynis as lynis_mod, greenbone as gvm_mod, trivy as trivy_mod

        if want_greenbone(args, mission) or getattr(args, "greenbone", False):
            journal.phase("Greenbone / GVM")
            result.greenbone = gvm_mod.run(cidr=cidr)
            etat_g = result.greenbone.get("etat") or "note"
            if result.greenbone.get("lance"):
                journal.outil("gvm-cli get_version", "", "ok")
            else:
                journal.skip("gvm-cli", result.greenbone.get("note") or etat_g)
            print(
                f"Greenbone : {etat_g} — "
                f"{'lecture GMP' if result.greenbone.get('lance') else result.greenbone.get('install')}"
            )
        else:
            result.greenbone = gvm_mod.etat()
            journal.skip("Greenbone / GVM", "plan éteint")

        if want_lynis(args, mission) or getattr(args, "lynis", False):
            journal.phase("Lynis opérateur")
            result.lynis = lynis_mod.run_operateur()
            if result.lynis.get("lance"):
                journal.outil("lynis audit system --quick", "poste opérateur", "ok")
                print("  lynis audit system --quick: ok")
            else:
                journal.skip("lynis", result.lynis.get("install") or "absent")
                print(f"  lynis: {result.lynis.get('etat') or 'absent'} — on continue")
        else:
            result.lynis = lynis_mod.etat()
            journal.skip("Lynis", "plan éteint")

        if want_trivy(args, mission) or getattr(args, "trivy", False):
            journal.phase("Trivy opérateur")
            result.trivy = trivy_mod.run_operateur()
            if result.trivy.get("lance"):
                journal.outil("trivy fs", "poste opérateur", "ok")
                print("  trivy fs: ok")
            else:
                journal.skip("trivy", result.trivy.get("install") or "absent")
                print(f"  trivy: {result.trivy.get('etat') or 'absent'} — on continue")
        else:
            result.trivy = trivy_mod.etat()
            journal.skip("Trivy", "plan éteint")
        result.orchestre = {
            "prevu": plan.get("orchestre_prevu") or [],
            "calibrage_lances": (calibrage_result or {}).get("n_lances") or 0,
            "calibrage_absents": (calibrage_result or {}).get("absents") or [],
            "lecture": (programme_result or {}).get("lecture") or [],
            **journal.as_dict(),
        }
    except Exception as exc:  # noqa: BLE001
        errors.append(f"lynis/gvm/trivy: {exc}")
        journal.skip("lynis/gvm/trivy", str(exc))

    pdf_path = None
    if getattr(args, "pdf", False):
        journal.note("PDF : après le HTML")
    else:
        journal.skip("PDF (hors scan)", "plan éteint")

    journal.couvrir(plan)
    result.orchestre = {
        "prevu": plan.get("orchestre_prevu") or [],
        "calibrage_lances": (calibrage_result or {}).get("n_lances") or 0,
        "calibrage_absents": (calibrage_result or {}).get("absents") or [],
        "lecture": (programme_result or {}).get("lecture") or [],
        **journal.as_dict(),
    }
    try:
        with budget.phase("rapport", kind="post"):
            render(result, html_path)
            journal.outil("rapport HTML", html_path.name, "ok")
    except Exception as exc:  # noqa: BLE001
        errors.append(f"rapport: {exc}")
        log.exception("rapport")
        journal.skip("rapport HTML", str(exc))

    if getattr(args, "pdf", False):
        from guardia.report.pdf_report import html_to_pdf
        pdf_out = RAPPORTS / f"{stamp}-{slug}.pdf"
        pdf_path, pdf_err = html_to_pdf(html_path, pdf_out)
        if pdf_err:
            errors.append(pdf_err)
            journal.skip("PDF (hors scan)", pdf_err)
        elif pdf_path:
            journal.outil("pdf", pdf_path.name, "ok")
        result.orchestre = {
            **(result.orchestre or {}),
            **journal.as_dict(),
        }

    try:
        from guardia.report.json_report import dump_checkup

        ok_json, err_json = dump_checkup(result, json_path)
        if not ok_json:
            errors.append(f"json: {err_json}")
            log.warning("json: %s", err_json)
            json_path = None
    except Exception as exc:  # noqa: BLE001
        errors.append(f"json: {exc}")
        log.warning("json: %s", exc)
        json_path = None
        ok_json = False

    ap = " all-ports" if (getattr(args, "all_ports", False) or mission.extras.get("all_ports")) else ""
    print(f"Hôtes : {len(hosts)}  (profondeur={mission.profondeur}{ap})")
    for h in hosts:
        print(f"  [{h.posture.value}] {h.ip} {h.hostname or ''} ({h.kind}) findings={len(h.findings)}")
    print(f"Rapport HTML : {html_path}")
    ti = getattr(result, "timings", {}) or {}
    if ti:
        print(f"Timings : {ti.get('elapsed_sec')}s / plafond {ti.get('limit_sec')}s — {ti.get('timings')}")
    if json_path is not None:
        print(f"JSON         : {json_path}")
    else:
        print("JSON         : (échec — voir avertissements)")
    if getattr(args, "pdf", False):
        print(f"PDF          : {pdf_path if pdf_path else '(échec — voir avertissements)'}")
    if errors:
        print("Résumé erreurs / avertissements :")
        for e in errors:
            print(f"  - {e}")
    return 0 if not any("timeout" in e and "discover" in e for e in errors) else 0


def cmd_ui(args: argparse.Namespace) -> int:
    """Lance l'interface graphique Tk (ttk)."""
    from guardia.ui.app import check_display, run_app

    err = check_display()
    if err:
        print(err, file=sys.stderr)
        return 2
    return int(run_app())



def cmd_queen(args: argparse.Namespace) -> int:
    """Vérifie la connexion Groq / queen_decide (comme ``guardia llm`` pour le local)."""
    from guardia.engines.llm_groq_directives import ligne_queen, probe_queen

    st = probe_queen(timeout=float(getattr(args, "timeout", None) or 8.0))
    print(ligne_queen(st))
    if st.get("contrat"):
        print(st["contrat"])
    print("Fichier      : {p}".format(p=st.get("queen_decide") or "(inconnu)"))
    print("Org          : {o}".format(o=st.get("org") or ""))
    print("Modèle       : {m}".format(m=st.get("model") or ""))
    print("API          : {b}".format(b=st.get("base") or ""))
    sample = st.get("models_sample") or []
    if sample:
        print("Modèles API  : " + ", ".join(sample[:8]))
    if getattr(args, "json", False):
        import json as _json

        safe = {k: v for k, v in st.items() if k != "key"}
        print(_json.dumps(safe, ensure_ascii=False, indent=2))
    return 0 if st.get("ok") else 2


def cmd_llm(args: argparse.Namespace) -> int:
    """Vérifie qu'une capacité d'explication est ouverte (llama-server ou garde)."""
    from guardia.engines.llm_gate import dump_status, exiger, ligne, ressources
    from guardia.engines.llm_bootstrap import GUARDIA_GGUF_URL, default_gguf_path, gguf_url

    # exiger(start=True) déclenche llm_bootstrap si GGUF absent (TTY).
    st = exiger(url=getattr(args, "url", None) or None, start=True)
    print(ligne(st))
    print(st.get("contrat") or "")
    res = ressources()
    print("GGUF         : {m}".format(m=res.get("model") or "(absent)"))
    if not res.get("model"):
        print("Défaut       : {p}".format(p=default_gguf_path()))
        print("URL catalogue: {u}".format(u=gguf_url() or GUARDIA_GGUF_URL))
        note = __import__("os").environ.get("GUARDIA_LLM_NOTE") or ""
        if note:
            print("Note         : {n}".format(n=note))
    print("llama-server : {s}".format(s=res.get("server") or "(absent)"))
    print("URL          : {u}".format(u=st.get("url") or "(aucune)"))
    probed = st.get("probed") or []
    if probed:
        print("Sondé        : " + ", ".join(probed))
    dirs = st.get("search_dirs") or res.get("search_dirs") or []
    if dirs and not res.get("model"):
        print("Dossiers     :")
        for d in dirs[:10]:
            print("  - " + d)
        print("Force        : export GUARDIA_LLM_MODEL=/chemin/vers/modele.gguf")
    if getattr(args, "json", False):
        print(dump_status(st))
    return 0 if st.get("ok") else 2


def cmd_lab(args: argparse.Namespace) -> int:
    """Labs adaptatifs — aucun paquet réseau. Observe comment le cerveau réagit."""
    from guardia.labs.runner import jouer, jouer_tous
    from guardia.labs.scenarios import SCENARIOS

    wanted = getattr(args, "id", None)
    if wanted:
        factory = None
        for f in SCENARIOS:
            sc = f()
            if sc.get("id") == wanted:
                factory = sc
                break
        if factory is None:
            print("lab inconnu : {w}".format(w=wanted), file=sys.stderr)
            print("disponibles : " + ", ".join(f().get("id") for f in SCENARIOS), file=sys.stderr)
            return 2
        bundle = {"labs": [jouer(factory)], "n": 1, "ok": 0, "ko": 0}
        bundle["ok"] = 1 if bundle["labs"][0]["ok"] else 0
        bundle["ko"] = 1 - bundle["ok"]
    else:
        bundle = jouer_tous()
    for r in bundle["labs"]:
        mark = "OK" if r["ok"] else "KO"
        print("[{m}] {i} — {t}".format(m=mark, i=r["id"], t=r["titre"]))
        print("      {s}".format(s=r.get("synthese") or ""))
        for c in r.get("checks") or []:
            if not c["ok"]:
                print("      manque : {n} ({d})".format(n=c["nom"], d=c["detail"]))
        if r.get("passi_summary"):
            s = r["passi_summary"]
            print(
                "      PASSI : {v} vérifié(s) · {p} en attente · {c} chaînes".format(
                    v=s.get("verified"), p=s.get("pending_human"), c=r.get("chaines_alimentees")
                )
            )
    print("{ok}/{n} labs".format(ok=bundle["ok"], n=bundle["n"]))
    return 0 if bundle["ko"] == 0 else 1



def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(
        prog="guardia",
        description="Guardia — évaluation défensive LAN (Platon-Y / Echoes of Hackers)",
    )
    p.add_argument("--verbose", "-v", action="store_true", help="logs détaillés")
    sub = p.add_subparsers(dest="cmd")

    sp = sub.add_parser("about", help="version et signature")
    sp.set_defaults(func=cmd_about)

    sp = sub.add_parser("version", help="alias de about")
    sp.set_defaults(func=cmd_about)

    sp = sub.add_parser(
        "identite",
        help="opérateur identifié : qui nous sommes, User-Agent, paraphe opérateur",
    )
    sp.add_argument("--mission", "-m", help="fichier mission.yaml (paraphe opérateur)")
    sp.set_defaults(func=cmd_identite)

    sp = sub.add_parser(
        "dossier",
        help="liasse d'audit (8 pièces, hashes). Le Red est un contrat, pas un bouton",
    )
    sp.add_argument("--mission", "-m", required=True, help="fichier mission.yaml")
    sp.add_argument("--generer", action="store_true", help="écrire les pièces + MANIFEST.sha256")
    sp.set_defaults(func=cmd_dossier)

    sp = sub.add_parser(
        "passi",
        help="offre de service inspirée PASSI + pack autorisations (pas une qualification)",
    )
    sp.add_argument("--mission", "-m", help="fichier mission.yaml")
    sp.add_argument("--generer", action="store_true", help="écrire la liasse autorisations")
    sp.add_argument("--markdown", action="store_true", help="afficher le dossier de contrôles en Markdown")
    sp.add_argument("--export", metavar="DIR", help="exporter le dossier PASSI JSON/Markdown + manifest")
    sp.set_defaults(func=cmd_passi)

    sp = sub.add_parser(
        "cerveau",
        help="DAG adaptatif : observer → décider → tester (pas un simulateur PASSI)",
    )
    sp.add_argument("--mission", "-m", help="fichier mission.yaml")
    sp.add_argument(
        "--llm-groq",
        action="store_true",
        help="Groq optionnel pour directives (GROQ_API_KEY env ; lecture seule ; à valider)",
    )
    sp.set_defaults(func=cmd_cerveau)

    sp = sub.add_parser("wizard", help="questionnaire → mission.yaml")
    sp.set_defaults(func=cmd_wizard)

    sp = sub.add_parser(
        "rgpd",
        help="configurer la fiche RGPD d'une mission (signalement, pas un certificat)",
    )
    sp.add_argument("--mission", "-m", required=True, help="fichier mission.yaml")
    sp.add_argument("--show", action="store_true", help="affiche la fiche, n'édite pas")
    sp.add_argument("--edit", action="store_true", help="questionnaire sans demander confirmation")
    sp.set_defaults(func=cmd_rgpd)

    sp = sub.add_parser(
        "usages",
        help="configurer la fiche usages & droits (portes, pas un dump)",
    )
    sp.add_argument("--mission", "-m", required=True, help="fichier mission.yaml")
    sp.add_argument("--show", action="store_true", help="affiche la fiche, n'édite pas")
    sp.add_argument("--edit", action="store_true", help="questionnaire sans demander confirmation")
    sp.set_defaults(func=cmd_usages)

    sp = sub.add_parser("ui", help="interface graphique Tk (checkup / discover / wizard)")
    sp.set_defaults(func=cmd_ui)

    sp = sub.add_parser(
        "queen",
        help="vérifie la connexion Groq / queen_decide (comme llm pour le local)",
    )
    sp.add_argument("--json", action="store_true", help="statut JSON (sans clé)")
    sp.add_argument("--timeout", type=float, default=8.0, help="timeout API secondes")
    sp.set_defaults(func=cmd_queen)

    sp = sub.add_parser(
        "llm",
        help="vérifie l'ouverture du LLM (llama-server) ou active la garde locale",
    )
    sp.add_argument("--url", help="URL llama-server (défaut http://127.0.0.1:2443)")
    sp.add_argument("--json", action="store_true", help="dump JSON de l'état")
    sp.set_defaults(func=cmd_llm)

    sp = sub.add_parser(
        "lab",
        help="labs adaptatifs (hôtes synthétiques, zéro paquet) — observe les décisions",
    )
    sp.add_argument("--id", help="un scénario (https-only, smb-rdp, ot-modbus, …)")
    sp.set_defaults(func=cmd_lab)

    sp = sub.add_parser(
        "liens",
        help="checkup des liens (dossiers, lanceurs, Thunar, Firefox) — machine unique ÉOH",
    )
    sp.set_defaults(func=cmd_liens)

    sp = sub.add_parser(
        "firefox-neutre",
        help="installe le profil Firefox ESR neutre + raccourci Bureau (HTML / hub)",
    )
    sp.set_defaults(func=cmd_firefox_neutre)

    sp = sub.add_parser(
        "inventaire",
        help="liste les outils Kali présents (PATH) → rapports/inventaire-kali.txt",
    )
    sp.add_argument("--court", action="store_true", help="sans listing brut du PATH")
    sp.set_defaults(func=cmd_inventaire)

    sp = sub.add_parser(
        "programme",
        help="liste les outils passifs de la visite",
    )
    sp.add_argument("--mission", "-m", help="fichier mission.yaml")
    sp.add_argument("--url", help="URL du programme (sinon site_url)")
    sp.add_argument("--cidr", help="CIDR du programme (sinon mission)")
    sp.add_argument(
        "--burp",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    sp.add_argument(
        "--programme",
        action="store_true",
        help=argparse.SUPPRESS,
    )
    sp.set_defaults(func=cmd_programme)

    sp = sub.add_parser(
        "outil",
        help="liste les outils de lecture (nmap, testssl, smbclient…) + aide d'install",
    )
    sp.add_argument(
        "nom",
        nargs="?",
        default="list",
        help="id d'outil (nmap, testssl, smbclient, nuclei…) ou 'list'",
    )
    sp.add_argument("--mission", "-m", help="fichier mission.yaml")
    sp.add_argument("--url", help="URL du mandat")
    sp.add_argument("--open", action="store_true", help=argparse.SUPPRESS)
    sp.add_argument(
        "--run",
        action="store_true",
        help="lancer testssl / sslscan / whatweb sur l'URL du mandat",
    )
    sp.add_argument(
        "--yes",
        action="store_true",
        help="attestation opérateur si mandat non coché (labo seulement)",
    )
    sp.set_defaults(func=cmd_outil)

    sp = sub.add_parser("discover", help="découverte d'hôtes seule")
    sp.add_argument("--mission", "-m", help="fichier mission.yaml")
    sp.add_argument("--cidr", help="CIDR à scanner")
    sp.add_argument(
        "--yes",
        action="store_true",
        help="attestation opérateur si mandat non coché ET CIDR clairement local (RFC1918)",
    )
    sp.add_argument(
        "--full",
        action="store_true",
        help="parc inconnu : découverte plus patiente + empreinte top-200 (défensif)",
    )
    sp.set_defaults(func=cmd_discover)

    sp = sub.add_parser("run", help="checkup complet (si mandat OK)")
    sp.add_argument(
        "--mission",
        "-m",
        help="fichier mission.yaml (extras : all_ports/llm/pdf/max_time/parc_inconnu ; "
        "ex. missions/exemple-full.yaml)",
    )
    sp.add_argument("--cidr", help="CIDR (override mission / auto)")
    sp.add_argument(
        "--profile",
        choices=["maison", "pme", "ecole"],
        help="profil moteur (maison|pme|ecole — pas « full » ; pour full, "
        "charge missions/exemple-full.yaml ou passe --full/--all-ports/--llm/--pdf)",
    )
    sp.add_argument(
        "--yes",
        action="store_true",
        help="attestation opérateur si mandat non coché ET CIDR clairement local — "
        "documente que l'opérateur confirme l'autorisation écrite",
    )
    sp.add_argument(
        "--full",
        action="store_true",
        help="approfondit les actions cochées : LAN plus patient / site plus d'outils",
    )
    sp.add_argument(
        "--all-ports",
        action="store_true",
        dest="all_ports",
        help="empreinte TCP 1-65535 (nmap -p-) — très long ; pas activé par défaut même en --full",
    )
    sp.add_argument(
        "--llm",
        action="store_true",
        help="polish local des findings (CyberSec 3B / llama-server) — n'invente rien",
    )
    sp.add_argument("--llm-model", help="chemin GGUF (défaut: volume guardia-models/)")
    sp.add_argument(
        "--llm-groq",
        action="store_true",
        help="Interrogation Groq optionnelle pour directives + fiche (GROQ_API_KEY env ; jamais d'exploit ; proposition à valider). YAML : llm_groq: true",
    )
    sp.add_argument(
        "--llm-url",
        default="http://127.0.0.1:2443",
        help="URL llama-server (défaut http://127.0.0.1:2443)",
    )
    sp.add_argument("--llm-server", help="binaire llama-server (défaut: bot_y/moteur/)")
    sp.add_argument(
        "--ngl",
        type=int,
        default=99,
        help="couches GPU (défaut 99 ; 0=CPU seulement avec --cpu-llm ou sans GPU)",
    )
    sp.add_argument(
        "--cpu-llm",
        action="store_true",
        help="autorise le LLM en CPU même si une GPU NVIDIA est détectée",
    )
    sp.add_argument(
        "--max-time",
        type=int,
        default=None,
        metavar="SEC",
        help="plafond durée du SCAN en secondes (défaut 7200). LLM / HTML / JSON hors horloge.",
    )
    sp.add_argument(
        "--no-lan",
        action="store_true",
        dest="no_lan",
        help="ne pas scanner le parc (nmap). Pour un site / RGPD seul.",
    )
    sp.add_argument(
        "--lan",
        action="store_true",
        help="forcer le scan LAN (défaut : allumé sauf --no-lan / YAML lan: false)",
    )
    sp.add_argument(
        "--pdf",
        action="store_true",
        help="exporte aussi le rapport en PDF (weasyprint si installé)",
    )
    sp.add_argument(
        "--audit",
        action="store_true",
        help="après le run classique : passage audit poussé (hôtes flagués, "
        "ports admin + scripts info http-title/ssl-cert/smb-security-mode) — défensif",
    )
    sp.add_argument(
        "--audit-full",
        action="store_true",
        dest="audit_full",
        help="audit niveau full (implique --audit) : + http-headers, ssh-hostkey, "
        "ssl-enum-ciphers ; max 64 hôtes ; ports admin élargis — défensif, pas de vuln. "
        "YAML : audit_full: true ou audit: full. Mandat modeles/a-signer/mandat-audit-full",
    )
    from guardia.core.defaults import DEFAULT_SITE_URL

    sp.add_argument(
        "--site",
        nargs="?",
        const=DEFAULT_SITE_URL,
        default=None,
        metavar="URL",
        help="audit défensif du site web (URL du mandat). Sans URL : "
        f"{DEFAULT_SITE_URL} (prérempli lab). YAML : site_url",
    )
    sp.add_argument(
        "--equipe",
        choices=["blue", "red"],
        default="blue",
        help="blue = évaluation actuelle. red = regard attaquant (mot de passe, lecture seule)",
    )
    sp.add_argument(
        "--lynis",
        action="store_true",
        help="Lynis sur le poste opérateur ÉOH (pas un scan du client). "
        "Absent : on continue. YAML lynis: true.",
    )
    sp.add_argument(
        "--greenbone",
        action="store_true",
        help="Orchestrer Greenbone/GVM en lecture GMP (version, feeds). "
        "Pas un Full and Fast automatique. YAML greenbone: true. "
        "Absent / daemon muet : on continue.",
    )
    sp.add_argument(
        "--trivy",
        action="store_true",
        help="Trivy fs sur le poste opérateur (pas le LAN client). "
        "YAML trivy: true. Absent : on continue.",
    )
    sp.add_argument(
        "--passi",
        action="store_true",
        help="Mode PASSI (prestation d'audit). Distinct de --full. "
        "Pas une qualification ANSSI. YAML passi: true. "
        "Allume Lynis + Greenbone lecture. Jamais Metasploit/Burp/hydra.",
    )
    sp.add_argument(
        "--passi-activites",
        dest="passi_activites",
        help="Activités PASSI séparées par des virgules "
        "(organisationnel_physique,architecture,configuration,code_source,intrusion).",
    )
    sp.add_argument(
        "--autorisations",
        action="store_true",
        help="Pack autorisations red (huit pièces, jouées). "
        "Incomplet = offre en brouillon. YAML autorisations: true.",
    )
    sp.add_argument(
        "--red-pass",
        dest="red_pass",
        default="",
        help=argparse.SUPPRESS,
    )
    sp.add_argument(
        "--red-team",
        action="store_true",
        dest="red_team",
        help="Porte Red Team avancee (defensif). Exige --red-ok ou env GUARDIA_RED_OK, "
        "ou YAML red_team + red_actions_signed. Pas d'exploitation.",
    )
    sp.add_argument(
        "--red-ok",
        action="store_true",
        dest="red_ok",
        help="Attestation operateur : document signe / ROE couvre les actions red demandees.",
    )
    sp.add_argument(
        "--red-actions-signed",
        dest="red_actions_signed",
        default="",
        help="Liste CSV d'actions attestees (audit_full,web_profond,smb_hygiene,rgpd,"
        "passi,ot_lecture,inventaire_all_ports). YAML : red_actions_signed: [...].",
    )
    sp.add_argument("--programme", action="store_true", help=argparse.SUPPRESS)
    sp.add_argument("--no-burp", action="store_true", dest="no_burp", help=argparse.SUPPRESS)
    sp.add_argument("--no-programme", action="store_true", dest="no_programme", help=argparse.SUPPRESS)
    sp.add_argument(
        "--rgpd",
        action="store_true",
        help="signalement RGPD sur demande (contrôle selon les exigences RGPD). "
        "PAS un certificat de conformité. Aussi activé par --audit-full / YAML rgpd: true. "
        "Configurer la fiche : python3 -m guardia rgpd -m FILE. Couper : --no-rgpd",
    )
    sp.add_argument(
        "--no-rgpd",
        action="store_true",
        dest="no_rgpd",
        help="n'ajoute pas le signalement RGPD (même en audit full)",
    )
    sp.add_argument(
        "--usages",
        action="store_true",
        help="chapitre usages & droits (ce que les gens peuvent faire). "
        "Auto pour le profil école. YAML usages: true. "
        "Configurer : python3 -m guardia usages -m FILE. Couper : --no-usages",
    )
    sp.add_argument(
        "--no-usages",
        action="store_true",
        dest="no_usages",
        help="n'ajoute pas le chapitre usages & droits (même en profil école)",
    )
    sp.add_argument(
        "--cve",
        action="store_true",
        dest="cve",
        help="corrélation CVE / configs faibles (catalogue local lecture). "
        "Auto si --audit / --audit-full / --full / --passi ou YAML cve: true. "
        "YAML : cve: true. Couper : --no-cve",
    )
    sp.add_argument(
        "--no-cve",
        action="store_true",
        dest="no_cve",
        help="désactive la corrélation CVE même en audit/full/passi",
    )
    sp.add_argument(
        "--calibrage",
        action="store_true",
        help="force le calibrage Kali (déjà allumé par défaut)",
    )
    sp.add_argument(
        "--no-calibrage",
        action="store_true",
        dest="no_calibrage",
        help="coupe le calibrage (nmap + modules seulement)",
    )
    sp.add_argument(
        "--reprendre",
        action="store_true",
        help="reprend le checkpoint du cerveau (nœuds déjà joués sautés)",
    )
    sp.add_argument(
        "--machines",
        action="store_true",
        help="scan défensif machines / OT — Ethernet industriel "
        "(Modbus TCP, S7, OPC-UA, EtherNet/IP, Profinet…). "
        "Lecture seule, pas d'écriture automate. YAML : machines: true",
    )
    sp.add_argument(
        "--pistes",
        action="store_true",
        help="chapitre pistes à explorer (catalogue, pas des findings). "
        "Auto PME / école / --llm. Couper : --no-pistes",
    )
    sp.add_argument(
        "--no-pistes",
        action="store_true",
        dest="no_pistes",
        help="n'ajoute pas le chapitre pistes",
    )
    sp.add_argument(
        "--restructure",
        action="store_true",
        help="force le chapitre « où restructurer le parc » "
        "(déjà auto pour PME / école / audit)",
    )
    sp.add_argument(
        "--workers",
        type=int,
        default=None,
        metavar="N",
        help="parallélisme empreinte services (1–8). Défaut: auto ≈ cpu/2 borné à 4. "
        "Ctrl+1 / SIGUSR1 = passer la phase en cours.",
    )

    # Coupes explicites UI (cases décochées) — priment sur le YAML
    sp.add_argument("--no-passi", action="store_true", dest="no_passi",
                    help="coupe le mode PASSI même si le YAML a passi: true")
    sp.add_argument("--no-site", action="store_true", dest="no_site",
                    help="coupe l'audit site même si le YAML a site_url")
    sp.add_argument("--no-lynis", action="store_true", dest="no_lynis",
                    help="coupe Lynis même si le YAML a lynis: true")
    sp.add_argument("--no-greenbone", action="store_true", dest="no_greenbone",
                    help="coupe Greenbone même si le YAML a greenbone: true")
    sp.add_argument("--no-trivy", action="store_true", dest="no_trivy",
                    help="coupe Trivy même si le YAML a trivy: true")
    sp.add_argument("--no-machines", action="store_true", dest="no_machines",
                    help="coupe machines/OT même si le YAML a machines: true")
    sp.add_argument("--no-autorisations", action="store_true", dest="no_autorisations",
                    help="coupe le pack autorisations même si le YAML l'allume")
    sp.add_argument("--no-audit", action="store_true", dest="no_audit",
                    help="coupe l'audit poussé même si le YAML a audit: true")
    sp.add_argument("--no-llm", action="store_true", dest="no_llm",
                    help="coupe le LLM même si le YAML a llm: true")
    sp.add_argument("--no-pdf", action="store_true", dest="no_pdf",
                    help="coupe l'export PDF même si le YAML a pdf: true")
    sp.add_argument("--no-full", action="store_true", dest="no_full",
                    help="coupe le mode full même si le YAML a profondeur full")
    sp.add_argument("--no-all-ports", action="store_true", dest="no_all_ports",
                    help="coupe all-ports même si le YAML a all_ports: true")

    sp.add_argument("--cidr-catalog", action="store_true", dest="cidr_catalog",
                    help="CIDR vide UI : catalogue de plages (ignore YAML cidr)")
    sp.set_defaults(func=cmd_run)

    return p


def main(argv: list[str] | None = None) -> int:
    argv = argv if argv is not None else sys.argv[1:]
    parser = build_parser()
    if not argv:
        parser.print_help()
        return 0
    args = parser.parse_args(argv)
    if not getattr(args, "func", None):
        parser.print_help()
        return 0
    cmd = getattr(args, "cmd", None)
    try:
        from guardia.engines.llm_gate import COMMANDS_DEMARRAGE, COMMANDS_SANS_LLM, exiger, ligne

        start = cmd in COMMANDS_DEMARRAGE
        status = exiger(allow_garde=True, start=start, url=getattr(args, "url", None) or getattr(args, "llm_url", None))
        args.llm_status = status
        # L'UI réaffiche après tentative de démarrage — éviter le doublon.
        if cmd not in COMMANDS_SANS_LLM and cmd != "ui":
            print(ligne(status), flush=True)
    except Exception as exc:  # noqa: BLE001
        log.warning("llm gate: %s", exc)
    try:
        return int(args.func(args))
    except KeyboardInterrupt:
        print("\nAnnulé.", file=sys.stderr)
        return 130
    except GuardiaError as exc:
        print(f"erreur: {exc}", file=sys.stderr)
        return 1
