"""Guardia — moteur d'orchestration d'audit défensif (Echoes of Hackers)."""
__version__ = "1.4.0"
__signature__ = "Platon-Y / Echoes of Hackers"
