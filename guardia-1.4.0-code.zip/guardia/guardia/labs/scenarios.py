"""Scénarios de laboratoire — hôtes synthétiques, aucun paquet réseau."""
from __future__ import annotations

from guardia.core.models import Host, Mission


def _host(ip: str, ports: list[int], kind: str = "pc", hostname: str = "") -> Host:
    h = Host(ip=ip, hostname=hostname or ip, kind=kind)
    h.ports = [{"port": p, "proto": "tcp", "name": "open"} for p in ports]
    return h


def _mission(**kwargs: object) -> Mission:
    extras = dict(kwargs.pop("extras", {}) or {})  # type: ignore[arg-type]
    m = Mission(
        client=str(kwargs.get("client") or "Lab"),
        cidr=str(kwargs.get("cidr") or "192.0.2.0/24"),
        mandat_nda_signes=bool(kwargs.get("mandat", True)),
        operateur_signe=bool(kwargs.get("operateur", True)),
        profondeur=str(kwargs.get("profondeur") or "standard"),
        profil_moteur=str(kwargs.get("profil") or "pme"),
    )
    m.extras = extras
    return m


def https_only() -> dict:
    m = _mission(client="Lab HTTPS", extras={"site_url": "https://example.test", "passi": False})
    return {
        "id": "https-only",
        "titre": "Un serveur HTTPS, rien d'autre",
        "mission": m,
        "hosts": [_host("192.0.2.10", [443], "serveur", "www")],
        "equipe": "blue",
        "attendu": {
            "ouvre": ["tls_assessment", "http_headers"],
            "prune": ["smb_read", "ot_safe"],
            "bloque": ["zap_active", "metasploit"],
        },
    }


def smb_rdp() -> dict:
    m = _mission(client="Lab SMB/RDP")
    return {
        "id": "smb-rdp",
        "titre": "Partage Windows + bureau à distance",
        "mission": m,
        "hosts": [_host("192.0.2.20", [139, 445, 3389], "pc", "poste-compta")],
        "equipe": "blue",
        "attendu": {
            "ouvre": ["smb_read", "rdp_read"],
            "prune": ["ot_safe"],
            "bloque": ["impacket"],
        },
    }


def ot_modbus() -> dict:
    m = _mission(client="Lab OT", extras={"machines": True})
    return {
        "id": "ot-modbus",
        "titre": "Automate Modbus TCP",
        "mission": m,
        "hosts": [_host("192.0.2.30", [502], "ot", "plc-1")],
        "equipe": "blue",
        "attendu": {
            "ouvre": ["ot_safe"],
            "prune": ["smb_read"],
            "bloque": ["metasploit"],
        },
    }


def admin_expose() -> dict:
    m = _mission(client="Lab admin")
    return {
        "id": "admin-expose",
        "titre": "Interface d'administration 8443",
        "mission": m,
        "hosts": [_host("192.0.2.40", [8443], "nas", "nas-1")],
        "equipe": "blue",
        "attendu": {
            "ouvre": ["tls_assessment", "admin_surface"],
            "evenement": "exposed_admin_service",
            "bloque": ["zap_active"],
        },
    }


def sans_mandat() -> dict:
    m = _mission(client="Lab sans mandat", mandat=False, operateur=False)
    return {
        "id": "sans-mandat",
        "titre": "Découverte refusée sans mandat",
        "mission": m,
        "hosts": [_host("192.0.2.50", [80])],
        "equipe": "blue",
        "attendu": {
            "refuse": ["nmap_discover"],
        },
    }


def avenant_red() -> dict:
    m = _mission(client="Lab red avenant", extras={"passi": True, "equipe": "red"})
    return {
        "id": "avenant-red",
        "titre": "Red encadré : avenant jamais auto",
        "mission": m,
        "hosts": [_host("192.0.2.60", [80, 443, 445, 3389, 389], "serveur", "dc")],
        "equipe": "red",
        "attendu": {
            "ouvre": ["tls_assessment", "smb_read"],
            "bloque": ["zap_active", "metasploit", "bloodhound", "ffuf", "impacket"],
        },
    }


def passi_architecture() -> dict:
    m = _mission(
        client="Lab PASSI architecture",
        extras={
            "passi": True,
            "passi_activities": ["architecture", "configuration"],
            "site_url": "https://example.test",
            "architecture_docs": {"l2_l3": "pieces/l2.pdf"},
        },
    )
    return {
        "id": "passi-archi",
        "titre": "Observations → contrôle P-ARCH-06",
        "mission": m,
        "hosts": [
            _host("192.0.2.10", [443], "serveur", "www"),
            _host("192.0.2.11", [22, 80], "serveur", "app"),
        ],
        "equipe": "blue",
        "passi": True,
        "attendu": {
            "ouvre": ["tls_assessment"],
            "passi_control": "P-ARCH-06",
            "passi_status": "verified",
        },
    }


def mixte_prune() -> dict:
    m = _mission(client="Lab mixte")
    return {
        "id": "mixte-prune",
        "titre": "HTTPS + SMB : deux branches, OT écarté",
        "mission": m,
        "hosts": [
            _host("192.0.2.10", [443], "serveur"),
            _host("192.0.2.20", [445], "pc"),
        ],
        "equipe": "blue",
        "attendu": {
            "ouvre": ["tls_assessment", "smb_read"],
            "prune": ["ot_safe"],
        },
    }


SCENARIOS = (
    https_only,
    smb_rdp,
    ot_modbus,
    admin_expose,
    sans_mandat,
    avenant_red,
    passi_architecture,
    mixte_prune,
)
