"""Labs Guardia — réactions du cerveau sans réseau réel."""
from guardia.labs.runner import LABOS, jouer, jouer_tous

__all__ = ["LABOS", "jouer", "jouer_tous"]
