"""Exécute les labs : cerveau + dossier PASSI, zéro paquet réseau."""
from __future__ import annotations

from typing import Any

from guardia.cerveau import raisonner
from guardia.engines.autorisations import build_autorisations
from guardia.labs.scenarios import SCENARIOS


def _etats(brain: dict[str, Any]) -> dict[str, str]:
    return {str(d.get("cap")): str(d.get("etat")) for d in brain.get("decisions") or []}


def _verifie(attendu: dict[str, Any], brain: dict[str, Any], assessment: dict[str, Any] | None) -> list[dict[str, Any]]:
    etats = _etats(brain)
    types = {e.get("type") for e in brain.get("evenements") or []}
    checks: list[dict[str, Any]] = []

    def _ok(cond: bool, nom: str, detail: str) -> None:
        checks.append({"nom": nom, "ok": cond, "detail": detail})

    for cap in attendu.get("ouvre") or []:
        st = etats.get(cap, "")
        _ok(st in ("ouvre", "porte"), "ouvre " + cap, st or "absent")
    for cap in attendu.get("prune") or []:
        st = etats.get(cap, "")
        _ok(st == "prune", "prune " + cap, st or "absent")
    for cap in attendu.get("bloque") or []:
        st = etats.get(cap, "")
        _ok(st in ("bloque_policy", "refuse"), "bloque " + cap, st or "absent")
    for cap in attendu.get("refuse") or []:
        st = etats.get(cap, "")
        _ok(st in ("refuse", "bloque_policy"), "refuse " + cap, st or "absent")
    ev = attendu.get("evenement")
    if ev:
        _ok(ev in types, "événement " + ev, "présent" if ev in types else "absent")
    cid = attendu.get("passi_control")
    if cid and assessment:
        row = next((r for r in assessment.get("controls") or [] if r.get("id") == cid), None)
        want = attendu.get("passi_status") or "verified"
        got = (row or {}).get("status")
        _ok(got == want, "PASSI " + cid, "{g} (voulu {w})".format(g=got, w=want))
        chaines = assessment.get("chaines") or []
        ch = next((c for c in chaines if c.get("controle") == cid), None)
        _ok(bool(ch and ch.get("preuve")), "chaîne " + cid, (ch or {}).get("preuve") or "vide")
    return checks


def jouer(scenario: dict[str, Any]) -> dict[str, Any]:
    mission = scenario["mission"]
    hosts = scenario["hosts"]
    equipe = scenario.get("equipe") or "blue"
    authz = build_autorisations(mission, pour_passi=bool((mission.extras or {}).get("passi")))
    brain = raisonner(
        mission,
        hosts=hosts,
        plan={
            "lynis": bool((mission.extras or {}).get("lynis")),
            "greenbone": bool((mission.extras or {}).get("greenbone")),
            "site_url": (mission.extras or {}).get("site_url") or "",
            "machines": bool((mission.extras or {}).get("machines")),
        },
        equipe=equipe,
        autorisations=authz,
    )
    assessment = None
    if scenario.get("passi") or (mission.extras or {}).get("passi"):
        from guardia.engines.passi_assessment import build_assessment

        assessment = build_assessment(
            mission,
            {
                "equipe": equipe,
                "autorisations": authz,
                "hosts": hosts,
                "journal": {"etapes": [{"id": "lab", "etat": "joue"}]},
                "adaptatif": brain,
                "findings": brain.get("findings_candidats") or [],
                "evidence_data": {
                    "architecture_docs": (mission.extras or {}).get("architecture_docs") or {},
                },
            },
        )
    checks = _verifie(scenario.get("attendu") or {}, brain, assessment)
    ok = all(c["ok"] for c in checks) if checks else True
    return {
        "id": scenario["id"],
        "titre": scenario["titre"],
        "ok": ok,
        "synthese": brain.get("synthese"),
        "n_ouverts": brain.get("n_ouverts"),
        "n_ecartes": brain.get("n_ecartes"),
        "n_refuses_policy": brain.get("n_refuses_policy"),
        "evenements": sorted({e.get("type") for e in brain.get("evenements") or [] if e.get("type")}),
        "decisions": [
            {"cap": d.get("cap"), "etat": d.get("etat"), "why": d.get("why")}
            for d in brain.get("decisions") or []
        ],
        "checks": checks,
        "passi_summary": (assessment or {}).get("summary") if assessment else None,
        "chaines_alimentees": ((assessment or {}).get("summary") or {}).get("chaines_alimentees") if assessment else 0,
    }


def jouer_tous() -> dict[str, Any]:
    resultats = [jouer(factory()) for factory in SCENARIOS]
    return {
        "labs": resultats,
        "n": len(resultats),
        "ok": sum(1 for r in resultats if r["ok"]),
        "ko": sum(1 for r in resultats if not r["ok"]),
    }


LABOS = tuple(factory().get("id") for factory in SCENARIOS)
