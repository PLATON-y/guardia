"""Regard attaquant — lecture seule.

Même faits que le checkup. On dit par où ça casse, dans quel ordre.
Pas d'exploit. Pas de brute. Pas de dump.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import Any

from guardia.core.models import CheckupResult, Finding, Host


_ATTCK: tuple[tuple[tuple[str, ...], str, str], ...] = (
    (("nmap", "port", "open", "discover"), "T1046", "Network Service Discovery"),
    (("partage", "smb", "nfs", "share", "admin$"), "T1135", "Network Share Discovery"),
    (("ldap", "annuaire", "namingcontext"), "T1087", "Account Discovery"),
    (("rdp", "3389", "vnc", "5900", "winrm"), "T1021", "Remote Services"),
    (("snmp", "public"), "T1046", "Network Service Discovery"),
    (("ftp-anon", "anonymous"), "T1021.002", "Remote Services: SMB/FTP"),
    (("tls", "http", "web-", "certificat"), "T1190", "Exploit Public-Facing Application"),
    (("ot-", "modbus", "ipmi", "bmc"), "T0886", "ICS: Remote Services"),
    (("axfr", "dns-zone"), "T1018", "Remote System Discovery"),
)


def _blob_host(h: Host) -> str:
    parts = [h.kind, h.hostname, h.ip]
    for f in h.findings or []:
        parts.append(f.id)
        parts.append(f.titre)
        parts.append(getattr(f, "pourquoi_nuit", "") or "")
    for p in h.ports or []:
        if isinstance(p, dict):
            parts.append(str(p.get("port") or ""))
            parts.append(str(p.get("name") or ""))
            parts.append(str(p.get("product") or ""))
            parts.append(str(p.get("version") or ""))
    return " ".join(parts).lower()


def _all_findings(result: CheckupResult) -> list[Finding]:
    out: list[Finding] = []
    for h in result.hosts or []:
        out.extend(h.findings or [])
    return out


def _chemins(result: CheckupResult) -> list[dict[str, str]]:
    """2–3 chemins concrets, à partir de ce qui est vu. On ne les emprunte pas."""
    hosts = result.hosts or []
    blobs = [(h, _blob_host(h)) for h in hosts]
    out: list[dict[str, str]] = []

    def add(titre: str, detail: str, ordre: str) -> None:
        if any(c["titre"] == titre for c in out):
            return
        out.append({"titre": titre, "detail": detail, "ordre": ordre})

    partage = next((h for h, b in blobs if "partage" in b or "smb" in b or "nfs" in b), None)
    rdp = next((h for h, b in blobs if "3389" in b or "rdp" in b or "vnc" in b), None)
    ldap = next((h for h, b in blobs if "ldap" in b or "annuaire" in b), None)
    ot = next((h for h, b in blobs if h.kind == "ot" or "modbus" in b or "ipmi" in b), None)
    ftp = next((h for h, b in blobs if "ftp" in b and "anon" in b), None)
    web = bool((result.website or {}).get("findings"))
    snmp = next((h for h, b in blobs if "snmp" in b), None)

    n = 1
    if ftp:
        add(
            f"Porte anonyme ({ftp.ip})",
            "FTP sans mot de passe. Première marche : un dossier ouvert, puis le reste du LAN.",
            str(n),
        )
        n += 1
    if partage and rdp and partage.ip != rdp.ip:
        add(
            f"Partage {partage.ip} → poste {rdp.ip}",
            "Fichiers visibles, puis prise d'écran (RDP/VNC) sur une autre machine. Classic.",
            str(n),
        )
        n += 1
    elif rdp:
        add(
            f"Prise de poste {rdp.ip}",
            "Bureau à distance vu depuis le LAN. C'est la main sur l'écran.",
            str(n),
        )
        n += 1
    elif partage:
        add(
            f"Fichiers ouverts ({partage.ip})",
            "Partage trop large. On y lit le métier sans casser de mot de passe.",
            str(n),
        )
        n += 1
    if ldap:
        add(
            f"Annuaire joignable ({ldap.ip})",
            "Le rootDSE répond. Trop de monde voit qui est qui — et souvent trop de portes ensuite.",
            str(n),
        )
        n += 1
    if ot:
        add(
            f"Atelier depuis le bureau ({ot.ip})",
            "Un automate / BMC se voit du LAN métier. On ne touche pas. On le dit.",
            str(n),
        )
        n += 1
    if snmp and not ot:
        add(
            f"SNMP public ({snmp.ip})",
            "Communauté public : nom, modèle, parfois plus. Cartographie gratuite.",
            str(n),
        )
        n += 1
    if web:
        add(
            "Site du mandat",
            "Défauts TLS / en-têtes / cookies vus de l'extérieur. Surface publique, pas le LAN.",
            str(n),
        )
        n += 1
    return out[:4]


def _attck(result: CheckupResult) -> list[dict[str, str]]:
    blob = " ".join(_blob_host(h) for h in result.hosts or []).lower()
    if result.website:
        blob += " web tls http"
    seen: list[dict[str, str]] = []
    ids: set[str] = set()
    for keys, tid, nom in _ATTCK:
        if tid in ids:
            continue
        if any(k in blob for k in keys):
            ids.add(tid)
            seen.append({"id": tid, "nom": nom})
    return seen[:8]


_CVE_LOCAL: tuple[tuple[str, str, str], ...] = (
    ("smb v1", "SMBv1 offert", "Protocole retiré. À couper, pas à exploiter ici."),
    ("tlsv1.0", "TLS 1.0 encore proposé", "Protocole trop ancien. Couper."),
    ("sslv3", "SSLv3 encore proposé", "Protocole mort. Couper."),
    ("openssh_7.", "OpenSSH 7.x", "Branche ancienne. Historique CVE connu — on ne lance rien."),
    ("php/5", "PHP 5 encore servi", "Fin de vie. Mettre à jour."),
    ("apache/2.2", "Apache 2.2", "Fin de vie. Historique CVE — lecture seule."),
    ("windows server 2008", "Windows 2008 vu", "Hors support. Cible évidente, on n'entre pas."),
    ("windows server 2012", "Windows 2012 vu", "Hors support étendu. À planifier."),
)


def _cve_bannieres(result: CheckupResult) -> list[dict[str, str]]:
    out: list[dict[str, str]] = []
    for h in result.hosts or []:
        blob = _blob_host(h)
        for needle, titre, note in _CVE_LOCAL:
            if needle in blob:
                out.append({"hote": h.ip, "titre": titre, "note": note, "source": "bannière"})
    # searchsploit local si présent — titres seulement, timeout court
    sp = shutil.which("searchsploit")
    if sp:
        products: list[str] = []
        for h in result.hosts or []:
            for p in h.ports or []:
                if not isinstance(p, dict):
                    continue
                prod = str(p.get("product") or "").strip()
                ver = str(p.get("version") or "").strip()
                if prod and ver:
                    products.append(f"{prod} {ver.split()[0]}")
        for q in products[:4]:
            try:
                r = subprocess.run(
                    [sp, "--disable-colour", "-t", q],
                    capture_output=True,
                    text=True,
                    timeout=6,
                    check=False,
                )
            except (OSError, subprocess.TimeoutExpired):
                continue
            lines = [
                ln.strip()
                for ln in (r.stdout or "").splitlines()
                if ln.strip() and "No Results" not in ln and not ln.startswith("-")
            ]
            if lines:
                out.append(
                    {
                        "hote": q,
                        "titre": f"Historique public : {q}",
                        "note": lines[0][:180],
                        "source": "searchsploit (titre, pas d'exploit)",
                    }
                )
    # dédup
    seen: set[str] = set()
    uniq: list[dict[str, str]] = []
    for row in out:
        k = row["titre"]
        if k in seen:
            continue
        seen.add(k)
        uniq.append(row)
    return uniq[:8]


def _cibles(chemins: list[dict[str, str]]) -> list[str]:
    return [c["titre"] for c in chemins[:3]]


def build_regard(result: CheckupResult) -> dict[str, Any]:
    chemins = _chemins(result)
    return {
        "equipe": "red",
        "lecture_seule": True,
        "intrusion": False,
        "limite": (
            "Regard attaquant. On n'entre pas. L'intrusion viendra "
            "quand le cadre judiciaire sera posé — pas avant."
        ),
        "chemins": chemins,
        "cibles": _cibles(chemins),
        "attck": _attck(result),
        "cve_bannieres": _cve_bannieres(result),
    }
