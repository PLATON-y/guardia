"""Signalement RGPD — sur demande uniquement.

Ce n'est PAS un certificat de conformité, PAS une certification CNIL / DPO,
PAS un audit juridique opposable. C'est un **signalement** établi **sur demande**,
après contrôle selon les exigences RGPD (UE 2016/679), la loi Informatique et
Libertés, et les points CNIL actualisés (cookies / consentement).

La fiche `rgpd_config` (UI / wizard / YAML) alimente les déclarations
opérateur. Une déclaration « oui » n'est **pas** une conformité.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Finding, Gravite, Mission
from guardia.engines.rgpd_config import (
    config_is_blank,
    load_rgpd_config,
    raw_config_from_mission,
)

DISCLAIMER = (
    "Signalement RGPD établi sur demande. Contrôle selon les exigences du RGPD "
    "(règlement UE 2016/679), de la loi Informatique et Libertés, et des "
    "recommandations CNIL (cookies et traceurs, consentement). "
    "Ceci n'est pas un certificat de conformité, ni une certification CNIL, "
    "ni un tampon « RGPD OK ». C'est un signalement : ce qui a été contrôlé, "
    "ce qui a été vu, ce qui manque encore."
)

# statuts autorisés — jamais « conforme »
STATUT_VU = "observé"
STATUT_NON_VU = "non observé — signalé"
STATUT_CONFIRMER = "à confirmer avec vous"
STATUT_HORS = "hors observation à distance"
STATUT_DECLARE = "déclaré — pas un certificat"


def _item(
    iid: str,
    titre: str,
    exigence: str,
    statut: str,
    observation: str,
    signalement: str,
    que_faire: list[str],
) -> dict[str, Any]:
    return {
        "id": iid,
        "titre": titre,
        "exigence": exigence,
        "statut": statut,
        "observation": observation,
        "signalement": signalement,
        "que_faire": que_faire,
    }


def _from_tri(
    val: str,
    *,
    oui_msg: str,
    non_msg: str,
    inconnu_msg: str,
    signal_if_non: bool = True,
) -> tuple[str, str]:
    """Retourne (statut, signalement) d'après une déclaration oui/non/inconnu."""
    if val == "oui":
        return STATUT_DECLARE, oui_msg
    if val == "non":
        if signal_if_non:
            return STATUT_NON_VU, non_msg
        return STATUT_DECLARE, non_msg
    return STATUT_CONFIRMER, inconnu_msg


def build_rgpd_signalement(
    mission: Mission,
    *,
    website: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Construit le signalement (observables site + fiche rgpd_config)."""
    web = website or {}
    sig = web.get("signals") or {}
    findings_web = web.get("findings") or []
    web_ids = set()
    for f in findings_web:
        if hasattr(f, "id"):
            web_ids.add(f.id)
        elif isinstance(f, dict):
            web_ids.add(str(f.get("id") or ""))

    cfg = load_rgpd_config(mission)
    blank = config_is_blank(raw_config_from_mission(mission))
    has_site = bool(web.get("url"))
    items: list[dict[str, Any]] = []

    # --- Observables site (si module web allumé) ---
    if has_site:
        items.append(
            _item(
                "rgpd-https",
                "Chiffrement du site (HTTPS / TLS)",
                "RGPD art. 32 — sécurité du traitement",
                STATUT_NON_VU if "web-pas-https" in web_ids else (
                    STATUT_VU if web.get("ok") else STATUT_CONFIRMER
                ),
                f"url={web.get('url')} https_final={((web.get('pages') or {}).get('home') or {}).get('https')}",
                "Signalé si le site n'est pas en HTTPS de bout en bout."
                if "web-pas-https" in web_ids
                else "HTTPS observé ou handshake TLS tenté — pas un certificat de conformité.",
                ["Imposer HTTPS + redirection 301 + HSTS une fois stable."],
            )
        )
        items.append(
            _item(
                "rgpd-mentions",
                "Mentions légales accessibles",
                "LCEN art. 6 — identification de l'éditeur",
                STATUT_VU if sig.get("legal_link") else STATUT_NON_VU,
                "lien / page mentions légales "
                + ("détecté" if sig.get("legal_link") else "non détecté"),
                "Absence de mentions légales visibles → signalement."
                if not sig.get("legal_link")
                else "Page ou lien observé. Le contenu juridique n'a pas été validé mot à mot.",
                ["Page Mentions légales en pied de site : éditeur, contact, hébergeur."],
            )
        )
        items.append(
            _item(
                "rgpd-info",
                "Information des personnes (politique de confidentialité)",
                "RGPD art. 12, 13 et 14",
                STATUT_VU if sig.get("privacy_page") or sig.get("legal_link") else STATUT_NON_VU,
                "page privacy "
                + ("observée" if sig.get("privacy_page") else "non observée sur les chemins usuels"),
                "Sans information claire, le visiteur ne peut pas comprendre le traitement."
                if not (sig.get("privacy_page") or sig.get("legal_link"))
                else "Une page d'information semble présente. Contenu exhaustif = à relire avec vous.",
                [
                    "Politique en français : finalités, bases légales, durées, destinataires, droits, contact.",
                    "Lien depuis le footer et depuis le bandeau cookies.",
                ],
            )
        )
        trackers = list(sig.get("trackers") or [])
        cmp = list(sig.get("cmp") or [])
        refus = str(cfg.get("refus_aussi_simple") or "inconnu")
        if trackers and not cmp:
            st_cookie, obs_cookie, sig_cookie = (
                STATUT_NON_VU,
                "traceurs=" + ", ".join(trackers) + " ; aucun CMP / bandeau détecté",
                "Traceurs sans consentement visible : signalement (reco CNIL cookies / art. 82 LIL).",
            )
        elif refus == "non":
            st_cookie, obs_cookie, sig_cookie = (
                STATUT_NON_VU,
                f"déclaration opérateur refus_aussi_simple=non ; trackers={trackers or '—'} cmp={cmp or '—'}",
                "L'opérateur a vu un bandeau où refuser n'est pas au même niveau qu'accepter — signalement CNIL.",
            )
        elif trackers:
            st_cookie = STATUT_CONFIRMER if refus != "oui" else STATUT_DECLARE
            obs_cookie = (
                "traceurs=" + ", ".join(trackers) + " ; cmp=" + ", ".join(cmp[:6])
                + f" ; refus_aussi_simple={refus}"
            )
            sig_cookie = (
                "CMP observé. Déclaration refus=oui : noté, sans valider le consentement multi-terminaux."
                if refus == "oui"
                else "CMP observé et traceurs présents : à confirmer qu'aucun tag non essentiel ne part avant le clic."
            )
        elif not cmp:
            st_cookie, obs_cookie, sig_cookie = (
                STATUT_CONFIRMER,
                "ni tracker usuel ni CMP dans le HTML d'accueil"
                + f" ; refus_aussi_simple={refus}",
                "Peut être légitime (cookies techniques seulement) — à confirmer sur le navigateur réel.",
            )
        else:
            st_cookie = STATUT_VU if refus != "non" else STATUT_NON_VU
            obs_cookie = "cmp=" + ", ".join(cmp[:6]) + f" ; refus_aussi_simple={refus}"
            sig_cookie = "Bandeau / CMP observé. Pas une validation du consentement multi-terminaux."
        items.append(
            _item(
                "rgpd-cookies",
                "Cookies et traceurs — consentement",
                "LIL art. 82 · reco CNIL cookies (refus aussi simple qu'accepter) · "
                "reco consentement multi-terminaux (2026)",
                st_cookie,
                obs_cookie,
                sig_cookie,
                [
                    "Refuser aussi simple qu'accepter (même niveau, pas de case précochée).",
                    "Pas de traceur non essentiel avant le choix.",
                    "Si comptes logués : suivre la reco CNIL 2026 (consentement multi-terminaux).",
                ],
            )
        )
        contact = str(cfg.get("contact_droits") or "").strip()
        droits_vu = bool(sig.get("dpo_or_rights")) or bool(contact)
        items.append(
            _item(
                "rgpd-droits",
                "Exercice des droits / contact",
                "RGPD art. 15 à 22 · art. 12",
                STATUT_VU if sig.get("dpo_or_rights") else (
                    STATUT_DECLARE if contact else STATUT_NON_VU
                ),
                (
                    "mention DPO / droits observée sur le site"
                    if sig.get("dpo_or_rights")
                    else (
                        f"contact déclaré en fiche : {contact}"
                        if contact
                        else "pas de motif DPO / droits dans le HTML, pas de contact en fiche"
                    )
                ),
                "Sans modalité d'exercice visible ni contact déclaré, les personnes ne peuvent pas agir."
                if not droits_vu
                else "Contact noté — à vérifier que la boîte est lue. Pas un certificat.",
                [
                    "Indiquer un e-mail (et DPO s'il est désigné).",
                    "Décrire accès, rectification, effacement, limitation, opposition, portabilité.",
                ],
            )
        )
    else:
        items.append(
            _item(
                "rgpd-site-non-demande",
                "Site web non inclus dans ce signalement",
                "Périmètre — uniquement les URL autorisées",
                STATUT_HORS,
                "module site éteint pour cette mission",
                "Le volet site (mentions, cookies, HTTPS) n'a pas été contrôlé. "
                "Relancer avec --site si le mandat le prévoit.",
                ["Cocher le module site et renseigner l'URL du mandat."],
            )
        )

    if blank:
        items.append(
            _item(
                "rgpd-fiche-vide",
                "Fiche RGPD non configurée",
                "Signalement sur demande — déclarations opérateur",
                STATUT_CONFIRMER,
                "rgpd_config absent ou tout à « inconnu »",
                "Le module est allumé mais la fiche n'a pas été remplie. "
                "Les points ci-dessous restent à confirmer. "
                "UI : bouton « Configurer RGPD » · CLI : python3 -m guardia rgpd -m <mission.yaml>",
                [
                    "Ouvrir Configurer RGPD et poser les questions au responsable.",
                    "Enregistrer dans la mission (rgpd_config) puis relancer le checkup.",
                ],
            )
        )

    resp = str(cfg.get("responsable") or mission.client or "").strip()
    contact = str(cfg.get("contact_droits") or "").strip()

    st, msg = _from_tri(
        str(cfg.get("registre_tenu") or "inconnu"),
        oui_msg="Déclaré tenu — à pouvoir présenter en contrôle. Pas un certificat.",
        non_msg="Registre art. 30 déclaré absent — signalement (plus de déclaration CNIL depuis 2018).",
        inconnu_msg="À confirmer : un registre interne existe, est à jour, et peut être présenté en contrôle.",
    )
    items.append(
        _item(
            "rgpd-registre",
            "Registre des activités de traitement",
            "RGPD art. 30 — plus de déclaration CNIL préalable depuis 2018",
            st,
            f"déclaration={cfg.get('registre_tenu')} · responsable={resp or '—'}",
            msg,
            [
                "Tenir le registre art. 30.1 (responsable) / 30.2 (sous-traitant).",
                "Y tracer finalités, catégories de données, destinataires, durées, transferts, mesures.",
            ],
        )
    )

    st, msg = _from_tri(
        str(cfg.get("registre_violations") or "inconnu"),
        oui_msg="Déclaré tenu. Vérifier qu'il est réellement alimenté après chaque incident.",
        non_msg="Pas de registre des violations déclaré — signalement art. 33.5.",
        inconnu_msg="À confirmer : journal des incidents, même non notifiés à la CNIL.",
    )
    items.append(
        _item(
            "rgpd-violations",
            "Registre des violations et notification 72 h",
            "RGPD art. 33 et 34 · art. 33.5 (documentation interne)",
            st,
            f"registre_violations={cfg.get('registre_violations')} "
            f"procedure_72h={cfg.get('procedure_72h')}",
            msg,
            [
                "Documenter chaque incident (date, faits, données, mesures).",
                "Préparer le circuit 72 h CNIL + information des personnes si besoin.",
            ],
        )
    )
    st72, msg72 = _from_tri(
        str(cfg.get("procedure_72h") or "inconnu"),
        oui_msg="Procédure 72 h déclarée — à tester (qui appelle qui, modèle CNIL).",
        non_msg="Pas de procédure 72 h déclarée — signalement : en cas d'incident vous serez hors délai.",
        inconnu_msg="À confirmer : qui déclenche la notification, avec quel modèle.",
    )
    items.append(
        _item(
            "rgpd-72h",
            "Procédure de notification CNIL sous 72 h",
            "RGPD art. 33 — dès que possible et au plus tard 72 h si risque",
            st72,
            f"procedure_72h={cfg.get('procedure_72h')}",
            msg72,
            [
                "Désigner un déclencheur (direction / DPO / prestataire).",
                "Garder un modèle de notification CNIL prêt.",
            ],
        )
    )

    st, msg = _from_tri(
        str(cfg.get("contrats_art28") or "inconnu"),
        oui_msg="Contrats art. 28 déclarés. À relire (finalités, sous-traitance ultérieure, localisation).",
        non_msg="Pas de contrats art. 28 déclarés — signalement : flux non encadrés.",
        inconnu_msg="Signalement de vigilance : sans contrat art. 28, le responsable ne maîtrise pas ses flux.",
    )
    sous = str(cfg.get("sous_traitants") or "").strip() or "(liste vide — à compléter)"
    items.append(
        _item(
            "rgpd-sous-traitants",
            "Sous-traitants et encadrement (art. 28)",
            "RGPD art. 28 · transferts hors UE (art. 44 et s.) · SREN (clauses UE/EEE)",
            st,
            f"sous-traitants déclarés : {sous} · art28={cfg.get('contrats_art28')} "
            f"· hors_ue={cfg.get('transferts_hors_ue')}",
            msg,
            [
                "Lister hébergeur, DNS, e-mail, analytics, paiement, support.",
                "Contrat art. 28 + clauses de transfert si hors UE/EEE (SREN : risque d'accès tiers pays).",
            ],
        )
    )
    st_t, msg_t = _from_tri(
        str(cfg.get("transferts_hors_ue") or "inconnu"),
        oui_msg="Transferts hors UE/EEE déclarés — documenter garanties (CCT, décisions d'adéquation). Pas un certificat.",
        non_msg="Aucun transfert hors UE/EEE déclaré. À recouper avec l'hébergeur / la stack réelle.",
        inconnu_msg="À cartographier : où vivent vraiment les sauvegardes, l'e-mail, l'analytics.",
        signal_if_non=False,
    )
    items.append(
        _item(
            "rgpd-transferts",
            "Transferts hors UE / EEE",
            "RGPD art. 44 et s. · SREN (clauses de localisation)",
            st_t,
            f"transferts_hors_ue={cfg.get('transferts_hors_ue')}",
            msg_t,
            [
                "Identifier chaque outil (cloud, support, analytics) et son pays.",
                "Si hors UE/EEE : garanties + mention dans la politique.",
            ],
        )
    )

    st, msg = _from_tri(
        str(cfg.get("durees_ecrites") or "inconnu"),
        oui_msg="Durées déclarées écrites — vérifier qu'une purge réelle existe (pas seulement une phrase).",
        non_msg="Pas de durées écrites déclarées — signalement art. 5.1.e.",
        inconnu_msg="À confirmer : chaque traitement a une durée écrite et une purge.",
    )
    items.append(
        _item(
            "rgpd-durees",
            "Durées de conservation",
            "RGPD art. 5.1.e (minimisation dans le temps)",
            st,
            f"durees_ecrites={cfg.get('durees_ecrites')}",
            msg,
            ["Écrire les durées dans le registre et la politique.", "Planifier une purge / archivage."],
        )
    )

    dpo = str(cfg.get("dpo_designe") or "inconnu")
    ecole = (mission.profil_moteur or "").lower() == "ecole" or (
        mission.type_structure or ""
    ).lower() == "ecole"
    if dpo == "oui":
        st_dpo, msg_dpo = STATUT_DECLARE, "DPO déclaré désigné. Noter le contact. Pas une certification DPO."
    elif dpo == "non" and ecole:
        st_dpo, msg_dpo = (
            STATUT_NON_VU,
            "Établissement scolaire sans DPO déclaré — à cadrer (souvent un DPO académique / collectivité).",
        )
    elif dpo == "non":
        st_dpo, msg_dpo = (
            STATUT_DECLARE,
            "Pas de DPO déclaré. Souvent légitime hors autorité / traitement à grande échelle — à confirmer selon l'activité.",
        )
    else:
        st_dpo, msg_dpo = STATUT_CONFIRMER, "À confirmer si un DPO est requis (autorité, santé, grande échelle)."
    items.append(
        _item(
            "rgpd-dpo",
            "Désignation d'un DPO",
            "RGPD art. 37 à 39",
            st_dpo,
            f"dpo_designe={dpo} · contact={contact or '—'}",
            msg_dpo,
            [
                "Si requis : désigner et publier le contact.",
                "Sinon : garder un contact droits (privacy@) qui répond vraiment.",
            ],
        )
    )

    mineurs = str(cfg.get("mineurs") or "inconnu")
    if mineurs == "oui" or ecole:
        items.append(
            _item(
                "rgpd-mineurs",
                "Mineurs / élèves (France : 15 ans pour le consentement)",
                "Loi Informatique et Libertés — consentement du mineur 15 ans · RGPD art. 8",
                STATUT_DECLARE if mineurs == "oui" else STATUT_CONFIRMER,
                f"mineurs={mineurs} · type={mission.type_structure}",
                "Signalement de vigilance : comptes partagés, ENT, photos d'élèves, "
                "tracking sur espace pédagogique — à cadrer avec le responsable d'établissement.",
                [
                    "Base légale mission de service public / obligation légale plutôt que consentement « cookie ».",
                    "Pas de traceur pub sur espaces élèves.",
                    "Photos / listes : information parents, durées courtes.",
                ],
            )
        )

    nis = str(cfg.get("nis2_concerne") or "inconnu")
    extras = dict(mission.extras or {})
    taille = str(extras.get("taille_parc") or "").lower()
    st_n, msg_n = _from_tri(
        nis,
        oui_msg="Vous vous déclarez potentiellement NIS2 : early warning 24 h puis 72 h ANSSI "
        "s'ajoutent au RGPD. Ce n'est pas un classement officiel.",
        non_msg="Vous ne vous déclarez pas NIS2. À revoir si le secteur / la taille change. Pas un verdict.",
        inconnu_msg="Ce n'est pas un classement NIS2. Si PME de secteur essentiel / important : "
        "24 h / 72 h et gouvernance cyber s'ajoutent au RGPD. À vérifier avec vous.",
        signal_if_non=False,
    )
    items.append(
        _item(
            "rgpd-nis2",
            "NIS2 — est-ce que ça vous concerne ? (à cadrer, pas un verdict)",
            "Directive (UE) 2022/2555 — transposition France / ANSSI "
            "(early warning 24 h puis 72 h pour entités essentielles / importantes)",
            st_n,
            f"nis2_concerne={nis} · taille_parc={taille or '?'} type={mission.type_structure or '?'}",
            msg_n,
            [
                "Vérifier le secteur et la taille (moyenne / grande) face au périmètre NIS2.",
                "Si concerné : gouvernance, mesures, notification ANSSI 24 h / 72 h — chantier à part.",
            ],
        )
    )
    items.append(
        _item(
            "rgpd-art32",
            "Mesures de sécurité (art. 32) vues via le checkup LAN / site",
            "RGPD art. 32 — mesures appropriées (pas une liste magique)",
            STATUT_CONFIRMER,
            "le checkup Guardia documente l'exposition réseau et, le cas échéant, le site",
            "Les findings LAN / site du rapport alimentent ce point. Ils ne prouvent ni "
            "l'absence de faille, ni une conformité art. 32. C'est un éclairage, un signalement.",
            [
                "Lire le chapitre restructuration et les findings d'exposition.",
                "Prioriser chiffrement, mots de passe, cloisonnement, sauvegardes testées.",
            ],
        )
    )

    n_signales = sum(1 for i in items if i["statut"] == STATUT_NON_VU)
    n_confirmer = sum(1 for i in items if i["statut"] == STATUT_CONFIRMER)
    n_declares = sum(1 for i in items if i["statut"] == STATUT_DECLARE)

    findings: list[Finding] = []
    if n_signales:
        findings.append(
            Finding(
                id="rgpd-synthese-signales",
                titre=f"Signalement RGPD : {n_signales} point(s) non observé(s) / non déclaré(s)",
                pourquoi_nuit=(
                    "Des exigences RGPD / LCEN / cookies n'apparaissent pas sur le périmètre "
                    "contrôlé, ou ont été déclarées absentes. Ce n'est pas un certificat : "
                    "c'est un signalement sur demande."
                ),
                preuve=(
                    f"{n_signales} signalé(s), {n_declares} déclaré(s), "
                    f"{n_confirmer} à confirmer"
                ),
                remede_etapes=[
                    "Traiter d'abord les lignes « non observé / non déclaré — signalé ».",
                    "Compléter la fiche RGPD (Configurer RGPD) pour les lignes « à confirmer ».",
                    "Ne pas afficher de badge « conforme RGPD » tant que ces points ne sont pas tenus.",
                ],
                qui_peut="responsable de traitement / prestataire / ÉOH en accompagnement",
                priorite="cette_semaine" if n_signales else "plus_tard",
                gravite=Gravite.HAUTE if n_signales >= 2 else Gravite.MOYENNE,
                hote=str(web.get("host") or "rgpd"),
            )
        )

    return {
        "nature": "signalement_sur_demande",
        "certificat": False,
        "disclaimer": DISCLAIMER,
        "controle_selon": [
            "RGPD (UE) 2016/679",
            "Loi Informatique et Libertés n° 78-17",
            "LCEN (mentions légales)",
            "Recommandations CNIL cookies et traceurs",
            "Recommandation CNIL consentement multi-terminaux (2026)",
            "Rappel NIS2 / SREN : vigilance, pas un classement",
        ],
        "site_url": web.get("url") or "",
        "config": cfg,
        "fiche_vide": blank,
        "items": items,
        "compteurs": {
            "observes": sum(1 for i in items if i["statut"] == STATUT_VU),
            "declares": n_declares,
            "signales": n_signales,
            "a_confirmer": n_confirmer,
            "hors": sum(1 for i in items if i["statut"] == STATUT_HORS),
        },
        "findings": findings,
    }
