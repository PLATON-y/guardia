"""Lynis — durcissement d'une machine Linux autorisée.

Lynis ne se lance pas « sur le LAN ». Il s'exécute sur la machine où il
est installé. Guardia l'orchestre sur le poste opérateur ÉOH (hygiène
de la station Kali), et invite à le lancer sur un Linux client si le
mandat le prévoit — sur CE poste, pas à distance. Absent : on continue.
"""
from __future__ import annotations

import shutil
import subprocess
from typing import Any

INVITE = (
    "Lynis n'est pas un scan réseau. Pour auditer un Linux client : "
    "l'installer sur CETTE machine, avec autorisation écrite, puis "
    "`sudo lynis audit system`. Kali opérateur : `sudo apt install lynis` "
    "puis `sudo lynis audit system --quick`."
)


def etat() -> dict[str, Any]:
    path = shutil.which("lynis")
    return {
        "installe": bool(path),
        "binaire": path or "",
        "invite": INVITE if not path else (
            "Présent. Guardia orchestre `lynis audit system --quick` "
            "sur le poste opérateur (--lynis). Un Linux client s'audite "
            "sur place, pas à distance."
        ),
        "install": "sudo apt install lynis",
        "lecture_seule": True,
        "distant": False,
        "orchestre": True,
        "lance": False,
        "etat": "present" if path else "absent",
        "note": (
            "Lynis présent. Guardia orchestre le poste opérateur."
            if path
            else "Lynis absent. Pas un scan LAN. On continue."
        ),
    }


def run_operateur(*, timeout: int = 90) -> dict[str, Any]:
    """Hygiène de la station Kali opérateur — pas un audit du client."""
    st = etat()
    st["orchestre"] = True
    if not st["installe"]:
        st["lance"] = False
        st["extrait"] = ""
        st["etat"] = "absent"
        return st
    argv = [st["binaire"], "audit", "system", "--quick", "--no-colors", "--dont-wait"]
    try:
        p = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        text = (p.stdout or "") + "\n" + (p.stderr or "")
    except Exception as exc:  # noqa: BLE001
        st["lance"] = False
        st["extrait"] = str(exc)
        st["etat"] = "erreur"
        return st
    st["lance"] = True
    st["etat"] = "ok"
    st["commande"] = " ".join(argv)
    st["extrait"] = text[-4000:]
    st["note"] = (
        "Résultat = poste opérateur ÉOH, pas le parc client. "
        "À joindre au dossier opérateur, pas à présenter comme un finding client."
    )
    return st
