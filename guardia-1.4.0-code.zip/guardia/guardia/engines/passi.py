"""Mode PASSI — workflow d’appui à la prestation, autorisations signées, pas une qualification.

Le module structure cinq activités publiques, les préconditions, les capacités
disponibles, les autorisations et la traçabilité. Les phases intrusives et
d'exploitation restent explicitement séparées et soumises à validation humaine.

Ce n'est pas un certificat. Le prestataire n'est pas qualifié PASSI ANSSI.
Les documents ne formulent aucune demande de qualification.
Les capacités logicielles (périmètre, traces, repro, validation, rapport)
ne sont pas une qualification organisationnelle.
"""
from __future__ import annotations

import shutil
from typing import Any

from guardia.core.identite import ASSOCIATION, NAF, RNA, SIREN, SIGLE
from guardia.core.models import Mission

DISCLAIMER = (
    "Prestataire non qualifié PASSI ANSSI. "
    "Outil professionnel d'Echoes of Hackers, association déclarée, ESS. "
    "Mode inspiré du référentiel public. "
    "Ceci n'est pas un certificat, pas une conformité, pas un document CNIL. "
    "Les capacités logicielles ne sont pas une qualification organisationnelle."
)

ATTESTATION_EXECUTE = (
    "Mode PASSI exécuté. Cinq domaines et six briques joués en lecture, "
    "autorisations signées. Ceci n'est pas un certificat. "
    "Prestataire non qualifié PASSI ANSSI."
)

ATTESTATION_NON = (
    "Mode PASSI non exécuté : les autorisations ne sont pas signées. "
    "La case à cocher ne suffit pas. Ceci n'est pas un certificat."
)

QUALIF_ORGA = (
    "La qualification PASSI ANSSI est organisationnelle "
    "(prestataire, processus, habilitations). "
    "Elle n'est pas un attribut du logiciel. "
    "Guardia démontre des capacités techniques équivalentes aux cinq domaines, "
    "en lecture. Le prestataire n'est pas qualifié PASSI ANSSI."
)

CAPACITES = (
    "Périmètre : CIDR, URL, exclusions, fenêtre, opérateur, client",
    "Traçabilité : mission → actif → test → résultat → preuve → constat → reco",
    "Reproductibilité : commande lecture dans le finding",
    "Validation humaine : confirmée / non reproductible / faux positif / à investiguer",
    "Rapport : grandes lignes, orchestre, hashes, conservation deux ans",
    "Journal : joué / sauté / absent",
    "Arrêt d'urgence à tout moment",
    "Avenant offensif jamais lancé automatiquement",
)

STATUTS_AUDITEUR: tuple[tuple[str, str], ...] = (
    ("a_investiguer", "À investiguer"),
    ("confirmee", "Confirmée"),
    ("non_reproductible", "Non reproductible"),
    ("faux_positif", "Faux positif"),
)

# Jamais lancés automatiquement, même présents sur le Kali.
JAMAIS_LANCER: tuple[str, ...] = (
    "metasploit-framework",
    "sqlmap",
    "hydra",
    "hashcat",
    "john",
    "burpsuite",
    "zaproxy",
    "bettercap",
    "bloodhound",
    "crackmapexec",
    "netexec",
    "impacket-scripts",
    "responder",
    "mimikatz",
    "feroxbuster",
    "ffuf",
    "gobuster",
    "masscan",
)

# Uniquement ce qui sert les cinq domaines. Pas de GUI, pas de doublon, pas d'OSINT hors mandat.
OUTILS_UTILES: tuple[str, ...] = (
    "nmap",
    "arp-scan",
    "dnsrecon",
    "whois",
    "dig",
    "host",
    "curl",
    "openssl",
    "lynis",
    "gvm-tools",
    "testssl.sh",
    "sslscan",
    "enum4linux",
    "smbmap",
    "nuclei",
    "nikto",
    "whatweb",
)

KALI_PARC: tuple[str, ...] = OUTILS_UTILES + JAMAIS_LANCER

# Cœur type PASSI (15) — moteur vs avenant vs hors. ZAP/Burp/BloodHound/Impacket jamais auto.
COEUR: tuple[dict[str, Any], ...] = (
    {"nom": "nmap", "brique": "recon", "role": "moteur"},
    {"nom": "nuclei", "brique": "vulns", "role": "moteur", "note": "tech/info/tls — pas d'exploit"},
    {
        "nom": "openvas",
        "brique": "vulns",
        "role": "moteur-lecture",
        "alias": "gvm-tools",
        "note": "GMP lecture, pas un Full and Fast auto",
    },
    {"nom": "zaproxy", "brique": "web", "role": "avenant"},
    {"nom": "lynis", "brique": "systeme", "role": "moteur", "note": "poste opérateur, pas le parc client"},
    {"nom": "testssl.sh", "brique": "web", "role": "moteur"},
    {
        "nom": "tshark",
        "brique": "reseau",
        "role": "moteur-si-pcap",
        "note": "pas de capture auto — pcap nommé en avenant",
    },
    {"nom": "whatweb", "brique": "web", "role": "moteur"},
    {
        "nom": "amass",
        "brique": "recon",
        "role": "hors-mandat",
        "note": "OSINT hors URL signée",
    },
    {"nom": "scapy", "brique": "reseau", "role": "avenant"},
    {"nom": "ghidra", "brique": "forensics", "role": "avenant"},
    {"nom": "yara", "brique": "forensics", "role": "avenant"},
    {"nom": "sleuthkit", "brique": "forensics", "role": "avenant"},
    {"nom": "bloodhound", "brique": "intrusion", "role": "avenant"},
    {"nom": "impacket-scripts", "brique": "intrusion", "role": "avenant"},
)

BRIQUES: tuple[dict[str, Any], ...] = (
    {
        "id": "recon",
        "nom": "Reconnaissance et cartographie",
        "role": "Cartographier le périmètre signé. Lecture. Pas d'OSINT hors URL.",
        "outils_moteur": ("nmap", "arp-scan", "dnsrecon", "whois", "dig", "host", "curl"),
        "outils_avenant": ("amass",),
        "statut": "moteur",
    },
    {
        "id": "vulns",
        "nom": "Vulnérabilités",
        "role": "Expositions en lecture. Nuclei info. GVM lecture GMP. Pas un Full and Fast auto.",
        "outils_moteur": ("nuclei", "gvm-tools"),
        "outils_avenant": (
            "openvas-full-and-fast",
            "bloodhound",
            "impacket-scripts",
            "metasploit-framework",
        ),
        "statut": "moteur",
    },
    {
        "id": "web",
        "nom": "Audit web",
        "role": "URL du mandat seulement. Bannières, TLS, techno.",
        "outils_moteur": ("whatweb", "nikto", "testssl.sh", "sslscan", "curl"),
        "outils_avenant": ("zaproxy", "burpsuite", "ffuf"),
        "statut": "moteur",
    },
    {
        "id": "systeme",
        "nom": "Audit système",
        "role": "Lynis sur le poste opérateur. Pas le parc client.",
        "outils_moteur": ("lynis",),
        "outils_avenant": (),
        "statut": "moteur",
    },
    {
        "id": "reseau",
        "nom": "Analyse réseau",
        "role": "Empreinte des services, TLS, SMB. Pas de capture auto.",
        "outils_moteur": ("nmap", "testssl.sh", "enum4linux", "smbmap"),
        "outils_avenant": ("tshark", "scapy", "masscan", "bettercap"),
        "statut": "moteur",
    },
    {
        "id": "forensics",
        "nom": "Forensics",
        "role": "Hors moteur LAN. Image disque nommée : avenant.",
        "outils_moteur": (),
        "outils_avenant": ("ghidra", "yara", "sleuthkit"),
        "statut": "documenté — moteur inerte",
    },
)

DOMAINES: tuple[dict[str, Any], ...] = (
    {
        "id": "architecture",
        "nom": "Audit d'architecture",
        "domaine_passi": "Architecture",
        "guardia": (
            "Cartographie LAN, desserte, DNS du mandat. Lecture. "
            "Site : whois / dig / host / curl — pas d'OSINT hors URL signée."
        ),
        "livrable": "Carte du parc, chantiers de cloisonnement, enregistrement du domaine.",
        "outils": ("nmap", "arp-scan", "dnsrecon", "whois", "dig", "host", "curl"),
        "hors_moteur": (),
        "niveau": 1,
        "brique": "recon",
    },
    {
        "id": "configuration",
        "nom": "Audit de configuration",
        "domaine_passi": "Configuration",
        "guardia": (
            "Lynis (poste opérateur), Greenbone lecture GMP, TLS, SMB, bannières HTTP. "
            "Pas un Full and Fast auto."
        ),
        "livrable": "Findings de configuration + remède. Hygiène ANSSI en signalement.",
        "outils": (
            "lynis",
            "gvm-tools",
            "testssl.sh",
            "sslscan",
            "enum4linux",
            "smbmap",
            "nuclei",
            "nikto",
            "whatweb",
            "openssl",
        ),
        "hors_moteur": (),
        "niveau": 1,
        "brique": "vulns",
    },
    {
        "id": "code",
        "nom": "Audit de code source",
        "domaine_passi": "Code source",
        "guardia": (
            "Hors moteur LAN. Dépôt nommé : avenant, poste autorisé, pas le CIDR client."
        ),
        "livrable": "Revue de code sur dépôt nommé. Hors Guardia LAN.",
        "outils": (),
        "hors_moteur": (),
        "niveau": 2,
        "absent_utile": ("trivy",),
        "brique": "forensics",
    },
    {
        "id": "intrusion",
        "nom": "Tests d'intrusion",
        "domaine_passi": "Tests d'intrusion",
        "guardia": (
            "Regard attaquant : mêmes faits, par où ça casse. On n'entre pas. "
            "Niveaux 2-3 : documents, moteur inerte."
        ),
        "livrable": "Chemins d'attaque possibles, ATT&CK observé, ordre de visée. Pas d'exploit.",
        "outils": ("nmap", "nuclei"),
        "hors_moteur": (),
        "niveau": 3,
        "avenant_groupe": (
            "Metasploit, Burp, ZAP, hydra, BloodHound, Impacket, ffuf, masscan : "
            "avenant, jamais lancés auto."
        ),
        "brique": "vulns",
    },
    {
        "id": "organisationnel",
        "nom": "Audit organisationnel et physique",
        "domaine_passi": "Organisationnel et physique",
        "guardia": (
            "Hygiène ANSSI, usages & droits, identités à la porte, "
            "signalement RGPD. Liasse signée obligatoire pour exécuter le mode. "
            "Périmètre, traces, validation humaine."
        ),
        "livrable": "Signalements, fiche usages, huit pièces, conservation deux ans.",
        "outils": (),
        "hors_moteur": (),
        "niveau": 0,
        "brique": "systeme",
    },
)


def _which(nom: str) -> str:
    aliases = {
        "gvm-tools": "gvm-cli",
        "gvm": "gvm-cli",
        "openvas": "gvm-cli",
        "testssl.sh": "testssl.sh",
        "ldap-utils": "ldapsearch",
        "snmp": "snmpget",
        "impacket-scripts": "impacket-smbclient",
        "sleuthkit": "fls",
    }
    bin_ = aliases.get(nom, nom)
    return shutil.which(bin_) or shutil.which(nom) or ""


def _outil_etat(nom: str) -> dict[str, Any]:
    path = _which(nom)
    return {
        "nom": nom,
        "present": bool(path),
        "chemin": path,
        "dans_parc_kali": nom in KALI_PARC,
        "utile": nom in OUTILS_UTILES,
        "jamais_lancer": nom in JAMAIS_LANCER,
    }


def perimetre(mission: Mission | None = None) -> dict[str, Any]:
    """CIDR, URL, exclusions, fenêtre — ce qui est signé, rien d'autre."""
    exclusions_defaut = (
        "exploitation",
        "hors_perimetre",
        "dump_annuaire",
        "brute_force",
        "malware_hunting",
    )
    if mission is None:
        return {
            "cidr": "",
            "url": "",
            "exclusions": list(exclusions_defaut),
            "fenetre": "",
            "operateur": "",
            "client": "",
            "signe": False,
        }
    ex = mission.extras or {}
    interdit = ex.get("interdit") or []
    if isinstance(interdit, str):
        interdit = [interdit]
    exclusions = [str(x) for x in interdit] or list(exclusions_defaut)
    fenetre = str(ex.get("fenetre") or ex.get("date") or "")
    return {
        "cidr": mission.cidr or "",
        "url": str(ex.get("site_url") or ""),
        "exclusions": exclusions,
        "fenetre": fenetre,
        "operateur": mission.operateur_nom or "",
        "client": mission.client or "",
        "signe": bool(mission.mandat_nda_signes and mission.operateur_signe),
    }


def tracer(finding: Any, mission: Mission | None = None, actif: str = "") -> dict[str, Any]:
    """Chaîne mission → actif → test → résultat → preuve → constat → reco."""
    if isinstance(finding, dict):
        remede = finding.get("remede_etapes") or finding.get("remede") or []
        if not isinstance(remede, list):
            remede = [str(remede)]
        return {
            "mission": (mission.client if mission else "") or "",
            "actif": actif or str(finding.get("hote") or ""),
            "test": str(finding.get("commande") or finding.get("preuve_repro") or ""),
            "resultat": str(finding.get("preuve") or ""),
            "preuve": str(finding.get("preuve") or ""),
            "constat": str(finding.get("observation") or finding.get("titre") or ""),
            "reco": [str(x) for x in remede],
            "statut_auditeur": str(finding.get("statut_auditeur") or "a_investiguer"),
            "finding_id": str(finding.get("id") or ""),
        }
    remede = getattr(finding, "remede_etapes", None) or []
    return {
        "mission": (mission.client if mission else "") or "",
        "actif": actif or str(getattr(finding, "hote", "") or ""),
        "test": str(getattr(finding, "commande", "") or getattr(finding, "preuve_repro", "") or ""),
        "resultat": str(getattr(finding, "preuve", "") or ""),
        "preuve": str(getattr(finding, "preuve", "") or ""),
        "constat": str(getattr(finding, "observation", "") or getattr(finding, "titre", "") or ""),
        "reco": [str(x) for x in remede],
        "statut_auditeur": str(getattr(finding, "statut_auditeur", "") or "a_investiguer"),
        "finding_id": str(getattr(finding, "id", "") or ""),
    }


def attacher_traces(offre: dict[str, Any], hosts: Any = None, mission: Mission | None = None) -> dict[str, Any]:
    """Remplit les traces à partir des findings déjà observés."""
    traces: list[dict[str, Any]] = []
    for h in hosts or []:
        ip = getattr(h, "ip", "") if not isinstance(h, dict) else str(h.get("ip") or "")
        findings = getattr(h, "findings", None) if not isinstance(h, dict) else h.get("findings")
        for f in findings or []:
            traces.append(tracer(f, mission, ip))
    offre["traces"] = traces
    offre["n_traces"] = len(traces)
    n_conf = sum(1 for t in traces if t.get("statut_auditeur") == "confirmee")
    n_inv = sum(1 for t in traces if t.get("statut_auditeur") == "a_investiguer")
    offre["validation"] = {
        "n": len(traces),
        "confirmees": n_conf,
        "a_investiguer": n_inv,
        "note": (
            "Un finding n'est pas un verdict. "
            "L'opérateur pose confirmée / non reproductible / faux positif / à investiguer."
        ),
    }
    return offre


def aptitude() -> dict[str, Any]:
    """Preuve d'aptitude professionnelle — faits, pas une demande."""
    outils = [_outil_etat(n) for n in OUTILS_UTILES]
    coeur = []
    for c in COEUR:
        nom = str(c.get("alias") or c["nom"])
        et = _outil_etat(nom)
        coeur.append({**c, "present": et["present"], "chemin": et["chemin"]})
    return {
        "outil": "Guardia",
        "editeur": f"{ASSOCIATION} ({SIGLE})",
        "forme": "association déclarée, entreprise de l'ESS",
        "rna": RNA,
        "siren": SIREN,
        "naf": NAF,
        "nature": (
            "Plateforme d'évaluation défensive LAN. Lecture. "
            "Opérateur identifié. Mandat écrit. Pas d'exploit."
        ),
        "niveaux_moteur": "0-1 lecture",
        "niveaux_documentes": "2-3 moteur inerte",
        "domaines": [d["domaine_passi"] for d in DOMAINES],
        "briques": [b["nom"] for b in BRIQUES],
        "controles": [
            "Autorisation écrite, datée, périmétrée — obligatoire",
            "Opérateur identifié, User-Agent nominatif, pas de furtivité",
            "Journal d'orchestre : joué / sauté / absent",
            "Hashes SHA-256 des pièces",
            "Avenant offensif jamais lancé automatiquement",
            "Arrêt d'urgence à tout moment",
            "Conservation deux ans, puis destruction ou prolongation écrite",
            "Validation humaine des findings (pas un verdict scanner)",
            "Traçabilité mission → actif → test → résultat → preuve → constat → reco",
        ],
        "capacites_logicielles": list(CAPACITES),
        "qualification_organisationnelle": QUALIF_ORGA,
        "outils_utiles": outils,
        "n_utiles_presents": sum(1 for o in outils if o["present"]),
        "n_utiles": len(outils),
        "coeur": coeur,
        "jamais_lancer": list(JAMAIS_LANCER),
        "passi_qualifie": False,
        "certificat": False,
    }


def _briques_etat() -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for b in BRIQUES:
        moteur = [_outil_etat(n) for n in (b.get("outils_moteur") or ())]
        avenant = [
            {**_outil_etat(n), "etat": "avenant", "why": "jamais lancé auto"}
            for n in (b.get("outils_avenant") or ())
        ]
        n_ok = sum(1 for o in moteur if o["present"])
        out.append(
            {
                "id": b["id"],
                "nom": b["nom"],
                "role": b["role"],
                "statut": b["statut"],
                "outils_moteur": moteur,
                "outils_avenant": avenant,
                "jouables_aujourd_hui": n_ok,
                "n_avenant": len(avenant),
            }
        )
    return out


def build_offre(
    mission: Mission | None = None,
    *,
    autorisations: dict[str, Any] | None = None,
    equipe: str = "red",
) -> dict[str, Any]:
    """Offre. Pas une qualification. Red team + liasse signée pour exécuter."""
    apt = aptitude()
    peri = perimetre(mission)
    domaines: list[dict[str, Any]] = []
    for d in DOMAINES:
        outils = [_outil_etat(n) for n in (d.get("outils") or ())]
        n_ok = sum(1 for o in outils if o["present"])
        domaines.append(
            {
                "id": d["id"],
                "nom": d["nom"],
                "domaine_passi": d["domaine_passi"],
                "guardia": d["guardia"],
                "livrable": d["livrable"],
                "niveau": d["niveau"],
                "brique": d.get("brique") or "",
                "outils": outils,
                "hors_moteur": [],
                "absents_utiles": list(d.get("absent_utile") or []),
                "avenant_groupe": d.get("avenant_groupe") or "",
                "jouables_aujourd_hui": n_ok,
                "avenant_kali": 1 if d.get("avenant_groupe") else 0,
                "statut": (
                    "moteur"
                    if d["niveau"] <= 1
                    else "documenté — moteur inerte"
                    if d["niveau"] >= 2
                    else "liasse"
                ),
            }
        )
    auth = autorisations or {}
    complet = bool(auth.get("complet"))
    try:
        from guardia.engines.passi_assessment import requested_activities
        activities = requested_activities(mission or Mission())
    except Exception:
        activities = ["intrusion"]
    intrusion_requested = "intrusion" in activities
    passi_requested = bool((getattr(mission, "extras", None) or {}).get("passi"))
    execute = complet and (equipe == "red" if intrusion_requested else (equipe == "red" or (passi_requested and equipe == "blue")))
    presentable = execute
    if execute:
        statut = "mode PASSI exécuté — pas un certificat"
        attestation = ATTESTATION_EXECUTE
    elif equipe != "red" and not (passi_requested and not intrusion_requested):
        statut = "éteint — red team requis"
        attestation = ATTESTATION_NON
    else:
        statut = "non exécuté — autorisations non signées"
        attestation = ATTESTATION_NON
    briques = _briques_etat()
    return {
        "orchestre": True,
        "equipe": equipe,
        "disclaimer": DISCLAIMER,
        "attestation": attestation,
        "execute": execute,
        "passi_qualifie": False,
        "certificat": False,
        "presentable": presentable,
        "statut": statut,
        "domaines": domaines,
        "n_domaines": len(domaines),
        "n_moteur": sum(1 for x in domaines if x["niveau"] <= 1),
        "n_avenant": sum(1 for x in domaines if x["niveau"] >= 2),
        "briques": briques,
        "n_briques": len(briques),
        "coeur": apt.get("coeur") or [],
        "perimetre": peri,
        "traces": [],
        "n_traces": 0,
        "capacites": list(CAPACITES),
        "qualification_organisationnelle": QUALIF_ORGA,
        "aptitude": apt,
        "kali": {
            "parc": list(OUTILS_UTILES),
            "note": (
                "Outils utiles seulement. Absent : on continue. "
                "GUI, doublons et avenant : hors orchestre."
            ),
        },
        "offre": (
            "Cinq domaines inspirés du référentiel public. "
            "Six briques techniques (recon, vulns, web, système, réseau, forensics). "
            "Guardia joue architecture, configuration et organisationnel en lecture. "
            "Code, intrusion, forensics : documents, moteur inerte. "
            "ZAP, Burp, BloodHound, Impacket, Metasploit, ffuf : avenant, jamais auto. "
            "Autorisations signées obligatoires. "
            "Capacités logicielles, pas une qualification organisationnelle."
        ),
        "jamais_lancer": list(JAMAIS_LANCER),
    }


def _jouer_briques(offre: dict[str, Any], *, execute: bool, journal: Any | None) -> list[dict[str, Any]]:
    """Vue architecture : moteur vs avenant. Ne relance pas les binaires."""
    play: list[dict[str, Any]] = []
    n_avenant = 0
    if journal is not None:
        journal.note("Architecture six briques — capacités logicielles, pas une qualification")
    for b in offre.get("briques") or []:
        actions: list[dict[str, Any]] = []
        bid = str(b.get("id") or "")
        if journal is not None:
            journal.note(f"Brique {b.get('nom')} — {b.get('statut')}")
        if execute:
            for o in b.get("outils_moteur") or []:
                nom = str(o.get("nom") or "")
                if nom in JAMAIS_LANCER:
                    continue
                present = bool(o.get("present"))
                if str(b.get("statut") or "").startswith("document"):
                    etat = "skip"
                    why = "hors moteur LAN — avenant"
                else:
                    etat = "joue" if present else "skip"
                    why = "lecture — brique" if present else "absent de ce Kali — on continue"
                actions.append({"nom": nom, "etat": etat, "why": why, "present": present})
            for o in b.get("outils_avenant") or []:
                nom = str(o.get("nom") or "")
                n_avenant += 1
                why = "avenant — jamais lancé auto"
                actions.append({"nom": nom, "etat": "avenant", "why": why, "present": bool(o.get("present"))})
                if journal is not None:
                    journal.skip(f"PASSI avenant {nom}", why)
        else:
            for o in (b.get("outils_moteur") or []) + (b.get("outils_avenant") or []):
                nom = str(o.get("nom") or "")
                present = bool(o.get("present"))
                avenant = nom in JAMAIS_LANCER or str(o.get("etat") or "") == "avenant"
                actions.append(
                    {
                        "nom": nom,
                        "etat": "avenant" if avenant else ("pret" if present else "absent"),
                        "why": (
                            "avenant — non lancé"
                            if avenant
                            else "présent — non lancé (mode non exécuté)"
                            if present
                            else "absent"
                        ),
                        "present": present,
                    }
                )
        play.append({"id": bid, "brique": b.get("nom"), "actions": actions})
    offre["play_briques"] = play
    offre["n_briques_avenant"] = n_avenant
    return play


def orchestrer(
    mission: Mission | None = None,
    *,
    autorisations: dict[str, Any] | None = None,
    equipe: str = "red",
    journal: Any | None = None,
    hosts: Any = None,
) -> dict[str, Any]:
    """Joue les cinq domaines et les six briques. Avenant condensé. Liasse signée = exécuté."""
    offre = build_offre(mission, autorisations=autorisations, equipe=equipe)
    play: list[dict[str, Any]] = []
    n_joue = 0
    n_skip = 0
    n_avenant = 0
    if journal is not None:
        journal.note(DISCLAIMER)
        journal.note(str(offre.get("attestation") or offre.get("statut") or ""))
        peri = offre.get("perimetre") or {}
        journal.note(
            "Périmètre "
            f"CIDR={peri.get('cidr') or '—'} "
            f"URL={peri.get('url') or '—'} "
            f"fenêtre={peri.get('fenetre') or '—'}"
        )
    if not offre.get("execute"):
        why = offre.get("statut") or "autorisations non signées"
        if journal is not None:
            journal.skip("Mode PASSI", why)
        for d in offre.get("domaines") or []:
            actions = []
            for o in d.get("outils") or []:
                nom = str(o.get("nom") or "")
                present = bool(o.get("present"))
                actions.append(
                    {
                        "nom": nom,
                        "etat": "pret" if present else "absent",
                        "why": "présent — non lancé (mode non exécuté)" if present else "absent",
                        "present": present,
                    }
                )
            play.append({"id": d.get("id"), "domaine": d.get("domaine_passi"), "actions": actions})
        offre["play"] = play
        offre["n_joue"] = 0
        offre["n_skip"] = 0
        offre["n_avenant"] = 0
        _jouer_briques(offre, execute=False, journal=journal)
        attacher_traces(offre, hosts, mission)
        return _attacher_v22(offre, mission, autorisations=autorisations, equipe=equipe, hosts=hosts, execute=False)

    for d in offre.get("domaines") or []:
        actions: list[dict[str, Any]] = []
        niveau = int(d.get("niveau") or 0)
        did = str(d.get("id") or "")
        if journal is not None:
            journal.note(f"Domaine {d.get('domaine_passi')} — {d.get('statut')}")
        if did == "organisationnel":
            n_joue += 1
            actions.append(
                {
                    "nom": "liasse + hygiène",
                    "etat": "joue",
                    "why": "organisationnel — pièces signées, périmètre, traces",
                    "present": True,
                }
            )
            if journal is not None:
                journal.outil("PASSI organisationnel", "liasse + hygiène", "ok")
        if did == "code":
            n_skip += 1
            why = "hors moteur LAN — avenant dépôt nommé"
            actions.append({"nom": "code source", "etat": "skip", "why": why, "present": False})
            if journal is not None:
                journal.skip("PASSI code source", why)
            for a in d.get("absents_utiles") or []:
                n_skip += 1
                actions.append(
                    {"nom": a, "etat": "skip", "why": "absent de ce Kali", "present": False}
                )
                if journal is not None:
                    journal.skip(f"PASSI {a}", "absent de ce Kali")
        if did == "intrusion" and d.get("avenant_groupe"):
            n_avenant += 1
            why = str(d.get("avenant_groupe"))
            actions.append({"nom": "avenant intrusion", "etat": "avenant", "why": why, "present": False})
            if journal is not None:
                journal.skip("PASSI avenant intrusion", "jamais lancé auto")
        for o in d.get("outils") or []:
            nom = str(o.get("nom") or "")
            if nom in JAMAIS_LANCER:
                continue
            present = bool(o.get("present"))
            if niveau >= 2:
                etat = "regard" if present else "skip"
                why = "lecture seulement — pas d'intrusion" if present else "absent — on continue"
            else:
                etat = "joue" if present else "skip"
                why = "lecture — moteur" if present else "absent de ce Kali — on continue"
            actions.append({"nom": nom, "etat": etat, "why": why, "present": present})
            if etat in ("joue", "regard"):
                n_joue += 1
                if journal is not None:
                    journal.outil(f"PASSI {nom}", did, "ok")
            else:
                n_skip += 1
                if journal is not None:
                    journal.skip(f"PASSI {nom}", why)
        play.append({"id": did, "domaine": d.get("domaine_passi"), "actions": actions})
    offre["play"] = play
    offre["n_joue"] = n_joue
    offre["n_skip"] = n_skip
    offre["n_avenant"] = n_avenant
    _jouer_briques(offre, execute=True, journal=journal)
    attacher_traces(offre, hosts, mission)
    return _attacher_v22(offre, mission, autorisations=autorisations, equipe=equipe, hosts=hosts, execute=True)


def _attacher_v22(
    offre: dict[str, Any],
    mission: Mission | None,
    *,
    autorisations: dict[str, Any] | None,
    equipe: str,
    hosts: Any,
    execute: bool,
) -> dict[str, Any]:
    """Relie le dossier v2.2 (aptitude, cadrage, matrice) à l'orchestre."""
    try:
        from guardia.passi import construire_dossier
    except Exception:
        return offre
    try:
        dossier = construire_dossier(
            mission,
            autorisations=autorisations or {},
            equipe=equipe,
            hosts=hosts,
            execute=execute,
            outils_etat=None,
        )
    except Exception:
        return offre
    offre["v22"] = dossier
    offre["aptitude_prealable"] = dossier.get("aptitude") or {}
    offre["cadrage"] = dossier.get("cadrage") or {}
    offre["matrice"] = dossier.get("matrice") or []
    offre["activites"] = dossier.get("activites") or []
    offre["activites_demandees"] = dossier.get("activites_demandees") or []
    offre["couverture"] = dossier.get("couverture") or {}
    offre["cockpit"] = dossier.get("cockpit") or {}
    return offre
