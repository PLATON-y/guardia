"""Pack autorisations red — les huit pièces, jouées une à une.

Case red : « Autorisations ». Pour le mode PASSI, les pièces requises
doivent être signées — la case ne suffit pas. Pièce 04 (Red) devient
obligatoire. Incomplet = mode PASSI non exécuté.
"""
from __future__ import annotations

from pathlib import Path
from typing import Any

from guardia.core.dossier import PIECES, etat, generer
from guardia.core.identite import operateur_a_signe, operateur_de
from guardia.core.models import Mission
from guardia.core.paths import RAPPORTS


def build_autorisations(
    mission: Mission,
    *,
    generer_liasse: bool = False,
    pour_passi: bool = False,
) -> dict[str, Any]:
    st = etat(mission)
    pieces = []
    for p in st.get("pieces") or []:
        requis = bool(p.get("requis"))
        if pour_passi and p.get("id") == "04-autorisation-red-team":
            requis = True
        signe = bool(p.get("signe"))
        pieces.append(
            {
                "id": p.get("id"),
                "titre": p.get("titre"),
                "requis": requis,
                "signe": signe,
                "etat": "ok" if signe else ("manque" if requis else "facultatif"),
            }
        )
    op = operateur_a_signe(mission)
    mandat = bool(getattr(mission, "mandat_nda_signes", False))
    extras: dict[str, Any] = {}
    journal_extra = [
        {
            "id": "operateur",
            "titre": f"Opérateur {operateur_de(mission)}",
            "requis": True,
            "signe": op,
            "etat": "ok" if op else "manque",
        },
        {
            "id": "mandat",
            "titre": "Mandat + NDA cochés",
            "requis": True,
            "signe": mandat,
            "etat": "ok" if mandat else "manque",
        },
        {
            "id": "fenetre",
            "titre": "Fenêtre de dates / CIDR du jour",
            "requis": True,
            "signe": bool(getattr(mission, "cidr", None) or (mission.extras or {}).get("cidr")),
            "etat": "ok" if (getattr(mission, "cidr", None) or (mission.extras or {}).get("cidr")) else "manque",
        },
    ]
    manquantes = [x["titre"] for x in pieces + journal_extra if x["requis"] and not x["signe"]]
    complet = not manquantes
    out: dict[str, Any] = {
        "orchestre": True,
        "pour_passi": pour_passi,
        "parc": st.get("parc"),
        "niveau": st.get("niveau"),
        "niveau_libelle": st.get("niveau_libelle"),
        "pieces": pieces,
        "extra": journal_extra,
        "manquantes": manquantes,
        "complet": complet,
        "presentable": complet,
        "passi": st.get("passi"),
        "note": (
            "Liasse signée. Mode PASSI exécutable."
            if complet and pour_passi
            else "Liasse complète."
            if complet
            else "Liasse incomplète : " + ", ".join(manquantes) + ". Mode PASSI non exécuté."
            if pour_passi
            else "Liasse incomplète : " + ", ".join(manquantes) + "."
        ),
    }
    if generer_liasse:
        dest = RAPPORTS / "dossier-autorisations"
        try:
            extras = generer(mission, dest)
            out["genere"] = extras
            out["dossier_path"] = str(dest)
        except Exception as exc:  # noqa: BLE001
            out["genere_erreur"] = str(exc)
    _ = Path
    return out
