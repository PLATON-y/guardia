"""Identités — ce que la porte dit.

Pas un audit IAM 3CT. Pas un dump. Pas de liste de logins.
En Red : on dit si l'annuaire se montre, si le LDAP est en clair,
si un portail SSO se nomme, si Guest / FTP anonyme / RDP sans NLA
sont là. Le cycle de vie, les orphelins, le « qui a validé » :
hors visite.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import CheckupResult, Host

_SSO = (
    "lemonldap",
    "adfs",
    "keycloak",
    "authelia",
    "authentik",
    "okta",
    "entra",
    "freeipa",
    "cas ",
    "glpi",
    "sso",
    "openid",
    "saml",
)


def _blob(h: Host) -> str:
    parts = [h.kind, h.hostname, h.ip]
    for p in h.ports or []:
        if isinstance(p, dict):
            parts.append(str(p.get("port") or ""))
            parts.append(str(p.get("name") or ""))
            parts.append(str(p.get("product") or ""))
            parts.append(str(p.get("version") or ""))
            sc = p.get("scripts") or {}
            if isinstance(sc, dict):
                parts.extend(str(v) for v in sc.values())
    for f in h.findings or []:
        parts.append(f.id)
        parts.append(f.titre)
        parts.append(getattr(f, "pourquoi_nuit", "") or "")
    return " ".join(parts).lower()


def build_identites(result: CheckupResult) -> dict[str, Any]:
    hosts = result.hosts or []
    portes: list[dict[str, str]] = []
    sso: list[str] = []

    def add(titre: str, preuve: str, statut: str) -> None:
        if any(p["titre"] == titre for p in portes):
            return
        portes.append({"titre": titre, "preuve": preuve, "statut": statut})

    for h in hosts:
        b = _blob(h)
        if "389" in b or "ldap" in b or "namingcontext" in b:
            add("Annuaire joignable", f"{h.ip} — LDAP / rootDSE. On n'entre pas.", "prouvé")
        if "389" in b and "636" not in b:
            add("LDAP en clair", f"{h.ip} : 389 vu, 636 non vu.", "prouvé")
        if "88" in b or "kerberos" in b:
            add("Kerberos vu", f"{h.ip} port 88.", "prouvé")
        if "smb-security-mode" in b and ("disabled" in b or "not required" in b or "message_signing: disabled" in b):
            add("SMB sans signing", f"{h.ip} smb-security-mode.", "prouvé")
        if "3389" in b or "rdp" in b:
            nla = "nla" in b or "rdp-ntlm" in b
            add(
                "Bureau à distance",
                f"{h.ip} 3389. NLA : {'vu' if nla else 'non confirmé'}.",
                "prouvé",
            )
        if "ftp-anon" in b or ("ftp" in b and "anon" in b):
            add("FTP anonyme", f"{h.ip} — porte sans mot de passe.", "prouvé")
        if "guest" in b or "everyone" in b:
            add("Partage trop large", f"{h.ip} — Guest / Everyone (noms, pas le contenu).", "prouvé")
        for needle in _SSO:
            if needle in b:
                sso.append(f"{h.ip} — empreinte « {needle.strip()} »")
    web = result.website or {}
    wblob = " ".join(str(x) for x in web.values()).lower() if web else ""
    for needle in _SSO:
        if needle in wblob:
            sso.append(f"site du mandat — empreinte « {needle.strip()} »")

    hors = [
        "Qui a accès à quoi, et pourquoi — hors visite (IGA / revue des droits).",
        "Comptes orphelins / joiners-leavers vs RH — il faudrait l'export RH, pas un dump.",
        "MFA réellement enrôlé — déclaratif, pas lu sur le LAN.",
        "Schéma Supann / cycle de vie — audit de processus, pas un checkup.",
    ]
    return {
        "titre": "Identités — ce que la porte dit",
        "limite": (
            "Pas un audit IAM. Pas un dump d'annuaire. Aucun nom de personne. "
            "Le regard s'arrête à la porte."
        ),
        "portes": portes,
        "sso": sso[:6],
        "hors_visite": hors,
        "lecture_seule": True,
    }
