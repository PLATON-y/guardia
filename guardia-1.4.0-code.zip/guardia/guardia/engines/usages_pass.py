"""Passage lecture-seule des portes (partages, NFS, LDAP, FTP anonyme).

Nmap scripts informatifs. On liste les portes, on n'entre pas.
Borné aux hôtes qui ont déjà 21/139/445/2049/389/636.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
import time
from pathlib import Path

from guardia.core.models import Host
from guardia.engines.audit_pass import _merge_ports, _parse_xml
from guardia.engines.parc_roles import ports_of

log = logging.getLogger("guardia.usages")

USAGES_PORTS = "21,88,111,139,389,445,636,2049"
USAGES_SCRIPTS = "smb-enum-shares,nfs-showmount,ldap-rootdse,ftp-anon"


def select_usages_targets(hosts: list[Host], *, max_hosts: int = 24) -> list[Host]:
    interesting: list[Host] = []
    for h in hosts:
        if ports_of(h) & {21, 88, 111, 139, 389, 445, 636, 2049, 548}:
            interesting.append(h)
    return interesting[:max_hosts]


def run_usages_pass(
    hosts: list[Host],
    *,
    remaining_sec: float | None = None,
    timeout: int = 180,
) -> tuple[list[Host], list[str]]:
    warns: list[str] = []
    targets = select_usages_targets(hosts)
    if not targets:
        warns.append("usages: aucun hôte avec porte fichiers/annuaire/ftp à observer")
        return [], warns
    if not shutil.which("nmap"):
        warns.append("usages: nmap absent — chapitre fiche + ports seulement")
        return [], warns
    if remaining_sec is not None and remaining_sec < 25:
        warns.append("usages: observation des portes sautée (budget)")
        return [], warns

    # déjà joué via audit-full ?
    already = False
    for h in targets:
        for p in h.ports or []:
            sc = p.get("scripts") or {}
            if isinstance(sc, dict) and "smb-enum-shares" in sc:
                already = True
                break
        if already:
            break
    if already:
        log.info("usages pass: smb-enum-shares déjà présent — pas de second nmap")
        return targets, warns

    ips = [h.ip for h in targets]
    host_map = {h.ip: h for h in targets}
    to = timeout
    if remaining_sec is not None:
        to = max(40, min(timeout, int(remaining_sec) - 8))

    log.info("usages pass: %d hôte(s) — scripts=%s", len(ips), USAGES_SCRIPTS)
    t0 = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="guardia-usages-") as td:
        xml_path = Path(td) / "usages.xml"
        cmd = [
            "nmap",
            "-sV",
            "--version-light",
            "-p",
            USAGES_PORTS,
            "--script",
            USAGES_SCRIPTS,
            "-oX",
            str(xml_path),
            *ips,
        ]
        try:
            from guardia.core.operator import set_active_subprocess, get_operator

            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            set_active_subprocess(proc)
            try:
                try:
                    proc.communicate(timeout=to)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.communicate()
                    warns.append(f"usages: timeout nmap après {to}s — parse partiel")
            finally:
                set_active_subprocess(None)
            if get_operator().should_stop_phase():
                warns.append("usages: arrêt opérateur pendant l'observation des portes")
        except OSError as exc:
            warns.append(f"usages nmap: {exc}")
            return targets, warns

        xml_text = xml_path.read_text(encoding="utf-8", errors="replace") if xml_path.exists() else ""
        parsed = _parse_xml(xml_text)
        for ip, ports_parsed in parsed.items():
            h = host_map.get(ip)
            if h:
                _merge_ports(h, ports_parsed)
                if "usages_pass" not in h.notes:
                    h.notes.append("usages_pass")

    log.info("usages pass terminé en %.1fs (%d cibles)", time.monotonic() - t0, len(targets))
    return targets, warns
