"""Greenbone / OpenVAS — Guardia orchestre la lecture GMP, pas un Full and Fast.

Un scan GVM « Full and Fast » est long, authentifié, et sort du budget
d'une visite. Guardia ne le lance pas toute seule. Elle PARLE à GVM :
version, feeds, configs — lecture. Absent / daemon muet : on note, on
enchaîne. L'export GSA se joint au dossier ; Guardia n'invente pas de CVE.
"""
from __future__ import annotations

import os
import shutil
import subprocess
from typing import Any

INVITE = (
    "Sur Kali : `sudo apt install gvm` puis `sudo gvm-setup` "
    "(premier setup long, mot de passe admin affiché une fois). "
    "Démarrer : `sudo gvm-start`. Guardia lit la version GMP "
    "(`gvm-cli socket --xml '<get_version/>'`). Un scan Full and Fast "
    "reste GSA (navigateur), hors budget visite. Joindre l'export au dossier."
)


def etat() -> dict[str, Any]:
    bins = {
        "gvm-cli": shutil.which("gvm-cli") or "",
        "gvm-start": shutil.which("gvm-start") or "",
        "gvmd": shutil.which("gvmd") or "",
        "openvas": shutil.which("openvas") or "",
        "gsa": shutil.which("gsad") or shutil.which("gsa") or "",
    }
    installe = any(bins.values())
    return {
        "installe": installe,
        "binaires": {k: v for k, v in bins.items() if v},
        "invite": INVITE,
        "install": "sudo apt install gvm && sudo gvm-setup",
        "orchestre": True,
        "lance": False,
        "etat": "present" if installe else "absent",
        "note": (
            "Greenbone présent. Guardia orchestre la lecture GMP (version / feeds)."
            if installe
            else "Greenbone / OpenVAS absent. Pilier vulnérabilités : "
            "l'installer donne des CVE structurées. Guardia orchestre : "
            "absent = on continue, ce n'est plus une invitation oubliée."
        ),
        "lecture_seule": True,
    }


def _gmp(xml: str, timeout: int = 12) -> dict[str, Any]:
    cli = shutil.which("gvm-cli")
    if not cli:
        return {"ok": False, "extrait": "gvm-cli absent", "rc": 127}
    user = os.environ.get("GVM_USER") or os.environ.get("GVM_USERNAME") or ""
    password = os.environ.get("GVM_PASSWORD") or os.environ.get("GVM_PASS") or ""
    socket = os.environ.get("GVM_SOCKET") or "/run/gvmd/gvmd.sock"
    attempts: list[list[str]] = [[cli, "socket", "--xml", xml]]
    if socket:
        attempts.append([cli, "socket", "--socketpath", socket, "--xml", xml])
    if user and password:
        attempts.append(
            [cli, "socket", "--gmp-username", user, "--gmp-password", password, "--xml", xml]
        )
    last = {"ok": False, "extrait": "gvm-cli : aucune réponse", "rc": -1}
    for argv in attempts:
        try:
            p = subprocess.run(
                argv,
                capture_output=True,
                text=True,
                timeout=timeout,
                check=False,
            )
        except FileNotFoundError:
            return {"ok": False, "extrait": "gvm-cli introuvable", "rc": 127}
        except subprocess.TimeoutExpired:
            last = {"ok": False, "extrait": f"timeout {timeout}s", "rc": -1}
            continue
        except OSError as exc:
            last = {"ok": False, "extrait": str(exc), "rc": -1}
            continue
        out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
        if p.returncode == 0 and "<" in out:
            return {"ok": True, "extrait": out[:4000], "rc": 0, "commande": " ".join(argv[:4])}
        last = {"ok": False, "extrait": (out or f"rc={p.returncode}")[:800], "rc": p.returncode}
    return last


def run(*, cidr: str = "", timeout: int = 16) -> dict[str, Any]:
    """Lecture GMP. Jamais un scan Full and Fast automatique."""
    _ = cidr
    st = etat()
    st["orchestre"] = True
    if not st["installe"]:
        st["lance"] = False
        st["etat"] = "absent"
        return st
    if not shutil.which("gvm-cli"):
        st["lance"] = False
        st["etat"] = "present-sans-cli"
        st["note"] = (
            "GVM partiellement installé (daemon vu, gvm-cli absent). "
            "`sudo apt install gvm-tools`. On continue."
        )
        return st
    ver = _gmp("<get_version/>", timeout=timeout)
    st["commande"] = "gvm-cli socket --xml '<get_version/>'"
    st["extrait"] = ver.get("extrait") or ""
    if not ver.get("ok"):
        st["lance"] = False
        st["etat"] = "present-down"
        st["note"] = (
            "gvm-cli présent, daemon muet. `sudo gvm-start` puis relancer. "
            "On continue — pas un refus au client."
        )
        return st
    st["lance"] = True
    st["etat"] = "ok"
    feeds = _gmp("<get_feeds/>", timeout=timeout)
    st["feeds"] = (feeds.get("extrait") or "")[:1500]
    st["feeds_ok"] = bool(feeds.get("ok"))
    st["note"] = (
        "GVM joint. Lecture version / feeds. "
        "Scan Full and Fast : GSA (navigateur), hors budget d'une visite Guardia. "
        "Joindre l'export au dossier — Guardia n'invente pas de CVE."
    )
    return st
