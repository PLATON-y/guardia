"""Passage audit poussé (défensif) — après un run classique.

Sélectionne les hôtes « intéressants » du premier rapport (findings /
posture ≠ ok) et approfondit l'empreinte services (ports admin + scripts
nmap *informatifs* sûrs). Aucun exploit.

Niveaux :
  - standard : http-title, ssl-cert, smb-security-mode
  - full     : + http-headers, ssh-hostkey, ssl-enum-ciphers
"""
from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
import time
import xml.etree.ElementTree as ET
from pathlib import Path

from guardia.core.models import Host, Posture
from guardia.engines.audit_catalog import catalog_for_level

log = logging.getLogger("guardia.audit")

# Ports typiques d'un audit hygiène (pas un -p- complet)
AUDIT_PORTS = (
    "21,22,23,25,53,80,110,139,143,443,445,587,993,995,"
    "1433,1521,3306,3389,5432,5900,6379,8080,8443,9100,9200,27017"
)

# Légèrement plus large pour audit full (toujours borné)
AUDIT_PORTS_FULL = (
    "21,22,23,25,53,80,110,111,135,139,143,389,443,445,465,587,636,993,995,"
    "1433,1521,2049,3306,3389,5432,5900,5985,5986,6379,8080,8443,8888,"
    "9100,9200,9443,27017"
)

# Scripts nmap catégorie informative / safe — pas de vuln/exploit
AUDIT_SCRIPTS_STANDARD = "http-title,ssl-cert,smb-security-mode"
AUDIT_SCRIPTS_FULL = (
    "http-title,ssl-cert,smb-security-mode,"
    "http-headers,ssh-hostkey,ssl-enum-ciphers,"
    "smb-enum-shares,nfs-showmount,ldap-rootdse"
)

# Compat anciens imports
AUDIT_SCRIPTS = AUDIT_SCRIPTS_STANDARD


def scripts_for_level(level: str = "standard") -> str:
    return AUDIT_SCRIPTS_FULL if (level or "").strip().lower() == "full" else AUDIT_SCRIPTS_STANDARD


def ports_for_level(level: str = "standard") -> str:
    return AUDIT_PORTS_FULL if (level or "").strip().lower() == "full" else AUDIT_PORTS


def select_audit_targets(hosts: list[Host], *, max_hosts: int = 32) -> list[Host]:
    """Priorise hôtes à findings ou posture surveillance/risque/critique."""
    interesting: list[Host] = []
    rest: list[Host] = []
    for h in hosts:
        if h.findings or h.posture in (
            Posture.SURVEILLANCE,
            Posture.RISQUE,
            Posture.CRITIQUE,
        ):
            interesting.append(h)
        else:
            rest.append(h)
    # Si parc petit et rien de flagué : audit léger sur tout (démo)
    if not interesting and len(hosts) <= 12:
        return hosts[:max_hosts]
    out = interesting + rest
    return out[:max_hosts]


def _merge_ports(host: Host, new_ports: list[dict]) -> None:
    by_port = {int(p.get("port", -1)): p for p in (host.ports or []) if "port" in p}
    for p in new_ports:
        try:
            num = int(p.get("port", -1))
        except (TypeError, ValueError):
            continue
        if num < 0:
            continue
        old = by_port.get(num)
        if old is None:
            by_port[num] = p
        else:
            # enrichit bannières / scripts sans perdre l'existant
            for k, v in p.items():
                if v and (not old.get(k) or k in ("script", "scripts", "product", "version", "name")):
                    if k == "scripts" and isinstance(v, dict) and isinstance(old.get("scripts"), dict):
                        old["scripts"].update(v)
                    else:
                        old[k] = v
            by_port[num] = old
    host.ports = sorted(by_port.values(), key=lambda x: int(x.get("port", 0)))


def _parse_xml(xml_text: str) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    if not xml_text.strip():
        return out
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return out
    for host_el in root.findall("host"):
        addr = ""
        for a in host_el.findall("address"):
            if a.get("addrtype") == "ipv4":
                addr = a.get("addr") or ""
        if not addr:
            continue
        ports: list[dict] = []
        ports_el = host_el.find("ports")
        if ports_el is None:
            continue
        for port_el in ports_el.findall("port"):
            state = port_el.find("state")
            if state is None or state.get("state") != "open":
                continue
            svc = port_el.find("service")
            scripts: dict[str, str] = {}
            for sc in port_el.findall("script"):
                sid = sc.get("id") or ""
                # scripts de portes / ciphers : garder assez pour parser
                longish = {
                    "ssl-enum-ciphers",
                    "smb-enum-shares",
                    "nfs-showmount",
                    "ldap-rootdse",
                    "ftp-anon",
                }
                lim = 2500 if sid in longish else 500
                scripts[sid] = (sc.get("output") or "")[:lim]
            entry = {
                "port": int(port_el.get("portid") or 0),
                "proto": port_el.get("protocol") or "tcp",
                "name": (svc.get("name") if svc is not None else "") or "",
                "product": (svc.get("product") if svc is not None else "") or "",
                "version": (svc.get("version") if svc is not None else "") or "",
                "scripts": scripts,
            }
            ports.append(entry)
        out[addr] = ports
    return out


def run_audit_pass(
    hosts: list[Host],
    *,
    remaining_sec: float | None = None,
    timeout: int = 240,
    level: str = "standard",
) -> tuple[list[Host], list[str]]:
    """Approfondit les cibles. Retourne (hôtes audités, avertissements).

    level: "standard" | "full"
    """
    warns: list[str] = []
    lv = (level or "standard").strip().lower()
    if lv not in ("standard", "full"):
        lv = "standard"
    max_hosts = 64 if lv == "full" else 32
    targets = select_audit_targets(hosts, max_hosts=max_hosts)
    if not targets:
        warns.append("audit: aucun hôte à approfondir")
        return [], warns
    if not shutil.which("nmap"):
        warns.append("audit: nmap absent")
        return [], warns
    if remaining_sec is not None and remaining_sec < 30:
        warns.append("audit sauté (budget temps restant trop faible)")
        return [], warns

    ips = [h.ip for h in targets]
    host_map = {h.ip: h for h in targets}
    to = timeout
    if remaining_sec is not None:
        to = max(45, min(timeout, int(remaining_sec) - 10))
    # full un peu plus long (scripts supplémentaires)
    if lv == "full":
        to = max(to, min(timeout + 120, int(remaining_sec or timeout + 120) - 5 if remaining_sec else timeout + 120))

    scripts = scripts_for_level(lv)
    ports = ports_for_level(lv)
    cat_n = len(catalog_for_level(lv))
    log.info(
        "audit pass [%s]: %d hôte(s) — ports=%s scripts=%s (catalogue %d capacités)",
        lv,
        len(ips),
        ports[:40] + ("…" if len(ports) > 40 else ""),
        scripts,
        cat_n,
    )
    t0 = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="guardia-audit-") as td:
        xml_path = Path(td) / "audit.xml"
        cmd = [
            "nmap",
            "-sV",
            "-p",
            ports,
            "--version-light",
            "--script",
            scripts,
            "-oX",
            str(xml_path),
            *ips,
        ]
        try:
            from guardia.core.operator import set_active_subprocess, get_operator

            proc = subprocess.Popen(
                cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True
            )
            set_active_subprocess(proc)
            try:
                try:
                    proc.communicate(timeout=to)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.communicate()
                    warns.append(f"audit: timeout nmap après {to}s — parse partiel")
            finally:
                set_active_subprocess(None)
            if get_operator().should_stop_phase():
                warns.append("audit: arrêt opérateur pendant le passage")
        except OSError as exc:
            warns.append(f"audit nmap: {exc}")
            return targets, warns

        xml_text = xml_path.read_text(encoding="utf-8", errors="replace") if xml_path.exists() else ""
        parsed = _parse_xml(xml_text)
        for ip, ports_parsed in parsed.items():
            h = host_map.get(ip)
            if h:
                _merge_ports(h, ports_parsed)
                note = f"audit_pass:{lv}"
                if note not in h.notes:
                    h.notes.append(note)

    log.info(
        "audit pass [%s] terminé en %.1fs (%d cibles)",
        lv,
        time.monotonic() - t0,
        len(targets),
    )
    return targets, warns
