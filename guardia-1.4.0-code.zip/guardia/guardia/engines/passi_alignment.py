"""Matrice opérationnelle d'alignement PASSI v2.2.

Ce module ne déclare jamais une qualification PASSI. Il transforme les cinq
activités couvertes par le référentiel en objectifs vérifiables dans Guardia
et calcule un état de couverture à partir des données réellement présentes.

Les identifiants G-PASSI-* sont des identifiants internes Guardia et ne sont
pas des références officielles ANSSI.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Iterable


SOURCE = {
    "reference": "ANSSI PASSI — référentiel d'exigences v2.2",
    "reference_date": "2024-08-01",
    "evaluation_grid": "PASSI — trame d'évaluation v1.2",
    "url": "https://cyber.gouv.fr/offre-de-service/solutions-certifiees-et-qualifiees/comprendre-levaluation-de-securite/qualification-de-produit-et-services/referentiels-qualification/",
}

DOMAINS = (
    ("organisationnel_physique", "Audit organisationnel et physique"),
    ("architecture", "Audit d'architecture"),
    ("configuration", "Audit de configuration"),
    ("code_source", "Audit de code source"),
    ("intrusion", "Tests d'intrusion"),
)

STATUSES = (
    "covered",
    "partial",
    "supported_with_human_gate",
    "not_applicable",
    "not_covered",
)


@dataclass(frozen=True)
class Control:
    id: str
    family: str
    title: str
    objective: str
    evidence: tuple[str, ...]
    implemented_by: tuple[str, ...]
    human_gate: bool = False
    notes: str = ""


CONTROLS: tuple[Control, ...] = (
    Control("G-PASSI-PRE-01", "preparation", "Périmètre explicite", "Définir les cibles et exclusions avant les actions.", ("mission.scope",), ("core.mission_yaml", "core.models.Mission")),
    Control("G-PASSI-PRE-02", "preparation", "Objectifs et critères de mission", "Conserver les objectifs et critères d'évaluation de la mission.", ("mission.objectives", "mission.criteria"), ("core.models.Mission",), True),
    Control("G-PASSI-PRE-03", "preparation", "Autorisation écrite", "Bloquer les actions encadrées tant que les pièces attendues ne sont pas réunies.", ("authorizations",), ("engines.autorisations", "engines.passi")),
    Control("G-PASSI-PRE-04", "preparation", "Opérateur identifié", "Associer l'exécution et la validation à un opérateur identifié.", ("operator",), ("core.identite", "core.autorisation")),
    Control("G-PASSI-PRE-05", "preparation", "Note de cadrage", "Conserver une fiche structurée de cadrage, portée et contraintes.", ("framing",), ("engines.passi_alignment",), True),
    Control("G-PASSI-PRE-06", "preparation", "Approche par les risques / échantillonnage", "Permettre d'expliquer la profondeur ou l'échantillonnage retenu.", ("mission.depth", "risk_budget"), ("core.models.Mission", "core.budget"), True),
    Control("G-PASSI-PRE-07", "preparation", "Sauvegarde / continuité", "Tracer les mesures de sauvegarde et la capacité d'arrêt.", ("emergency_stop", "backup"), ("core.autorisation", "core.dossier"), True),
    Control("G-PASSI-PRE-08", "preparation", "Suivi des changements de cadrage", "Tracer les changements de périmètre et validations associées.", ("change_log",), ("core.orchestrate",), True),

    Control("G-PASSI-ORG-01", "organisationnel_physique", "Politiques et procédures", "Permettre la collecte structurée des politiques et procédures de sécurité.", ("questionnaire", "documents"), ("engines.usages", "engines.hygiene"), True),
    Control("G-PASSI-ORG-02", "organisationnel_physique", "Entretiens et observations", "Permettre de rattacher entretiens et observations à des contrôles.", ("interviews", "observations"), ("engines.usages",), True),
    Control("G-PASSI-ORG-03", "organisationnel_physique", "Mise en pratique", "Distinguer existence d'une règle et mise en pratique observée.", ("practice_evidence",), ("engines.hygiene", "engines.usages"), True),
    Control("G-PASSI-ORG-04", "organisationnel_physique", "Processus physiques", "Tracer les éléments liés à la sécurité physique et aux supports.", ("physical_processes",), ("engines.usages",), True),
    Control("G-PASSI-ORG-05", "organisationnel_physique", "Validation humaine", "Soumettre les constats organisationnels à l'auditeur.", ("review" ,), ("engines.passi"), True),

    Control("G-PASSI-ARC-01", "architecture", "Inventaire et cartographie", "Cartographier les actifs et services observés dans le périmètre.", ("hosts", "services", "asset_graph"), ("engines.discover", "engines.enrich", "cerveau.graphe")),
    Control("G-PASSI-ARC-02", "architecture", "Flux et exposition", "Identifier les services exposés et les relations pertinentes.", ("hosts", "correlation", "exposure_paths"), ("engines.services", "engines.correlation", "cerveau.adaptatif")),
    Control("G-PASSI-ARC-03", "architecture", "Frontières et segmentation", "Permettre de documenter zones, frontières et décisions de segmentation.", ("architecture_review",), ("cerveau.graphe",), True),
    Control("G-PASSI-ARC-04", "architecture", "Justification par les preuves", "Associer les conclusions d'architecture aux observations source.", ("evidence",), ("cerveau.evidence", "engines.correlation")),
    Control("G-PASSI-ARC-05", "architecture", "Revue auditeur", "Permettre de confirmer ou contester les conclusions d'architecture.", ("review",), ("report.html_report",), True),

    Control("G-PASSI-CFG-01", "configuration", "Contrôles de configuration", "Exécuter des contrôles de configuration adaptés au composant ciblé.", ("config_checks",), ("engines.lynis", "engines.greenbone", "engines.audit_pass")),
    Control("G-PASSI-CFG-02", "configuration", "Contrôle des composants réseau", "Évaluer l'hygiène des services, protocoles et équipements exposés.", ("services", "network_checks"), ("engines.services", "engines.netinfo", "engines.audit_pass")),
    Control("G-PASSI-CFG-03", "configuration", "Non vérifiable / non applicable", "Ne pas confondre absence de preuve et conformité.", ("status_model",), ("core.models", "report.html_report")),
    Control("G-PASSI-CFG-04", "configuration", "Preuves de configuration", "Conserver la provenance des contrôles de configuration.", ("evidence",), ("cerveau.evidence", "report.json_report")),
    Control("G-PASSI-CFG-05", "configuration", "Approfondissement ciblé", "Approfondir les contrôles à partir des observations pertinentes.", ("adaptive_decisions",), ("cerveau.adaptatif",), True),
    Control("G-PASSI-CFG-06", "configuration", "Validation humaine", "Permettre la validation des écarts de configuration.", ("review",), ("report.html_report",), True),

    Control("G-PASSI-CODE-01", "code_source", "Entrée du code", "Prévoir un dépôt ou périmètre de code explicitement nommé.", ("code_scope",), ("core.models.Mission",), True),
    Control("G-PASSI-CODE-02", "code_source", "Analyse statique", "Permettre une analyse automatique du code source lorsque le corpus est fourni.", ("sast", "dependencies"), ("engines.trivy",), True),
    Control("G-PASSI-CODE-03", "code_source", "Conditions de compilation", "Conserver les paramètres de build utiles à l'analyse lorsque nécessaires.", ("build",), ("core.models.Mission",), True),
    Control("G-PASSI-CODE-04", "code_source", "Revue humaine", "Ne pas transformer automatiquement une alerte statique en finding confirmé.", ("review",), ("engines.correlation",), True),
    Control("G-PASSI-CODE-05", "code_source", "Preuves de code", "Associer un constat à un fichier, emplacement ou artefact de code.", ("code_evidence",), ("cerveau.evidence",), True),

    Control("G-PASSI-INTR-01", "intrusion", "Préconditions d'intrusion", "Vérifier périmètre, horaires, sources et autorisations avant tout test intrusif.", ("authorization", "roe"), ("engines.autorisations", "core.autorisation"), True),
    Control("G-PASSI-INTR-02", "intrusion", "Cibles et adresses de provenance", "Conserver les cibles et les adresses de provenance prévues.", ("targets", "sources"), ("core.models.Mission", "engines.autorisations"), True),
    Control("G-PASSI-INTR-03", "intrusion", "Fenêtre d'autorisation", "Conserver la fenêtre temporelle de l'autorisation.", ("time_window",), ("core.models.Mission", "engines.autorisations"), True),
    Control("G-PASSI-INTR-04", "intrusion", "Journal des tests", "Journaliser les actions, résultats et interruptions.", ("journal",), ("core.orchestrate", "report.json_report")),
    Control("G-PASSI-INTR-05", "intrusion", "Arrêt d'urgence", "Permettre l'arrêt de la campagne et conserver l'état final.", ("emergency_stop",), ("core.dossier", "core.orchestrate"), True),
    Control("G-PASSI-INTR-06", "intrusion", "Maîtrise des risques de perturbation", "Évaluer et limiter les actions pouvant perturber la production ou les environnements mutualisés.", ("risk_budget", "policy"), ("core.budget", "cerveau.policy"), True),
    Control("G-PASSI-INTR-07", "intrusion", "Validation des résultats d'intrusion", "Faire valider humainement les conclusions et leur impact.", ("review",), ("engines.passi", "report.html_report"), True),

    Control("G-PASSI-REP-01", "restitution", "Traçabilité complète", "Relier mission, actif, action, résultat, preuve, constat et recommandation.", ("trace",), ("engines.passi", "cerveau.evidence")),
    Control("G-PASSI-REP-02", "restitution", "Résultats et limitations", "Présenter ce qui a été exécuté, bloqué, absent ou non vérifiable.", ("journal", "coverage"), ("report.html_report", "report.json_report")),
    Control("G-PASSI-REP-03", "restitution", "Intégrité des preuves", "Conserver les identifiants et l'intégrité des pièces importantes.", ("sha256",), ("cerveau.evidence", "core.dossier")),
    Control("G-PASSI-REP-04", "restitution", "Rapport technique et synthèse", "Produire une restitution exploitable par l'auditeur et le commanditaire.", ("html", "pdf", "json"), ("report.html_report", "report.pdf_report", "report.json_report")),
    Control("G-PASSI-REP-05", "restitution", "Suivi et audit de contrôle", "Préserver les éléments nécessaires à une vérification ultérieure des écarts corrigés.", ("findings", "evidence", "retention"), ("cerveau.evidence", "report.recap"), True),
)


def _get(data: Any, *keys: str, default: Any = None) -> Any:
    cur = data
    for key in keys:
        if isinstance(cur, dict):
            cur = cur.get(key, default)
        else:
            cur = getattr(cur, key, default)
        if cur is None:
            return default
    return cur


def _mission_has_scope(mission: Any) -> bool:
    return bool(_get(mission, "cidr") or _get(mission, "extras", default={}).get("site_url") or _get(mission, "extras", default={}).get("scope"))


def _requested_code(mission: Any) -> bool:
    ex = _get(mission, "extras", default={}) or {}
    acts = ex.get("passi_activities") or ex.get("activities") or []
    return "code_source" in acts or ex.get("code_source") is True


def _requested_org(mission: Any) -> bool:
    ex = _get(mission, "extras", default={}) or {}
    acts = ex.get("passi_activities") or ex.get("activities") or []
    return "organisationnel_physique" in acts or ex.get("organisationnel_physique") is True


def _requested_intrusion(mission: Any, result: Any) -> bool:
    return str(_get(result, "equipe", default="blue")) == "red" or bool((_get(mission, "extras", default={}) or {}).get("passi"))


def _status(control: Control, mission: Any, result: Any) -> tuple[str, str]:
    code = control.id
    auth = _get(result, "autorisations", default={}) or {}
    complete_auth = bool(auth.get("complet"))
    hosts = _get(result, "hosts", default=[]) or []
    journal = _get(result, "journal", default={}) or {}
    have_journal = bool(journal)
    evidence = _get(result, "correlation", default={}) or {}
    adaptive = _get(result, "adaptatif", default={}) or {}
    if code == "G-PASSI-PRE-01":
        ok = _mission_has_scope(mission)
        return ("covered" if ok else "partial", "Périmètre explicite détecté dans la mission." if ok else "Périmètre incomplet ou absent.")
    if code == "G-PASSI-PRE-02":
        return ("partial", "Objectifs/critères restent soumis au cadrage auditeur.")
    if code == "G-PASSI-PRE-03":
        return ("covered" if complete_auth else "partial", "Liasse d'autorisation complète." if complete_auth else "Liasse incomplète.")
    if code == "G-PASSI-PRE-04":
        ok = bool(_get(mission, "operateur_nom"))
        return ("covered" if ok else "partial", "Opérateur identifié." if ok else "Opérateur à renseigner.")
    if code in {"G-PASSI-PRE-05", "G-PASSI-PRE-06", "G-PASSI-PRE-07", "G-PASSI-PRE-08"}:
        return ("supported_with_human_gate", "Fonction outillée ; validation/cadrage humain requis.")
    if code.startswith("G-PASSI-ORG-"):
        if not _requested_org(mission):
            return ("not_applicable", "Activité organisationnelle non demandée dans cette mission.")
        return ("partial" if control.human_gate else "covered", "Collecte outillée ; revue humaine nécessaire." if control.human_gate else "Capacité disponible dans le produit.")
    if code.startswith("G-PASSI-ARC-"):
        ok = bool(hosts) or bool(_get(result, "adaptatif", default={}).get("graphe"))
        return ("covered" if ok else "partial", "Actifs/services observés." if ok else "Cartographie à produire sur la mission.")
    if code.startswith("G-PASSI-CFG-"):
        ok = bool(hosts) or bool(_get(result, "lynis")) or bool(_get(result, "greenbone"))
        if not ok:
            return ("partial", "Aucune preuve de configuration dans le résultat courant.")
        return ("supported_with_human_gate" if control.human_gate else "covered", "Contrôle outillé avec revue humaine." if control.human_gate else "Contrôle de configuration couvert.")
    if code.startswith("G-PASSI-CODE-"):
        if not _requested_code(mission):
            return ("not_applicable", "Audit de code non demandé.")
        return ("not_covered", "Le produit prépare le workflow mais aucun corpus de code n'est fourni dans cette mission.")
    if code.startswith("G-PASSI-INTR-"):
        if not _requested_intrusion(mission, result):
            return ("not_applicable", "Tests d'intrusion non demandés.")
        if code in {"G-PASSI-INTR-01", "G-PASSI-INTR-02", "G-PASSI-INTR-03"}:
            return ("supported_with_human_gate" if complete_auth else "partial", "Préconditions contrôlées par la liasse et validation humaine." if complete_auth else "Autorisation insuffisante.")
        if code == "G-PASSI-INTR-04":
            return ("covered" if have_journal else "partial", "Journal d'exécution disponible." if have_journal else "Journal à produire.")
        return ("supported_with_human_gate", "Capacité de gouvernance présente ; test intrusif réel soumis à autorisation et validation humaines.")
    if code.startswith("G-PASSI-REP-"):
        if code == "G-PASSI-REP-01":
            return ("covered" if evidence or _get(result, "passi", default={}).get("traces") else "partial", "Traçabilité disponible." if evidence or _get(result, "passi", default={}).get("traces") else "Traçabilité à enrichir.")
        if code == "G-PASSI-REP-02":
            return ("covered" if have_journal else "partial", "Journal et exclusions disponibles." if have_journal else "Journal absent.")
        if code == "G-PASSI-REP-03":
            return ("supported_with_human_gate", "Intégrité des preuves outillée ; conservation et contrôle restent à valider.")
        return ("covered" if _get(result, "recap") or _get(result, "passi") else "partial", "Restitution structurée disponible." if _get(result, "recap") or _get(result, "passi") else "Rapport à produire.")
    return ("partial", "À évaluer.")


def build_alignment(mission: Any, result: Any | None = None) -> dict[str, Any]:
    result = result or {}
    rows: list[dict[str, Any]] = []
    for control in CONTROLS:
        status, rationale = _status(control, mission, result)
        rows.append({
            "id": control.id,
            "family": control.family,
            "title": control.title,
            "objective": control.objective,
            "status": status,
            "rationale": rationale,
            "evidence": list(control.evidence),
            "implemented_by": list(control.implemented_by),
            "human_gate": control.human_gate,
            "notes": control.notes,
        })

    by_domain: dict[str, dict[str, int]] = {}
    for domain_id, domain_name in DOMAINS:
        items = [r for r in rows if r["family"] == domain_id]
        # Les contrôles génériques préparation/restitution sont exclus du score d'activité.
        counts = {s: sum(1 for r in items if r["status"] == s) for s in STATUSES}
        total = len(items)
        effective = counts["covered"] + counts["supported_with_human_gate"] * 0.75 + counts["partial"] * 0.5
        score = round(100 * effective / total) if total else 0
        by_domain[domain_id] = {**counts, "total": total, "score": score, "name": domain_name}

    operational = [r for r in rows if r["family"] in {"preparation", "restitution"}]
    eff = sum(1 if r["status"] == "covered" else 0.75 if r["status"] == "supported_with_human_gate" else 0.5 if r["status"] == "partial" else 0 for r in operational)
    op_score = round(100 * eff / len(operational)) if operational else 0
    return {
        "source": SOURCE,
        "guardia_identifiers": True,
        "disclaimer": "Matrice interne d'alignement : elle ne constitue ni qualification, ni certification, ni avis ANSSI.",
        "domains": list(DOMAINS),
        "controls": rows,
        "by_domain": by_domain,
        "operational": {"total": len(operational), "score": op_score},
        "summary": {
            "controls": len(rows),
            "covered": sum(1 for r in rows if r["status"] == "covered"),
            "partial": sum(1 for r in rows if r["status"] == "partial"),
            "human_gate": sum(1 for r in rows if r["status"] == "supported_with_human_gate"),
            "not_applicable": sum(1 for r in rows if r["status"] == "not_applicable"),
            "not_covered": sum(1 for r in rows if r["status"] == "not_covered"),
            "score_operational": op_score,
        },
    }


def as_markdown(alignment: dict[str, Any]) -> str:
    lines = [
        "# Matrice d'alignement PASSI v2.2 — Guardia",
        "",
        alignment.get("disclaimer", ""),
        "",
        f"Source : {SOURCE['reference']} ({SOURCE['reference_date']}) ; trame d'évaluation {SOURCE['evaluation_grid']}.",
        "",
        f"Score opérationnel de gouvernance : **{alignment.get('operational', {}).get('score', 0)} %**",
        "",
        "| ID Guardia | Famille | Objectif | État | Justification |",
        "|---|---|---|---|---|",
    ]
    for row in alignment.get("controls") or []:
        lines.append(f"| {row['id']} | {row['family']} | {row['objective']} | {row['status']} | {row['rationale']} |")
    lines += ["", "## Couverture par activité", "", "| Activité | Score | Couvert | Partiel | Gate humain | N/A | Non couvert |", "|---|---:|---:|---:|---:|---:|---:|"]
    for did, data in (alignment.get("by_domain") or {}).items():
        lines.append(f"| {data['name']} | {data['score']} % | {data['covered']} | {data['partial']} | {data['supported_with_human_gate']} | {data['not_applicable']} | {data['not_covered']} |")
    return "\n".join(lines)
