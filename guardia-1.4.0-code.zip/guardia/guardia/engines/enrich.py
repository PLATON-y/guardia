"""Enrichissement post-discover défensif (DNS, NetBIOS, mDNS) — soft-fail."""
from __future__ import annotations

import logging
import re
import shutil
import socket
import subprocess
from pathlib import Path

from guardia.core.models import Host

log = logging.getLogger("guardia.enrich")


def enrich_hosts(
    hosts: list[Host],
    workdir: Path | None = None,
    *,
    profondeur: str = "standard",
    remaining_sec: float | None = None,
) -> list[str]:
    """Enrichit hostname / notes. Retourne avertissements soft (outils absents, etc.)."""
    warns: list[str] = []
    if remaining_sec is not None and remaining_sec < 5:
        warns.append("enrich sauté (budget temps restant trop faible)")
        return warns
    if not hosts:
        return warns
    try:
        _reverse_dns(hosts)
    except Exception as exc:  # noqa: BLE001
        warns.append(f"reverse-dns: {exc}")
        log.warning("reverse-dns: %s", exc)
    try:
        w = _netbios(hosts)
        warns.extend(w)
    except Exception as exc:  # noqa: BLE001
        warns.append(f"netbios: {exc}")
        log.warning("netbios: %s", exc)
    try:
        w = _mdns(hosts)
        warns.extend(w)
    except Exception as exc:  # noqa: BLE001
        warns.append(f"mdns: {exc}")
        log.warning("mdns: %s", exc)
    if profondeur in ("full", "approfondi"):
        try:
            w = _nmap_list_light(hosts, workdir)
            warns.extend(w)
        except Exception as exc:  # noqa: BLE001
            warns.append(f"nmap-sL: {exc}")
            log.warning("nmap-sL: %s", exc)
    try:
        from guardia.engines.osi_map import attach_host_osi

        attach_host_osi(hosts)
    except Exception as exc:  # noqa: BLE001
        warns.append(f"osi_map: {exc}")
        log.debug("osi_map enrich: %s", exc)
    return warns


def _reverse_dns(hosts: list[Host]) -> None:
    for h in hosts:
        if h.hostname:
            continue
        try:
            name, _, _ = socket.gethostbyaddr(h.ip)
            if name and name != h.ip:
                h.hostname = name.rstrip(".")
                h.notes.append(f"hostname via reverse DNS: {h.hostname}")
        except (socket.herror, socket.gaierror, OSError):
            continue


def _netbios(hosts: list[Host]) -> list[str]:
    warns: list[str] = []
    nbtscan = shutil.which("nbtscan")
    if not nbtscan:
        warns.append("nbtscan absent — NetBIOS soft-skip")
        return warns
    by_ip = {h.ip: h for h in hosts}
    # nbtscan accepte une plage ou une IP ; on passe les IPs une par une / petit lot
    ips = [h.ip for h in hosts]
    for i in range(0, len(ips), 32):
        chunk = ips[i : i + 32]
        try:
            proc = subprocess.run(
                [nbtscan, "-s", ":", *chunk],
                capture_output=True,
                text=True,
                timeout=max(20, 2 * len(chunk)),
                check=False,
            )
        except (subprocess.TimeoutExpired, OSError) as exc:
            warns.append(f"nbtscan: {exc}")
            break
        for line in (proc.stdout or "").splitlines():
            # format typique: IP:NAME:server:user:mac...
            parts = [p.strip() for p in line.split(":")]
            if len(parts) < 2:
                continue
            ip, name = parts[0], parts[1]
            if ip in by_ip and name and name not in ("", "<unknown>"):
                h = by_ip[ip]
                if not h.hostname:
                    h.hostname = name
                h.notes.append(f"NetBIOS: {name}")
    return warns


def _mdns(hosts: list[Host]) -> list[str]:
    warns: list[str] = []
    avahi = shutil.which("avahi-browse")
    if not avahi:
        warns.append("avahi-browse absent — mDNS soft-skip")
        return warns
    try:
        proc = subprocess.run(
            [avahi, "-atrk"],
            capture_output=True,
            text=True,
            timeout=25,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        return [f"avahi-browse: {exc}"]
    text = proc.stdout or ""
    # Cherche IPv4 et noms dans la sortie
    ip_re = re.compile(r"address\s*=\s*\[(\d+\.\d+\.\d+\.\d+)\]", re.I)
    name_re = re.compile(r"hostname\s*=\s*\[([^\]]+)\]", re.I)
    by_ip = {h.ip: h for h in hosts}
    cur_ip = ""
    cur_host = ""
    for line in text.splitlines():
        m = ip_re.search(line)
        if m:
            cur_ip = m.group(1)
        m2 = name_re.search(line)
        if m2:
            cur_host = m2.group(1).rstrip(".")
        if cur_ip and cur_host and cur_ip in by_ip:
            h = by_ip[cur_ip]
            if not h.hostname:
                h.hostname = cur_host
            note = f"mDNS: {cur_host}"
            if note not in h.notes:
                h.notes.append(note)
            cur_ip, cur_host = "", ""
    return warns


def _nmap_list_light(hosts: list[Host], workdir: Path | None) -> list[str]:
    """nmap -sL sur les IPs déjà connues — reverse DNS nmap si utile."""
    warns: list[str] = []
    if not shutil.which("nmap"):
        return ["nmap absent — -sL soft-skip"]
    ips = [h.ip for h in hosts]
    if not ips:
        return warns
    out_dir = workdir or Path("/tmp")
    out_dir.mkdir(parents=True, exist_ok=True)
    out_base = out_dir / "enrich-sl"
    try:
        subprocess.run(
            ["nmap", "-sL", "-oG", str(out_base) + ".gnmap", *ips],
            capture_output=True,
            text=True,
            timeout=60,
            check=False,
        )
    except (subprocess.TimeoutExpired, OSError) as exc:
        return [f"nmap -sL: {exc}"]
    gnmap = Path(str(out_base) + ".gnmap")
    if not gnmap.is_file():
        return warns
    by_ip = {h.ip: h for h in hosts}
    try:
        text = gnmap.read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        return [f"nmap -sL read: {exc}"]
    # Host: 1.2.3.4 (name.local) Status: ...
    for line in text.splitlines():
        m = re.match(r"Host:\s+(\S+)\s+\(([^)]*)\)", line)
        if not m:
            continue
        ip, name = m.group(1), m.group(2).strip()
        if ip in by_ip and name and not by_ip[ip].hostname:
            by_ip[ip].hostname = name
            by_ip[ip].notes.append(f"hostname via nmap -sL: {name}")
    return warns
