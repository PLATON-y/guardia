"""Garde LLM — au lancement, Guardia exige une capacité d'explication.

Ordre :
1. llama-server déjà ouvert (2443, 18111, Ollama, URL mémorisée, GUARDIA_LLM_URL) ;
2. démarrage de llama-server + GGUF local, si trouvés ;
3. garde locale déterministe — reformule, n'invente aucune preuve.

Une mission ne démarre jamais « à l'aveugle ». La garde locale n'est pas un
modèle de langage : elle porte le même contrat (pas d'invention de faille).
"""
from __future__ import annotations

import json
import logging
import os
import socket
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

log = logging.getLogger("guardia.llm")

# Session possédée : llama-server reste vivant après le démarrage auto.
_SESSION: Any = None

# 2443 : port opérateur ÉOH (pixel-book). 18111 : historique Guardia.
DEFAULT_PORT = int(os.environ.get("GUARDIA_LLM_PORT") or "2443")
DEFAULT_URL = (os.environ.get("GUARDIA_LLM_URL") or "http://127.0.0.1:2443").rstrip("/")

COMMANDS_SANS_LLM = frozenset(
    {"about", "version", "identite", "llm", "queen", "liens", "inventaire", "help", None}
)
COMMANDS_DEMARRAGE = frozenset({"run", "llm", "ui"})

PROBE_PATHS = (
    "/health",
    "/v1/models",
    "/props",
    "/api/tags",
    "/",
)


def _cache_path() -> Path:
    try:
        from guardia.core.paths import RAPPORTS

        return RAPPORTS / "llm-url.txt"
    except Exception:
        return Path.home() / ".guardia-llm-url"


def _lire_cache() -> str:
    try:
        p = _cache_path()
        if p.is_file():
            return p.read_text(encoding="utf-8").strip().rstrip("/")
    except OSError:
        pass
    return ""


def _ecrire_cache(url: str) -> None:
    try:
        p = _cache_path()
        p.parent.mkdir(parents=True, exist_ok=True)
        p.write_text(url.rstrip("/") + "\n", encoding="utf-8")
    except OSError:
        pass


def candidate_urls(explicit: str | None = None) -> list[str]:
    """Ordre : URL forcée, env, cache, 2443, 18111, Ollama, llama.cpp."""
    out: list[str] = []

    def _add(u: str) -> None:
        u = (u or "").strip().rstrip("/")
        if u and u not in out and u.startswith("http"):
            out.append(u)

    _add(explicit or "")
    _add(os.environ.get("GUARDIA_LLM_URL") or "")
    _add(_lire_cache())
    _add("http://127.0.0.1:2443")
    _add("http://127.0.0.1:18111")
    _add("http://127.0.0.1:11434")
    _add("http://127.0.0.1:1234")
    _add("http://127.0.0.1:8765")
    return out


def _tcp_open(url: str, timeout: float = 0.25) -> bool:
    try:
        from urllib.parse import urlparse

        u = urlparse(url)
        host = u.hostname or "127.0.0.1"
        port = u.port or (443 if u.scheme == "https" else 80)
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except OSError:
        return False


def probe(url: str | None = None, timeout: float = 1.2) -> dict[str, Any]:
    """État d'un serveur. Ne démarre rien."""
    base = (url or DEFAULT_URL).rstrip("/")
    if not _tcp_open(base, timeout=min(timeout, 0.4)):
        return {
            "ok": False,
            "mode": "absent",
            "url": base,
            "why": "port fermé : {u}".format(u=base),
        }
    for path in PROBE_PATHS:
        try:
            req = urllib.request.Request(base + path, method="GET")
            with urllib.request.urlopen(req, timeout=timeout) as rep:
                if 200 <= getattr(rep, "status", 200) < 300:
                    body = b""
                    try:
                        body = rep.read(800)
                    except Exception:
                        pass
                    mode = "llama"
                    if path == "/api/tags" or b"ollama" in body.lower():
                        mode = "ollama"
                    elif path == "/v1/models":
                        mode = "openai-compat"
                    return {
                        "ok": True,
                        "mode": mode,
                        "url": base,
                        "why": "{u}{p} répond".format(u=base, p=path),
                    }
        except (OSError, urllib.error.URLError, TimeoutError, ValueError):
            continue
    return {
        "ok": False,
        "mode": "absent",
        "url": base,
        "why": "port ouvert mais pas d'API LLM sur {u}".format(u=base),
    }


def probe_many(urls: list[str] | None = None, timeout: float = 1.0) -> dict[str, Any]:
    probed: list[str] = []
    for u in urls or candidate_urls():
        probed.append(u)
        st = probe(u, timeout=timeout)
        if st["ok"]:
            st["probed"] = probed
            return st
    return {
        "ok": False,
        "mode": "absent",
        "url": (urls or candidate_urls() or [DEFAULT_URL])[0],
        "why": "aucun serveur LLM sur {n} URL".format(n=len(probed)),
        "probed": probed,
    }


def ressources() -> dict[str, Any]:
    """Où sont le GGUF et llama-server — y compris le disque USB Guardia."""
    from guardia.engines.llm_polish import LAST_SEARCH, resolve_model, resolve_server

    model = resolve_model(None)
    server = resolve_server(None)
    return {
        "model": str(model) if model else "",
        "server": str(server) if server else "",
        "model_ok": bool(model),
        "server_ok": bool(server),
        "search_dirs": list(LAST_SEARCH.get("dirs") or [])[:12],
        "search_found": list(LAST_SEARCH.get("found") or [])[:8],
        "skipped_small": list(LAST_SEARCH.get("skipped_small") or [])[:8],
    }


def _demarrer(url: str) -> dict[str, Any]:
    global _SESSION
    from guardia.engines.llm_polish import LlmSession, resolve_model, resolve_server, resolve_ngl

    model = resolve_model(None)
    server = resolve_server(None)
    if not model or not server:
        return {
            "ok": False,
            "mode": "absent",
            "url": url,
            "why": "GGUF ou llama-server introuvable (model={m} server={s})".format(
                m=bool(model), s=bool(server)
            ),
            "model": str(model or ""),
            "server": str(server or ""),
        }
    ngl, why_ngl = resolve_ngl(99, allow_cpu=True)
    print(
        "LLM : démarrage llama-server modèle={m} url={u} ngl={n} ({w})…".format(
            m=model.name, u=url, n=ngl, w=why_ngl
        ),
        flush=True,
    )
    sess = LlmSession(
        model=model,
        server_bin=server,
        base_url=url,
        ngl=ngl,
    )
    try:
        sess.ensure()
    except Exception as exc:  # noqa: BLE001
        return {
            "ok": False,
            "mode": "absent",
            "url": url,
            "why": "échec démarrage llama-server : {e}".format(e=exc),
            "model": str(model),
            "server": str(server),
        }
    _SESSION = sess
    st = probe(url)
    if st["ok"]:
        st["started"] = True
        st["model"] = str(model)
        st["server"] = str(server)
        return st
    return {
        "ok": False,
        "mode": "absent",
        "url": url,
        "why": "llama-server lancé mais /health ne répond pas",
        "model": str(model),
        "server": str(server),
    }


def garde_locale(finding: dict[str, Any]) -> dict[str, Any]:
    """Reformule sans inventer. Les faits (preuve, gravité, id) restent intacts."""
    titre = str(finding.get("titre") or finding.get("id") or "Observation")
    preuve = str(finding.get("preuve") or "").strip()
    pourquoi = str(finding.get("pourquoi_nuit") or "").strip()
    remede = finding.get("remede_etapes") or []
    if isinstance(remede, str):
        remede = [remede]
    if not pourquoi:
        pourquoi = "Observation retenue par le moteur. Aucune faille n'est inventée."
    if not remede:
        remede = ["Confronter l'observation à une preuve.", "Faire valider par l'auditeur."]
    clarifie = titre if titre.endswith(".") else titre + "."
    return {
        "titre": clarifie[:180],
        "pourquoi_nuit": (pourquoi + (" Preuve : " + preuve if preuve else "")).strip(),
        "remede_etapes": [str(x) for x in remede][:8],
        "qui_peut": str(finding.get("qui_peut") or "Auditeur / exploitant du SI"),
        "mode": "garde-locale",
    }


def exiger(
    *,
    url: str | None = None,
    obligatoire: bool = True,
    allow_garde: bool = True,
    start: bool = False,
) -> dict[str, Any]:
    """Retourne toujours un descripteur. `ok` est True s'il existe une capacité."""
    res = ressources()
    st = probe_many(candidate_urls(url))
    if st["ok"]:
        st["obligatoire"] = obligatoire
        st["contrat"] = "reformule un constat déjà établi"
        st.update({k: res[k] for k in ("model", "server") if not st.get(k)})
        _ecrire_cache(str(st.get("url") or ""))
        return st

    if start:
        if not res.get("model_ok"):
            try:
                from guardia.engines.llm_bootstrap import ensure_gguf

                got = ensure_gguf(interactive=None, ui=False)
                if got:
                    res = ressources()
            except Exception as exc:  # noqa: BLE001
                log.warning("llm bootstrap: %s", exc)
        target = url or DEFAULT_URL
        started = _demarrer(target)
        if started.get("ok"):
            started["obligatoire"] = obligatoire
            started["contrat"] = "reformule un constat déjà établi"
            _ecrire_cache(str(started.get("url") or target))
            return started
        st["start_why"] = started.get("why")
        st["model"] = started.get("model") or res.get("model")
        st["server"] = started.get("server") or res.get("server")

    why = st.get("why") or "LLM absent"
    extra = []
    if not res.get("model_ok"):
        extra.append("aucun GGUF > 10 Mo")
    else:
        extra.append("GGUF : " + str(res.get("model")))
    if not res.get("server_ok"):
        extra.append("llama-server introuvable")
    else:
        extra.append("binaire : " + str(res.get("server")))
    probed = st.get("probed") or []
    if probed:
        extra.append("sondé : " + ", ".join(probed))
    if st.get("start_why"):
        extra.append(str(st["start_why"]))
    detail = why + " — " + " ; ".join(extra)

    payload = {
        "url": "",
        "why": detail,
        "obligatoire": obligatoire,
        "model": res.get("model") or "",
        "server": res.get("server") or "",
        "probed": probed,
        "search_dirs": res.get("search_dirs") or [],
        "search_found": res.get("search_found") or [],
    }
    if allow_garde:
        payload.update(
            {
                "ok": True,
                "mode": "garde",
                "contrat": "explication déterministe à partir des faits moteur",
            }
        )
        return payload
    payload.update(
        {
            "ok": False,
            "mode": "absent",
            "url": st.get("url") or "",
            "contrat": "Aucune capacité d'explication.",
        }
    )
    return payload


def ligne(status: dict[str, Any]) -> str:
    mode = status.get("mode") or "absent"
    if mode == "llama":
        extra = " démarré" if status.get("started") else " déjà ouvert"
        return "LLM : llama-server{e} ({url}).".format(
            e=extra, url=status.get("url")
        )
    if mode == "openai-compat":
        return "LLM : compatible OpenAI ({url}).".format(url=status.get("url"))
    if mode == "ollama":
        return "LLM : Ollama ({url}).".format(url=status.get("url"))
    if mode == "garde":
        if status.get("server") and not status.get("model"):
            return "LLM : garde locale — llama-server trouvé, GGUF introuvable."
        if status.get("model") and not status.get("server"):
            return "LLM : garde locale — GGUF trouvé, llama-server introuvable (binaire PATH / bot_y/moteur)."
        if not status.get("server"):
            return "LLM : garde locale — llama-server et GGUF introuvables."
        return "LLM : garde locale — {why}".format(why=status.get("why") or "aucun llama-server")
    return "LLM : absent — {why}".format(why=status.get("why") or "indisponible")


def appliquer_garde(result: Any) -> int:
    """Applique la garde locale sur les findings déjà établis. Retourne le nombre reformulé."""
    n = 0
    hosts = getattr(result, "hosts", None) or []
    for h in hosts:
        for f in getattr(h, "findings", None) or []:
            payload = f.to_dict() if hasattr(f, "to_dict") else dict(f)
            out = garde_locale(payload)
            if hasattr(f, "titre"):
                f.titre = out["titre"]
                f.pourquoi_nuit = out["pourquoi_nuit"]
                f.remede_etapes = out["remede_etapes"]
                f.qui_peut = out["qui_peut"]
                n += 1
    return n


def dump_status(status: dict[str, Any]) -> str:
    return json.dumps(status, ensure_ascii=False, indent=2, default=str)
