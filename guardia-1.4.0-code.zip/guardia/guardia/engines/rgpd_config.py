"""Configuration du signalement RGPD — fiche opérateur / client.

Les réponses sont des **déclarations** (oui / non / inconnu), pas une preuve
et surtout pas un certificat. Elles évitent de laisser tout le chapitre
en « à confirmer » quand l'opérateur a déjà posé les questions.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Mission

# Jamais « conforme » ici.
TRI_CHOICES = ("inconnu", "oui", "non")

# kind: text | tri
RGPD_FIELDS: list[dict[str, str]] = [
    {
        "key": "responsable",
        "kind": "text",
        "label": "Responsable de traitement (nom / structure)",
        "help": "Celui qui décide des finalités — souvent le client, pas ÉOH.",
    },
    {
        "key": "contact_droits",
        "kind": "text",
        "label": "Contact exercice des droits (e-mail)",
        "help": "privacy@, dpo@, ou un vrai humain qui répond.",
    },
    {
        "key": "dpo_designe",
        "kind": "tri",
        "label": "Un DPO est-il désigné ?",
        "help": "Obligatoire surtout autorités / traitement à grande échelle. "
        "Une TPE n'en a pas forcément — ce n'est pas un tampon.",
    },
    {
        "key": "registre_tenu",
        "kind": "tri",
        "label": "Registre des traitements (art. 30) tenu et à jour ?",
        "help": "Plus de déclaration CNIL depuis 2018 : le registre interne le remplace.",
    },
    {
        "key": "registre_violations",
        "kind": "tri",
        "label": "Registre des violations (art. 33.5) tenu ?",
        "help": "Journal interne des incidents — même ceux non notifiés.",
    },
    {
        "key": "procedure_72h",
        "kind": "tri",
        "label": "Procédure de notification CNIL sous 72 h prévue ?",
        "help": "Si risque pour les personnes : 72 h. NIS2 peut ajouter 24 h / 72 h ANSSI.",
    },
    {
        "key": "sous_traitants",
        "kind": "text",
        "label": "Sous-traitants connus (hébergeur, e-mail, analytics…)",
        "help": "Liste libre. Ex. OVH, Infomaniak, Google Workspace, Mailjet.",
    },
    {
        "key": "contrats_art28",
        "kind": "tri",
        "label": "Contrats art. 28 avec ces sous-traitants ?",
        "help": "Sans contrat, le responsable ne maîtrise pas le flux.",
    },
    {
        "key": "transferts_hors_ue",
        "kind": "tri",
        "label": "Des données partent-elles hors UE / EEE ?",
        "help": "SREN / clauses de transfert. Inconnu = à cartographier.",
    },
    {
        "key": "durees_ecrites",
        "kind": "tri",
        "label": "Durées de conservation écrites (registre + politique) ?",
        "help": "Art. 5.1.e — pas de conservation « au cas où ».",
    },
    {
        "key": "mineurs",
        "kind": "tri",
        "label": "Traitement concernant des mineurs / élèves ?",
        "help": "France : 15 ans pour le consentement. École : souvent oui.",
    },
    {
        "key": "nis2_concerne",
        "kind": "tri",
        "label": "Pensez-vous être concerné par NIS2 ?",
        "help": "Pas un classement. Secteur essentiel/important + taille. À cadrer.",
    },
    {
        "key": "refus_aussi_simple",
        "kind": "tri",
        "label": "Bandeau cookies : refuser aussi simple qu'accepter ?",
        "help": "Reco CNIL. L'opérateur le voit dans le navigateur, pas nmap.",
    },
]


def empty_config() -> dict[str, Any]:
    out: dict[str, Any] = {}
    for f in RGPD_FIELDS:
        out[f["key"]] = "" if f["kind"] == "text" else "inconnu"
    return out


def _tri(v: Any) -> str:
    if v is True or v == 1:
        return "oui"
    if v is False or v == 0:
        return "non"
    s = str(v or "").strip().lower()
    if s in ("oui", "yes", "true", "1", "o"):
        return "oui"
    if s in ("non", "no", "false", "0", "n"):
        return "non"
    return "inconnu"


def normalize_config(raw: Any) -> dict[str, Any]:
    base = empty_config()
    if not isinstance(raw, dict):
        return base
    kinds = {f["key"]: f["kind"] for f in RGPD_FIELDS}
    for k, v in raw.items():
        if k not in kinds:
            continue
        if kinds[k] == "tri":
            base[k] = _tri(v)
        else:
            base[k] = str(v or "").strip()
    return base


def raw_config_from_mission(mission: Mission) -> dict[str, Any]:
    """Fiche telle qu'écrite (sans inférence école / responsable)."""
    extras = dict(mission.extras or {})
    raw = extras.get("rgpd_config")
    if raw is None:
        raw = extras.get("rgpd_cfg")
    return normalize_config(raw)


def load_rgpd_config(mission: Mission) -> dict[str, Any]:
    cfg = raw_config_from_mission(mission)
    # école : mineurs par défaut oui si encore inconnu (inférence, pas une preuve)
    typ = (mission.type_structure or "").lower()
    if cfg.get("mineurs") == "inconnu" and (
        (mission.profil_moteur or "").lower() == "ecole" or typ == "ecole"
    ):
        cfg["mineurs"] = "oui"
    if not cfg.get("responsable"):
        cfg["responsable"] = (mission.client or "").strip()
    return cfg


def config_is_blank(cfg: dict[str, Any]) -> bool:
    """True si l'opérateur n'a rien rempli (tout inconnu / vide)."""
    for f in RGPD_FIELDS:
        k = f["key"]
        if f["kind"] == "tri" and cfg.get(k) != "inconnu":
            return False
        if f["kind"] == "text" and str(cfg.get(k) or "").strip():
            # responsable auto-rempli avec le client ne compte pas comme config
            if k == "responsable":
                continue
            return False
    return True


def summary_line(cfg: dict[str, Any]) -> str:
    filled: list[str] = []
    for f in RGPD_FIELDS:
        k = f["key"]
        if f["kind"] == "tri" and cfg.get(k) not in (None, "", "inconnu"):
            filled.append(k)
        elif f["kind"] == "text" and k != "responsable" and str(cfg.get(k) or "").strip():
            filled.append(k)
    if not filled:
        return "fiche vide (tout à inconnu)"
    shown = ", ".join(filled[:8])
    extra = f" (+{len(filled) - 8})" if len(filled) > 8 else ""
    return f"{len(filled)} champ(s) renseigné(s) : {shown}{extra}"


def as_mission_extras(cfg: dict[str, Any]) -> dict[str, Any]:
    return {"rgpd": True, "rgpd_config": normalize_config(cfg)}


def _yaml_scalar(v: Any) -> str:
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return str(v)
    s = str(v)
    if s == "":
        return '""'
    special = set(":#{}[]&*!|>'\"%@`")
    if any(c in s for c in special) or s.lower() in (
        "true",
        "false",
        "null",
        "yes",
        "no",
        "on",
        "off",
    ):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return s


def _splice_rgpd_block(text: str, cfg: dict[str, Any]) -> str:
    """Réécrit rgpd / rgpd_config sans toucher au reste du YAML (stdlib)."""
    lines = text.splitlines()
    out: list[str] = []
    skip_indent = False
    for line in lines:
        stripped = line.lstrip()
        if skip_indent:
            if line.startswith((" ", "\t")) or not stripped:
                continue
            skip_indent = False
        if stripped.startswith("rgpd_config:"):
            skip_indent = True
            continue
        if stripped.startswith("rgpd:") and not stripped.startswith("rgpd_"):
            continue
        out.append(line)
    while out and out[-1] == "":
        out.pop()
    out.append("rgpd: true")
    out.append("rgpd_config:")
    norm = normalize_config(cfg)
    for f in RGPD_FIELDS:
        out.append(f"  {f['key']}: {_yaml_scalar(norm.get(f['key']))}")
    return "\n".join(out) + "\n"


def patch_mission_yaml(path: Any, cfg: dict[str, Any]) -> None:
    """Écrit rgpd: true + rgpd_config dans un YAML mission existant."""
    from pathlib import Path

    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(str(p))
    text = p.read_text(encoding="utf-8")
    try:
        import yaml  # type: ignore
    except ImportError:
        yaml = None
    if yaml:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError(f"mission invalide: {p}")
        data["rgpd"] = True
        data["rgpd_config"] = normalize_config(cfg)
        p.write_text(yaml.dump(data, allow_unicode=True, sort_keys=False), encoding="utf-8")
        return
    p.write_text(_splice_rgpd_block(text, cfg), encoding="utf-8")
