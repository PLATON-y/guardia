"""Dossier PASSI opérationnel : plan, preuves, contrôles et revue humaine.

Ce module transforme une mission PASSI en un état d'audit exploitable. Les
références ANSSI sont conservées comme contexte de cadrage, tandis que les
identifiants P-* restent internes à Guardia et ne constituent pas des
identifiants officiels du référentiel.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any
import hashlib
import json

from guardia.core.models import Mission

SOURCE = {
    "reference": "ANSSI PASSI — référentiel d'exigences v2.2",
    "date": "2024-08-01",
    "activities": [
        "organisationnel_physique",
        "architecture",
        "configuration",
        "code_source",
        "intrusion",
    ],
}

STATUS = ("verified", "partial", "pending_human", "not_applicable", "not_covered")


@dataclass(frozen=True)
class Control:
    id: str
    activity: str
    ref: str
    title: str
    objective: str
    evidence_keys: tuple[str, ...]
    human_gate: bool = False
    automated: bool = False


CONTROLS: tuple[Control, ...] = (
    Control("P-GEN-01", "general", "VI.4.1", "Objectifs, critères et périmètre", "Le plan d'audit explicite objectifs, critères et périmètre.", ("mission.objectives", "mission.criteria", "mission.scope")),
    Control("P-GEN-02", "general", "VI.4.1", "Approche par les risques", "La méthode, la profondeur et l'échantillonnage sont justifiables.", ("methodology", "sampling"), True),
    Control("P-GEN-03", "general", "VI.4.1", "Prérequis et informations d'entrée", "Les documents, personnes et prérequis nécessaires sont identifiés.", ("prerequisites",), True),
    Control("P-GEN-04", "general", "VI.4.1", "Traçabilité des actions et résultats", "Les actions, résultats et dates sont conservés.", ("execution_log",), automated=True),
    Control("P-GEN-05", "general", "VI.4.1", "Constats factuels et basés sur la preuve", "Les constats sont reliés à des éléments probants.", ("evidence",), True),
    Control("P-GEN-06", "general", "VI.4.1", "Réunion d'ouverture / validation de cadrage", "Le cadrage peut être confirmé avant exécution.", ("opening_meeting",), True),
    Control("P-GEN-07", "general", "VI.4.1", "Suivi des changements", "Les modifications du périmètre et des modalités sont tracées.", ("change_log",), True),
    Control("P-GEN-08", "general", "VI.4.1", "État final non dégradé", "Les impacts et restaurations éventuelles sont tracés.", ("closure_check",), True),
    Control("P-ARCH-01", "architecture", "VI.4.2", "Schémas d'architecture", "Revue des schémas de niveau 2 et 3 lorsqu'ils existent.", ("architecture_docs.l2_l3",), True),
    Control("P-ARCH-02", "architecture", "VI.4.2", "Matrices de flux", "Revue des matrices de flux lorsqu'elles existent.", ("architecture_docs.flow_matrix",), True),
    Control("P-ARCH-03", "architecture", "VI.4.2", "Règles de filtrage", "Revue des règles de filtrage pertinentes.", ("architecture_docs.filter_rules",), True),
    Control("P-ARCH-04", "architecture", "VI.4.2", "Configurations réseau", "Revue des configurations routeurs / commutateurs pertinentes.", ("architecture_docs.network_config",), True),
    Control("P-ARCH-05", "architecture", "VI.4.2", "Interconnexions", "Inventaire des interconnexions avec réseaux tiers ou Internet.", ("architecture_docs.interconnections",), True),
    Control("P-ARCH-06", "architecture", "VI.4.2", "Cartographie issue des observations", "Confronter la documentation à l'architecture observée.", ("asset_graph", "observations"), automated=True),
    Control("P-ARCH-07", "architecture", "VI.4.2", "Écarts d'architecture", "Documenter les écarts et leurs risques.", ("architecture_findings",), True),
    Control("P-CFG-01", "configuration", "VI.4.3", "Annuaires d'utilisateurs", "Évaluer la sécurité et/ou conformité des annuaires pertinents.", ("config.annuaire",), True),
    Control("P-CFG-02", "configuration", "VI.4.3", "Sécurité physique", "Évaluer les composants de sécurité physique pertinents.", ("config.physical_security",), True),
    Control("P-CFG-03", "configuration", "VI.4.3", "Composants réseau", "Évaluer routeurs, commutateurs et composants réseau pertinents.", ("config.network",), True),
    Control("P-CFG-04", "configuration", "VI.4.3", "Sécurité réseau", "Évaluer pare-feu, chiffreurs, antivirus et composants associés.", ("config.network_security",), True),
    Control("P-CFG-05", "configuration", "VI.4.3", "Sécurité locale", "Évaluer antivirus/EDR et mécanismes locaux pertinents.", ("config.endpoint_security",), True),
    Control("P-CFG-06", "configuration", "VI.4.3", "Systèmes d'exploitation", "Évaluer la configuration des systèmes d'exploitation.", ("config.os",), True),
    Control("P-CFG-07", "configuration", "VI.4.3", "Applications", "Évaluer la configuration des applications pertinentes.", ("config.applications",), True),
    Control("P-CFG-08", "configuration", "VI.4.3", "Cloud, conteneurs et virtualisation", "Évaluer les configurations pertinentes de ces environnements.", ("config.cloud", "config.containers", "config.virtualization"), True),
    Control("P-CFG-09", "configuration", "VI.4.3", "Échantillonnage et justificatifs", "Documenter le choix des composants contrôlés.", ("sampling.configuration",), True),
    Control("P-CFG-10", "configuration", "VI.4.3", "Constats de configuration basés sur la preuve", "Relier les écarts aux exports/captures/configurations source.", ("evidence",), True),
    Control("P-CODE-01", "code_source", "VI.4.4", "Périmètre de code", "Identifier clairement le dépôt, la version et les parties auditées.", ("code_scope",), True),
    Control("P-CODE-02", "code_source", "VI.4.4", "Spécifications et architecture", "Prendre en compte la documentation disponible du logiciel.", ("code.specifications", "code.architecture"), True),
    Control("P-CODE-03", "code_source", "VI.4.4", "Implémentation", "Analyser les parties de code pertinentes.", ("code.implementation",), True),
    Control("P-CODE-04", "code_source", "VI.4.4", "Administration et utilisation", "Prendre en compte les conditions d'administration et d'utilisation.", ("code.admin", "code.usage"), True),
    Control("P-CODE-05", "code_source", "VI.4.4", "Méthodes et résultats de tests", "Prendre en compte les tests du logiciel lorsqu'ils existent.", ("code.tests",), True),
    Control("P-CODE-06", "code_source", "VI.4.4", "Authentification", "Revoir les mécanismes d'authentification.", ("code.controls.authentication",), True),
    Control("P-CODE-07", "code_source", "VI.4.4", "Cryptographie", "Revoir les mécanismes cryptographiques.", ("code.controls.crypto",), True),
    Control("P-CODE-08", "code_source", "VI.4.4", "Utilisateurs", "Revoir la gestion des utilisateurs.", ("code.controls.users",), True),
    Control("P-CODE-09", "code_source", "VI.4.4", "Contrôles d'accès", "Revoir les contrôles d'accès aux ressources.", ("code.controls.access",), True),
    Control("P-CODE-10", "code_source", "VI.4.4", "Interactions", "Revoir les interactions avec d'autres applications.", ("code.controls.integrations",), True),
    Control("P-CODE-11", "code_source", "VI.4.4", "Validation des données", "Revoir la validation des données et entrées.", ("code.controls.input_validation",), True),
    Control("P-CODE-12", "code_source", "VI.4.4", "Preuves et traçabilité du code", "Rattacher les constats à des fichiers, révisions et emplacements.", ("code_evidence",), True),
    Control("P-INTR-01", "intrusion", "VI.4.5", "Mode boîte noire", "Prévoir un déroulé adapté aux informations minimales disponibles.", ("pentest.blackbox",), True),
    Control("P-INTR-02", "intrusion", "VI.4.5", "Mode boîte grise", "Prévoir un déroulé avec informations/identifiants légitimes convenus.", ("pentest.graybox",), True),
    Control("P-INTR-03", "intrusion", "VI.4.5", "Mode boîte blanche", "Prévoir un déroulé avec informations techniques approfondies.", ("pentest.whitebox",), True),
    Control("P-INTR-04", "intrusion", "VI.4.5", "Profil d'attaquant", "Définir le profil d'attaquant simulé avec le commanditaire.", ("pentest.attacker_profile",), True),
    Control("P-INTR-05", "intrusion", "VI.4.5", "Périmètre, horaires et sources", "Verrouiller cibles, provenance et fenêtre de test.", ("pentest.targets", "pentest.time_window", "pentest.sources"), True),
    Control("P-INTR-06", "intrusion", "VI.4.5", "Limitation des actions dangereuses", "Encadrer ou interdire les actions susceptibles de perturber la cible.", ("pentest.stop_conditions",), True),
    Control("P-INTR-07", "intrusion", "VI.4.5", "Traçabilité du test", "Conserver les actions, résultats et dates du test.", ("execution_log",), automated=True),
    Control("P-INTR-08", "intrusion", "VI.4.5", "Validation des preuves d'exploitabilité", "Distinguer hypothèse, vulnérabilité et exploitabilité démontrée.", ("pentest.validation",), True),
    Control("P-INTR-09", "intrusion", "VI.4.5", "Compte rendu et limitations", "Justifier les actions non réalisées et les limites.", ("pentest.limitations",), True),
    Control("P-ORG-01", "organisationnel_physique", "Activité PASSI", "Politiques et procédures", "Politiques et procédures de sécurité.", ("org.policies",), True),
    Control("P-ORG-02", "organisationnel_physique", "Activité PASSI", "Processus et pratiques", "Processus et pratiques effectivement appliqués.", ("org.processes", "org.practice"), True),
    Control("P-ORG-03", "organisationnel_physique", "Activité PASSI", "Entretiens", "Entretiens avec les personnes pertinentes.", ("org.interviews",), True),
    Control("P-ORG-04", "organisationnel_physique", "Activité PASSI", "Sécurité physique", "Sécurité physique et processus associés.", ("org.physical",), True),
    Control("P-ORG-05", "organisationnel_physique", "Activité PASSI", "Preuves et observations", "Preuves documentaires et observations.", ("org.evidence",), True),
    Control("P-ORG-06", "organisationnel_physique", "Activité PASSI", "Validation auditeur", "Constats et recommandations validés par l'auditeur.", ("review",), True),
)


def _extras(mission: Any) -> dict[str, Any]:
    ex = getattr(mission, "extras", None) or {}
    return ex if isinstance(ex, dict) else {}


def requested_activities(mission: Mission) -> list[str]:
    ex = _extras(mission)
    raw = ex.get("passi_activities") or ex.get("activities")
    if isinstance(raw, str):
        raw = [raw]
    if raw:
        vals = [str(x) for x in raw]
    else:
        vals = ["architecture", "configuration"]
        if ex.get("passi"):
            vals = list(SOURCE["activities"])
    return [x for x in SOURCE["activities"] if x in vals]


def _dig(mapping: Any, path: str) -> Any:
    if path.startswith("mission."):
        path = path.split(".", 1)[1]
        mapping = getattr(mapping, "extras", {}) or {}
    parts = path.split(".")
    cur = mapping
    for part in parts:
        if isinstance(cur, dict):
            cur = cur.get(part)
        else:
            cur = getattr(cur, part, None)
        if cur is None:
            return None
    return cur


def _truthy(value: Any) -> bool:
    if isinstance(value, (list, tuple, set, dict)):
        return bool(value)
    return value not in (None, "", False)


def _evidence_matches(result: dict[str, Any], key: str) -> bool:
    if key == "mission.scope":
        return bool(getattr(result.get("mission"), "cidr", None) or getattr(result.get("mission"), "extras", {}).get("site_url"))
    if "." in key:
        obj = result.get("evidence_data") or {}
        val = _dig(obj, key)
        if _truthy(val):
            return True
        return _truthy(_dig(result, key))
    return _truthy((result.get("evidence_data") or {}).get(key) or result.get(key))


def control_status(control: Control, mission: Mission, result: dict[str, Any]) -> tuple[str, str]:
    requested = control.activity in requested_activities(mission) or control.activity == "general"
    if not requested and control.activity != "general":
        return "not_applicable", "Activité non demandée dans la mission."

    hits = [k for k in control.evidence_keys if _evidence_matches(result, k)]
    if not hits:
        if control.human_gate:
            return "pending_human", "Preuve ou validation humaine attendue."
        return "not_covered", "Aucune preuve exploitable dans l'état courant."

    reviews = result.get("reviews") or {}
    if control.human_gate and reviews.get(control.id) not in ("approved", "confirmed"):
        return "pending_human", "Preuve détectée ({hits}), validation auditeur attendue.".format(hits=", ".join(hits))
    return "verified", "Preuve présente : {hits}.".format(hits=", ".join(hits))


def _feed_engine_evidence(mission: Mission, result: dict[str, Any]) -> dict[str, Any]:
    evidence_data = dict(result.get("evidence_data") or {})
    ex = _extras(mission)
    hosts = result.get("hosts") or []
    journal = result.get("journal") or {}
    if hosts:
        n_ports = sum(len(getattr(h, "ports", None) or []) for h in hosts)
        evidence_data.setdefault("asset_graph", True)
        evidence_data.setdefault("observations", True)
        evidence_data.setdefault("services", n_ports > 0)
        evidence_data.setdefault("network_checks", n_ports > 0)
        cfg = dict(evidence_data.get("config") or {})
        cfg.setdefault("network", n_ports > 0)
        evidence_data["config"] = cfg
    if journal:
        evidence_data.setdefault("execution_log", True)
        evidence_data.setdefault("trace", True)
    if result.get("lynis"):
        cfg = dict(evidence_data.get("config") or {})
        cfg.setdefault("os", True)
        evidence_data["config"] = cfg
    if result.get("greenbone"):
        cfg = dict(evidence_data.get("config") or {})
        cfg.setdefault("applications", True)
        evidence_data["config"] = cfg
    if result.get("correlation") or result.get("findings"):
        evidence_data.setdefault("evidence", True)
    if result.get("adaptatif"):
        evidence_data.setdefault("observations", True)
        evidence_data.setdefault("asset_graph", True)
    # Observations live → couverture configuration (ports, TLS, SMB, web)
    try:
        n_tls = n_smb = n_http = 0
        for h in hosts:
            for pr in getattr(h, "ports", None) or []:
                if not isinstance(pr, dict):
                    continue
                try:
                    port = int(pr.get("port") or 0)
                except (TypeError, ValueError):
                    continue
                if port in (443, 8443, 993, 995, 636):
                    n_tls += 1
                if port in (139, 445):
                    n_smb += 1
                if port in (80, 81, 443, 8080, 8443, 8000):
                    n_http += 1
        if n_tls or n_smb or n_http:
            cfg = dict(evidence_data.get("config") or {})
            if n_tls:
                cfg.setdefault("network_security", True)
                evidence_data.setdefault("tls_headers_live", True)
            if n_smb:
                cfg.setdefault("network", True)
                evidence_data.setdefault("smb_hygiene_live", True)
            if n_http:
                cfg.setdefault("applications", True)
                evidence_data.setdefault("web_headers_live", True)
            evidence_data["config"] = cfg
            evidence_data.setdefault("evidence", True)
        web = result.get("website") or {}
        if web:
            evidence_data.setdefault("web_headers_live", True)
            evidence_data.setdefault("tls_headers_live", True)
            cfg = dict(evidence_data.get("config") or {})
            cfg.setdefault("applications", True)
            evidence_data["config"] = cfg
        if result.get("rgpd"):
            evidence_data.setdefault("observations", True)
            evidence_data.setdefault("evidence", True)
        brain = result.get("adaptatif") or {}
        for ddir in brain.get("directives_passi_cnil") or []:
            if ddir.get("status") in ("opened", "done", "proposed") and ddir.get("passi_activity") == "configuration":
                cfg = dict(evidence_data.get("config") or {})
                cfg.setdefault("network", True)
                evidence_data["config"] = cfg
                evidence_data.setdefault("observations", True)
    except Exception:
        pass
    evidence_data.setdefault("mission", {})
    if isinstance(evidence_data["mission"], dict):
        evidence_data["mission"].setdefault("objectives", ex.get("objectives") or (ex.get("mission") or {}).get("objectives"))
        evidence_data["mission"].setdefault("criteria", ex.get("criteria") or (ex.get("mission") or {}).get("criteria"))
        evidence_data["mission"].setdefault("scope", bool(mission.cidr or ex.get("site_url")))
    for key in (
        "architecture_docs",
        "config",
        "code",
        "code_scope",
        "code_evidence",
        "pentest",
        "org",
        "review",
        "methodology",
        "sampling",
        "prerequisites",
        "opening_meeting",
        "change_log",
        "closure_check",
        "framing",
    ):
        if key not in evidence_data and ex.get(key) not in (None, "", [], {}):
            evidence_data[key] = ex.get(key)
    if ex.get("framing") and not evidence_data.get("sampling"):
        framing = ex.get("framing") or {}
        if isinstance(framing, dict):
            evidence_data.setdefault("sampling", framing.get("sampling"))
            evidence_data.setdefault("methodology", framing)
    return evidence_data


def build_assessment(mission: Mission, result: dict[str, Any] | None = None) -> dict[str, Any]:
    result = dict(result or {})
    result["mission"] = mission
    result["evidence_data"] = _feed_engine_evidence(mission, result)

    rows = []
    for control in CONTROLS:
        status, rationale = control_status(control, mission, result)
        rows.append({**asdict(control), "evidence_keys": list(control.evidence_keys), "status": status, "rationale": rationale})

    by_activity: dict[str, dict[str, Any]] = {}
    for activity in SOURCE["activities"]:
        items = [r for r in rows if r["activity"] == activity]
        counts = {s: sum(1 for r in items if r["status"] == s) for s in STATUS}
        total = len(items)
        weighted = counts["verified"] + 0.5 * counts["partial"]
        score = round(100 * weighted / total) if total else 0
        by_activity[activity] = {"total": total, **counts, "score": score}

    from guardia.engines.passi_chaine import attacher_chaines

    reviews = result.get("reviews") or {}
    pending = [r["id"] for r in rows if r["status"] == "pending_human"]
    findings = result.get("findings") or []
    chaines = attacher_chaines(rows, mission, result)
    return {
        "source": SOURCE,
        "mission": {
            "client": mission.client,
            "activities": requested_activities(mission),
            "depth": mission.profondeur,
            "scope": {"cidr": mission.cidr or "", "url": _extras(mission).get("site_url") or ""},
        },
        "mode": "assessment",
        "disclaimer": "Dossier d'audit PASSI : outil d'appui et de traçabilité. Il ne constitue ni qualification, ni certification, ni avis ANSSI.",
        "controls": rows,
        "by_activity": by_activity,
        "reviews": reviews,
        "findings_count": len(findings),
        "chaines": chaines,
        "summary": {
            "controls": len(rows),
            "verified": sum(1 for r in rows if r["status"] == "verified"),
            "pending_human": len(pending),
            "not_covered": sum(1 for r in rows if r["status"] == "not_covered"),
            "not_applicable": sum(1 for r in rows if r["status"] == "not_applicable"),
            "activities_requested": len(requested_activities(mission)),
            "assessment_ready": bool(mission.cidr or _extras(mission).get("site_url")) and bool(requested_activities(mission)),
            "chaines_alimentees": sum(1 for c in chaines if c.get("preuve")),
        },
        "execution_plan": build_execution_plan(mission),
        "next_actions": [
            {"control": cid, "action": "Validation ou production de preuve"} for cid in pending[:30]
        ],
    }


def build_execution_plan(mission: Mission) -> list[dict[str, Any]]:
    activities = set(requested_activities(mission))
    ex = _extras(mission)
    plan: list[dict[str, Any]] = [
        {"id": "passi-cadrage", "activity": "general", "capability": "cadrage", "authorization": "mission", "automatic": False},
        {"id": "passi-discovery", "activity": "general", "capability": "asset_discovery", "authorization": "network_scan", "automatic": True},
    ]
    if "architecture" in activities:
        plan += [
            {"id": "passi-archi-docs", "activity": "architecture", "capability": "review_architecture_documents", "authorization": "document_review", "automatic": False},
            {"id": "passi-archi-observe", "activity": "architecture", "capability": "architecture_observation", "authorization": "network_scan", "automatic": True},
        ]
    if "configuration" in activities:
        plan += [
            {"id": "passi-config-baseline", "activity": "configuration", "capability": "configuration_baseline", "authorization": "service_detection", "automatic": True},
            {"id": "passi-config-reviews", "activity": "configuration", "capability": "configuration_evidence_review", "authorization": "document_review", "automatic": False},
        ]
    if "code_source" in activities:
        plan += [
            {"id": "passi-code-intake", "activity": "code_source", "capability": "code_intake", "authorization": "code_scope", "automatic": False, "target": ex.get("code_scope")},
            {"id": "passi-code-sast", "activity": "code_source", "capability": "safe_static_analysis", "authorization": "code_scope", "automatic": True, "target": ex.get("code_scope")},
            {"id": "passi-code-review", "activity": "code_source", "capability": "human_code_review", "authorization": "review", "automatic": False},
        ]
    if "organisationnel_physique" in activities:
        plan += [
            {"id": "passi-org-docs", "activity": "organisationnel_physique", "capability": "document_review", "authorization": "document_review", "automatic": False},
            {"id": "passi-org-interviews", "activity": "organisationnel_physique", "capability": "interviews", "authorization": "human_gate", "automatic": False},
            {"id": "passi-org-physical", "activity": "organisationnel_physique", "capability": "physical_observation", "authorization": "human_gate", "automatic": False},
        ]
    if "intrusion" in activities:
        plan += [
            {"id": "passi-pentest-prep", "activity": "intrusion", "capability": "pentest_preconditions", "authorization": "roe_and_explicit_authorization", "automatic": False},
            {"id": "passi-pentest-blackbox", "activity": "intrusion", "capability": "pentest_blackbox", "authorization": "explicit_intrusion_authorization", "automatic": False},
            {"id": "passi-pentest-graybox", "activity": "intrusion", "capability": "pentest_graybox", "authorization": "explicit_intrusion_authorization", "automatic": False},
            {"id": "passi-pentest-whitebox", "activity": "intrusion", "capability": "pentest_whitebox", "authorization": "explicit_intrusion_authorization", "automatic": False},
            {"id": "passi-pentest-report", "activity": "intrusion", "capability": "pentest_evidence_review", "authorization": "review", "automatic": False},
        ]
    return plan


def as_markdown(assessment: dict[str, Any]) -> str:
    s = assessment.get("summary") or {}
    lines = [
        "# Dossier d'audit PASSI — Guardia",
        "",
        assessment.get("disclaimer", ""),
        "",
        "Mission : **{client}**".format(client=assessment.get("mission", {}).get("client", "Client")),
        "Activités : {acts}".format(acts=", ".join(assessment.get("mission", {}).get("activities") or []) or "aucune"),
        "Contrôles vérifiés : **{v} / {t}**".format(v=s.get("verified", 0), t=s.get("controls", 0)),
        "Validations humaines en attente : **{n}**".format(n=s.get("pending_human", 0)),
        "Chaînes alimentées : **{n}**".format(n=s.get("chaines_alimentees", 0)),
        "",
        "| ID Guardia | Réf. | Activité | État | Justification |",
        "|---|---|---|---|---|",
    ]
    for r in assessment.get("controls") or []:
        lines.append(
            "| {id} | {ref} | {act} | {st} | {why} |".format(
                id=r["id"], ref=r["ref"], act=r["activity"], st=r["status"], why=r["rationale"]
            )
        )
    lines.extend(["", "## Plan d'exécution", "", "| Étape | Activité | Capacité | Autorisation | Automatique |", "|---|---|---|---|---|"])
    for step in assessment.get("execution_plan") or []:
        auto = "oui" if step.get("automatic") else "non"
        lines.append(
            "| {i} | {a} | {c} | {u} | {auto} |".format(
                i=step["id"], a=step["activity"], c=step["capability"], u=step["authorization"], auto=auto
            )
        )
    lines.extend(["", "## Chaîne exigence → rapport", "", "| Exigence | Contrôle | Action | Outil | Résultat | Preuve | Validation |", "|---|---|---|---|---|---|---|"])
    for ch in assessment.get("chaines") or []:
        lines.append(
            "| {ex} | {co} | {ac} | {ou} | {re} | {pr} | {va} |".format(
                ex=ch.get("exigence") or "",
                co=ch.get("controle") or "",
                ac=ch.get("action") or "",
                ou=ch.get("outil") or "—",
                re=ch.get("resultat") or "—",
                pr=ch.get("preuve") or "—",
                va=ch.get("validation") or "",
            )
        )
    lines.extend(["", "## Prochaines actions", ""])
    for a in assessment.get("next_actions") or []:
        lines.append("- **{c}** — {a}".format(c=a["control"], a=a["action"]))
    return "\n".join(lines)


def export_assessment(assessment: dict[str, Any], directory: Path) -> dict[str, str]:
    directory.mkdir(parents=True, exist_ok=True)
    payload = json.dumps(assessment, ensure_ascii=False, indent=2, default=str).encode("utf-8")
    digest = hashlib.sha256(payload).hexdigest()
    json_path = directory / "passi-assessment.json"
    md_path = directory / "passi-assessment.md"
    manifest = directory / "MANIFEST-PASSI.sha256"
    json_path.write_bytes(payload)
    md_path.write_text(as_markdown(assessment) + "\n", encoding="utf-8")
    manifest.write_text(
        "{d}  {j}\n{m}  {n}\n".format(
            d=digest,
            j=json_path.name,
            m=hashlib.sha256(md_path.read_bytes()).hexdigest(),
            n=md_path.name,
        ),
        encoding="utf-8",
    )
    return {"json": str(json_path), "markdown": str(md_path), "manifest": str(manifest), "sha256": digest}
