"""Outils de lecture de Guardia — ce que le calibrage peut lancer.

Mandat + CIDR (et URL du jour). Guardia lance si l'outil est installé.
Absent : invitation Kali (apt + cheminement). Aide : python3 -m guardia outil list
"""
from __future__ import annotations

import json
import shutil
import subprocess
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Any
from urllib.parse import urlparse

from guardia.core.cadre import PROGRAMME
from guardia.core.models import Mission
from guardia.core.paths import RAPPORTS


@dataclass(frozen=True)
class Outil:
    id: str
    nom: str
    bins: tuple[str, ...]
    scope: str  # cidr | url
    pourquoi: str
    commande: str
    aide: str
    mode: str = "lecture"
    auto: bool = True
    avenant: str = "mandat"
    install: str = ""


CATALOGUE: tuple[Outil, ...] = (
    Outil(
        id="nmap",
        nom="nmap -sV",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Empreinte LAN. Ports et bannières.",
        commande="nmap -sV -T3 {cidr}",
        aide="Toujours au checkup. python3 -m guardia run -m MISSION --yes",
    ),
    Outil(
        id="arp-scan",
        nom="arp-scan",
        bins=("arp-scan",),
        scope="cidr",
        pourquoi="Inventaire L2 du CIDR.",
        commande="arp-scan --retry=1 {cidr}",
        aide="Calibré une fois sur le LAN. Paquet Kali : arp-scan",
    ),
    Outil(
        id="nbtscan",
        nom="nbtscan",
        bins=("nbtscan",),
        scope="cidr",
        pourquoi="Noms NetBIOS du parc.",
        commande="nbtscan -r {cidr}",
        aide="Calibré si 137/139. Paquet Kali : nbtscan",
    ),
    Outil(
        id="avahi-browse",
        nom="avahi-browse",
        bins=("avahi-browse",),
        scope="cidr",
        pourquoi="Services mDNS du LAN.",
        commande="avahi-browse -art -t",
        aide="Calibré une fois. Paquet Kali : avahi-utils",
    ),
    Outil(
        id="smbclient",
        nom="smbclient -L",
        bins=("smbclient",),
        scope="cidr",
        pourquoi="Noms de partages, pas les fichiers.",
        commande="smbclient -L //{host} -N",
        aide="Calibré si 445. Paquet Kali : smbclient",
    ),
    Outil(
        id="smb-shares",
        nom="nmap smb-enum-shares",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Noms de partages SMB.",
        commande="nmap -p 445 --script smb-enum-shares {host}",
        aide="Calibré si 445. python3 -m guardia outil list",
    ),
    Outil(
        id="smb-sec",
        nom="nmap smb-security-mode",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Signing SMB, dialectes.",
        commande="nmap -p 445 --script smb-security-mode,smb-os-discovery {host}",
        aide="Calibré si 445. python3 -m guardia outil list",
    ),
    Outil(
        id="enum4linux",
        nom="enum4linux-ng",
        bins=("enum4linux-ng", "enum4linux"),
        scope="cidr",
        pourquoi="Noms et partages SMB.",
        commande="enum4linux-ng {host}",
        aide="Calibré si 139/445. Paquet Kali : enum4linux-ng",
    ),
    Outil(
        id="showmount",
        nom="showmount -e",
        bins=("showmount",),
        scope="cidr",
        pourquoi="Exports NFS visibles.",
        commande="showmount -e {host}",
        aide="Calibré si 111/2049. Paquet Kali : nfs-common",
    ),
    Outil(
        id="rpcinfo",
        nom="rpcinfo -p",
        bins=("rpcinfo",),
        scope="cidr",
        pourquoi="Portmapper RPC.",
        commande="rpcinfo -p {host}",
        aide="Calibré si 111. Paquet Kali : rpcbind",
    ),
    Outil(
        id="ldapsearch",
        nom="ldapsearch rootDSE",
        bins=("ldapsearch",),
        scope="cidr",
        pourquoi="namingContexts.",
        commande="ldapsearch -x -H ldap://{host} -s base namingContexts",
        aide="Calibré si 389. Paquet Kali : ldap-utils",
    ),
    Outil(
        id="snmpget",
        nom="snmpget public",
        bins=("snmpget", "snmpwalk"),
        scope="cidr",
        pourquoi="Communauté public. Lecture sysDescr.",
        commande="snmpget -v2c -c public {host} sysDescr.0",
        aide="Calibré si 161. Paquet Kali : snmp",
    ),
    Outil(
        id="ike-scan",
        nom="ike-scan",
        bins=("ike-scan",),
        scope="cidr",
        pourquoi="Handshake IKE. Concentrateur VPN.",
        commande="ike-scan --sport=0 {host}",
        aide="Calibré si 500. Paquet Kali : ike-scan",
    ),
    Outil(
        id="ssh-audit",
        nom="ssh-audit",
        bins=("ssh-audit",),
        scope="cidr",
        pourquoi="Algorithmes SSH visibles.",
        commande="ssh-audit {host}",
        aide="Calibré si 22. Paquet Kali : ssh-audit",
    ),
    Outil(
        id="rdp-nla",
        nom="nmap rdp-enum-encryption",
        bins=("nmap",),
        scope="cidr",
        pourquoi="NLA et chiffrement RDP.",
        commande="nmap -p 3389 --script rdp-enum-encryption {host}",
        aide="Calibré si 3389. python3 -m guardia outil list",
    ),
    Outil(
        id="ftp-anon",
        nom="nmap ftp-anon",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Anonymous FTP.",
        commande="nmap -p 21 --script ftp-anon {host}",
        aide="Calibré si 21. python3 -m guardia outil list",
    ),
    Outil(
        id="smtp-open-relay",
        nom="nmap smtp-open-relay",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Relais SMTP ouvert.",
        commande="nmap -p 25 --script smtp-open-relay {host}",
        aide="Calibré si 25/587. python3 -m guardia outil list",
    ),
    Outil(
        id="db-info",
        nom="nmap mysql/mssql/redis-info",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Bannières bases.",
        commande="nmap -p 1433,3306,5432,6379,27017 --script mysql-info,ms-sql-info,redis-info {host}",
        aide="Calibré si 1433/3306/5432/6379/27017. python3 -m guardia outil list",
    ),
    Outil(
        id="whois",
        nom="whois",
        bins=("whois",),
        scope="url",
        pourquoi="Titulaire, registrar, dates du domaine du mandat. Lecture publique.",
        commande="whois {host}",
        aide="URL du mandat. Paquet Kali : whois. Absent : on continue.",
        install="sudo apt install whois",
    ),
    Outil(
        id="dig",
        nom="dig",
        bins=("dig",),
        scope="url",
        pourquoi="Enregistrements A, MX, NS, TXT du domaine du mandat.",
        commande="dig +time=3 +tries=1 +short {host}",
        aide="Paquet Kali : dnsutils. Absent : on continue.",
        install="sudo apt install dnsutils",
    ),
    Outil(
        id="host",
        nom="host",
        bins=("host",),
        scope="url",
        pourquoi="Résolution DNS du domaine du mandat.",
        commande="host {host}",
        aide="Paquet Kali : bind9-host. Absent : on continue.",
        install="sudo apt install bind9-host",
    ),
    Outil(
        id="curl",
        nom="curl / openssl s_client",
        bins=("curl", "openssl"),
        scope="url",
        pourquoi="En-têtes et TLS de l'URL du mandat.",
        commande="curl -sI {url}",
        aide="Module site : python3 -m guardia run -m MISSION --site URL --yes",
    ),
    Outil(
        id="testssl",
        nom="testssl.sh",
        bins=("testssl.sh", "testssl"),
        scope="url",
        pourquoi="Revue TLS de l'URL du mandat.",
        commande="testssl.sh --fast --quiet {url}",
        aide="Calibré si 443. Paquet Kali : `sudo apt install testssl.sh`. Chemins : /usr/bin/testssl.sh ou /usr/share/testssl.sh/testssl.sh. Absent : Guardia continue avec sslscan / sslyze / nmap ssl-enum-ciphers.",
        install="sudo apt install testssl.sh",
    ),
    Outil(
        id="sslscan",
        nom="sslscan",
        bins=("sslscan",),
        scope="url",
        pourquoi="Ciphers TLS visibles.",
        commande="sslscan --no-failed {host}",
        aide="Calibré si 443. Paquet Kali : sslscan",
    ),
    Outil(
        id="whatweb",
        nom="WhatWeb",
        bins=("whatweb",),
        scope="url",
        pourquoi="Empreinte HTTP discrète (aggression 1).",
        commande="whatweb -a 1 {url}",
        aide="Calibré si HTTP. Paquet Kali : whatweb",
    ),
    Outil(
        id="wafw00f",
        nom="wafw00f",
        bins=("wafw00f",),
        scope="url",
        pourquoi="Présence d'un WAF.",
        commande="wafw00f -a {url}",
        aide="Calibré si HTTP. Paquet Kali : wafw00f",
    ),
    Outil(
        id="nmap-http",
        nom="nmap http-title / ssl-cert",
        bins=("nmap",),
        scope="url",
        pourquoi="Titre HTTP et certificat visibles.",
        commande="nmap -p 80,443 --script http-title,http-headers,ssl-cert {host}",
        aide="Calibré si HTTP/443. python3 -m guardia outil list",
    ),
    Outil(
        id="nuclei",
        nom="Nuclei tech/info/tls",
        bins=("nuclei",),
        scope="url",
        pourquoi="Templates tech/info/tls.",
        commande=(
            "nuclei -u {url} -tags tech,info,tls,ssl "
            "-etags exploit,rce,lfi,sqli,kev"
        ),
        aide="Calibré si HTTP. Paquet Kali : nuclei",
    ),
    Outil(
        id="nikto",
        nom="Nikto Tuning 1",
        bins=("nikto",),
        scope="url",
        pourquoi="Fichiers intéressants, 20 s max.",
        commande="nikto -h {url} -Tuning 1 -maxtime 20",
        aide="Calibré si HTTP. Paquet Kali : nikto",
    ),
    Outil(
        id="wpscan",
        nom="WPScan passif",
        bins=("wpscan",),
        scope="url",
        pourquoi="WordPress, enum passive.",
        commande="wpscan --url {url} --plugins-detection passive --disable-tls-checks",
        aide="Calibré si HTTP. Paquet Kali : wpscan",
    ),
    Outil(
        id="sslyze",
        nom="sslyze",
        bins=("sslyze",),
        scope="url",
        pourquoi="Revue TLS : protocoles, ciphers, cert.",
        commande="sslyze {host}:443",
        aide="Calibré si 443. Paquet Kali : `sudo apt install sslyze` (ou pipx install sslyze).",
        install="sudo apt install sslyze",
    ),
    Outil(
        id="smbmap",
        nom="smbmap",
        bins=("smbmap",),
        scope="cidr",
        pourquoi="Noms de partages SMB, pas les fichiers.",
        commande="smbmap -H {host}",
        aide="Calibré si 445. Paquet Kali : smbmap",
    ),
    Outil(
        id="onesixtyone",
        nom="onesixtyone",
        bins=("onesixtyone",),
        scope="cidr",
        pourquoi="Communauté SNMP public.",
        commande="onesixtyone -c public {host}",
        aide="Calibré si 161. Paquet Kali : onesixtyone",
    ),
    Outil(
        id="ssl-enum",
        nom="nmap ssl-enum-ciphers",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Protocoles et ciphers TLS vus.",
        commande="nmap -p 443 --script ssl-enum-ciphers {host}",
        aide="Calibré si 443. python3 -m guardia outil list",
    ),
    Outil(
        id="dns-axfr",
        nom="nmap dns-zone-transfer",
        bins=("nmap",),
        scope="cidr",
        pourquoi="Transfert de zone DNS s'il est ouvert.",
        commande="nmap -p 53 --script dns-zone-transfer {host}",
        aide="Calibré si 53. Lecture, pas de modification.",
    ),
    Outil(
        id="snmpwalk",
        nom="snmpwalk public",
        bins=("snmpwalk",),
        scope="cidr",
        pourquoi="Inventaire SNMP communauté public (system). Pas d'écriture.",
        commande="snmpwalk -v2c -c public -t 2 -r 1 {host} system",
        aide="Calibré si 161. Paquet Kali : `sudo apt install snmp`.",
        install="sudo apt install snmp",
    ),
    Outil(
        id="greenbone",
        nom="Greenbone / OpenVAS (GVM)",
        bins=("gvm-cli", "gvm-start", "gvmd", "openvas"),
        scope="local",
        pourquoi="Pilier vulnérabilités (CVE structurées). Guardia orchestre la lecture GMP (version / feeds), pas un Full and Fast auto.",
        commande="gvm-cli socket --xml '<get_version/>'",
        aide="Guardia lit GVM s'il est là (`--greenbone` / YAML greenbone: true). Absent : on continue. Scan Full and Fast : GSA.",
        auto=True,
        install="sudo apt install gvm && sudo gvm-setup",
    ),
    Outil(
        id="lynis",
        nom="Lynis (Linux local)",
        bins=("lynis",),
        scope="local",
        pourquoi="Durcissement d'une machine Linux autorisée. Pas un scan réseau.",
        commande="sudo lynis audit system --quick --no-colors",
        aide="Sur Kali opérateur : `sudo apt install lynis` puis `--lynis`. Un Linux client s'audite SUR CE POSTE, avec mandat : `sudo lynis audit system`.",
        auto=True,
        install="sudo apt install lynis",
    ),
    Outil(
        id="trivy",
        nom="Trivy",
        bins=("trivy",),
        scope="local",
        pourquoi="Conteneurs, systèmes de fichiers, dépendances. Pas un scan LAN.",
        commande="trivy fs --quiet .",
        aide="Guardia orchestre `--trivy` sur le poste opérateur. YAML trivy: true. Absent : on continue.",
        auto=True,
        install="sudo apt install trivy",
    ),
)

_PATHS_EXTRA: dict[str, tuple[str, ...]] = {
    "testssl": (
        "/usr/bin/testssl.sh",
        "/usr/share/testssl.sh/testssl.sh",
    ),
}


def get_outil(oid: str) -> Outil | None:
    oid = (oid or "").strip().lower()
    for o in CATALOGUE:
        if o.id == oid:
            return o
    return None


def binaire(outil: Outil) -> str | None:
    for name in outil.bins:
        w = shutil.which(name)
        if w:
            return w
    for raw in _PATHS_EXTRA.get(outil.id, ()):
        p = Path(raw)
        if p.is_file():
            return str(p)
    return None


def urls_du_programme(mission: Mission, url: str | None = None) -> list[str]:
    extras = mission.extras or {}
    out: list[str] = []
    if url:
        out.append(str(url).strip())
    for key in ("site_url", "urls_programme"):
        val = extras.get(key)
        if isinstance(val, str) and val.strip():
            if val.strip().lower() not in ("1", "true", "oui", "yes"):
                out.append(val.strip())
        elif isinstance(val, list):
            out.extend(str(x).strip() for x in val if str(x).strip())
    seen: set[str] = set()
    uniq: list[str] = []
    for u in out:
        if not u.startswith("http"):
            u = "https://" + u
        if u not in seen:
            seen.add(u)
            uniq.append(u)
    return uniq


def avenant_web_coche(_args: Any | None, _mission: Mission) -> bool:
    return False


def _autorise(outil: Outil, *, has_url: bool, has_cidr: bool) -> bool:
    if outil.scope == "local":
        return True
    if outil.scope == "url" and not has_url:
        return False
    if outil.scope == "cidr" and not has_cidr:
        return False
    return True


def commande_encadree(outil: Outil, url: str = "", cidr: str = "") -> str:
    host = ""
    if url:
        u = urlparse(url if "://" in url else f"https://{url}")
        host = u.hostname or ""
        if u.port:
            host = f"{host}:{u.port}"
        elif (u.scheme or "https") == "https":
            host = f"{host}:443"
    if not host and cidr:
        host = cidr.split("/")[0]
    return (
        outil.commande.replace("{url}", url or "<URL>")
        .replace("{cidr}", cidr or "<CIDR>")
        .replace("{host}", host or "<hôte>")
    )


def build_programme(
    mission: Mission,
    *,
    cidr: str = "",
    url: str | None = None,
    args: Any | None = None,
    lecture: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    _ = args
    urls = urls_du_programme(mission, url)
    has_url = bool(urls)
    has_cidr = bool((cidr or mission.cidr or "").strip())
    outils = []
    for o in CATALOGUE:
        bin_ = binaire(o)
        outils.append(
            {
                "id": o.id,
                "nom": o.nom,
                "mode": "lecture",
                "auto": bool(o.auto),
                "scope": o.scope,
                "installe": bool(bin_),
                "binaire": bin_ or "",
                "autorise": _autorise(o, has_url=has_url, has_cidr=has_cidr),
                "pourquoi": o.pourquoi,
                "aide": o.aide,
                "install": o.install,
                "commande": commande_encadree(o, urls[0] if urls else "", cidr or mission.cidr or ""),
            }
        )
    return {
        "encadre": True,
        "analogie": PROGRAMME,
        "client": mission.client,
        "mandat": bool(mission.mandat_nda_signes),
        "assets": {
            "cidr": cidr or mission.cidr or "",
            "urls": urls,
        },
        "regles": [
            "Mandat écrit avant tout checkup.",
            "Périmètre : CIDR et/ou URL du jour.",
            "Calibrage : Guardia lance les outils installés, selon les portes vues.",
            "Absent : invitation d'installation Kali (apt + cheminement), on continue.",
            "Greenbone / Lynis / Trivy : orchestrés (lecture). Absent = on continue.",
        ],
        "outils": outils,
        "lecture": lecture or [],
        "fait_le": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
    }


def ecrire_programme(block: dict[str, Any], dest: Path | None = None) -> Path:
    RAPPORTS.mkdir(parents=True, exist_ok=True)
    if dest is None:
        stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
        dest = RAPPORTS / f"programme-{stamp}.json"
    dest.write_text(json.dumps(block, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return dest


def ouvrir_outil(oid: str, url: str | None = None) -> tuple[bool, str]:
    o = get_outil(oid)
    if o is None:
        connus = ", ".join(x.id for x in CATALOGUE)
        return False, f"Outil inconnu : {oid}. Catalogue : {connus}."
    cmd = commande_encadree(o, url or "")
    return False, f"{o.nom} se lance au calibrage. Aide : {o.aide} · {cmd}"


def _run_capt(argv: list[str], timeout: int) -> dict[str, Any]:
    try:
        p = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError:
        return {"ok": False, "extrait": "binaire introuvable"}
    except subprocess.TimeoutExpired:
        return {"ok": False, "extrait": f"timeout {timeout}s"}
    except OSError as exc:
        return {"ok": False, "extrait": str(exc)}
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return {"ok": p.returncode == 0, "extrait": out[:4000], "rc": p.returncode}


def run_lecture_ciblee(
    url: str, timeout: int = 25, *, profond: bool = False
) -> list[dict[str, Any]]:
    """Lance les outils URL du mandat. whois / dig / host, puis curl. profond=True : + wafw00f / nuclei / nikto / sslyze."""
    url = (url or "").strip()
    if not url:
        return []
    if not url.startswith("http"):
        url = "https://" + url
    host = urlparse(url).hostname or ""
    ids = ["whois", "dig", "host", "curl", "testssl", "sslscan", "whatweb"]
    if profond:
        ids.extend(["wafw00f", "nuclei", "nikto", "sslyze"])
    rows: list[dict[str, Any]] = []
    for oid in ids:
        o = get_outil(oid)
        if o is None:
            continue
        bin_ = binaire(o)
        if not bin_:
            print(f"  {o.nom}: absent — on continue", flush=True)
            rows.append(
                {"id": oid, "nom": o.nom, "installe": False, "lance": False, "extrait": "", "etat": "absent"}
            )
            continue
        if oid == "curl":
            argv = [
                bin_, "-sI", "-m", str(min(12, timeout)),
                "-A", "Guardia (Echoes of Hackers; checkup defensif autorise)",
                url,
            ]
        elif oid == "whois":
            argv = [bin_, host or url]
        elif oid == "dig":
            argv = [bin_, "+time=3", "+tries=1", "+noall", "+answer", "A", "MX", "NS", "TXT", host or url]
        elif oid == "host":
            argv = [bin_, host or url]
        elif oid == "testssl":
            argv = [bin_, "--fast", "--quiet", "--color", "0", url]
        elif oid == "sslscan":
            cible = f"{host}:443" if host else url
            argv = [bin_, "--no-failed", cible]
        elif oid == "whatweb":
            argv = [bin_, "-a", "1" if not profond else "3", "--color=never", url]
        elif oid == "wafw00f":
            argv = [bin_, "-a", url]
        elif oid == "nuclei":
            argv = [
                bin_, "-u", url, "-silent", "-nc",
                "-tags", "tech,info,tls,ssl",
                "-etags", "exploit,rce,lfi,sqli,kev,takeover",
                "-rate-limit", "8", "-c", "4",
            ]
        elif oid == "nikto":
            argv = [bin_, "-h", url, "-Tuning", "1", "-maxtime", "40" if profond else "20", "-nointeractive"]
        elif oid == "sslyze":
            argv = [bin_, "--json_out=-", f"{host}:443" if host else url]
        else:
            argv = [bin_, url]
        to = timeout if oid not in ("testssl", "nikto", "nuclei") else max(timeout, 25)
        res = _run_capt(argv, timeout=to)
        etat = "ok" if res.get("ok") else "note"
        print(f"  {o.nom}: {etat}", flush=True)
        rows.append(
            {
                "id": oid,
                "nom": o.nom,
                "installe": True,
                "lance": True,
                "ok": res.get("ok"),
                "etat": etat,
                "extrait": res.get("extrait") or "",
                "commande": " ".join(argv),
            }
        )
    return rows

