"""Détection locale du réseau (ignorant — on découvre)."""
from __future__ import annotations

import logging
import re
import subprocess
from dataclasses import dataclass

log = logging.getLogger("guardia.netinfo")


@dataclass
class NetContext:
    iface: str
    gateway: str
    cidr: str
    local_ip: str


def _run(cmd: list[str], timeout: int = 15) -> str:
    try:
        p = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
        return (p.stdout or "") + (p.stderr or "")
    except FileNotFoundError:
        log.warning("commande absente: %s", cmd[0])
        return ""
    except subprocess.TimeoutExpired:
        log.warning("timeout: %s", " ".join(cmd))
        return ""
    except OSError as exc:
        log.warning("échec %s: %s", cmd[0], exc)
        return ""


def detect() -> NetContext:
    """Trouve iface défaut, gateway, CIDR IPv4 — lève RuntimeError si impossible."""
    route = _run(["ip", "-4", "route", "show", "default"])
    m = re.search(r"default via (\S+) dev (\S+)", route)
    if not m:
        # fallback: première iface UP avec ipv4
        br = _run(["ip", "-br", "-4", "a"])
        for line in br.splitlines():
            parts = line.split()
            if len(parts) >= 3 and parts[1] == "UP" and parts[0] != "lo":
                iface = parts[0]
                ip_cidr = parts[2]
                return NetContext(iface=iface, gateway="", cidr=_guess_cidr(ip_cidr), local_ip=ip_cidr.split("/")[0])
        raise RuntimeError("aucune route par défaut IPv4 trouvée")

    gateway, iface = m.group(1), m.group(2)
    addr = _run(["ip", "-4", "-o", "addr", "show", "dev", iface])
    m2 = re.search(r"inet (\d+\.\d+\.\d+\.\d+/\d+)", addr)
    if not m2:
        raise RuntimeError(f"pas d'IPv4 sur {iface}")
    ip_cidr = m2.group(1)
    local_ip = ip_cidr.split("/")[0]
    # préfère le prefixe réseau kernel
    links = _run(["ip", "-4", "route", "show", "dev", iface])
    cidr = None
    for line in links.splitlines():
        if "proto kernel" in line and "/" in line.split()[0]:
            cidr = line.split()[0]
            break
    if not cidr:
        cidr = _guess_cidr(ip_cidr)
    log.info("réseau: iface=%s ip=%s gw=%s cidr=%s", iface, local_ip, gateway, cidr)
    return NetContext(iface=iface, gateway=gateway, cidr=cidr, local_ip=local_ip)


def _guess_cidr(ip_cidr: str) -> str:
    ip, prefix = ip_cidr.split("/")
    prefix = int(prefix)
    if prefix >= 24:
        a, b, c, _ = ip.split(".")
        return f"{a}.{b}.{c}.0/24"
    return ip_cidr
