"""Inventaire des outils Kali présents sur la machine opérateur ÉOH.

Une seule machine. Guardia liste ce qu'il peut lancer, et ce qui manque.
Pas besoin de sudo : /usr/bin se lit. Écrit rapports/inventaire-kali.txt
"""
from __future__ import annotations

import os
import shutil
import stat
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from guardia.core.paths import RAPPORTS, ROOT

# Programmes Kali utiles en évaluation défensive — chemins usuels.
CATALOGUE_KALI: tuple[tuple[str, str], ...] = (
    ("nmap", "empreinte LAN"),
    ("arp-scan", "inventaire L2"),
    ("netdiscover", "inventaire L2 alternatif"),
    ("nbtscan", "noms NetBIOS"),
    ("nmblookup", "NetBIOS"),
    ("smbclient", "liste de partages"),
    ("enum4linux", "enum SMB lecture"),
    ("enum4linux-ng", "enum SMB lecture"),
    ("showmount", "exports NFS"),
    ("ldapsearch", "rootDSE"),
    ("snmpget", "SNMP public"),
    ("snmpwalk", "SNMP public"),
    ("ike-scan", "VPN IKE"),
    ("ssh-audit", "algorithmes SSH"),
    ("sslscan", "ciphers TLS"),
    ("testssl.sh", "revue TLS"),
    ("testssl", "revue TLS"),
    ("whatweb", "empreinte HTTP"),
    ("wafw00f", "WAF"),
    ("nuclei", "tech/info/tls"),
    ("nikto", "fichiers intéressants"),
    ("wpscan", "WordPress passif"),
    ("sslyze", "revue TLS"),
    ("smbmap", "partages SMB"),
    ("onesixtyone", "SNMP public"),
    ("ntpq", "NTP"),
    ("curl", "en-têtes"),
    ("openssl", "s_client"),
    ("dig", "DNS local"),
    ("dnsrecon", "DNS local"),
    ("avahi-browse", "mDNS"),
    ("rpcinfo", "portmapper RPC"),
    ("tcpdump", "capture si mandat"),
    ("tshark", "capture si mandat"),
    ("p0f", "empreinte passive"),
    ("traceroute", "chemin"),
    ("lynis", "durcissement Linux local"),
    ("trivy", "conteneurs / FS / dépendances"),
    ("gvm-cli", "Greenbone CLI"),
    ("gvm-start", "Greenbone start"),
    ("gvmd", "Greenbone manager"),
    ("openvas", "moteur OpenVAS"),
    ("gsad", "Greenbone Security Assistant"),
)


def _which(name: str) -> str | None:
    p = shutil.which(name)
    if p:
        return p
    for c in (f"/usr/bin/{name}", f"/usr/sbin/{name}", f"/usr/share/{name}/{name}"):
        if Path(c).is_file():
            return c
    return None


def scan_path_bins(limit: int = 4000) -> list[str]:
    """Listing brut des exécutables dans PATH — sans sudo."""
    seen: set[str] = set()
    out: list[str] = []
    for d in (os.environ.get("PATH") or "").split(os.pathsep):
        if not d:
            continue
        try:
            entries = list(Path(d).iterdir())
        except OSError:
            continue
        for p in entries:
            name = p.name
            if name in seen:
                continue
            try:
                st = p.stat()
            except OSError:
                continue
            if stat.S_ISREG(st.st_mode) and (st.st_mode & 0o111):
                seen.add(name)
                out.append(f"{name}\t{p}")
                if len(out) >= limit:
                    return sorted(out, key=str.lower)
    return sorted(out, key=str.lower)


def build_inventaire(*, brut: bool = True) -> dict[str, Any]:
    present: list[dict[str, str]] = []
    absent: list[dict[str, str]] = []
    for nom, role in CATALOGUE_KALI:
        path = _which(nom)
        row = {"nom": nom, "role": role, "chemin": path or ""}
        if path:
            present.append(row)
        else:
            absent.append(row)
    listing = scan_path_bins() if brut else []
    return {
        "quand": datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
        "racine": str(ROOT),
        "euid": os.geteuid() if hasattr(os, "geteuid") else -1,
        "path": os.environ.get("PATH", ""),
        "present": present,
        "absent": absent,
        "brut": listing,
        "n_brut": len(listing),
    }


def format_txt(inv: dict[str, Any]) -> str:
    lines = [
        "Guardia — inventaire Kali (machine opérateur ÉOH)",
        f"Date : {inv.get('quand')}",
        f"Racine : {inv.get('racine')}",
        f"euid : {inv.get('euid')} (pas besoin de sudo pour lister /usr/bin)",
        "",
        "== Catalogue de lecture : installés ==",
    ]
    for r in inv.get("present") or []:
        lines.append(f"  {r['nom']:16} {r['chemin']:40} {r['role']}")
    lines += ["", "== Catalogue de lecture : absents (l'évaluation continue sans) =="]
    for r in inv.get("absent") or []:
        lines.append(f"  {r['nom']:16} {r['role']}")
    lines += [
        "",
        f"== PATH brut ({inv.get('n_brut', 0)} exécutables) ==",
    ]
    for row in inv.get("brut") or []:
        lines.append(f"  {row}")
    lines += [
        "",
        "Relancer : python3 -m guardia inventaire",
        "Calibrage : python3 -m guardia run -m missions/exemple-pme.yaml --yes",
        "",
    ]
    return "\n".join(lines) + "\n"


def ecrire_inventaire(inv: dict[str, Any] | None = None, dest: Path | None = None) -> Path:
    RAPPORTS.mkdir(parents=True, exist_ok=True)
    if inv is None:
        inv = build_inventaire()
    if dest is None:
        dest = RAPPORTS / "inventaire-kali.txt"
    dest.write_text(format_txt(inv), encoding="utf-8")
    return dest
