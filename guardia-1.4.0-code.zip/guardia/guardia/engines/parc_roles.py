"""Rôles de desserte : quelle machine sert les autres.

Ce n'est pas un inventaire de plus. Sur un parc scolaire, une PME ou une
fac, une seule machine (annuaire, fichiers, ENT, impression) tient souvent
le reste. Un trou là = tout le monde.

Heuristiques défensives, génériques — aucun nom de site, aucun client.
"""
from __future__ import annotations

import re
from typing import Any

from guardia.core.models import Host

AD_PORTS = {88, 389, 636, 3268, 3269}
FILE_EXTRA = {2049, 548}  # NFS, AFP
SMB_PORTS = {139, 445}
PRINT_PORTS = {9100, 515, 631}
DNS_PORT = {53}
RDS_PORTS = {3389, 5900}

_HN_ANNUAIRE = re.compile(
    r"\b(dc|pdc|adc|ad[-_]|ldap|samba|idm|freeipa|openldap)\b", re.I
)
_HN_FICHIER = re.compile(
    r"\b(srv|serveur|fileserver|file[-_]?srv|nas|storage|partage)\b", re.I
)


def ports_of(host: Host) -> set[int]:
    out: set[int] = set()
    for p in host.ports or []:
        try:
            n = int(p.get("port", -1))
        except (TypeError, ValueError):
            continue
        if n > 0:
            out.add(n)
    return out


def host_roles(host: Host) -> list[str]:
    """Rôles techniques visibles (ports + nom), sans authentification."""
    ps = ports_of(host)
    hn = f"{host.hostname or ''} {host.kind or ''}"
    roles: list[str] = []
    if ps & AD_PORTS or _HN_ANNUAIRE.search(hn):
        roles.append("annuaire")
    if (
        host.kind in ("nas", "serveur")
        or ps & FILE_EXTRA
        or _HN_FICHIER.search(host.hostname or "")
    ):
        roles.append("fichiers")
    if ps & PRINT_PORTS and host.kind in ("imprimante", "serveur", "nas"):
        roles.append("impression")
    if 53 in ps and ("annuaire" in roles or host.kind == "serveur"):
        roles.append("dns_interne")
    if ps & RDS_PORTS and host.kind in ("serveur", "nas"):
        roles.append("bureau_distant")
    # unique-ify keep order
    seen: set[str] = set()
    out: list[str] = []
    for r in roles:
        if r not in seen:
            seen.add(r)
            out.append(r)
    return out


def detect_serveurs_parc(hosts: list[Host]) -> list[dict[str, Any]]:
    """Machines qui *desservent* le parc, pas les postes individuels.

    Un PC Windows avec 445 n'est pas un serveur de parc.
    Un ou deux hôtes SMB au milieu de beaucoup de postes, si : oui.
    Un NAS / un annuaire / un hostname srv-* : oui.
    """
    n = len(hosts)
    smb_hosts = [h for h in hosts if ports_of(h) & SMB_PORTS]
    out: list[dict[str, Any]] = []
    for h in hosts:
        roles = host_roles(h)
        ps = ports_of(h)
        # Fichiers SMB : seulement si ce n'est pas « tous les PC ont 445 »
        if ps & SMB_PORTS:
            central_smb = (
                h.kind in ("nas", "serveur")
                or "annuaire" in roles
                or "fichiers" in roles
                or _HN_FICHIER.search(h.hostname or "")
            )
            # 1–2 hôtes SMB dans un parc : desserte, sauf si c'est clairement un poste
            if (
                not central_smb
                and len(smb_hosts) <= 2
                and n >= 5
                and h.kind not in ("pc", "phone", "tv", "console")
            ):
                central_smb = True
            if central_smb and "fichiers" not in roles:
                roles.append("fichiers")
        if not roles:
            continue
        out.append(
            {
                "ip": h.ip,
                "hostname": h.hostname or "",
                "kind": h.kind or "inconnu",
                "roles": roles,
                "ports": sorted(ps),
                "portee": (
                    "Un incident sur cette machine touche le reste du parc "
                    "(sessions, fichiers, impressions, comptes)."
                ),
            }
        )
    return out


def blast_sentence(serveurs: list[dict[str, Any]]) -> str:
    if not serveurs:
        return (
            "Aucun serveur de desserte identifié à distance "
            "(annuaire / fichiers / NAS). À confirmer avec vous : "
            "il y en a souvent un, même discret."
        )
    bits = []
    for s in serveurs[:6]:
        roles = ", ".join(s.get("roles") or []) or "?"
        name = s.get("hostname") or s.get("ip")
        bits.append(f"{name} ({roles})")
    extra = "…" if len(serveurs) > 6 else ""
    return (
        f"{len(serveurs)} machine(s) dessert/desservent le parc : "
        + " ; ".join(bits)
        + extra
        + ". C'est là que les droits comptent le plus."
    )
