"""Polish LLM optionnel — reformule les findings, n'invente rien.

Utilise llama-server (Vulkan) de bot_y si dispo, sinon un serveur déjà
écoute sur --llm-url. Les faits (preuve, gravité, id, priorite) restent
intacts ; seuls titre / pourquoi_nuit / remede_etapes / qui_peut peuvent
être clarifiés en français courant.
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import subprocess
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

from guardia.core.models import CheckupResult, Finding, Host, Mission

log = logging.getLogger("guardia.llm")


def gpu_nvidia_dispo() -> bool:
    """True si nvidia-smi voit au moins un GPU."""
    import shutil
    import subprocess

    if not shutil.which("nvidia-smi"):
        return False
    try:
        r = subprocess.run(
            ["nvidia-smi", "-L"],
            capture_output=True,
            text=True,
            timeout=3,
        )
        return r.returncode == 0 and "GPU" in (r.stdout or "")
    except (OSError, subprocess.TimeoutExpired):
        return False


def apply_prime_env(env: dict[str, str]) -> dict[str, str]:
    """Offload RTX sur hybride AMD+NVIDIA (écran reste AMD) — comme ~/bin/gpu."""
    env = dict(env)
    env["__NV_PRIME_RENDER_OFFLOAD"] = "1"
    env["__GLX_VENDOR_LIBRARY_NAME"] = "nvidia"
    env["__VK_LAYER_NV_optimus"] = "NVIDIA_only"
    env.setdefault(
        "VK_ICD_FILENAMES",
        "/usr/share/vulkan/icd.d/nvidia_icd.json",
    )
    return env


def resolve_ngl(requested: int, *, allow_cpu: bool = False) -> tuple[int, str]:
    """Si GPU trouvée et pas allow_cpu, force ngl>0 (défaut 99)."""
    req = int(requested)
    has = gpu_nvidia_dispo()
    if has and req <= 0 and not allow_cpu:
        log.info("GPU NVIDIA détectée — ngl forcé 99 (passe --cpu-llm pour CPU)")
        return 99, "gpu-forcé"
    if has and req > 0:
        return req, "gpu"
    if not has:
        return max(0, req), "cpu-pas-de-gpu"
    return max(0, req), "cpu-autorisé"


DEFAULT_PORT = 2443
BUNDLED_MODEL = Path(__file__).resolve().parents[2] / "models" / "cybersec-assistant-3b-Q4_K_M.gguf"
DEFAULT_MODEL_CANDIDATES = (
    BUNDLED_MODEL,
    Path("/run/media/platon-y/468EDC833CB95F10/guardia-models/cybersec-assistant-3b-Q4_K_M.gguf"),
    Path("/home/platon-y/Bureau/guardia/models/cybersec-assistant-3b-Q4_K_M.gguf"),
    Path.home() / "Bureau/guardia/models/cybersec-assistant-3b-Q4_K_M.gguf",
    Path.home() / "Bureau/guardia/models/cybersec-assistant-3b.gguf",
)
BOT_Y_SERVER = Path.home() / "Bureau/bot_y/moteur/llama-server"
# sous root, Path.home() = /root — garder le moteur côté opérateur platon-y
OPERATOR_SERVER = Path("/home/platon-y/Bureau/bot_y/moteur/llama-server")
ROOT_SIBLING_SERVER = Path(__file__).resolve().parents[3] / "bot_y" / "moteur" / "llama-server"
MIN_GGUF = 10_000_000
_SKIP_DIRS = {
    ".git",
    "node_modules",
    "__pycache__",
    "proc",
    "sys",
    "lost+found",
    ".cache",
    "Trash",
    ".Trash-1000",
    "snap",
}
_PREF = ("cybersec", "assistant", "instruct", "qwen", "mistral", "llama", "phi")
LAST_SEARCH: dict[str, Any] = {"dirs": [], "found": [], "skipped_small": []}
_cached_model: Path | None | str = "unset"


def _gguf_dirs() -> list[Path]:
    dirs: list[Path] = []
    try:
        from guardia.core.paths import ROOT

        dirs.extend(
            [
                ROOT / "models",
                ROOT / "modeles-llm",
                ROOT.parent / "guardia-models",
                ROOT.parent / "models",
                ROOT.parent / "modeles-llm",
            ]
        )
    except Exception:
        pass
    dirs.extend(
        [
            Path("/run/media/platon-y/468EDC833CB95F10/guardia-models"),
            Path("/home/platon-y/Bureau/guardia/models"),
            Path("/home/platon-y/Bureau/bot_y/modeles"),
            Path("/home/platon-y/Bureau/bot_y/models"),
            Path("/home/platon-y/Bureau/bot_y/moteur"),
            Path.home() / "Bureau/guardia/models",
            Path.home() / "guardia/models",
        ]
    )
    try:
        media = Path("/run/media")
        if media.is_dir():
            dirs.extend(sorted(media.glob("*/guardia-models")))
            dirs.extend(sorted(media.glob("*/*/guardia-models")))
            dirs.extend(sorted(media.glob("*/guardia/models")))
            dirs.extend(sorted(media.glob("*/models")))
            dirs.extend(sorted(media.glob("*/*/models")))
    except OSError:
        pass
    seen: set[str] = set()
    out: list[Path] = []
    for d in dirs:
        key = str(d)
        if key in seen:
            continue
        seen.add(key)
        out.append(d)
    return out


def _first_gguf(directory: Path) -> Path | None:
    try:
        if not directory.is_dir():
            return None
        for f in sorted(directory.glob("*.gguf")):
            try:
                if f.is_file() and f.stat().st_size > MIN_GGUF:
                    return f
            except OSError:
                continue
    except OSError:
        return None
    return None


def _walk_gguf(root: Path, max_depth: int = 3) -> list[Path]:
    found: list[Path] = []
    try:
        if not root.is_dir():
            return found
    except OSError:
        return found
    try:
        for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
            try:
                depth = len(Path(dirpath).relative_to(root).parts)
            except ValueError:
                depth = max_depth
            dirnames[:] = [d for d in dirnames if d not in _SKIP_DIRS and not d.startswith(".")]
            if depth >= max_depth:
                dirnames[:] = []
            for fn in filenames:
                if not fn.lower().endswith(".gguf"):
                    continue
                p = Path(dirpath) / fn
                try:
                    sz = p.stat().st_size
                except OSError:
                    continue
                if sz > MIN_GGUF:
                    found.append(p)
                else:
                    LAST_SEARCH["skipped_small"].append(
                        "{p} ({n} Mo)".format(p=p, n=sz // 1_000_000)
                    )
    except OSError:
        return found
    return found


def _score(path: Path) -> tuple[int, int]:
    name = path.name.lower()
    pref = 0
    for i, key in enumerate(_PREF):
        if key in name:
            pref = 80 - i
            break
    try:
        sz = path.stat().st_size
    except OSError:
        sz = 0
    return (pref, sz)


def _pick(cands: list[Path]) -> Path | None:
    uniq: list[Path] = []
    seen: set[str] = set()
    for p in cands:
        k = str(p)
        if k in seen:
            continue
        seen.add(k)
        uniq.append(p)
    if not uniq:
        return None
    uniq.sort(key=_score, reverse=True)
    LAST_SEARCH["found"] = [str(p) for p in uniq]
    return uniq[0]


def _walk_roots() -> list[Path]:
    roots: list[Path] = []
    try:
        from guardia.core.paths import ROOT

        roots.extend([ROOT, ROOT.parent])
    except Exception:
        pass
    roots.extend(
        [
            Path("/run/media/platon-y/468EDC833CB95F10"),
            Path("/home/platon-y/Bureau/bot_y"),
            Path("/home/platon-y/Bureau/guardia"),
            Path("/home/platon-y/Bureau"),
        ]
    )
    try:
        media = Path("/run/media")
        if media.is_dir():
            for p in sorted(media.glob("*")):
                if p.is_dir():
                    roots.append(p)
            for p in sorted(media.glob("*/*")):
                if p.is_dir():
                    roots.append(p)
    except OSError:
        pass
    try:
        srv = resolve_server(None)
    except Exception:
        srv = None
    if srv:
        roots.extend([srv.parent, srv.parent.parent])
    seen: set[str] = set()
    out: list[Path] = []
    for r in roots:
        k = str(r)
        if k in seen:
            continue
        seen.add(k)
        out.append(r)
    return out


def resolve_model(explicit: str | None) -> Path | None:
    global _cached_model
    env = (os.environ.get("GUARDIA_LLM_MODEL") or "").strip()
    if explicit or env:
        p = Path(explicit or env).expanduser()
        try:
            return p if p.is_file() else None
        except OSError:
            return None
    if _cached_model != "unset":
        return _cached_model if isinstance(_cached_model, Path) else None
    LAST_SEARCH["dirs"] = []
    LAST_SEARCH["found"] = []
    LAST_SEARCH["skipped_small"] = []
    cands: list[Path] = []
    for c in DEFAULT_MODEL_CANDIDATES:
        try:
            if c.is_file() and c.stat().st_size > MIN_GGUF:
                cands.append(c)
        except OSError:
            continue
    for d in _gguf_dirs():
        LAST_SEARCH["dirs"].append(str(d))
        found = _first_gguf(d)
        if found:
            cands.append(found)
    for root in _walk_roots():
        LAST_SEARCH["dirs"].append(str(root) + "/**")
        cands.extend(_walk_gguf(root, max_depth=3))
    picked = _pick(cands)
    _cached_model = picked
    return picked


def _is_file(path: Path) -> bool:
    try:
        return path.is_file()
    except OSError:
        return False


def resolve_server(explicit: str | None) -> Path | None:
    if explicit:
        p = Path(explicit).expanduser()
        return p if _is_file(p) else None
    cands = [
        OPERATOR_SERVER,
        ROOT_SIBLING_SERVER,
        BOT_Y_SERVER,
        Path("/home/platon-y/Bureau/bot_y/moteur/llama-server"),
        Path("/usr/local/bin/llama-server"),
        Path("/usr/bin/llama-server"),
    ]
    try:
        from guardia.core.paths import ROOT

        cands.extend(
            [
                ROOT / "bin" / "llama-server",
                ROOT.parent / "bot_y" / "moteur" / "llama-server",
                ROOT.parent / "llama-server",
            ]
        )
    except Exception:
        pass
    try:
        media = Path("/run/media")
        if media.is_dir():
            cands.extend(sorted(media.glob("*/bot_y/moteur/llama-server")))
            cands.extend(sorted(media.glob("*/*/bot_y/moteur/llama-server")))
    except OSError:
        pass
    for cand in cands:
        if _is_file(cand):
            return cand
    which = shutil.which("llama-server") or shutil.which("llama-cpp-server")
    return Path(which) if which else None


SYSTEM = (
    "Tu es le stylo de Guardia. Un constat moteur t'est donné : tu le rends lisible."
    " Tu ne crées aucun fait. Tu ne changes pas la gravité. Tu n'ajoutes pas d'outil."
    " qui_peut = la personne qui corrige (admin, occupant, prestataire). Jamais un attaquant."
    " remede_etapes = les mêmes gestes, plus clairs."
    " Réponds uniquement JSON : titre, pourquoi_nuit, remede_etapes, qui_peut."
)


class LlmSession:
    def __init__(
        self,
        *,
        model: Path | None,
        server_bin: Path | None,
        base_url: str,
        ngl: int,
        threads: int = 8,
        ctx: int = 2048,
    ) -> None:
        self.model = model
        self.server_bin = server_bin
        self.base_url = base_url.rstrip("/")
        self.ngl = ngl
        self.threads = threads
        self.ctx = ctx
        self._proc: subprocess.Popen[Any] | None = None
        self._owned = False

    def ensure(self) -> None:
        if self._healthy():
            return
        if self.server_bin is None or self.model is None:
            raise RuntimeError(
                "LLM indisponible : pas de serveur déjà prêt, et modèle ou "
                "llama-server introuvable. Place le GGUF sous models/ "
                "ou passe --llm-model / --llm-url."
            )
        env = dict(os.environ)
        libdir = str(self.server_bin.parent)
        env["LD_LIBRARY_PATH"] = libdir + (
            (":" + env["LD_LIBRARY_PATH"]) if env.get("LD_LIBRARY_PATH") else ""
        )
        if self.ngl > 0 and gpu_nvidia_dispo():
            env = apply_prime_env(env)
            log.info("PRIME offload RTX activé pour llama-server")
        port = DEFAULT_PORT
        try:
            port = int(self.base_url.rsplit(":", 1)[-1].split("/")[0])
        except ValueError:
            port = DEFAULT_PORT
        log.info("démarrage llama-server modèle=%s port=%s ngl=%s", self.model.name, port, self.ngl)
        self._proc = subprocess.Popen(
            [
                str(self.server_bin),
                "-m",
                str(self.model),
                "--host",
                "127.0.0.1",
                "--port",
                str(port),
                "-c",
                str(self.ctx),
                "-t",
                str(self.threads),
                "-ngl",
                str(self.ngl),
                "--chat-template",
                "chatml",
                "--no-webui",
            ],
            cwd=str(self.server_bin.parent),
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )
        self._owned = True
        deadline = time.time() + 180
        while time.time() < deadline:
            if self._proc.poll() is not None:
                raise RuntimeError("llama-server s'est arrêté au démarrage")
            if self._healthy():
                return
            time.sleep(0.5)
        raise RuntimeError("timeout démarrage llama-server (health)")

    def _healthy(self) -> bool:
        try:
            with urllib.request.urlopen(f"{self.base_url}/health", timeout=2) as rep:
                return 200 <= getattr(rep, "status", 200) < 300
        except (OSError, urllib.error.URLError):
            return False

    def chat(self, user: str, *, max_tokens: int = 400, temperature: float = 0.15) -> str:
        base = {
            "messages": [
                {"role": "system", "content": SYSTEM},
                {"role": "user", "content": user},
            ],
            "max_tokens": max_tokens,
            "temperature": temperature,
        }

        def _post(payload: dict[str, Any]) -> str:
            req = urllib.request.Request(
                f"{self.base_url}/v1/chat/completions",
                data=json.dumps(payload).encode("utf-8"),
                headers={"Content-Type": "application/json"},
                method="POST",
            )
            with urllib.request.urlopen(req, timeout=180) as rep:
                data = json.loads(rep.read().decode("utf-8"))
            return (data["choices"][0]["message"]["content"] or "").strip()

        try:
            return _post({**base, "response_format": {"type": "json_object"}})
        except urllib.error.HTTPError:
            return _post(base)

    def close(self) -> None:
        if self._owned and self._proc is not None and self._proc.poll() is None:
            self._proc.terminate()
            try:
                self._proc.wait(timeout=8)
            except subprocess.TimeoutExpired:
                self._proc.kill()
        self._proc = None
        self._owned = False


def _extract_json(text: str) -> dict[str, Any] | None:
    text = (text or "").strip()
    if not text:
        return None
    if "```" in text:
        lines = [ln for ln in text.splitlines() if not ln.strip().startswith("```")]
        text = "\n".join(lines).strip()
    start = text.find("{")
    end = text.rfind("}")
    if start < 0 or end <= start:
        return None
    chunk = text[start : end + 1]
    for candidate in (chunk, chunk.replace("'", '"')):
        try:
            data = json.loads(candidate)
        except json.JSONDecodeError:
            continue
        if not isinstance(data, dict):
            continue
        # rejette un echo de la payload d'entrée
        if "finding" in data or "hote" in data or "ton" in data:
            continue
        if "titre" not in data:
            continue
        return data
    return None


def _user_prompt(finding: Finding, mission: Mission, host: Host) -> str:
    ton = "tutoiement" if mission.ton_rapport == "tutoiement" else "vouvoiement"
    remede = "\n".join(f"- {s}" for s in finding.remede_etapes) or "- (aucune)"
    return (
        f"Ton du rapport: {ton}\n"
        f"Hôte: {host.ip} ({host.hostname or 'sans nom'}, type {host.kind})\n"
        f"Gravité (ne pas changer): {finding.gravite.value}\n"
        f"Preuve (ne pas changer): {finding.preuve}\n"
        f"Titre actuel: {finding.titre}\n"
        f"Pourquoi ça nuit: {finding.pourquoi_nuit}\n"
        f"Remèdes actuels:\n{remede}\n"
        f"Qui peut: {finding.qui_peut}\n\n"
        "Reformule titre / pourquoi_nuit / remede_etapes / qui_peut. "
        "Même sens, plus clair. JSON uniquement."
    )


def _apply(data: dict[str, Any], finding: Finding) -> None:
    titre = data.get("titre")
    pourquoi = data.get("pourquoi_nuit")
    remede = data.get("remede_etapes")
    qui = data.get("qui_peut")
    interdit = (
        "hacker",
        "attaquant",
        "exploit",
        "payload",
        "metasploit",
        "brute-force",
        "ransomware",
        "malware",
        "firmware",
    )

    def _sale(s: object) -> bool:
        low = str(s or "").lower()
        return any(w in low for w in interdit)

    if isinstance(titre, str) and titre.strip() and not _sale(titre):
        finding.titre = titre.strip()[:200]
    if isinstance(pourquoi, str) and pourquoi.strip() and not _sale(pourquoi):
        finding.pourquoi_nuit = pourquoi.strip()[:800]
    if isinstance(remede, list) and remede:
        steps = [str(x).strip() for x in remede if str(x).strip() and not _sale(x)]
        if steps:
            finding.remede_etapes = steps[:12]
    elif isinstance(remede, str) and remede.strip() and not _sale(remede):
        finding.remede_etapes = [remede.strip()]
    if isinstance(qui, str) and qui.strip() and not _sale(qui):
        finding.qui_peut = qui.strip()[:200]


def _polish_one(session: LlmSession, finding: Finding, mission: Mission, host: Host) -> list[str]:
    warns: list[str] = []
    raw = ""
    data = None
    prompt = _user_prompt(finding, mission, host)
    for attempt in range(2):
        try:
            msg = prompt if attempt == 0 else (
                prompt + "\n\nRéessaie. Une seule ligne JSON, clés: titre, pourquoi_nuit, remede_etapes, qui_peut."
            )
            raw = session.chat(msg, max_tokens=350, temperature=0.05)
        except Exception as exc:  # noqa: BLE001
            warns.append(f"llm chat {finding.id}@{host.ip}: {exc}")
            return warns
        data = _extract_json(raw)
        if data:
            break
    if not data:
        log.info("llm polish ignoré pour %s@%s (sortie illisible)", finding.id, host.ip)
        return warns
    _apply(data, finding)
    return warns


def polish_result(
    result: CheckupResult,
    *,
    model_path: str | None = None,
    server_bin: str | None = None,
    base_url: str = f"http://127.0.0.1:{DEFAULT_PORT}",
    ngl: int = 99,
    allow_cpu: bool = False,
) -> list[str]:
    warns: list[str] = []
    model = resolve_model(model_path)
    server = resolve_server(server_bin)
    ngl_eff, mode = resolve_ngl(ngl, allow_cpu=allow_cpu)
    log.info("LLM ngl=%s mode=%s", ngl_eff, mode)
    if mode == "gpu-forcé":
        warns.append(f"llm: GPU détectée — ngl forcé à {ngl_eff} (utilise --cpu-llm pour forcer CPU)")
    session = LlmSession(
        model=model,
        server_bin=server,
        base_url=base_url,
        ngl=ngl_eff,
    )
    try:
        try:
            session.ensure()
        except Exception as exc:  # noqa: BLE001
            return [f"llm: {exc}"]
        n = 0
        for host in result.hosts:
            for finding in host.findings:
                warns.extend(_polish_one(session, finding, result.mission, host))
                n += 1
        log.info("llm polish terminé sur %s finding(s)", n)
        warns.extend(_llm_indices_check(session, result))
        warns.extend(_llm_conseil_pistes(session, result))
    finally:
        session.close()
    return warns


SYSTEM_PISTES = (
    "Tu es le conseiller de Guardia (Echoes of Hackers), pas un attaquant. "
    "On te donne un inventaire LAN + un catalogue de pistes. "
    "Tu priorises les pistes du catalogue. Tu peux ajouter AU PLUS 3 pistes "
    "nouvelles pour une GRANDE structure, uniquement de l'hygiene defensive. "
    "INTERDIT: inventer un port absent, inventer une intrusion, exploit, PoC, "
    "dump, brute-force, password spray. "
    "INTERDIT: transformer une piste en finding (pas de gravite, pas de preuve d'incident). "
    "Reponds UNIQUEMENT en JSON: {\"prioritaires\": [id...], "
    "\"conseils\": [{\"id\", \"titre\", \"pourquoi\", \"indices\", \"commande\"}]}. "
    "commande = nmap ou curl lecture seule. Si rien: conseils=[]."
)

SYSTEM_INDICES = (
    "Tu es l'assistant cyber de Guardia (Echoes of Hackers). "
    "On te donne l'inventaire LAN (hotes + ports ouverts). "
    "Propose au plus 5 INDICES FAIBLES a verifier (hygiene), en francais. "
    "INTERDIT: affirmer qu'une attaque, intrusion, ransomware ou malware a eu lieu. "
    "INTERDIT: inventer un port qui n'est pas dans l'inventaire. "
    "INTERDIT: exploit, PoC, brute-force. "
    "Reponds UNIQUEMENT en JSON avec la cle indices (liste d'objets "
    "ip, titre, pourquoi_nuit, preuve, remede_etapes). "
    "Si rien a signaler: indices est une liste vide."
)


def _llm_indices_check(session: LlmSession, result: CheckupResult) -> list[str]:
    """Second regard LLM borné — n'ajoute que des INFO validés contre les ports réels."""
    warns: list[str] = []
    inv = []
    port_map: dict[str, set[int]] = {}
    host_map = {h.ip: h for h in result.hosts}
    for h in result.hosts:
        ports = []
        ps: set[int] = set()
        for p in h.ports:
            try:
                num = int(p.get("port", 0))
            except (TypeError, ValueError):
                continue
            if num:
                ps.add(num)
                ports.append({"port": num, "name": p.get("name") or ""})
        port_map[h.ip] = ps
        inv.append(
            {
                "ip": h.ip,
                "hostname": h.hostname,
                "kind": h.kind,
                "ports": ports[:40],
            }
        )
    if not inv:
        return warns
    user = (
        "Inventaire (faits seuls). Propose des indices FAIBLES à vérifier, "
        "sans crier à l'attaque.\n"
        + json.dumps({"hosts": inv}, ensure_ascii=False)[:6000]
    )
    # temporary system override via chat messages — use dedicated post
    raw = ""
    try:
        body = {
            "messages": [
                {"role": "system", "content": SYSTEM_INDICES},
                {"role": "user", "content": user},
            ],
            "max_tokens": 700,
            "temperature": 0.1,
        }
        import urllib.request as _u

        req = _u.Request(
            f"{session.base_url}/v1/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with _u.urlopen(req, timeout=180) as rep:
            data = json.loads(rep.read().decode("utf-8"))
        raw = (data["choices"][0]["message"]["content"] or "").strip()
    except Exception as exc:  # noqa: BLE001
        warns.append(f"llm indices: {exc}")
        return warns

    parsed = _extract_json(raw)
    if not parsed:
        # try array wrapper
        start = raw.find("{")
        end = raw.rfind("}")
        if start >= 0 and end > start:
            try:
                parsed = json.loads(raw[start : end + 1])
            except json.JSONDecodeError:
                parsed = None
    if not isinstance(parsed, dict):
        log.info("llm indices: sortie illisible — catalogue conservé")
        return warns
    indices = parsed.get("indices")
    if not isinstance(indices, list):
        return warns

    from guardia.core.models import Gravite

    added = 0
    for i, item in enumerate(indices[:5]):
        if not isinstance(item, dict):
            continue
        ip = str(item.get("ip") or "").strip()
        if ip not in host_map:
            continue
        titre = str(item.get("titre") or "").strip()
        pourquoi = str(item.get("pourquoi_nuit") or "").strip()
        preuve = str(item.get("preuve") or "").strip()
        remede = item.get("remede_etapes") or []
        if not titre or not preuve:
            continue
        # refuse attack language
        low = f"{titre} {pourquoi} {preuve}".lower()
        banned = ("attaque confirm", "compromis", "intrusion avér", "ransomware", "on a été pirat")
        if any(b in low for b in banned):
            continue
        # preuve must mention a real open port if it cites a number
        import re as _re

        cited = [int(x) for x in _re.findall(r"\b(\d{2,5})\b", preuve)]
        real = port_map.get(ip, set())
        if cited and not any(c in real for c in cited):
            continue
        if not isinstance(remede, list):
            remede = [str(remede)]
        steps = [str(s).strip() for s in remede if str(s).strip()][:8] or [
            "Vérifier manuellement avec l'occupant — indice faible uniquement."
        ]
        host_map[ip].findings.append(
            Finding(
                id=f"indice-llm-{i}-{ip.replace('.', '_')}",
                titre=titre[:200],
                pourquoi_nuit=(pourquoi or "Indice faible issu de la relecture inventaire.")[:800],
                preuve=preuve[:400],
                remede_etapes=steps,
                qui_peut="relecture humaine recommandée",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote=ip,
            )
        )
        added += 1
    if added:
        log.info("llm indices: %s indice(s) ajouté(s)", added)
    return warns


_BANNED_PISTES = (
    "exploit",
    "poc",
    "burp",
    "nuclei",
    "hashdump",
    "mimikatz",
    "bloodhound",
    "spray",
    "brute",
    "crack",
    "injection",
    "ransomware",
    "compromis",
)


def _llm_conseil_pistes(session: LlmSession, result: CheckupResult) -> list[str]:
    """Priorise le catalogue + au plus 3 conseils. Ne crée PAS de findings."""
    warns: list[str] = []
    block = getattr(result, "pistes", None) or {}
    items = list(block.get("items") or [])
    if not items and (result.plan or {}).get("pistes") is False:
        return warns

    inv = []
    real_ports: set[int] = set()
    for h in result.hosts or []:
        ports = []
        for p in h.ports or []:
            try:
                num = int(p.get("port") or 0)
            except (TypeError, ValueError):
                continue
            if num:
                real_ports.add(num)
                ports.append(num)
        inv.append({"ip": h.ip, "kind": h.kind, "hostname": h.hostname, "ports": ports[:30]})
    cat = [
        {"id": it.get("id"), "titre": it.get("titre"), "statut": it.get("statut")}
        for it in items
    ]
    user = (
        "Inventaire et catalogue. Priorise. Ajoute au plus 3 conseils lecture-seule "
        "si grande structure et trou réel dans le catalogue.\n"
        + json.dumps(
            {
                "taille": (block.get("taille") or ""),
                "structure": (block.get("structure") or ""),
                "hosts": inv[:40],
                "catalogue": cat[:40],
            },
            ensure_ascii=False,
        )[:7000]
    )
    raw = ""
    try:
        body = {
            "messages": [
                {"role": "system", "content": SYSTEM_PISTES},
                {"role": "user", "content": user},
            ],
            "max_tokens": 700,
            "temperature": 0.1,
        }
        req = urllib.request.Request(
            f"{session.base_url}/v1/chat/completions",
            data=json.dumps(body).encode("utf-8"),
            headers={"Content-Type": "application/json"},
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=180) as rep:
            data = json.loads(rep.read().decode("utf-8"))
        raw = (data["choices"][0]["message"]["content"] or "").strip()
    except Exception as exc:  # noqa: BLE001
        warns.append(f"llm pistes: {exc}")
        return warns

    parsed = _extract_json(raw)
    if not isinstance(parsed, dict):
        start = raw.find("{")
        end = raw.rfind("}")
        if start >= 0 and end > start:
            try:
                parsed = json.loads(raw[start : end + 1])
            except json.JSONDecodeError:
                parsed = None
    if not isinstance(parsed, dict):
        log.info("llm pistes: sortie illisible — catalogue conservé")
        return warns

    prior = parsed.get("prioritaires") or []
    if isinstance(prior, list):
        want = {str(x) for x in prior if str(x).strip()}
        for it in items:
            if it.get("id") in want and it.get("statut") != "déjà vu":
                it["priorite"] = "cette_semaine"
                it["source"] = "catalogue+llm"

    extra: list[dict[str, Any]] = []
    conseils = parsed.get("conseils") or []
    if not isinstance(conseils, list):
        conseils = []
    import re as _re

    from guardia.engines.pistes import merge_llm_pistes

    n = 0
    for i, c in enumerate(conseils[:3]):
        if not isinstance(c, dict):
            continue
        titre = str(c.get("titre") or "").strip()
        pourquoi = str(c.get("pourquoi") or "").strip()
        indices = str(c.get("indices") or "").strip()
        cmd = str(c.get("commande") or "").strip()
        if not titre or not cmd:
            continue
        blob = f"{titre} {pourquoi} {cmd}".lower()
        if any(b in blob for b in _BANNED_PISTES):
            continue
        cmd_l = cmd.lower()
        if not (cmd_l.startswith("nmap") or cmd_l.startswith("curl") or cmd_l.startswith("observation")):
            continue
        cited = [int(x) for x in _re.findall(r"\b(\d{2,5})\b", cmd + " " + indices)]
        if cited and real_ports and not any(cport in real_ports for cport in cited):
            # ports cités absents de l'inventaire → on refuse (pas d'invention)
            continue
        extra.append(
            {
                "id": f"conseil-llm-{i}",
                "titre": titre[:200],
                "pourquoi": (pourquoi or "Conseil LLM — à confirmer sur le LAN.")[:500],
                "statut": "conseil LLM (à confirmer)",
                "priorite": "cette_semaine",
                "indices": (indices or "aucun port cité — relecture humaine")[:400],
                "commande": cmd[:300],
                "hors": "Pas un finding. Pas d'exploit. À confirmer par l'opérateur.",
                "source": "llm",
            }
        )
        n += 1
    if extra:
        result.pistes = merge_llm_pistes(block if block else {"items": items}, extra)
        log.info("llm pistes: %s conseil(s)", n)
    elif items:
        result.pistes = {**block, "items": items}
    return warns

