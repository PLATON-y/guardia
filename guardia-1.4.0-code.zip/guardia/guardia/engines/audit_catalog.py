"""Catalogue des capacités du passage audit Guardia (défensif).

Exporté pour le mandat « audit full » et la doc opérateur.
Chaque entrée décrit précisément ce qui est fait, ce qui ne l'est pas,
et ce qui apparaît dans le rapport (faiblesse + remède).
"""
from __future__ import annotations

from typing import Any

# level: "standard" | "full" | "both"
AUDIT_CATALOG: list[dict[str, Any]] = [
    {
        "id": "inventaire-ports-admin",
        "title_fr": "Inventaire ports admin / surface",
        "level": "both",
        "what_we_do": (
            "Re-scan ciblé des ports d'administration et de services sensibles "
            "sur les hôtes flagués du run classique (liste bornée, pas un -p-)."
        ),
        "what_we_dont": (
            "Pas de scan exhaustif Internet, pas d'exploitation, pas de brute-force."
        ),
        "report_output": (
            "Finding surface élevée si trop de ports ouverts ; remèdes : fermer / "
            "filtrer / documenter l'inventaire."
        ),
    },
    {
        "id": "rdp-vnc-telnet",
        "title_fr": "RDP / VNC / Telnet exposés",
        "level": "both",
        "what_we_do": (
            "Détecte la présence des ports 3389 (RDP), 5900 (VNC), 23 (Telnet) "
            "sur le LAN autorisé."
        ),
        "what_we_dont": (
            "Aucune tentative de connexion, d'auth, ni d'outil d'attaque remote."
        ),
        "report_output": (
            "Findings haute / moyenne avec remèdes : MFA, isolation VLAN, "
            "remplacer Telnet par SSH, pas d'exposition Internet."
        ),
    },
    {
        "id": "datastores-visibles",
        "title_fr": "Datastores visibles (MySQL, Postgres, Mongo, Redis, MSSQL)",
        "level": "both",
        "what_we_do": (
            "Repère les ports typiques 3306, 5432, 27017, 6379, 1433 joignables "
            "depuis le LAN."
        ),
        "what_we_dont": (
            "Pas de login, pas de dump, pas de script vuln datastore."
        ),
        "report_output": (
            "Finding haute + remèdes : binder localhost / VLAN admin, auth forte, "
            "sauvegardes chiffrées."
        ),
    },
    {
        "id": "smb-signing",
        "title_fr": "SMB signing / hygiène SMB",
        "level": "both",
        "what_we_do": (
            "Script nmap informatif smb-security-mode : lit si la signature de "
            "messages SMB est désactivée."
        ),
        "what_we_dont": (
            "Pas de relay SMB, pas d'énumération agressive de partages sensibles."
        ),
        "report_output": (
            "Finding moyenne si signing disabled + remèdes Require Security Signature, "
            "retirer SMBv1, limiter les partages."
        ),
    },
    {
        "id": "tls-cert",
        "title_fr": "TLS cert expired/invalid + inventaire TLS",
        "level": "both",
        "what_we_do": (
            "Script ssl-cert : extrait métadonnées certificat (validité, sujet)."
        ),
        "what_we_dont": (
            "Pas de MITM, pas de casse de chiffrement, pas de fuzz TLS."
        ),
        "report_output": (
            "Finding moyenne si expiré/invalide ; INFO inventaire si présent — "
            "remèdes renouvellement / suivi CN."
        ),
    },
    {
        "id": "http-admin",
        "title_fr": "Interfaces admin HTTP (http-title)",
        "level": "both",
        "what_we_do": (
            "Script http-title : titre de page pour repérer admin / login / NAS / "
            "management."
        ),
        "what_we_dont": (
            "Pas de credential stuffing, pas de crawl offensif."
        ),
        "report_output": (
            "Finding moyenne + remèdes mot de passe fort, restriction IP/VLAN, "
            "mise à jour firmware."
        ),
    },
    {
        "id": "http-headers",
        "title_fr": "http-headers infos (Server / X-Powered-By) — hygiène INFO",
        "level": "full",
        "what_we_do": (
            "Script http-headers (audit full) : bannières Server / X-Powered-By "
            "pour hygiène d'exposition."
        ),
        "what_we_dont": (
            "Pas d'exploitation de versions, pas de fingerprint offensif poussé."
        ),
        "report_output": (
            "Finding INFO/moyenne si bannière trop bavarde ou vieillissante + "
            "remède : masquer / moderniser la stack."
        ),
    },
    {
        "id": "ssh-hostkey",
        "title_fr": "ssh-hostkey fingerprint — inventaire",
        "level": "full",
        "what_we_do": (
            "Script ssh-hostkey (audit full) : empreintes de clés SSH pour inventaire."
        ),
        "what_we_dont": (
            "Pas de brute-force SSH, pas de tentative de login."
        ),
        "report_output": (
            "Finding INFO inventaire + remède : documenter les fingerprints, "
            "alerter si changement inattendu."
        ),
    },
    {
        "id": "ssl-enum-ciphers",
        "title_fr": "ssl-enum-ciphers — suites faibles (hygiène WARNING)",
        "level": "full",
        "what_we_do": (
            "Script nmap ssl-enum-ciphers (informatif) : liste les suites ; "
            "repère mots-clés faibles RC4, DES, NULL, export."
        ),
        "what_we_dont": (
            "Pas de script vuln/*, pas d'attaque sur le handshake."
        ),
        "report_output": (
            "Finding moyenne + remèdes : désactiver suites faibles, imposer TLS 1.2+."
        ),
    },
    {
        "id": "partages-imprimantes-9100",
        "title_fr": "Partages / imprimantes 9100",
        "level": "both",
        "what_we_do": (
            "Détecte le port 9100 (JetDirect / raw print) souvent ouvert sans contrôle."
        ),
        "what_we_dont": (
            "Pas d'envoi de jobs d'impression, pas de dump de file d'attente."
        ),
        "report_output": (
            "Finding moyenne + remèdes : segmenter le VLAN print, auth si possible, "
            "couper 9100 si inutile."
        ),
    },
    {
        "id": "ftp-cleartext",
        "title_fr": "FTP 21 en clair",
        "level": "both",
        "what_we_do": "Détecte le port 21 (FTP) ouvert sur le LAN.",
        "what_we_dont": "Pas de login FTP, pas de transfert de fichier test.",
        "report_output": (
            "Finding haute + remèdes : SFTP/FTPS, couper FTP anonyme, filtrer le port."
        ),
    },
    {
        "id": "dns-forwarder-soft",
        "title_fr": "DNS / forwarder parasites (couverture soft)",
        "level": "both",
        "what_we_do": (
            "Repérage soft déjà partiellement couvert par le checkup classique "
            "(port 53 / forwarders inattendus) — le passage audit ne force pas "
            "d'énumération DNS agressive."
        ),
        "what_we_dont": (
            "Pas de zone transfer forcé, pas de spoof DNS, pas d'amplification."
        ),
        "report_output": (
            "Findings éventuels côté règles universelles ; remèdes : DNS légitime "
            "uniquement, filtrer les resolveurs pirates."
        ),
    },
    {
        "id": "site-web",
        "title_fr": "Site web (URL du mandat) — TLS / en-têtes / mentions / cookies",
        "level": "full",
        "what_we_do": (
            "Si une URL est fournie (--site / site_url, prérempli example.test en lab) : "
            "HTTPS, certificat, en-têtes de sécurité, pages légales, bandeau / CMP, "
            "traceurs visibles. Lecture seule."
        ),
        "what_we_dont": (
            "Lecture : curl / TLS / empreinte HTTP sur l'URL du mandat.",
        ),
        "report_output": (
            "Chapitre « Site web » + findings web-* avec remèdes. "
            "N'est lancé que si le module est demandé."
        ),
    },
    {
        "id": "rgpd-signalement",
        "title_fr": "Signalement RGPD (sur demande) — pas un certificat",
        "level": "full",
        "what_we_do": (
            "Contrôle selon les exigences RGPD / LIL / LCEN / reco CNIL cookies. "
            "On dit ce qui a été observé, non observé, ou à confirmer avec vous."
        ),
        "what_we_dont": (
            "Pas de certificat de conformité, pas de certification CNIL / DPO, "
            "pas de tampon « RGPD OK ». Ce n'est qu'un signalement sur demande."
        ),
        "report_output": (
            "Chapitre « Signalement RGPD (sur demande) » dans le rapport full. "
            "Couper avec --no-rgpd."
        ),
    },
    {
        "id": "usages-droits",
        "title_fr": "Usages & droits — ce que les gens peuvent faire (pas un dump)",
        "level": "both",
        "what_we_do": (
            "Auto école, sinon --usages. Fiche opérateur (comptes, admin local, VLAN, "
            "serveur de desserte) + observation lecture-seule des portes : "
            "noms de partages SMB, exports NFS, rootDSE LDAP, FTP anonyme. "
            "On montre la porte, on n'entre pas."
        ),
        "what_we_dont": (
            "Lecture des portes (noms de partages, exports, rootDSE). "
            "Pas de lecture de fichiers métier.",
        ),
        "report_output": (
            "Chapitre « Usages & droits » + « Pour la direction ». "
            "Findings usages-* avec preuve reproductible (commande lecture seule)."
        ),
    },
    {
        "id": "portes-smb-nfs-ldap",
        "title_fr": "Portes sans mot de passe (smb-enum-shares / nfs-showmount / ldap-rootdse)",
        "level": "full",
        "what_we_do": (
            "Scripts nmap informatifs : liste des *noms* de partages, des exports NFS, "
            "du rootDSE LDAP. Démonstration respectueuse d'une exposition."
        ),
        "what_we_dont": (
            "Pas d'ouverture de fichiers, pas de dump AD, pas de montage NFS métier, "
            "pas de scripts vuln/*, pas de credential stuffing."
        ),
        "report_output": (
            "Findings usages-partage-* si des disques / C$ / guest apparaissent. "
            "LDAP rootDSE = INFO (souvent normal), pas une liste de personnes."
        ),
    },
    {
        "id": "restructuration-parc",
        "title_fr": "Où restructurer le parc (VLAN, admin, datastores, OT)",
        "level": "both",
        "what_we_do": (
            "Lecture d'architecture à partir de l'inventaire : LAN plat, surface admin, "
            "bases exposées, automates mélangés au bureau. Auto pour PME / école / audit."
        ),
        "what_we_dont": (
            "Pas une topologie câblée certifiée, pas de reconfiguration du matériel."
        ),
        "report_output": (
            "Chapitre « Où restructurer le parc » avec chantiers priorisés + remèdes."
        ),
    },
    {
        "id": "machines-ot",
        "title_fr": "Machines / OT (sur demande) — lecture, pas d'écriture automate",
        "level": "full",
        "what_we_do": (
            "Si --machines / machines: true : Ethernet industriel "
            "(Modbus TCP, S7, OPC-UA, EtherNet/IP, Profinet, IEC-104, MELSEC). "
            "TCP + UDP borné, lecture seule."
        ),
        "what_we_dont": (
            "Pas d'écriture sur automate, pas d'injection de trame, pas de dump."
        ),
        "report_output": (
            "Findings ot-* + chapitre machines. Module éteint par défaut."
        ),
    },
]


def catalog_for_level(level: str = "standard") -> list[dict[str, Any]]:
    """Filtre le catalogue selon standard | full."""
    lv = (level or "standard").strip().lower()
    if lv == "full":
        return list(AUDIT_CATALOG)
    return [e for e in AUDIT_CATALOG if e.get("level") in ("standard", "both")]


def catalog_ids(level: str = "standard") -> list[str]:
    return [str(e["id"]) for e in catalog_for_level(level)]


def catalog_as_markdown(level: str = "full") -> str:
    """Résumé markdown pour docs / mandat."""
    lines: list[str] = []
    for e in catalog_for_level(level):
        lines.append(f"### {e['title_fr']} (`{e['id']}`)")
        lines.append(f"- **On fait :** {e['what_we_do']}")
        lines.append(f"- **Rapport :** {e['report_output']}")
        lines.append("")
    return "\n".join(lines)


def catalog_as_html_items(level: str = "full") -> str:
    """Blocs HTML <li> pour le mandat à signer."""
    parts: list[str] = []
    for e in catalog_for_level(level):
        lvl = e.get("level", "both")
        badge = "standard + full" if lvl == "both" else str(lvl)
        parts.append(
            "<li>"
            f"<strong>{e['title_fr']}</strong> "
            f"(<code>{e['id']}</code> — {badge})"
            "<ul>"
            f"<li><em>On fait :</em> {e['what_we_do']}</li>"
            f"<li><em>Dans le rapport :</em> {e['report_output']}</li>"
            "</ul>"
            "</li>"
        )
    return "\n".join(parts)
