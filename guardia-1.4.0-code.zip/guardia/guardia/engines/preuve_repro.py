"""Preuves reproductibles — lecture seule.

Doctrine ÉOH : pendant la plage d'audit (« temps de charge »), Guardia
*démontre* qu'une exposition est réelle et qu'un scénario est *réalisable*
via une commande rejouable (bannières, TLS, noms de partages, en-têtes…).
On n'envoie jamais d'exploit au client. On indique ensuite quoi faire (remède).
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Finding, Host

# id prefix / exact → commande type ({ip} substitué) — lecture seule uniquement
_REPRO: list[tuple[str, str]] = [
    ("usages-admin-share", "nmap -p 445 --script smb-enum-shares {ip}  # noms, pas les fichiers"),
    ("usages-partage-disque", "nmap -p 445 --script smb-enum-shares {ip}  # noms, pas les fichiers"),
    ("usages-desserte", "nmap -sV -p 88,389,445,2049 {ip}  # empreinte desserte, pas de login"),
    ("audit-smb-signing", "nmap -p 445 --script smb-security-mode {ip}"),
    ("audit-remote-3389", "nmap -sV -p 3389 {ip}  # présence RDP, pas de login"),
    ("audit-remote-5900", "nmap -sV -p 5900 {ip}  # présence VNC, pas de login"),
    ("audit-db-", "nmap -sV -p 1433,3306,5432,6379 {ip}  # port datastore visible, pas de dump"),
    ("audit-tls-", "nmap -p 443 --script ssl-enum-ciphers {ip}  # TLS, pas d'exploit"),
    ("web-pas-https", "curl -sI http://{ip}/  # en-têtes seulement"),
    ("web-", "curl -sI https://{ip}/  # en-têtes / cookies, pas de payload"),
    ("net-ecole-rdp-smb", "nmap -sV -p 139,445,3389 {ip}  # surface, pas d'auth"),
    ("ot-", "nmap -sV -p 102,502,4840,44818,34962 {ip}  # Ethernet industriel, pas d'écriture"),
    ("http-", "curl -sI http://{ip}/  # en-têtes HTTP lecture"),
    ("tls-", "nmap -p 443 --script ssl-cert,ssl-enum-ciphers {ip}"),
    ("smb-", "nmap -p 445 --script smb-security-mode,smb-os-discovery {ip}"),
]

DEMO_PHRASE = (
    "Démonstration d'exposition (lecture) pendant la plage d'audit : "
    "on frappe à la porte (knock), on voit la réponse, on n'entre pas. "
    "La commande ci-dessous est rejouable par l'opérateur agréé. "
    "Aucun exploit n'est fourni au client ; aucun payload n'est lancé."
)

REMEDE_PHRASE = (
    "Pour vous protéger, il faudrait appliquer les remèdes / la restructuration "
    "indiqués — pas une procédure d'attaque."
)

NOTE_AUCUNE_EXPLOITATION = (
    "Aucune exploitation n'a été exécutée ; démonstration par sollicitation lecture seule "
    "(knock : voir la réponse, ne pas entrer). "
    "La preuve est la réponse / trace rejouable pour vérification par techniciens agréés. "
    "Le programme laisse une piste d'audit autorisée."
)


def phrase_impact(f: Finding, *, vouvoiement: bool = True) -> str:
    """« Ceci permettrait de … » — hypothèse d'impact, sans étapes d'exploit."""
    base = (f.pourquoi_nuit or "").strip()
    if not base:
        titre = (f.titre or "cette exposition").strip()
        base = f"compromettre la confidentialité ou la disponibilité liée à « {titre} »"
    low = base.lower()
    if low.startswith("ceci permettrait"):
        return base if base.endswith(".") else base + "."
    # retirer un éventuel « de » initial pour éviter « de de »
    if base.lower().startswith("de "):
        base = base[3:]
    return f"Ceci permettrait de {base[0].lower() + base[1:] if base else '…'}".rstrip(".") + "."


def phrase_protection(f: Finding, *, vouvoiement: bool = True) -> str:
    """« Pour vous protéger, il faudrait … » — remèdes, jamais d'exploit."""
    etapes = [str(s).strip() for s in (f.remede_etapes or []) if str(s).strip()]
    if etapes:
        corps = " ; ".join(etapes[:6])
        return f"Pour vous protéger, il faudrait : {corps}."
    return (
        "Pour vous protéger, il faudrait réduire la surface exposée, "
        "appliquer les correctifs / durcissements indiqués et vérifier en lecture seule."
    )


def template_client_finding(f: Finding, *, vouvoiement: bool = True) -> dict[str, str]:
    """Structure vouvoiement client-facing (observation / impact / remède / note)."""
    obs = (getattr(f, "observation", "") or f.titre or "").strip()
    preuve = (
        getattr(f, "commande", "")
        or getattr(f, "preuve_repro", "")
        or getattr(f, "preuve", "")
        or ""
    ).strip()
    return {
        "observation": obs or "Observation en lecture seule pendant la plage d'audit.",
        "preuve_lecture": preuve,
        "impact": phrase_impact(f, vouvoiement=vouvoiement),
        "protection": phrase_protection(f, vouvoiement=vouvoiement),
        "note": NOTE_AUCUNE_EXPLOITATION,
    }


def _cmd_for(fid: str, ip: str) -> str:
    for prefix, tmpl in _REPRO:
        if fid == prefix or fid.startswith(prefix):
            return tmpl.replace("{ip}", ip or "<ip>")
    return ""


def _fallback_cmd(f: Finding, ip: str) -> str:
    """Si aucun préfixe connu : commande générique lecture selon gravité/titre."""
    titre = (f.titre or "").lower()
    preuve = (f.preuve or "").lower()
    blob = titre + " " + preuve
    host = ip or f.hote or "<ip>"
    if any(x in blob for x in ("tls", "https", "certificat", "ssl")):
        return f"nmap -p 443 --script ssl-cert,ssl-enum-ciphers {host}  # démo lecture TLS"
    if any(x in blob for x in ("smb", "partage", "445")):
        return f"nmap -p 445 --script smb-security-mode,smb-enum-shares {host}  # démo lecture SMB"
    if any(x in blob for x in ("http", "cookie", "en-tête", "header", "web")):
        return f"curl -sI https://{host}/  # démo lecture en-têtes"
    if any(x in blob for x in ("rdp", "3389", "vnc")):
        return f"nmap -sV -p 3389,5900 {host}  # démo présence admin, pas de login"
    if f.preuve and len(str(f.preuve)) < 200 and not any(
        x in str(f.preuve).lower() for x in ("exploit", "payload", "metasploit", "msf")
    ):
        return str(f.preuve)
    return f"nmap -sV -T3 {host}  # empreinte lecture — démonstration d'exposition"


def phrase_demonstration(f: Finding, *, vouvoiement: bool = True) -> str:
    """Libellé client-facing (vouvoiement) pour un finding réalisable."""
    titre = f.titre or "cette exposition"
    impact = phrase_impact(f, vouvoiement=vouvoiement)
    protection = phrase_protection(f, vouvoiement=vouvoiement)
    if vouvoiement:
        return (
            f"Nous avons frappé à la porte (knock) pendant la plage d'audit : "
            f"« {titre} » est observable en lecture seule ; on n'entre pas. "
            f"{impact} {protection} {NOTE_AUCUNE_EXPLOITATION}"
        )
    return (
        f"On a frappé (knock) pendant la plage d'audit : « {titre} » est observable "
        f"en lecture ; on n'entre pas. {impact} Ensuite : remède — pas d'exploit. "
        f"{NOTE_AUCUNE_EXPLOITATION}"
    )


def ensure_realisable_repro(f: Finding, ip: str = "") -> None:
    """Tout finding qui affirme une exposition « réalisable » porte une repro lecture."""
    needs = False
    blob = " ".join(
        [
            str(f.titre or ""),
            str(f.pourquoi_nuit or ""),
            str(f.preuve or ""),
            str(f.interpretation or ""),
            str(f.observation or ""),
        ]
    ).lower()
    if any(
        k in blob
        for k in (
            "réalisable",
            "realisable",
            "exposition",
            "exposé",
            "expose",
            "ouvert",
            "accessible",
            "sans authent",
            "démontr",
            "demonstr",
        )
    ):
        needs = True
    if (f.gravite.value if hasattr(f.gravite, "value") else str(f.gravite or "")) in (
        "critique",
        "haute",
        "moyenne",
    ):
        needs = True
    if not needs and not getattr(f, "preuve_repro", ""):
        # findings candidats cerveau : toujours une piste rejouable si preuve non vide
        if f.preuve or f.titre:
            needs = True
    if not needs:
        return
    cmd = getattr(f, "commande", "") or getattr(f, "preuve_repro", "") or ""
    if not cmd:
        cmd = _cmd_for(f.id or "", ip or f.hote or "<ip>") or _fallback_cmd(f, ip)
    # Refuse toute commande qui ressemble à un exploit
    low = cmd.lower()
    if any(x in low for x in ("metasploit", "msfconsole", "exploit/", "--payload", "reverse_tcp")):
        cmd = _fallback_cmd(f, ip)
    f.commande = cmd
    f.preuve_repro = cmd
    if not getattr(f, "interpretation", ""):
        f.interpretation = DEMO_PHRASE
    elif "démonstration" not in (f.interpretation or "").lower() and "demonstration" not in (
        f.interpretation or ""
    ).lower():
        f.interpretation = (f.interpretation or "").rstrip() + " — " + DEMO_PHRASE


def attach_chaine(f: Finding, ip: str = "", *, vouvoiement: bool = True) -> None:
    """Chaîne Finding → observation → commande lecture → interprétation → remède."""
    if not getattr(f, "observation", ""):
        f.observation = f.titre or ""
    ensure_realisable_repro(f, ip)
    cmd = getattr(f, "commande", "") or getattr(f, "preuve_repro", "") or ""
    if not cmd:
        cmd = _cmd_for(f.id or "", ip or f.hote or "<ip>")
    if not cmd and getattr(f, "preuve", ""):
        cmd = f.preuve
    if cmd:
        f.commande = cmd
        if not getattr(f, "preuve_repro", ""):
            f.preuve_repro = cmd
    if not getattr(f, "interpretation", ""):
        f.interpretation = f.pourquoi_nuit or DEMO_PHRASE
    # Marqueur structuré (extras via note dans interpretation déjà ; champ dédié si besoin)
    note = phrase_demonstration(f, vouvoiement=vouvoiement)
    if "plage d'audit" not in (f.interpretation or ""):
        f.interpretation = ((f.interpretation or "").rstrip() + " " + note).strip()


def attach_repro(hosts: list[Host], *, vouvoiement: bool = True) -> dict[str, Any]:
    """Remplit preuve_repro + chaîne démo lecture pour tous les findings hôtes."""
    n = 0
    for h in hosts or []:
        ip = h.ip
        for f in h.findings or []:
            before = getattr(f, "preuve_repro", "") or ""
            attach_chaine(f, ip, vouvoiement=vouvoiement)
            if getattr(f, "preuve_repro", ""):
                n += 1
            elif before:
                n += 1
    return {
        "findings_avec_repro": n,
        "nature": "knock — voir la réponse, ne pas entrer (lecture seule)",
        "disclaimer": DEMO_PHRASE,
        "note": NOTE_AUCUNE_EXPLOITATION,
    }


def attach_repro_findings(
    findings: list[Finding], ip: str = "<ip>", *, vouvoiement: bool = True
) -> None:
    for f in findings or []:
        attach_chaine(f, ip, vouvoiement=vouvoiement)
