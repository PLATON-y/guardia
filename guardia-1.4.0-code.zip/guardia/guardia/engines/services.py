"""Empreinte services légère : nmap -sV top ports (par lots)."""
from __future__ import annotations

import logging
import time
import shutil
import subprocess
import tempfile
from concurrent.futures import ThreadPoolExecutor
import xml.etree.ElementTree as ET
from pathlib import Path

from guardia.core.models import Host

log = logging.getLogger("guardia.services")

# Profils : nombre de ports top
TOP_PORTS = {
    "doux": "20",
    "standard": "50",
    "approfondi": "100",
    # parc inconnu : inventaire large, toujours -sV light (pas de scripts vuln)
    "full": "200",
}

# Taille de lot d'IPs pour nmap -sV (gros parc)
BATCH_SIZE = 16


def _parse_ports(xml_text: str) -> dict[str, list[dict]]:
    """ip -> list of port dicts."""
    out: dict[str, list[dict]] = {}
    if not xml_text.strip():
        return out
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError as exc:
        log.warning("XML services illisible: %s", exc)
        return out
    for h in root.findall("host"):
        ip = ""
        for addr in h.findall("address"):
            if addr.get("addrtype") == "ipv4":
                ip = addr.get("addr", "")
        if not ip:
            continue
        ports: list[dict] = []
        for p in h.findall("ports/port"):
            state = p.find("state")
            if state is None or state.get("state") != "open":
                continue
            svc = p.find("service")
            ports.append(
                {
                    "port": int(p.get("portid", "0") or 0),
                    "proto": p.get("protocol", "tcp"),
                    "name": (svc.get("name") if svc is not None else "") or "",
                    "product": (svc.get("product") if svc is not None else "") or "",
                    "version": (svc.get("version") if svc is not None else "") or "",
                    "extrainfo": (svc.get("extrainfo") if svc is not None else "") or "",
                }
            )
        out[ip] = ports
    return out


# Ports qui justifient un test. Le -p- 1-65535 n'est plus le défaut (90 % du temps mission).
PRIORITY_PORTS: tuple[int, ...] = (
    22,
    53,
    80,
    81,
    88,
    135,
    139,
    161,
    389,
    443,
    445,
    636,
    993,
    995,
    1433,
    2049,
    3306,
    3389,
    5432,
    5900,
    5985,
    8080,
    8443,
    9100,
    102,
    502,
    4840,
    44818,
)


def _plist(ports: tuple[int, ...]) -> str:
    return ",".join(str(p) for p in ports)


def _port_args(profondeur: str, all_ports: bool) -> tuple[list[str], str]:
    """Retourne (args nmap ports, label log).

    Ports prioritaires, puis top-200 si all_ports / full.
    L'empreinte -sV reste light. Pas de 1-65535 automatique.
    """
    if all_ports or profondeur in ("full", "approfondi"):
        extra = "T:1-1024" if profondeur == "full" and all_ports else ""
        ports = _plist(PRIORITY_PORTS)
        if extra:
            ports = f"{ports},{extra}"
            return ["-p", ports, "-T3", "--max-retries", "1"], "priority+1-1024"
        return ["--top-ports", "200", "-T3", "--max-retries", "1"], "priority/top-200"
    top = TOP_PORTS.get(profondeur, TOP_PORTS["standard"])
    # Standard : d'abord les portes qui ouvrent des branches.
    return ["-p", _plist(PRIORITY_PORTS), "-T3", "--max-retries", "1"], f"priority (top-{top} repli)"


def _batch_timeout(
    n_in_batch: int,
    timeout_per_host: int,
    *,
    all_ports: bool,
    profondeur: str,
    total_hosts: int,
) -> int:
    """Timeout adaptatif selon taille du lot et profondeur."""
    if all_ports:
        return max(180, timeout_per_host * min(n_in_batch, 4))
    base = timeout_per_host * min(n_in_batch, 8)
    if profondeur == "full":
        base = max(base, 150 * min(n_in_batch, 4))
    if total_hosts > 64:
        base = int(base * 1.25)
    return max(120, base)


def scan_services(
    hosts: list[Host],
    profondeur: str = "standard",
    timeout_per_host: int = 90,
    all_ports: bool = False,
    batch_size: int = BATCH_SIZE,
    remaining_sec: float | None = None,
    workers: int = 1,
    reserve_sec: float = 0,
) -> list[str]:
    """Enrichit hosts[].ports. Retourne erreurs non fatales.

    all_ports=True : plus de 1-65535 auto. Ports prioritaires, top-200
    si le budget le permet. Toujours sans scripts d'exploit.
    Scan par lots de batch_size IPs pour limiter la charge sur gros CIDR.

    reserve_sec : secondes à ne pas manger pour laisser classify/rules/audit.
    Si le reste utile est trop court pour un -p-, repli automatique vers top-ports.
    """
    errors: list[str] = []
    if not hosts:
        return errors
    if not shutil.which("nmap"):
        errors.append("nmap absent — pas d'empreinte services")
        return errors

    usable = remaining_sec
    if remaining_sec is not None and reserve_sec:
        usable = max(20.0, float(remaining_sec) - float(reserve_sec))

    effective_all = bool(all_ports)
    n = max(1, len(hosts))
    if effective_all and usable is not None:
        # Un -p- honnête demande ~1–3 min/hôte. En dessous : on replie.
        need = max(180.0, 70.0 * min(n, 8))
        if usable < need:
            effective_all = False
            errors.append(
                "budget: --all-ports replié vers top-ports pour laisser "
                "classify / rules / audit / rapport "
                f"(reste utile {usable:.0f}s, besoin estimé {need:.0f}s). "
                "Relance avec --max-time plus haut pour un -p- complet."
            )
            log.warning("all-ports replié (reste utile %.0fs < %.0fs)", usable, need)

    if effective_all:
        timeout_per_host = max(timeout_per_host, 120)
        if usable is not None:
            timeout_per_host = max(60, min(timeout_per_host, int(usable)))
    elif profondeur == "full" and timeout_per_host < 150:
        timeout_per_host = 150

    port_args, label = _port_args(profondeur, effective_all)
    ips = [h.ip for h in hosts]
    host_map = {h.ip: h for h in hosts}
    total = len(ips)
    bs = max(1, batch_size)

    log.info(
        "empreinte services -sV %s sur %d hôte(s) (lots de %d)",
        label,
        total,
        bs,
    )

    try:
        from guardia.core.operator import get_operator
    except Exception:  # noqa: BLE001
        get_operator = None  # type: ignore

    n_workers = max(1, min(int(workers or 1), 8))
    if n_workers > 1:
        log.info("services multi-thread: %d workers (lots parallèles bornés)", n_workers)

    t_scan0 = time.monotonic()
    remaining_for_loop = usable
    for start in range(0, total, bs):
        if get_operator and get_operator().should_stop_phase():
            errors.append(
                f"arrêt opérateur: empreinte services stoppée après {start}/{total} hôte(s) — suite du checkup"
            )
            log.warning("opérateur: stop services à %d/%d", start, total)
            break
        if remaining_for_loop is not None:
            left = remaining_for_loop - (time.monotonic() - t_scan0)
            if left < 15:
                errors.append(
                    f"budget temps: empreinte services arrêtée après {start}/{total} hôte(s) "
                    f"(reste {left:.0f}s) — rapport partiel, classify/rules conservés"
                )
                log.warning("budget: stop services à %d/%d", start, total)
                break
        chunk = ips[start : start + bs]
        batch_to = _batch_timeout(
            len(chunk),
            timeout_per_host,
            all_ports=effective_all,
            profondeur=profondeur,
            total_hosts=total,
        )
        if remaining_for_loop is not None:
            left = remaining_for_loop - (time.monotonic() - t_scan0)
            batch_to = max(5, min(batch_to, int(left)))
        with tempfile.TemporaryDirectory(prefix="guardia-svc-") as td:
            xml_path = Path(td) / "svc.xml"
            cmd = [
                "nmap",
                "-sV",
                *port_args,
                "--version-light",
                "-oX",
                str(xml_path),
                *chunk,
            ]
            try:
                log.info(
                    "lot %d–%d / %d (timeout %ss)",
                    start + 1,
                    start + len(chunk),
                    total,
                    batch_to,
                )
                from guardia.core.operator import set_active_subprocess, get_operator as _gop

                proc = subprocess.Popen(
                    cmd,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                )
                set_active_subprocess(proc)
                try:
                    try:
                        stdout, stderr = proc.communicate(timeout=batch_to)
                    except subprocess.TimeoutExpired:
                        proc.kill()
                        stdout, stderr = proc.communicate()
                        raise
                finally:
                    set_active_subprocess(None)
                if _gop().should_stop_phase():
                    errors.append(
                        f"arrêt opérateur pendant nmap lot @{chunk[0]} — phase services tronquée"
                    )
                    break
                if proc.returncode not in (0, 1):
                    errors.append(
                        f"nmap -sV rc={proc.returncode} lot@{chunk[0]}: "
                        f"{(stderr or '')[:200]}"
                    )
                xml_text = (
                    xml_path.read_text(encoding="utf-8", errors="replace")
                    if xml_path.exists()
                    else ""
                )
                parsed = _parse_ports(xml_text)
                for ip, ports in parsed.items():
                    if ip in host_map:
                        host_map[ip].ports = ports
            except subprocess.TimeoutExpired:
                errors.append(f"timeout empreinte services lot @{chunk[0]} (repli unitaire)")
                log.warning("timeout nmap -sV lot %s (%s)", chunk[0], label)

                def _one(ip: str) -> None:
                    h = host_map[ip]
                    try:
                        # repli unitaire : jamais -p- si on est déjà en timeout
                        _scan_one(
                            h,
                            profondeur,
                            min(timeout_per_host, 180),
                            all_ports=False,
                        )
                    except Exception as exc:  # noqa: BLE001
                        h.errors.append(f"services: {exc}")
                        errors.append(f"{h.ip}: {exc}")

                if n_workers > 1:
                    with ThreadPoolExecutor(max_workers=n_workers) as pool:
                        list(pool.map(_one, chunk))
                else:
                    for ip in chunk:
                        _one(ip)
            except OSError as exc:
                errors.append(f"nmap -sV: {exc}")

    try:
        from guardia.engines.osi_map import attach_host_osi

        attach_host_osi(hosts)
    except Exception as exc:  # noqa: BLE001
        log.debug("osi_map services: %s", exc)

    return errors


def _scan_one(
    host: Host,
    profondeur: str,
    timeout: int,
    *,
    all_ports: bool = False,
) -> None:
    port_args, _label = _port_args(profondeur, all_ports)
    with tempfile.TemporaryDirectory(prefix="guardia-1-") as td:
        xml_path = Path(td) / "one.xml"
        proc = subprocess.run(
            [
                "nmap", "-sV", *port_args, "--version-light",
                "-oX", str(xml_path), host.ip,
            ],
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        del proc  # rc non bloquant
        if xml_path.exists():
            parsed = _parse_ports(xml_path.read_text(encoding="utf-8", errors="replace"))
            host.ports = parsed.get(host.ip, [])
