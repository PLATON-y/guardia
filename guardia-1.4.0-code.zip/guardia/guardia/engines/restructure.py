"""Chapitre « où restructurer » — parcs / entreprises.

Pas un scan de plus : une lecture d'architecture à partir de l'inventaire.
L'avance, c'est de dire où couper, pas seulement lister les ports.
"""
from __future__ import annotations

from collections import defaultdict
from typing import Any

from guardia.core.models import Finding, Gravite, Host, Mission

IOT = {"iot", "tv", "console", "camera", "phone"}
METIER = {"pc", "nas", "serveur", "box"}
RESEAU = {"box", "router", "switch", "ap"}


def _ports(host: Host) -> set[int]:
    out: set[int] = set()
    for p in host.ports or []:
        try:
            n = int(p.get("port", -1))
        except (TypeError, ValueError):
            continue
        if n > 0:
            out.add(n)
    return out


def _f(
    fid: str,
    titre: str,
    pourquoi: str,
    preuve: str,
    etapes: list[str],
    gravite: Gravite,
    priorite: str,
    qui: str,
) -> Finding:
    return Finding(
        id=fid,
        titre=titre,
        pourquoi_nuit=pourquoi,
        preuve=preuve[:400],
        remede_etapes=etapes,
        qui_peut=qui,
        priorite=priorite,
        gravite=gravite,
        hote="parc",
    )


def build_restructure(
    hosts: list[Host],
    mission: Mission,
    *,
    gateway: str = "",
) -> dict[str, Any]:
    kinds = defaultdict(list)
    for h in hosts:
        kinds[h.kind or "inconnu"].append(h)

    n = len(hosts)
    n_inconnu = len(kinds.get("inconnu") or [])
    n_iot = sum(len(kinds[k]) for k in IOT if k in kinds)
    n_pc = len(kinds.get("pc") or [])
    n_nas = len(kinds.get("nas") or [])
    n_net = sum(len(kinds[k]) for k in RESEAU if k in kinds)

    admin_hosts = []
    db_hosts = []
    ot_hosts = []
    rdp_hosts = []
    for h in hosts:
        ps = _ports(h)
        if ps & {22, 23, 3389, 5900, 8291, 8443}:
            admin_hosts.append(h)
        if ps & {3306, 5432, 27017, 6379, 1433, 9200}:
            db_hosts.append(h)
        if ps & {502, 102, 4840, 44818, 47808, 20000}:
            ot_hosts.append(h)
        if 3389 in ps or 5900 in ps:
            rdp_hosts.append(h)

    chantiers: list[Finding] = []
    profil = (mission.profil_moteur or "").lower()
    tut = mission.ton_rapport == "tutoiement"
    qui = "toi-même / prestataire" if tut else "direction / prestataire IT / ÉOH en option"

    if n_iot and (n_pc or n_nas):
        chantiers.append(
            _f(
                "restr-vlan-iot",
                "Cloisonner l'IoT / TV / caméras loin des postes métier",
                "Sur un LAN plat, un objet faible (caméra, TV, ampoule) devient le "
                "pont vers les PC et le NAS. C'est le chantier n°1 de restructuration "
                "d'un parc, pas un détail de port.",
                f"IoT-like={n_iot} · PC={n_pc} · NAS={n_nas} · total={n}",
                [
                    "SSID / VLAN « objets » distinct du SSID bureautique.",
                    "Isolation client Wi‑Fi sur le SSID objets / invités.",
                    "Caméras et NAS : règles firewall (objets → NAS interdit sauf besoin réel).",
                ],
                Gravite.HAUTE,
                "cette_semaine",
                qui,
            )
        )

    if n_inconnu >= max(3, n // 3) and n >= 4:
        chantiers.append(
            _f(
                "restr-inventaire",
                "Trop d'appareils sans identité — inventaire à reprendre",
                "On ne restructure pas un parc qu'on ne sait pas nommer. Hostnames vides "
                "et type « inconnu » = trou d'inventaire, pas seulement un oubli cosmétique.",
                f"{n_inconnu}/{n} hôte(s) kind=inconnu",
                [
                    "Nommer chaque appareil (DHCP réservé + libellé).",
                    "Cartographier : qui, où, à qui, quel service.",
                    "Sortir du parc ce qui n'a plus d'usage (shadow IT).",
                ],
                Gravite.MOYENNE,
                "cette_semaine",
                qui,
            )
        )

    if len(admin_hosts) >= 3:
        ips = ", ".join(h.ip for h in admin_hosts[:8])
        chantiers.append(
            _f(
                "restr-admin-jump",
                "Surface d'administration trop large sur le LAN",
                "SSH / RDP / VNC / WinBox ouverts un peu partout : n'importe quel poste "
                "compromis peut tâtonner l'admin. Il faut un saut (jump host / VPN / VLAN admin), "
                "pas 12 consoles sur le même plat.",
                f"{len(admin_hosts)} hôte(s) admin : {ips}",
                [
                    "VLAN management : SSH/RDP seulement depuis ce VLAN ou un bastion.",
                    "Couper Telnet / VNC là où SSH ou un outil moderne suffit.",
                    "MFA sur les accès distants restants.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                qui,
            )
        )

    if db_hosts:
        ips = ", ".join(f"{h.ip}({h.kind})" for h in db_hosts[:8])
        chantiers.append(
            _f(
                "restr-datastores",
                "Bases / datastores joignables depuis le LAN de travail",
                "MySQL, Postgres, Mongo, Redis, MSSQL ouverts sur le réseau bureautique : "
                "un rançongiciel ou un stagiaire trop curieux voit les données. "
                "À reculer derrière localhost / VLAN data.",
                ips,
                [
                    "Binder les bases sur localhost ou un VLAN data.",
                    "Auth forte, pas de compte anonyme, pas d'écoute 0.0.0.0 sans firewall.",
                    "Sauvegardes chiffrées testées (restauration réelle, pas seulement le dump).",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                qui,
            )
        )

    if rdp_hosts and profil in ("pme", "ecole"):
        chantiers.append(
            _f(
                "restr-rdp",
                "Accès distants (RDP / VNC) à ramener dans un tunnel",
                "RDP à plat sur le LAN PME / école est le scénario latéral classique. "
                "Restructurer = VPN ou Zero Trust, pas « on laisse 3389 on verra ».",
                ", ".join(h.ip for h in rdp_hosts[:8]),
                [
                    "VPN ou passerelle RDS ; pas de 3389 vers Internet, et pas vers le VLAN élèves.",
                    "NLA + MFA ; comptes individuels, pas « salles » partagés.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                qui,
            )
        )

    if n_net == 0 and n >= 3:
        chantiers.append(
            _f(
                "restr-matos-reseau",
                "Matériel réseau peu identifié (box / switch / AP)",
                "Sans savoir où sont les switches et les bornes, on ne peut ni segmenter "
                "ni garantir qu'un AP pirate n'est pas là. Inventaire L2/L3 d'abord.",
                f"kinds réseau vus={n_net} ; gateway={gateway or '?'}",
                [
                    "Marquer la box officielle (gateway) et chaque AP / switch.",
                    "Couper le DHCP secondaire (double NAT).",
                    "Mot de passe admin unique, plus le défaut usine.",
                ],
                Gravite.MOYENNE,
                "cette_semaine",
                qui,
            )
        )

    if ot_hosts:
        chantiers.append(
            _f(
                "restr-ot",
                "Automates / OT sur le même plat que le bureau",
                "Modbus, S7, OPC-UA ou EtherNet/IP à côté des PC : un incident bureautique "
                "peut toucher la machine. Restructurer = zone OT, pas un antivirus de plus.",
                ", ".join(h.ip for h in ot_hosts[:8]),
                [
                    "VLAN / pare-feu OT distinct (ISA/IEC 62443 en esprit, sans se rêver certifiant).",
                    "Pas d'exposition Internet des automates.",
                    "Accès maintenance nominatif, pas de mot de passe constructeur.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                qui,
            )
        )

    if profil == "ecole":
        chantiers.append(
            _f(
                "restr-ecole",
                "Parc scolaire : 3 mondes (élèves / profs / admin)",
                "Notes, dossiers, comptes enseignants et postes élèves ne doivent pas "
                "se voir. C'est de la restructuration, pas un « petit VLAN si on a le temps ».",
                f"profil=ecole · hôtes={n}",
                [
                    "SSID / VLAN élèves, enseignants, administration, invités.",
                    "Interdire RDP/SMB du VLAN élèves vers l'admin.",
                    "Comptes individuels ; fin des sessions « salle 12 ».",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                "DSI établissement / prestataire / ÉOH",
            )
        )

    try:
        from guardia.engines.parc_roles import detect_serveurs_parc

        serveurs = detect_serveurs_parc(hosts)
    except Exception:
        serveurs = []
    if serveurs:
        s0 = serveurs[0]
        chantiers.append(
            _f(
                "restr-desserte",
                "La machine qui dessert les autres : la traiter d'abord",
                "Inventorier les PC un par un ne tranche pas si un serveur "
                "(annuaire, fichiers, impression) tient tout le monde. "
                "Un trou ici n'est pas « une machine de plus ».",
                ", ".join(
                    f"{s.get('hostname') or s['ip']} [{', '.join(s.get('roles') or [])}]"
                    for s in serveurs[:6]
                ),
                [
                    "Nommer le rôle, le responsable, le VLAN de cette machine.",
                    "Qui a le droit de la joindre : pas les élèves, pas l'invité.",
                    "Sauvegardes testées — si elle tombe, le parc s'arrête.",
                    "Comptes nominatifs ; plus de session « salle » sur ce serveur.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                qui,
            )
        )

    if not chantiers:
        chantiers.append(
            _f(
                "restr-veille",
                "Pas de chantier lourd évident sur l'inventaire actuel",
                "L'échantillon visible ne crie pas à la refonte. Ça ne veut pas dire "
                "que le parc est « fini » : ça veut dire qu'on n'invente pas de travaux.",
                f"{n} hôte(s) · kinds={', '.join(sorted(kinds))}",
                [
                    "Garder un inventaire à jour (nouveaux AP, TV, NAS).",
                    "Revoir après tout changement de box / de local.",
                ],
                Gravite.INFO,
                "plus_tard",
                qui,
            )
        )

    priorites = [c for c in chantiers if c.gravite in (Gravite.CRITIQUE, Gravite.HAUTE)]
    return {
        "resume": (
            f"{n} appareil(s) inventorié(s) · {len(chantiers)} chantier(s) "
            f"dont {len(priorites)} prioritaire(s). "
            "Lecture d'architecture, pas une topologie câblée certifiée."
        ),
        "stats": {
            "hotes": n,
            "inconnus": n_inconnu,
            "iot": n_iot,
            "pc": n_pc,
            "nas": n_nas,
            "reseau": n_net,
            "admin": len(admin_hosts),
            "datastores": len(db_hosts),
            "ot": len(ot_hosts),
        },
        "chantiers": chantiers,
    }
