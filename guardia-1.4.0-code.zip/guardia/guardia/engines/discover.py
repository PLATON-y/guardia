"""Découverte d'hôtes (nmap)."""
from __future__ import annotations

import ipaddress
import logging
import re
import shutil
import subprocess
import xml.etree.ElementTree as ET
from pathlib import Path

from guardia.core.errors import ToolMissingError
from guardia.core.identite import assert_nmap_honnete
from guardia.core.models import Host

log = logging.getLogger("guardia.discover")


def _timeout_for_cidr(cidr: str, base: int, profondeur: str) -> int:
    """Scale timeout with CIDR size when parseable (défensif, gros /16 etc.)."""
    t = base
    try:
        net = ipaddress.ip_network(cidr, strict=False)
        hosts = net.num_addresses
        if hosts > 1024:
            t = max(t, 600)
        elif hosts > 256:
            t = max(t, 360)
        elif hosts > 64:
            t = max(t, 240)
    except ValueError:
        pass
    if profondeur == "full":
        t = max(t, 300)
    return t


def _which_nmap() -> str:
    p = shutil.which("nmap")
    if not p:
        raise ToolMissingError("nmap introuvable — installe nmap")
    return p


def discover(
    cidr: str,
    workdir: Path,
    timeout: int = 180,
    profondeur: str = "standard",
) -> list[Host]:
    """Découverte ping/ARP. Retourne une liste d'Host (peut être partielle).

    profondeur=full : un peu plus patient (retries / timeout), toujours -sn défensif.
    Timeout scale avec la taille du CIDR si parseable.
    """
    nmap = _which_nmap()
    workdir.mkdir(parents=True, exist_ok=True)
    out_base = workdir / "discover"
    timeout = _timeout_for_cidr(cidr, timeout, profondeur)
    if profondeur == "full":
        cmd = [
            nmap, "-sn", "-PR", "-PE", "-PP", "-PS22,80,443,445,3389",
            "-T3", "--max-retries", "3", "-oA", str(out_base), cidr,
        ]
    else:
        cmd = [nmap, "-sn", "-PR", "-T4", "--max-retries", "2", "-oA", str(out_base), cidr]
    assert_nmap_honnete(cmd)
    log.info("discovery (à visage découvert): %s", " ".join(cmd))
    try:
        from guardia.core.operator import set_active_subprocess, get_operator

        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        set_active_subprocess(proc)
        try:
            try:
                proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
                log.error("discovery timeout après %ss — on parse ce qui existe", timeout)
        finally:
            set_active_subprocess(None)
        if get_operator().should_stop_phase():
            log.warning("arrêt opérateur pendant discovery — parse partiel")
    except OSError as exc:
        log.error("discovery échec: %s", exc)
        return []

    xml_path = Path(str(out_base) + ".xml")
    hosts: list[Host] = []
    if xml_path.is_file():
        try:
            hosts = _parse_xml(xml_path)
        except Exception as exc:
            log.warning("parse XML discovery: %s — fallback gnmap", exc)
    if not hosts:
        gnmap = Path(str(out_base) + ".gnmap")
        hosts = _parse_gnmap(gnmap)
    try:
        from guardia.engines.osi_map import attach_host_osi

        attach_host_osi(hosts, cidr=cidr)
    except Exception as exc:  # noqa: BLE001
        log.debug("osi_map discover: %s", exc)
    return hosts


def _parse_xml(path: Path) -> list[Host]:
    tree = ET.parse(path)
    root = tree.getroot()
    hosts: list[Host] = []
    for h in root.findall("host"):
        status = h.find("status")
        if status is not None and status.get("state") != "up":
            continue
        ip = ""
        mac = ""
        vendor = ""
        for addr in h.findall("address"):
            if addr.get("addrtype") == "ipv4":
                ip = addr.get("addr") or ""
            elif addr.get("addrtype") == "mac":
                mac = addr.get("addr") or ""
                vendor = addr.get("vendor") or ""
        hostname = ""
        hn = h.find("hostnames/hostname")
        if hn is not None:
            hostname = hn.get("name") or ""
        if ip:
            hosts.append(Host(ip=ip, hostname=hostname, mac=mac, vendor=vendor))
    log.info("%d hôte(s) up", len(hosts))
    return hosts


def _parse_gnmap(path: Path) -> list[Host]:
    hosts: list[Host] = []
    if not path.is_file():
        return hosts
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return hosts
    current: Host | None = None
    for line in text.splitlines():
        if line.startswith("Host:"):
            m = re.match(r"Host:\s+(\S+)\s+\(([^)]*)\)\s+Status:\s+Up", line)
            if m:
                ip, name = m.group(1), m.group(2).strip()
                current = Host(ip=ip, hostname=name)
                hosts.append(current)
        elif "Ports:" not in line and current and "MAC:" in line:
            # rare in gnmap - skip
            pass
    # also from nmap stdout style in .nmap
    nmap_txt = path.with_suffix(".nmap")
    if nmap_txt.is_file():
        try:
            t = nmap_txt.read_text(encoding="utf-8", errors="replace")
        except OSError:
            t = ""
        ip_re = re.compile(r"Nmap scan report for (?:(\S+) \()?(\d+\.\d+\.\d+\.\d+)\)?")
        mac_re = re.compile(r"MAC Address: ([0-9A-F:]+)(?: \(([^)]+)\))?", re.I)
        cur = None
        by_ip = {h.ip: h for h in hosts}
        for line in t.splitlines():
            m = ip_re.search(line)
            if m:
                hostn, ip = m.group(1) or "", m.group(2)
                if hostn and hostn.replace("(", "").endswith(".lan"):
                    pass
                # group1 may be hostname without paren form
                m2 = re.match(r"Nmap scan report for (.+) \((\d+\.\d+\.\d+\.\d+)\)", line)
                m3 = re.match(r"Nmap scan report for (\d+\.\d+\.\d+\.\d+)", line)
                if m2:
                    hostname, ip = m2.group(1), m2.group(2)
                elif m3:
                    hostname, ip = "", m3.group(1)
                else:
                    continue
                if ip not in by_ip:
                    by_ip[ip] = Host(ip=ip, hostname=hostname)
                else:
                    if hostname and not by_ip[ip].hostname:
                        by_ip[ip].hostname = hostname
                cur = by_ip[ip]
            mm = mac_re.search(line)
            if mm and cur:
                cur.mac = mm.group(1)
                cur.vendor = mm.group(2) or cur.vendor
        hosts = list(by_ip.values())
    log.info("%d hôte(s) (gnmap/nmap)", len(hosts))
    return hosts
