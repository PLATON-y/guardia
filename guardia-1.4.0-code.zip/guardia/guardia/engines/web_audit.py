"""Audit défensif d'un site web autorisé (URL du mandat / de la mission).

Stdlib only. Pas de crawl offensif, pas de fuzz, pas de credentials.
Préremplissage lab : https://example.test
"""
from __future__ import annotations

import logging
import re
import socket
import ssl
import urllib.error
import urllib.request
from datetime import datetime, timezone
from typing import Any
from urllib.parse import urljoin, urlparse

from guardia.core.identite import user_agent as _ua
from guardia.core.defaults import DEFAULT_SITE_URL
from guardia.core.models import Finding, Gravite, Mission

log = logging.getLogger("guardia.web")

USER_AGENT = _ua()
FETCH_TIMEOUT = 12
MAX_BODY = 400_000

LEGAL_PATHS = (
    "/mentions-legales",
    "/mentions_legales",
    "/mentionslegales",
    "/legal",
    "/legal-notice",
    "/politique-de-confidentialite",
    "/politique_de_confidentialite",
    "/confidentialite",
    "/privacy",
    "/privacy-policy",
    "/cookies",
    "/politique-cookies",
    "/cgu",
    "/cgv",
)

SECURITY_TXT_PATHS = (
    "/.well-known/security.txt",
    "/security.txt",
)

CMP_MARKERS = (
    "tarteaucitron",
    "axeptio",
    "didomi",
    "cookiebot",
    "onetrust",
    "optanon",
    "quantcast",
    "sirdata",
    "iubenda",
    "cookieyes",
    "cookie-consent",
    "cookieconsent",
    "gestion des cookies",
    "gérer les cookies",
    "gerer les cookies",
    "tout refuser",
    "refuser tout",
    "refuser les cookies",
)

TRACKER_MARKERS = (
    ("googletagmanager.com", "Google Tag Manager"),
    ("google-analytics.com", "Google Analytics"),
    ("gtag/js", "gtag.js"),
    ("connect.facebook.net", "Meta Pixel"),
    ("fbevents.js", "Meta Pixel"),
    ("hotjar.com", "Hotjar"),
    ("clarity.ms", "Microsoft Clarity"),
    ("snap.licdn.com", "LinkedIn Insight"),
    ("doubleclick.net", "DoubleClick"),
    ("googlesyndication.com", "Google Ads"),
)

LEGAL_LINK_RE = re.compile(
    r"mentions\s*l[eé]gales|politique\s+de\s+confidentialit[eé]|privacy\s*policy|"
    r"gestion\s+des\s+cookies|politique\s+cookies|\bcgu\b|\bcgv\b",
    re.I,
)
DPO_RE = re.compile(
    r"d[eé]l[eé]gu[eé]\s+[àa]\s+la\s+protection|dpo\b|data\s+protection\s+officer|"
    r"droit[s]?\s+d['’]acc[eè]s|exercer\s+vos\s+droits",
    re.I,
)


def normalize_url(url: str) -> str:
    u = (url or "").strip()
    if not u:
        return DEFAULT_SITE_URL
    if not re.match(r"^https?://", u, re.I):
        u = "https://" + u
    return u.rstrip("/") or DEFAULT_SITE_URL


def _host(url: str) -> str:
    return urlparse(url).hostname or ""


def _finding(
    fid: str,
    titre: str,
    pourquoi: str,
    preuve: str,
    etapes: list[str],
    gravite: Gravite,
    priorite: str,
    mission: Mission,
    hote: str,
) -> Finding:
    tut = mission.ton_rapport == "tutoiement"
    qui = "toi-même / webmaster" if tut else "vous-même / webmaster / prestataire"
    return Finding(
        id=fid,
        titre=titre,
        pourquoi_nuit=pourquoi,
        preuve=preuve[:400],
        remede_etapes=etapes,
        qui_peut=qui,
        priorite=priorite,
        gravite=gravite,
        hote=hote,
    )


def _opener(timeout: int = FETCH_TIMEOUT) -> urllib.request.OpenerDirector:
    ctx = ssl.create_default_context()
    https = urllib.request.HTTPSHandler(context=ctx)
    return urllib.request.build_opener(https, urllib.request.HTTPRedirectHandler)


def _fetch(url: str, *, timeout: int = FETCH_TIMEOUT) -> dict[str, Any]:
    out: dict[str, Any] = {
        "url": url,
        "final_url": url,
        "status": 0,
        "headers": {},
        "body": "",
        "error": "",
        "https": url.lower().startswith("https://"),
    }
    req = urllib.request.Request(
        url,
        headers={
            "User-Agent": USER_AGENT,
            "Accept": "text/html,application/xhtml+xml,text/plain;q=0.9,*/*;q=0.8",
            "Accept-Language": "fr-FR,fr;q=0.9,en;q=0.4",
        },
        method="GET",
    )
    try:
        opener = _opener(timeout)
        with opener.open(req, timeout=timeout) as resp:
            out["status"] = int(getattr(resp, "status", 0) or resp.getcode() or 0)
            out["final_url"] = resp.geturl() or url
            hdrs = {str(k).lower(): str(v) for k, v in resp.headers.items()}
            out["headers"] = hdrs
            raw = resp.read(MAX_BODY + 1)
            if len(raw) > MAX_BODY:
                raw = raw[:MAX_BODY]
            out["body"] = raw.decode("utf-8", errors="replace")
            out["https"] = out["final_url"].lower().startswith("https://")
    except urllib.error.HTTPError as exc:
        out["status"] = int(exc.code or 0)
        out["error"] = f"HTTP {exc.code}"
        try:
            out["headers"] = {str(k).lower(): str(v) for k, v in (exc.headers or {}).items()}
            raw = exc.read(MAX_BODY) if exc.fp else b""
            out["body"] = raw.decode("utf-8", errors="replace")
        except Exception:
            pass
    except Exception as exc:  # noqa: BLE001
        out["error"] = f"{type(exc).__name__}: {exc}"
        log.warning("web fetch %s: %s", url, exc)
    return out


def _tls_info(hostname: str, port: int = 443) -> dict[str, Any]:
    info: dict[str, Any] = {
        "ok": False,
        "version": "",
        "cipher": "",
        "not_after": "",
        "subject": "",
        "issuer": "",
        "error": "",
        "days_left": None,
    }
    if not hostname:
        info["error"] = "hostname vide"
        return info
    ctx = ssl.create_default_context()
    try:
        with socket.create_connection((hostname, port), timeout=8) as sock:
            with ctx.wrap_socket(sock, server_hostname=hostname) as ssock:
                info["ok"] = True
                info["version"] = ssock.version() or ""
                cipher = ssock.cipher()
                info["cipher"] = (cipher[0] if cipher else "") or ""
                cert = ssock.getpeercert() or {}
                info["not_after"] = str(cert.get("notAfter") or "")
                subj = cert.get("subject") or ()
                iss = cert.get("issuer") or ()
                def _cn(seq: Any) -> str:
                    for rdn in seq:
                        for k, v in rdn:
                            if k == "commonName":
                                return str(v)
                    return ""
                info["subject"] = _cn(subj)
                info["issuer"] = _cn(iss)
                if info["not_after"]:
                    try:
                        dt = datetime.strptime(info["not_after"], "%b %d %H:%M:%S %Y %Z").replace(
                            tzinfo=timezone.utc
                        )
                        info["days_left"] = int((dt - datetime.now(timezone.utc)).total_seconds() // 86400)
                    except ValueError:
                        pass
    except Exception as exc:  # noqa: BLE001
        info["error"] = f"{type(exc).__name__}: {exc}"
        log.info("tls %s: %s", hostname, exc)
    return info


def parse_trackers_and_cmp(body: str) -> dict[str, Any]:
    low = (body or "").lower()
    trackers = [label for needle, label in TRACKER_MARKERS if needle in low]
    # unique preserve order
    seen: set[str] = set()
    trackers_u = []
    for t in trackers:
        if t not in seen:
            seen.add(t)
            trackers_u.append(t)
    cmp_hits = [m for m in CMP_MARKERS if m in low]
    legal = bool(LEGAL_LINK_RE.search(body or ""))
    dpo = bool(DPO_RE.search(body or ""))
    return {
        "trackers": trackers_u,
        "cmp": cmp_hits,
        "legal_link": legal,
        "dpo_or_rights": dpo,
    }


def header_gaps(headers: dict[str, str]) -> list[str]:
    h = {k.lower(): v for k, v in (headers or {}).items()}
    gaps: list[str] = []
    if "strict-transport-security" not in h:
        gaps.append("Strict-Transport-Security (HSTS)")
    csp = h.get("content-security-policy", "")
    xfo = h.get("x-frame-options", "")
    if not csp and not xfo:
        gaps.append("Content-Security-Policy ou X-Frame-Options")
    if "x-content-type-options" not in h:
        gaps.append("X-Content-Type-Options")
    if "referrer-policy" not in h:
        gaps.append("Referrer-Policy")
    if "permissions-policy" not in h and "feature-policy" not in h:
        gaps.append("Permissions-Policy")
    return gaps


def audit_website(url: str, mission: Mission, *, timeout: int = FETCH_TIMEOUT) -> dict[str, Any]:
    """Contrôle défensif d'une URL autorisée. Soft-fail réseau."""
    url = normalize_url(url)
    host = _host(url)
    findings: list[Finding] = []
    pages: dict[str, Any] = {}
    notes: list[str] = []

    home = _fetch(url, timeout=timeout)
    pages["home"] = {
        "url": home.get("final_url") or url,
        "status": home.get("status"),
        "error": home.get("error"),
        "https": home.get("https"),
    }
    tls = _tls_info(host)

    if home.get("error") and not home.get("status"):
        findings.append(
            _finding(
                "web-injoignable",
                "Site web injoignable depuis le poste opérateur",
                "Sans page d'accueil joignable, on ne peut pas contrôler HTTPS, "
                "mentions légales ni cookies. À relancer ou à vérifier DNS / pare-feu.",
                str(home.get("error")),
                [
                    "Vérifier que l'URL du mandat est exacte.",
                    "Tester depuis un réseau autorisé (pas seulement le LAN client).",
                    "Si le site est down : le noter comme incident de disponibilité.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                mission,
                host,
            )
        )
        return {
            "url": url,
            "host": host,
            "tls": tls,
            "headers": home.get("headers") or {},
            "pages": pages,
            "signals": {},
            "findings": findings,
            "notes": notes + [str(home.get("error"))],
            "ok": False,
        }

    if url.lower().startswith("http://") or not home.get("https"):
        findings.append(
            _finding(
                "web-pas-https",
                "Le site n'est pas servi en HTTPS de bout en bout",
                "Sans TLS, les données des visiteurs (formulaires, cookies, sessions) "
                "circulent en clair. Exigence de sécurité (RGPD art. 32) et de confiance.",
                f"url={url} final={home.get('final_url')} https={home.get('https')}",
                [
                    "Imposer HTTPS (Let's Encrypt / certificat prestataire).",
                    "Rediriger tout HTTP → HTTPS (301).",
                    "Activer HSTS une fois HTTPS stable.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                mission,
                host,
            )
        )

    if tls.get("ok"):
        ver = str(tls.get("version") or "")
        if ver in ("SSLv2", "SSLv3", "TLSv1", "TLSv1.1"):
            findings.append(
                _finding(
                    "web-tls-vieux",
                    f"TLS trop ancien ({ver})",
                    "SSL/TLS 1.0/1.1 (ou SSL) sont cassés. Un visiteur peut être "
                    "écouté plus facilement. À passer en TLS 1.2+ (idéalement 1.3).",
                    f"{host} {ver} cipher={tls.get('cipher')}",
                    [
                        "Désactiver SSL, TLS 1.0 et 1.1 côté serveur / reverse-proxy.",
                        "Imposer TLS 1.2 minimum, TLS 1.3 si possible.",
                    ],
                    Gravite.HAUTE,
                    "tout_de_suite",
                    mission,
                    host,
                )
            )
        days = tls.get("days_left")
        if isinstance(days, int) and days < 0:
            findings.append(
                _finding(
                    "web-cert-expire",
                    "Certificat TLS expiré",
                    "Un certificat périmé casse la confiance du navigateur et masque "
                    "souvent un oubli de maintenance.",
                    f"not_after={tls.get('not_after')} days_left={days}",
                    [
                        "Renouveler le certificat immédiatement.",
                        "Mettre un rappel J-30 (cron / Let's Encrypt auto).",
                    ],
                    Gravite.HAUTE,
                    "tout_de_suite",
                    mission,
                    host,
                )
            )
        elif isinstance(days, int) and days < 21:
            findings.append(
                _finding(
                    "web-cert-bientot",
                    "Certificat TLS bientôt expiré",
                    "Sans renouvellement, le cadenas casse d'ici peu — image et confiance.",
                    f"not_after={tls.get('not_after')} days_left={days}",
                    ["Planifier le renouvellement avant expiration.", "Vérifier le renouvellement automatique."],
                    Gravite.MOYENNE,
                    "cette_semaine",
                    mission,
                    host,
                )
            )
    elif host:
        notes.append(f"tls: {tls.get('error') or 'échec handshake'}")

    headers = home.get("headers") or {}
    gaps = header_gaps(headers)
    if gaps:
        findings.append(
            _finding(
                "web-headers-manque",
                "En-têtes de sécurité HTTP incomplets",
                "HSTS, CSP, Referrer-Policy, etc. réduisent le vol de session, le clickjacking "
                "et les fuites de referer. Ce n'est pas une faille d'exploit, c'est de l'hygiène.",
                "manque: " + ", ".join(gaps),
                [
                    "Ajouter Strict-Transport-Security une fois HTTPS stable.",
                    "Poser une Content-Security-Policy adaptée (démarrer en report-only si besoin).",
                    "X-Content-Type-Options: nosniff ; Referrer-Policy: strict-origin-when-cross-origin.",
                ],
                Gravite.MOYENNE,
                "cette_semaine",
                mission,
                host,
            )
        )
    noisy = []
    for k in ("server", "x-powered-by", "x-aspnet-version", "x-generator"):
        if k in {x.lower() for x in headers}:
            noisy.append(f"{k}={headers.get(k) or headers.get(k.title())}")
    if noisy:
        findings.append(
            _finding(
                "web-banniere",
                "Bannière serveur trop bavarde",
                "Server / X-Powered-By renseignent la stack. Hygiène d'exposition, pas une faille seule.",
                "; ".join(noisy)[:240],
                ["Masquer ou minimiser Server / X-Powered-By.", "Documenter la stack en interne."],
                Gravite.INFO,
                "plus_tard",
                mission,
                host,
            )
        )

    body = home.get("body") or ""
    signals = parse_trackers_and_cmp(body)

    # pages légales
    legal_ok = bool(signals.get("legal_link"))
    conf_ok = False
    base = home.get("final_url") or url
    for path in LEGAL_PATHS:
        probe = _fetch(urljoin(base + "/", path.lstrip("/")), timeout=min(8, timeout))
        st = int(probe.get("status") or 0)
        pages[path] = {"status": st, "error": probe.get("error")}
        if st == 200:
            lowp = path.lower()
            if "mention" in lowp or "legal" in lowp:
                legal_ok = True
            if "confidential" in lowp or "privacy" in lowp or "cookie" in lowp:
                conf_ok = True
            pb = probe.get("body") or ""
            extra = parse_trackers_and_cmp(pb)
            if extra.get("dpo_or_rights"):
                signals["dpo_or_rights"] = True
            if extra.get("legal_link"):
                legal_ok = True

    sec_txt = False
    for path in SECURITY_TXT_PATHS:
        probe = _fetch(urljoin(base + "/", path.lstrip("/")), timeout=min(8, timeout))
        pages[path] = {"status": probe.get("status"), "error": probe.get("error")}
        if int(probe.get("status") or 0) == 200 and (probe.get("body") or "").strip():
            sec_txt = True
            break
    robots = _fetch(urljoin(base + "/", "robots.txt"), timeout=min(8, timeout))
    pages["/robots.txt"] = {"status": robots.get("status"), "error": robots.get("error")}

    if not legal_ok:
        findings.append(
            _finding(
                "web-mentions-legales",
                "Mentions légales non observées",
                "En France, les mentions légales (LCEN) doivent être accessibles. "
                "Leur absence est un manquement classique, pas un détail.",
                "pas de lien / page mentions légales détecté sur l'accueil et chemins usuels",
                [
                    "Publier une page Mentions légales liée depuis le pied de page.",
                    "Y mettre éditeur, SIREN/SIRET si société, hébergeur, contact.",
                ],
                Gravite.HAUTE,
                "cette_semaine",
                mission,
                host,
            )
        )
    if not conf_ok and not signals.get("legal_link"):
        findings.append(
            _finding(
                "web-politique-conf",
                "Politique de confidentialité non observée",
                "Le RGPD (art. 13-14) exige d'informer les personnes : finalités, bases, durées, droits. "
                "Sans page visible, le visiteur n'est pas informé.",
                "pas de page privacy / confidentialité 200 sur les chemins usuels",
                [
                    "Publier une politique de confidentialité en français, liée depuis le footer et le bandeau cookies.",
                    "Y décrire traitements, bases légales, durées, destinataires, droits, contact.",
                ],
                Gravite.HAUTE,
                "cette_semaine",
                mission,
                host,
            )
        )

    trackers = list(signals.get("trackers") or [])
    cmp = list(signals.get("cmp") or [])
    if trackers and not cmp:
        findings.append(
            _finding(
                "web-trackers-sans-cmp",
                "Traceurs détectés sans bandeau / CMP visible",
                "La CNIL exige un consentement préalable pour les traceurs non essentiels, "
                "et un refus aussi simple que l'acceptation. Déposer Analytics / pixel avant "
                "consentement est un manquement fréquent.",
                "trackers=" + ", ".join(trackers),
                [
                    "Installer un CMP (ou bandeau conforme) avant tout traceur non essentiel.",
                    "Bouton « tout refuser » au même niveau que « tout accepter ».",
                    "Ne charger Google Analytics / pixels qu'après consentement.",
                ],
                Gravite.HAUTE,
                "tout_de_suite",
                mission,
                host,
            )
        )
    elif trackers:
        findings.append(
            _finding(
                "web-trackers",
                "Traceurs tiers présents — à vérifier avec le consentement",
                "Des traceurs sont chargés. Si le CMP est bien câblé, c'est acceptable ; "
                "sinon le consentement est fictif. À confirmer dans le bandeau réel (navigateur).",
                "trackers=" + ", ".join(trackers) + " ; cmp=" + ", ".join(cmp[:6]),
                [
                    "Vérifier qu'aucun tag non essentiel ne part avant le clic.",
                    "Documenter chaque traceur dans la politique cookies.",
                ],
                Gravite.MOYENNE,
                "cette_semaine",
                mission,
                host,
            )
        )
    elif not cmp:
        findings.append(
            _finding(
                "web-pas-bandeau",
                "Pas de bandeau cookies / CMP observé",
                "Si le site ne dépose aucun traceur non essentiel, l'absence de bandeau peut être légitime. "
                "À confirmer (cookies techniques seulement). Sinon, bandeau CNIL obligatoire.",
                "aucun marqueur CMP ni tracker usuel dans le HTML d'accueil",
                [
                    "Inventorier les cookies réellement déposés (navigateur).",
                    "Si uniquement techniques : le dire dans la politique cookies.",
                    "Sinon : bandeau conforme CNIL (accepter / refuser au même niveau).",
                ],
                Gravite.INFO,
                "cette_semaine",
                mission,
                host,
            )
        )

    if not signals.get("dpo_or_rights"):
        findings.append(
            _finding(
                "web-droits-personnes",
                "Mention des droits / DPO non observée sur l'accueil",
                "Les personnes doivent savoir comment exercer accès, rectification, effacement, "
                "opposition. Un contact (DPO ou responsable) doit être indiqué.",
                "pas de motif DPO / droits d'accès dans le HTML parcouru",
                [
                    "Ajouter dans la politique de confidentialité : droits RGPD + modalité d'exercice.",
                    "Indiquer un e-mail de contact (et DPO s'il est désigné).",
                ],
                Gravite.MOYENNE,
                "cette_semaine",
                mission,
                host,
            )
        )

    if not sec_txt:
        findings.append(
            _finding(
                "web-security-txt",
                "Pas de security.txt observé",
                "Le fichier /.well-known/security.txt (RFC 9116) dit à qui signaler une faille. "
                "Utile, pas obligatoire RGPD, mais très bien vu pour un acteur cyber.",
                "/.well-known/security.txt non servi en 200",
                [
                    "Publier /.well-known/security.txt (Contact, Expires, Preferred-Languages: fr).",
                    "Boîte mail dédiée (security@…) lue réellement.",
                ],
                Gravite.INFO,
                "plus_tard",
                mission,
                host,
            )
        )

    return {
        "url": url,
        "host": host,
        "tls": tls,
        "headers": {k: v for k, v in list(headers.items())[:40]},
        "pages": pages,
        "signals": {
            "trackers": trackers,
            "cmp": cmp,
            "legal_link": legal_ok,
            "privacy_page": conf_ok,
            "dpo_or_rights": bool(signals.get("dpo_or_rights")),
            "security_txt": sec_txt,
        },
        "findings": findings,
        "notes": notes,
        "ok": True,
    }


def findings_as_dicts(result: dict[str, Any]) -> list[dict[str, Any]]:
    out = []
    for f in result.get("findings") or []:
        if hasattr(f, "to_dict"):
            out.append(f.to_dict())
        elif isinstance(f, dict):
            out.append(f)
    return out
