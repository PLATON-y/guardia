"""Corrélation CVE / configs faibles — lecture seule.

Compare ports, bannières et flags dérivés (SMBv1, TLS 1.0/1.1…) à un
catalogue local curated (pas de dump NVD). Produit des Finding compatibles
avec la chaîne observation / « Ceci permettrait de… » / remède / note.
"""
from __future__ import annotations

import logging
import re
from pathlib import Path
from typing import Any

from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.engines.preuve_repro import (
    NOTE_AUCUNE_EXPLOITATION,
    phrase_impact,
    phrase_protection,
)
from guardia.rules.engine import posture_from_findings

log = logging.getLogger("guardia.engines.cve_correlate")

_CATALOG_PATH = Path(__file__).resolve().parent.parent / "rules" / "cve_catalog.yaml"

_GRAV = {
    "critique": Gravite.CRITIQUE,
    "haute": Gravite.HAUTE,
    "moyenne": Gravite.MOYENNE,
    "basse": Gravite.BASSE,
    "info": Gravite.INFO,
}


def catalog_path() -> Path:
    return _CATALOG_PATH


def load_catalog(path: Path | None = None) -> list[dict[str, Any]]:
    """Charge le YAML (ou JSON frère). Retourne [] si absent / illisible."""
    p = path or _CATALOG_PATH
    if not p.is_file():
        alt = p.with_suffix(".json")
        if alt.is_file():
            p = alt
        else:
            log.warning("catalogue CVE introuvable : %s", p)
            return []
    try:
        text = p.read_text(encoding="utf-8")
    except OSError as exc:
        log.warning("lecture catalogue CVE : %s", exc)
        return []
    data: Any = None
    if p.suffix.lower() in (".yaml", ".yml"):
        try:
            import yaml  # type: ignore

            data = yaml.safe_load(text)
        except Exception as exc:  # noqa: BLE001
            log.warning("yaml catalogue CVE : %s", exc)
            return []
    else:
        import json

        try:
            data = json.loads(text)
        except Exception as exc:  # noqa: BLE001
            log.warning("json catalogue CVE : %s", exc)
            return []
    if isinstance(data, dict):
        entries = data.get("entries") or []
    elif isinstance(data, list):
        entries = data
    else:
        return []
    return [e for e in entries if isinstance(e, dict) and e.get("id")]


def _ports_index(host: Host) -> dict[int, dict[str, Any]]:
    out: dict[int, dict[str, Any]] = {}
    for p in host.ports or []:
        if not isinstance(p, dict):
            continue
        try:
            num = int(p.get("port") or 0)
        except (TypeError, ValueError):
            continue
        if num:
            out[num] = p
    return out


def _scripts_blob(port: dict[str, Any]) -> str:
    scripts = port.get("scripts") or {}
    if isinstance(scripts, dict):
        return " ".join(f"{k} {v}" for k, v in scripts.items())
    if isinstance(scripts, list):
        return " ".join(str(x) for x in scripts)
    return str(scripts or "")


def derive_flags(host: Host) -> set[str]:
    """Flags soft dérivés des scripts / bannières — jamais une sonde d'attaque."""
    flags: set[str] = set()
    for p in host.ports or []:
        if not isinstance(p, dict):
            continue
        blob = " ".join(
            [
                str(p.get("name") or ""),
                str(p.get("product") or ""),
                str(p.get("version") or ""),
                str(p.get("extrainfo") or ""),
                _scripts_blob(p),
            ]
        ).lower()
        # SMBv1
        if any(
            x in blob
            for x in (
                "smb1",
                "smb v1",
                "smbv1",
                "nt lm 0.12",
                "samba.*dialect.*1",
                "message_signing: disabled_and_smb1",
            )
        ) or re.search(r"\bsmb\s*v?1\b", blob) or "dialect: nt lm 0.12" in blob:
            flags.add("smb_v1")
        if "smb-security-mode" in blob and (
            "message_signing: disabled" in blob
            or "message signing is disabled" in blob
            or "smb signing disabled" in blob
        ):
            flags.add("smb_signing_disabled")
        # TLS / SSL
        if re.search(r"\btls(v)?1(\.0)?\b", blob) or "tlsv1.0" in blob or "tls 1.0" in blob:
            flags.add("tls_1_0")
        if "tlsv1.1" in blob or "tls 1.1" in blob or re.search(r"\btlsv?1\.1\b", blob):
            flags.add("tls_1_1")
        if "sslv3" in blob or "ssl 3.0" in blob or "sslv3.0" in blob:
            flags.add("ssl_v3")
        # SNMP
        if "snmp" in blob and any(x in blob for x in ("v1", "v2c", "public", "private")):
            flags.add("snmp_v1v2")
        # Admin HTTP soft
        try:
            portnum = int(p.get("port") or 0)
        except (TypeError, ValueError):
            portnum = 0
        if portnum in (8080, 8443, 9443) and any(
            x in blob for x in ("admin", "manage", "tomcat", "router", "nas", "printer", "login")
        ):
            flags.add("admin_http")
        if portnum in (8080, 8443, 9443) and host.kind in (
            "nas",
            "imprimante",
            "printer",
            "camera",
            "iot",
            "box",
            "router",
        ):
            flags.add("admin_http")
    # Notes hôte
    for n in host.notes or []:
        low = str(n).lower()
        if "smbv1" in low or "smb1" in low:
            flags.add("smb_v1")
        if "tls 1.0" in low or "tlsv1.0" in low:
            flags.add("tls_1_0")
        if "tls 1.1" in low or "tlsv1.1" in low:
            flags.add("tls_1_1")
    return flags


def _re_ok(pattern: str | None, text: str) -> bool:
    if not pattern:
        return True
    try:
        return bool(re.search(pattern, text or "", re.IGNORECASE | re.DOTALL))
    except re.error:
        return False


def _entry_matches(
    entry: dict[str, Any],
    host: Host,
    ports: dict[int, dict[str, Any]],
    flags: set[str],
) -> tuple[bool, str]:
    """Retourne (match?, observation courte)."""
    m = entry.get("match") or {}
    if not isinstance(m, dict):
        return False, ""

    want_ports = [int(x) for x in (m.get("ports") or []) if str(x).isdigit() or isinstance(x, int)]
    want_flags = [str(x) for x in (m.get("flags") or [])]
    service_names = [str(x).lower() for x in (m.get("service_names") or [])]
    product_re = m.get("product_regex")
    version_re = m.get("version_regex")
    banner_re = m.get("banner_regex")

    # Au moins une contrainte
    if not (want_ports or want_flags or service_names or product_re or version_re or banner_re):
        return False, ""

    hit_ports: list[int] = []
    if want_ports:
        hit_ports = [p for p in want_ports if p in ports]
        if not hit_ports and not want_flags:
            # ports requis et absents → non
            if not (product_re or version_re or banner_re or service_names):
                return False, ""
        if want_ports and not hit_ports and not want_flags and not (
            product_re or version_re or banner_re or service_names
        ):
            return False, ""

    if want_flags:
        if not any(f in flags for f in want_flags):
            # flags requis non vus : si ports seuls suffisent pour certaines entrées
            # (ex. telnet = port 23 sans flag), on n'exige les flags que s'ils sont
            # la contrainte principale. Ici flags absents → échec sauf si ports
            # matchent ET aucun flag n'était la seule règle.
            if not hit_ports and not (product_re or version_re or banner_re or service_names):
                return False, ""
            if want_flags and not any(f in flags for f in want_flags):
                # Entrées flag-centrées (smb_v1, tls_*) : le flag est obligatoire
                only_flag = bool(want_flags) and not (product_re or version_re or banner_re)
                if only_flag and not hit_ports:
                    return False, ""
                if only_flag and hit_ports and want_flags:
                    # Port ouvert + flag requis (SMBv1 sur 445) → flag obligatoire
                    return False, ""

    # service_names
    if service_names:
        names_ok = False
        for pdict in (ports[p] for p in (hit_ports or list(ports)) if p in ports):
            nm = str(pdict.get("name") or "").lower()
            if any(s in nm or nm == s for s in service_names):
                names_ok = True
                break
        if not names_ok and want_ports and hit_ports:
            # port match suffit pour telnet/ftp si name vide
            names_ok = True
        if not names_ok and not hit_ports:
            return False, ""

    # product / version / banner sur les ports candidats (ou tous)
    candidates = [ports[p] for p in hit_ports if p in ports] if hit_ports else list(ports.values())
    if not candidates and (product_re or version_re or banner_re):
        return False, ""

    prod_hit = False
    if product_re or version_re or banner_re:
        for pd in candidates or list(ports.values()):
            product = str(pd.get("product") or "")
            version = str(pd.get("version") or "")
            banner = " ".join(
                [product, version, str(pd.get("name") or ""), _scripts_blob(pd)]
            )
            ok_p = _re_ok(product_re, product) if product_re else True
            ok_v = _re_ok(version_re, version) if version_re else True
            ok_b = _re_ok(banner_re, banner) if banner_re else True
            # Si product_regex est posé, on exige un product non vide qui matche
            if product_re and not product and not banner_re:
                continue
            if version_re and not version:
                continue
            if ok_p and ok_v and ok_b:
                prod_hit = True
                if not hit_ports:
                    try:
                        hit_ports.append(int(pd.get("port") or 0))
                    except (TypeError, ValueError):
                        pass
                break
        if not prod_hit:
            return False, ""
    elif want_ports and not hit_ports:
        return False, ""
    elif want_flags and not any(f in flags for f in want_flags):
        return False, ""
    elif want_ports and hit_ports and want_flags and not any(f in flags for f in want_flags):
        return False, ""

    # Observation
    parts: list[str] = [f"Hôte {host.ip}"]
    if hit_ports:
        detail = []
        for pr in hit_ports[:4]:
            pd = ports.get(pr) or {}
            label = pd.get("name") or pd.get("product") or "tcp"
            ver = (pd.get("version") or "").strip()
            detail.append(f"{pr}/{label}" + (f" {ver}" if ver else ""))
        parts.append("ports " + ", ".join(detail))
    matched_flags = [f for f in want_flags if f in flags]
    if matched_flags:
        parts.append("indices " + ", ".join(matched_flags))
    if host.hostname:
        parts.append(f"({host.hostname})")
    return True, " — ".join(parts)


def _fid(entry_id: str, host: Host) -> str:
    return f"cve-{entry_id}-{host.ip.replace('.', '_')}"


def finding_from_entry(
    entry: dict[str, Any],
    host: Host,
    observation: str,
    *,
    vouvoiement: bool = True,
) -> Finding:
    grav = _GRAV.get(str(entry.get("gravite") or "info").lower(), Gravite.INFO)
    titre = str(entry.get("titre_fr") or entry.get("id") or "Corrélation CVE")
    impact = str(entry.get("impact_permettrait") or "").strip()
    remedes = [str(x).strip() for x in (entry.get("remede_etapes") or []) if str(x).strip()]
    cves = [str(x) for x in (entry.get("cve_ids") or []) if str(x).strip()]
    refs = [str(x) for x in (entry.get("refs") or []) if str(x).strip()]
    preuve_bits = [observation]
    if cves:
        preuve_bits.append("CVE : " + ", ".join(cves[:6]))
    if refs:
        preuve_bits.append("Réf. : " + refs[0])
    preuve = " | ".join(preuve_bits)
    f = Finding(
        id=_fid(str(entry.get("id") or "x"), host),
        titre=titre,
        pourquoi_nuit=impact or "une exposition liée à une configuration ou version connue comme fragile",
        preuve=preuve,
        remede_etapes=remedes
        or [
            "Réduisez la surface exposée et appliquez les correctifs / durcissements constructeur.",
            "Retestez en lecture seule après remédiation.",
        ],
        qui_peut="vous-même / prestataire IT" if vouvoiement else "toi-même / prestataire",
        priorite=str(entry.get("priorite") or "cette_semaine"),
        gravite=grav,
        hote=host.ip,
        observation=observation,
        interpretation=(
            f"Corrélation catalogue local (lecture). "
            f"{NOTE_AUCUNE_EXPLOITATION}"
        ),
        commande="",
        preuve_repro="",
        statut_auditeur="a_investiguer",
    )
    # Enrichit pourquoi pour phrase_impact
    f.pourquoi_nuit = impact or f.pourquoi_nuit
    # Attache libellés client dans interpretation
    try:
        imp = phrase_impact(f, vouvoiement=True)
        prot = phrase_protection(f, vouvoiement=True)
        extra = ""
        if cves:
            extra += " Identifiants publics : " + ", ".join(cves[:4]) + "."
        if refs:
            extra += " Documentation : " + refs[0] + "."
        f.interpretation = f"{imp} {prot} {NOTE_AUCUNE_EXPLOITATION}{extra}".strip()
    except Exception:  # noqa: BLE001
        pass
    return f


def correlate_host(
    host: Host,
    entries: list[dict[str, Any]],
    *,
    vouvoiement: bool = True,
) -> list[Finding]:
    ports = _ports_index(host)
    flags = derive_flags(host)
    out: list[Finding] = []
    seen_ids: set[str] = set()
    for entry in entries:
        ok, obs = _entry_matches(entry, host, ports, flags)
        if not ok:
            continue
        fid = _fid(str(entry.get("id")), host)
        if fid in seen_ids:
            continue
        # Évite doublon si déjà présent
        if any(getattr(f, "id", "") == fid for f in (host.findings or [])):
            continue
        seen_ids.add(fid)
        out.append(finding_from_entry(entry, host, obs, vouvoiement=vouvoiement))
    return out


def correlate_hosts(
    hosts: list[Host],
    mission: Mission | None = None,
    *,
    catalog: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Ajoute les findings CVE sur chaque hôte. Retourne un bloc résumé."""
    entries = catalog if catalog is not None else load_catalog()
    vouvoiement = True
    if mission is not None:
        vouvoiement = (mission.ton_rapport or "") == "vouvoiement" or bool(
            (mission.extras or {}).get("passi")
        )
    added = 0
    by_id: dict[str, int] = {}
    findings_dicts: list[dict[str, Any]] = []
    for host in hosts or []:
        new_f = correlate_host(host, entries, vouvoiement=vouvoiement)
        if new_f:
            host.findings.extend(new_f)
            host.posture = posture_from_findings(host)
            added += len(new_f)
            for f in new_f:
                eid = (f.id or "").split("-")[1] if "-" in (f.id or "") else f.id
                # id form cve-<entry>-ip → entry = parts between
                parts = (f.id or "").split("-")
                key = "-".join(parts[1:-4]) if len(parts) > 5 else (parts[1] if len(parts) > 1 else f.id)
                # simpler: use titre / catalog id from entry via rematch
                by_id[key] = by_id.get(key, 0) + 1
                findings_dicts.append(f.to_dict())
    return {
        "orchestre": True,
        "nature": "corrélation CVE lecture seule — catalogue local, pas de dump NVD",
        "catalogue_entries": len(entries),
        "catalogue_path": str(_CATALOG_PATH),
        "n_findings": added,
        "par_regle": by_id,
        "findings": findings_dicts,
        "note": NOTE_AUCUNE_EXPLOITATION,
        "titre_section": "Corrélation CVE (lecture)",
    }


def want_cve(args: Any = None, mission: Mission | None = None) -> bool:
    """CLI --cve / --no-cve ; extras cve ; auto si audit / audit_full / passi."""
    if args is not None and getattr(args, "no_cve", False):
        return False
    if args is not None and getattr(args, "cve", False):
        return True
    ex: dict[str, Any] = {}
    if mission is not None:
        ex = dict(mission.extras or {})
    if "cve" in ex:
        v = ex.get("cve")
        if v is False or str(v).strip().lower() in ("0", "false", "non", "off", "no"):
            return False
        if v is True or str(v).strip().lower() in ("1", "true", "oui", "on", "yes"):
            return True
    # Auto-on : audit / audit-full / passi / --full / profil full
    if args is not None:
        if getattr(args, "audit", False) or getattr(args, "audit_full", False):
            return True
        if getattr(args, "passi", False):
            return True
        if getattr(args, "full", False):
            return True
    if ex.get("audit") or ex.get("audit_full") or ex.get("passi"):
        return True
    if str(ex.get("audit_level") or "").lower() == "full":
        return True
    if ex.get("parc_inconnu") or str(ex.get("mode") or "").lower() == "full":
        return True
    if mission is not None and (mission.profondeur or "") == "full":
        return True
    # red-signed audit_full / smb hygiene
    opened = ex.get("red_actions_opened") or []
    if "audit_full" in opened or "smb_hygiene" in opened:
        return True
    return False
