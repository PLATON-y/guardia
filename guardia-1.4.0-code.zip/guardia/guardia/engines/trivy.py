"""Trivy — scan local (FS / image), pas un scan LAN.

Trivy ne se lance pas « sur le CIDR ». Guardia l'orchestre sur le poste
opérateur (le dépôt / le FS autorisé). Absent : on note, on enchaîne.
"""
from __future__ import annotations

import shutil
import subprocess
from pathlib import Path
from typing import Any

from guardia.core.paths import ROOT

INVITE = (
    "Trivy n'est pas un scan réseau. Kali : `sudo apt install trivy`. "
    "Utile sur un dépôt / une image / un FS autorisés. Guardia l'appelle "
    "sur le poste opérateur (`--trivy` ou YAML trivy: true)."
)


def etat() -> dict[str, Any]:
    path = shutil.which("trivy")
    return {
        "installe": bool(path),
        "binaire": path or "",
        "invite": INVITE,
        "install": "sudo apt install trivy",
        "orchestre": True,
        "lance": False,
        "distant": False,
        "lecture_seule": True,
        "note": (
            "Présent. Guardia orchestre un `trivy fs` du poste opérateur."
            if path
            else "Trivy absent. Pas un scan LAN. On continue."
        ),
    }


def run_operateur(*, cible: str | None = None, timeout: int = 60) -> dict[str, Any]:
    """Hygiène du FS opérateur — pas un audit du parc client."""
    st = etat()
    st["orchestre"] = True
    if not st["installe"]:
        st["etat"] = "absent"
        st["extrait"] = ""
        return st
    root = Path(cible) if cible else ROOT
    argv = [
        st["binaire"],
        "fs",
        "--quiet",
        "--skip-db-update",
        "--scanners",
        "vuln",
        "--severity",
        "HIGH,CRITICAL",
        str(root),
    ]
    try:
        p = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
        text = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    except subprocess.TimeoutExpired:
        st["lance"] = False
        st["etat"] = "timeout"
        st["extrait"] = f"timeout {timeout}s"
        st["commande"] = " ".join(argv)
        return st
    except Exception as exc:  # noqa: BLE001
        st["lance"] = False
        st["etat"] = "erreur"
        st["extrait"] = str(exc)
        return st
    st["lance"] = True
    st["etat"] = "ok"
    st["commande"] = " ".join(argv)
    st["extrait"] = text[-4000:]
    st["note"] = (
        "Résultat = poste opérateur ÉOH (FS Guardia), pas le parc client. "
        "À joindre au dossier opérateur."
    )
    return st
