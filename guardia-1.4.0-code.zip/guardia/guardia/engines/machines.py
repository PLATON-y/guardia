"""Scan machines / OT — Ethernet industriel, sur demande.

Les grandes machines d'atelier parlent **Ethernet industriel** (Modbus TCP,
Siemens S7, OPC-UA, EtherNet/IP, Profinet, IEC-104, DNP3, MELSEC…), pas un
bus CAN. Guardia ne fait que de la lecture (nmap -sV / -sU borné) :
pas d'écriture automate, pas d'injection de trame.
"""
from __future__ import annotations

import logging
import shutil
import subprocess
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path
from typing import Any

from guardia.core.models import Finding, Gravite, Host, Mission

log = logging.getLogger("guardia.machines")

# TCP — lecture seule, pas un -p-.
OT_PORTS_TCP = (
    "102,502,789,1089,1090,1091,1911,1962,2222,2404,2455,4000,4840,"
    "5006,5007,9600,20000,34962,34963,34964,44818,47808"
)

# UDP — Profinet (34962-34964), EtherNet/IP I/O (2222), BACnet (47808).
OT_PORTS_UDP = "2222,34962,34963,34964,44818,47808"

OT_LABEL = {
    102: "ISO-TSAP / Siemens S7 / Profinet (ISO)",
    502: "Modbus TCP",
    4840: "OPC-UA",
    44818: "EtherNet/IP (CIP)",
    47808: "BACnet/IP",
    20000: "DNP3",
    1911: "Niagara Fox",
    2222: "EtherNet/IP I/O",
    2404: "IEC 60870-5-104",
    2455: "CODESYS",
    9600: "OMRON FINS",
    1962: "PCWorx",
    4000: "Emerson / remote OT (indice)",
    1089: "FF / fondation fieldbus (indice)",
    1090: "FF (indice)",
    1091: "FF (indice)",
    789: "Crimson / Red Lion (indice)",
    34962: "PROFINET (DCP / RT)",
    34963: "PROFINET (RPC)",
    34964: "PROFINET (RPC / context)",
    5006: "MELSEC (Mitsubishi)",
    5007: "MELSEC (Mitsubishi)",
}

KIND_OT = "ot"

NOTE_ETHERNET = (
    "Ethernet industriel (Modbus TCP, S7, OPC-UA, EtherNet/IP, Profinet, "
    "IEC-104, DNP3, MELSEC) — lecture seule, pas d'écriture automate."
)


def _parse_xml(xml_text: str) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    if not (xml_text or "").strip():
        return out
    try:
        root = ET.fromstring(xml_text)
    except ET.ParseError:
        return out
    for host_el in root.findall("host"):
        addr = ""
        for a in host_el.findall("address"):
            if a.get("addrtype") == "ipv4":
                addr = a.get("addr") or ""
        if not addr:
            continue
        ports: list[dict] = []
        ports_el = host_el.find("ports")
        if ports_el is None:
            continue
        for port_el in ports_el.findall("port"):
            state = port_el.find("state")
            if state is None or state.get("state") != "open":
                continue
            svc = port_el.find("service")
            ports.append(
                {
                    "port": int(port_el.get("portid") or 0),
                    "proto": port_el.get("protocol") or "tcp",
                    "name": (svc.get("name") if svc is not None else "") or "",
                    "product": (svc.get("product") if svc is not None else "") or "",
                    "version": (svc.get("version") if svc is not None else "") or "",
                }
            )
        out.setdefault(addr, []).extend(ports)
    return out


def _merge_ports(host: Host, new_ports: list[dict]) -> None:
    by_key = {
        (int(p.get("port", -1)), str(p.get("proto") or "tcp")): p
        for p in (host.ports or [])
        if "port" in p
    }
    for p in new_ports:
        try:
            num = int(p.get("port", -1))
        except (TypeError, ValueError):
            continue
        if num < 0:
            continue
        key = (num, str(p.get("proto") or "tcp"))
        old = by_key.get(key)
        if old is None:
            by_key[key] = p
        else:
            for k, v in p.items():
                if v and not old.get(k):
                    old[k] = v
            by_key[key] = old
    host.ports = sorted(
        by_key.values(),
        key=lambda x: (int(x.get("port", 0)), str(x.get("proto") or "tcp")),
    )


def _run_nmap(cmd: list[str], xml_path: Path, timeout: int, warns: list[str], tag: str) -> str:
    log.info("machines/OT %s : %s", tag, " ".join(cmd[:12]))
    try:
        from guardia.core.operator import set_active_subprocess

        proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True)
        set_active_subprocess(proc)
        try:
            try:
                proc.communicate(timeout=timeout)
            except subprocess.TimeoutExpired:
                proc.kill()
                proc.communicate()
                warns.append(f"machines: timeout nmap {tag} après {timeout}s — parse partiel")
        finally:
            set_active_subprocess(None)
    except OSError as exc:
        warns.append(f"machines nmap {tag}: {exc}")
        return ""
    if xml_path.exists():
        return xml_path.read_text(encoding="utf-8", errors="replace")
    return ""


def scan_ot_ports(
    hosts: list[Host],
    *,
    timeout: int = 120,
) -> tuple[list[Host], list[str]]:
    """Nmap ciblé ports OT (TCP + UDP Profinet/EtherNet/IP borné)."""
    warns: list[str] = []
    if not hosts:
        return [], ["machines: aucun hôte"]
    if not shutil.which("nmap"):
        return [], ["machines: nmap absent"]
    ips = [h.ip for h in hosts]
    host_map = {h.ip: h for h in hosts}
    tcp_budget = max(20, int(timeout * 0.7))
    udp_budget = max(15, int(timeout - tcp_budget))
    parsed: dict[str, list[dict]] = {}
    with tempfile.TemporaryDirectory(prefix="guardia-ot-") as td:
        xml_tcp = Path(td) / "ot-tcp.xml"
        cmd_tcp = [
            "nmap",
            "-sV",
            "-p",
            OT_PORTS_TCP,
            "--version-light",
            "-T3",
            "--max-retries",
            "1",
            "-oX",
            str(xml_tcp),
            *ips,
        ]
        xml_text = _run_nmap(cmd_tcp, xml_tcp, tcp_budget, warns, "tcp")
        for ip, ports in _parse_xml(xml_text).items():
            parsed.setdefault(ip, []).extend(ports)

        xml_udp = Path(td) / "ot-udp.xml"
        cmd_udp = [
            "nmap",
            "-sU",
            "-p",
            OT_PORTS_UDP,
            "-T3",
            "--max-retries",
            "0",
            "--host-timeout",
            "8s",
            "-oX",
            str(xml_udp),
            *ips,
        ]
        xml_u = _run_nmap(cmd_udp, xml_udp, udp_budget, warns, "udp")
        for ip, ports in _parse_xml(xml_u).items():
            parsed.setdefault(ip, []).extend(ports)

        touched: list[Host] = []
        for ip, ports in parsed.items():
            h = host_map.get(ip)
            if not h:
                continue
            ot_open = [p for p in ports if int(p.get("port") or 0) in OT_LABEL]
            if ot_open:
                _merge_ports(h, ports)
                if h.kind in ("inconnu", "", None):
                    h.kind = KIND_OT
                if "machines_ot" not in h.notes:
                    h.notes.append("machines_ot")
                touched.append(h)
        return touched, warns


def apply_machine_rules(hosts: list[Host], mission: Mission) -> list[Finding]:
    """Findings Ethernet industriel (exposition visible). Pas de finding CAN."""
    out: list[Finding] = []
    tut = mission.ton_rapport == "tutoiement"
    qui = "toi-même / automaticien" if tut else "automaticien / prestataire OT / ÉOH"
    ot_seen: list[tuple[Host, int, str]] = []
    for h in hosts:
        for p in h.ports or []:
            try:
                num = int(p.get("port", -1))
            except (TypeError, ValueError):
                continue
            if num in OT_LABEL:
                proto = str(p.get("proto") or "tcp")
                ot_seen.append((h, num, proto))
                out.append(
                    Finding(
                        id=f"ot-{num}-{h.ip.replace('.', '_')}",
                        titre=f"Ethernet industriel visible : {OT_LABEL[num]} (port {num}/{proto})",
                        pourquoi_nuit=(
                            "Un protocole d'atelier joignable depuis le LAN bureautique "
                            "élargit l'incident (arrêt machine, consigne altérée). "
                            "Guardia n'écrit pas sur l'automate : c'est un signalement d'exposition."
                        ),
                        preuve=f"{h.ip}:{num}/{proto} {OT_LABEL[num]} "
                        f"{p.get('product','')} {p.get('version','')}".strip(),
                        remede_etapes=[
                            "Confirmer que cet hôte est bien un automate / IHM / passerelle voulue.",
                            "Le sortir du VLAN bureau (zone OT, pare-feu entre IT et atelier).",
                            "Couper l'écoute si le port n'est plus utilisé.",
                            "Changer les mots de passe constructeur ; accès maintenance nominatif.",
                        ],
                        qui_peut=qui,
                        priorite="tout_de_suite",
                        gravite=Gravite.HAUTE,
                        hote=h.ip,
                    )
                )
    if not ot_seen:
        out.append(
            Finding(
                id="ot-aucun-port-industriel",
                titre="Aucun port Ethernet industriel visible sur cet échantillon",
                pourquoi_nuit=(
                    "Les grandes machines d'atelier parlent Ethernet industriel "
                    "(Modbus TCP, S7, OPC-UA, EtherNet/IP, Profinet…), pas un bus CAN. "
                    "Rien n'écoute ici depuis le LAN scanné — soit l'OT est ailleurs "
                    "(VLAN, hors CIDR), soit il n'y en a pas dans le mandat."
                ),
                preuve=f"sondage TCP {OT_PORTS_TCP} + UDP {OT_PORTS_UDP} — aucun port OT ouvert",
                remede_etapes=[
                    "Si l'atelier est dans le mandat : confirmer le VLAN / le CIDR OT.",
                    "Si un bus terrain (CAN, AS-i) existe : le noter, rester sur l'Ethernet IP du mandat.",
                    "Séparer IT / OT même si rien n'est visible aujourd'hui.",
                ],
                qui_peut="opérateur ÉOH + responsable atelier",
                priorite="plus_tard",
                gravite=Gravite.INFO,
                hote="parc",
            )
        )
    return out


def run_machines(
    hosts: list[Host],
    mission: Mission,
    *,
    remaining_sec: float | None = None,
) -> dict[str, Any]:
    warns: list[str] = []
    to = 120
    if remaining_sec is not None:
        if remaining_sec < 25:
            return {
                "done": False,
                "warns": ["machines sauté (budget trop juste)"],
                "findings": [],
                "hotes_ot": 0,
            }
        to = max(25, min(180, int(remaining_sec) - 5))
    touched, w = scan_ot_ports(hosts, timeout=to)
    warns.extend(w)
    findings = apply_machine_rules(hosts, mission)
    return {
        "done": True,
        "warns": warns,
        "findings": findings,
        "hotes_ot": len(touched),
        "ports_tcp": OT_PORTS_TCP,
        "ports_udp": OT_PORTS_UDP,
        "note": NOTE_ETHERNET,
    }
