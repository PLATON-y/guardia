"""Corrélation — plusieurs observations, un constat.

Le directeur ne doit pas lire « 0 à risque » puis « suite TLS faible ».
Guardia groupe ce qui parle du même équipement / du même thème.
Le LLM, s'il est allumé, interprète ce bloc. Il n'invente rien.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import CheckupResult, Gravite

_TLS = ("tls", "ssl", "cipher", "https", "443", "certificat", "crypto")
_SMB = ("smb", "445", "partage", "signing")
_RDP = ("rdp", "3389", "nla", "bureau")


def _blob(f: Any) -> str:
    if hasattr(f, "id"):
        return f"{f.id} {f.titre} {getattr(f, 'preuve', '')} {getattr(f, 'pourquoi_nuit', '')}".lower()
    if isinstance(f, dict):
        return " ".join(str(f.get(k) or "") for k in ("id", "titre", "preuve", "pourquoi_nuit")).lower()
    return str(f).lower()


def _grav(f: Any) -> Gravite:
    g = getattr(f, "gravite", None)
    if isinstance(g, Gravite):
        return g
    if isinstance(f, dict):
        try:
            return Gravite(str(f.get("gravite") or "info"))
        except ValueError:
            return Gravite.INFO
    return Gravite.INFO


def _titre(f: Any) -> str:
    return str(getattr(f, "titre", None) or (f.get("titre") if isinstance(f, dict) else "") or "")


def _hote(f: Any) -> str:
    return str(getattr(f, "hote", None) or (f.get("hote") if isinstance(f, dict) else "") or "")


def _rank(g: Gravite) -> int:
    return {
        Gravite.CRITIQUE: 4,
        Gravite.HAUTE: 3,
        Gravite.MOYENNE: 2,
        Gravite.BASSE: 1,
        Gravite.INFO: 0,
    }.get(g, 0)


def _group(findings: list[Any], keys: tuple[str, ...], titre: str, action: str) -> dict[str, Any] | None:
    hit = [f for f in findings if any(k in _blob(f) for k in keys)]
    if len(hit) < 1:
        return None
    worst = max((_grav(f) for f in hit), key=_rank)
    hotes = sorted({_hote(f) for f in hit if _hote(f)})
    return {
        "titre": titre,
        "gravite": worst.value,
        "hotes": hotes,
        "n": len(hit),
        "sources": [_titre(f) for f in hit[:8]],
        "action": action,
        "lecture_seule": True,
    }


def build_correlation(result: CheckupResult) -> dict[str, Any]:
    findings: list[Any] = [f for h in (result.hosts or []) for f in (h.findings or [])]
    for block in (result.website, result.machines, result.usages, result.rgpd):
        if isinstance(block, dict):
            findings.extend(block.get("findings") or [])
    items: list[dict[str, Any]] = []
    for keys, titre, action in (
        (
            _TLS,
            "Configuration TLS à renforcer",
            "Revoir les protocoles et suites autorisés. Désactiver ce qui est obsolète. Retester (testssl.sh / sslyze).",
        ),
        (
            _SMB,
            "Partages / signing SMB",
            "Restreindre les partages visibles, activer le signing, sortir les comptes guest.",
        ),
        (
            _RDP,
            "Bureau à distance exposé",
            "Couper RDP du LAN métier, ou NLA + réseau d'administration.",
        ),
    ):
        g = _group(findings, keys, titre, action)
        if g:
            items.append(g)
    return {
        "items": items,
        "regle": (
            "Une observation n'est pas un risque critique par défaut. "
            "La gravité (critique / élevé / moyen / information) est celle du finding. "
            "La posture d'un hôte (ok / à risque) est un autre compteur. "
            "Les deux sont affichés séparément."
        ),
        "llm": "Le modèle local reformule ce bloc s'il est allumé.",
    }
