"""Chapitre Usages & droits — ce que les gens peuvent faire.

On observe les *portes* visibles, on croise la fiche opérateur,
on dit quelle machine dessert les autres.
"""
from __future__ import annotations

import re
from typing import Any

from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.engines.parc_roles import blast_sentence, detect_serveurs_parc, ports_of
from guardia.engines.usages_config import (
    config_is_blank,
    load_usages_config,
    raw_config_from_mission,
)

DISCLAIMER = (
    "Chapitre usages & droits, sur demande / profil école. "
    "Guardia ne s'assoit pas derrière chaque session : il ne voit pas "
    "ce qu'un élève ou un salarié *fait* sur le poste. "
    "Il observe les portes visibles sans authentification (noms de partages, "
    "exports NFS, rootDSE LDAP, FTP anonyme) et croise vos déclarations. "
    "On montre la porte, on n'entre pas. "
    "Ceci n'est pas un audit IAM, pas un dump de comptes, pas un certificat."
)

STATUT_VU = "observé"
STATUT_NON_VU = "non observé — signalé"
STATUT_CONFIRMER = "à confirmer avec vous"
STATUT_DECLARE = "déclaré — pas un certificat"
STATUT_HORS = "hors observation à distance"

# partages « techniques » qu'on ne crie pas
_SHARES_NOISE = {
    "ipc$", "print$", "ipc", "print",
}


def _item(
    iid: str,
    titre: str,
    exigence: str,
    statut: str,
    observation: str,
    signalement: str,
    que_faire: list[str],
) -> dict[str, Any]:
    return {
        "id": iid,
        "titre": titre,
        "exigence": exigence,
        "statut": statut,
        "observation": observation,
        "signalement": signalement,
        "que_faire": que_faire,
    }


def _from_tri(
    val: str,
    *,
    oui_msg: str,
    non_msg: str,
    inconnu_msg: str,
    signal_if_non: bool = True,
    signal_if_oui: bool = False,
) -> tuple[str, str]:
    if val == "oui":
        if signal_if_oui:
            return STATUT_NON_VU, oui_msg
        return STATUT_DECLARE, oui_msg
    if val == "non":
        if signal_if_non:
            return STATUT_NON_VU, non_msg
        return STATUT_DECLARE, non_msg
    return STATUT_CONFIRMER, inconnu_msg


def _scripts_of(host: Host) -> dict[str, str]:
    merged: dict[str, str] = {}
    for p in host.ports or []:
        sc = p.get("scripts") or {}
        if isinstance(sc, dict):
            for k, v in sc.items():
                merged[str(k)] = str(v)
    return merged


def parse_smb_shares(output: str) -> list[str]:
    """Noms de partages (nmap smb-enum-shares). Pas le contenu."""
    if not output:
        return []
    found = re.findall(r"\\\\[^\\\s]+\\([^\\:\r\n]+)\s*:", output)
    if not found:
        found = re.findall(r"^\s*\|?\s*([A-Za-z0-9._$ -]+):\s*$", output, re.M)
        found = [
            x for x in found
            if x.strip().lower() not in ("account_used", "type", "comment")
        ]
    out: list[str] = []
    seen: set[str] = set()
    for n in found:
        s = n.strip().strip("\\")
        key = s.lower()
        if not s or key in seen:
            continue
        seen.add(key)
        out.append(s)
    return out


def parse_nfs_exports(output: str) -> list[str]:
    if not output:
        return []
    lines = []
    for line in output.splitlines():
        s = line.strip().lstrip("|").strip()
        if s.startswith("/") or (s and s[0] == "/" ):
            lines.append(s[:200])
        elif re.match(r"^\S+\s+\S+", s) and not s.lower().startswith("exports"):
            lines.append(s[:200])
    return lines[:24]


def disk_shares(names: list[str]) -> list[str]:
    out = []
    for n in names:
        if n.lower() in _SHARES_NOISE:
            continue
        out.append(n)
    return out


def collect_portes(hosts: list[Host]) -> list[dict[str, Any]]:
    """Portes visibles sans mot de passe (lecture)."""
    portes: list[dict[str, Any]] = []
    for h in hosts:
        sc = _scripts_of(h)
        smb = sc.get("smb-enum-shares") or ""
        if smb:
            names = parse_smb_shares(smb)
            disks = disk_shares(names)
            guest = "guest" in smb.lower() or "anonymous" in smb.lower()
            adminish = [n for n in names if n.lower() in ("admin$", "c$", "d$", "c", "admin")]
            portes.append(
                {
                    "ip": h.ip,
                    "kind": "smb",
                    "guest": guest,
                    "shares": names,
                    "disks": disks,
                    "admin_shares": adminish,
                    "raw": smb[:400],
                }
            )
        nfs = sc.get("nfs-showmount") or sc.get("nfs-ls") or ""
        if nfs:
            portes.append(
                {
                    "ip": h.ip,
                    "kind": "nfs",
                    "exports": parse_nfs_exports(nfs),
                    "raw": nfs[:400],
                }
            )
        ldap = sc.get("ldap-rootdse") or ""
        if ldap:
            portes.append(
                {
                    "ip": h.ip,
                    "kind": "ldap",
                    "anonymous": True,
                    "raw": ldap[:400],
                }
            )
        ftp = sc.get("ftp-anon") or ""
        if ftp and ("anonymous" in ftp.lower() or "logged in" in ftp.lower()):
            portes.append(
                {
                    "ip": h.ip,
                    "kind": "ftp-anon",
                    "raw": ftp[:300],
                }
            )
    return portes


def build_usages(
    mission: Mission,
    hosts: list[Host],
    *,
    pass_done: bool = False,
    pass_warns: list[str] | None = None,
) -> dict[str, Any]:
    cfg = load_usages_config(mission)
    blank = config_is_blank(raw_config_from_mission(mission))
    serveurs = detect_serveurs_parc(hosts)
    portes = collect_portes(hosts)
    items: list[dict[str, Any]] = []
    ecole = (mission.profil_moteur or "").lower() == "ecole" or (
        mission.type_structure or ""
    ).lower() == "ecole"

    items.append(
        _item(
            "usages-perimetre",
            "Ce que ce chapitre est (et n'est pas)",
            "Mandat — observation des portes, pas des sessions",
            STATUT_VU,
            "lecture seule · noms de partages, pas les fichiers",
            DISCLAIMER,
            [
                "Lire avec la direction : la question est « qui peut atteindre quoi ».",
                "Compléter la fiche usages (UI / CLI) pour les droits qu'on ne voit pas à distance.",
            ],
        )
    )

    if blank:
        items.append(
            _item(
                "usages-fiche-vide",
                "Fiche usages & droits non configurée",
                "Déclarations opérateur — comptes, admin local, VLAN, serveur central",
                STATUT_CONFIRMER,
                "usages_config absent ou tout à « inconnu »",
                "Sans la fiche, on voit les portes réseau, pas la politique de comptes. "
                "UI : Configurer usages · CLI : python3 -m guardia usages -m <mission.yaml>",
                [
                    "Poser les questions au responsable de parc (pas aux élèves).",
                    "Enregistrer, relancer le checkup.",
                ],
            )
        )

    # Serveur de desserte
    st_srv = STATUT_VU if serveurs else STATUT_CONFIRMER
    if str(cfg.get("serveur_central") or "") == "oui" and not serveurs:
        st_srv = STATUT_DECLARE
    if str(cfg.get("serveur_central") or "") == "non" and not serveurs:
        st_srv = STATUT_DECLARE
    items.append(
        _item(
            "usages-serveur-parc",
            "Machine(s) qui desservent les autres",
            "Un trou sur le serveur de parc n'est pas « une machine de plus »",
            st_srv,
            blast_sentence(serveurs)
            + (
                f" · déclaration serveur_central={cfg.get('serveur_central')} "
                f"rôle={cfg.get('serveur_central_role') or '—'}"
            ),
            "C'est souvent là que tiennent les sessions, les devoirs, les partages, "
            "l'annuaire. À traiter avant de passer les PC en revue un par un.",
            [
                "Nommer le serveur de desserte (rôle, responsable, VLAN).",
                "Restreindre qui le joint : pas le VLAN élèves / pas l'invité.",
                "Comptes nominatifs ; plus de session « salle » sur ce serveur.",
                "Sauvegardes testées — si cette machine tombe, le parc s'arrête.",
            ],
        )
    )

    # Portes SMB / NFS / LDAP
    smb_portes = [p for p in portes if p.get("kind") == "smb"]
    disks_all = [(p["ip"], n) for p in smb_portes for n in (p.get("disks") or [])]
    admin_all = [(p["ip"], n) for p in smb_portes for n in (p.get("admin_shares") or [])]
    guest_smb = [p for p in smb_portes if p.get("guest") and p.get("disks")]
    if admin_all:
        st_smb, sig_smb = (
            STATUT_NON_VU,
            "Partages admin (C$ / ADMIN$) visibles sans authentification forte — signalement.",
        )
    elif disks_all:
        st_smb, sig_smb = (
            STATUT_NON_VU,
            "Noms de partages disque visibles sans compte : la porte est ouverte. "
            "On n'a pas lu les fichiers.",
        )
    elif smb_portes:
        st_smb, sig_smb = (
            STATUT_VU,
            "SMB répond ; IPC$ / print$ seulement, ou liste incomplète. Pas un dump.",
        )
    elif not pass_done:
        st_smb, sig_smb = (
            STATUT_CONFIRMER,
            "Observation des partages non jouée (budget / nmap / module). "
            "Les ports 139/445 restent un indice.",
        )
    else:
        st_smb, sig_smb = (
            STATUT_VU,
            "Pas de liste de partages obtenue sans compte — bon signe, pas une preuve d'absence.",
        )
    obs_smb = (
        f"hôtes SMB listés={len(smb_portes)} · disques={disks_all[:12] or '—'} "
        f"· admin={admin_all[:6] or '—'} · guest={len(guest_smb)}"
    )
    items.append(
        _item(
            "usages-partages",
            "Partages visibles sans mot de passe (noms seulement)",
            "Ce qu'un visiteur / une session élève sur le LAN peut *voir* comme portes",
            st_smb,
            obs_smb,
            sig_smb,
            [
                "Retirer le guest / anonyme.",
                "Droits minimaux : groupes, pas « Tout le monde ».",
                "Sortir les partages du VLAN élèves / invité.",
                "Les devoirs, notes, RH n'ont rien à faire sur un partage ouvert.",
            ],
        )
    )

    nfs_p = [p for p in portes if p.get("kind") == "nfs"]
    if nfs_p:
        items.append(
            _item(
                "usages-nfs",
                "Exports NFS visibles (showmount)",
                "NFS trop large = le même problème que le partage guest, côté Unix",
                STATUT_NON_VU,
                str([(p["ip"], p.get("exports")) for p in nfs_p][:8]),
                "Export listé en lecture. Pas de montage des données métier par Guardia.",
                [
                    "Restreindre les exports à des IP / sous-réseaux nommés.",
                    "Pas de `*` sur des données élèves / RH.",
                    "root_squash, auth si possible (NFSv4 + Kerberos).",
                ],
            )
        )

    ldap_p = [p for p in portes if p.get("kind") == "ldap"]
    if ldap_p:
        items.append(
            _item(
                "usages-ldap",
                "Annuaire : réponse anonyme (rootDSE)",
                "LDAP / AD — rootDSE anonyme est souvent normal ; ce n'est pas un dump d'élèves",
                STATUT_VU,
                ", ".join(p["ip"] for p in ldap_p),
                "L'annuaire se présente sans compte. Ce n'est pas une énumération d'utilisateurs. "
                "On n'a pas listé les personnes.",
                [
                    "Vérifier qu'un bind anonyme ne liste pas les comptes (ça, c'est chez vous, pas ici).",
                    "LDAPS ; limiter qui joint 389/636 (pas le VLAN élèves).",
                    "Cette machine est une desserte : la traiter comme telle.",
                ],
            )
        )

    ftp_p = [p for p in portes if p.get("kind") == "ftp-anon"]
    if ftp_p:
        items.append(
            _item(
                "usages-ftp-anon",
                "FTP anonyme accepté",
                "La porte s'ouvre sans clé — démonstration respectueuse, pas un dump",
                STATUT_NON_VU,
                ", ".join(p["ip"] for p in ftp_p),
                "Login anonymous réussi côté nmap ftp-anon. Pas de dépôt, pas de téléchargement métier.",
                ["Couper FTP ; SFTP / FTPS si besoin réel.", "Pas d'anonyme, jamais."],
            )
        )

    # Droits déclarés
    st, msg = _from_tri(
        str(cfg.get("comptes_individuels") or "inconnu"),
        oui_msg="Comptes nominatifs déclarés. Vérifier que les salles n'ont plus de session partagée.",
        non_msg="Pas de comptes nominatifs déclarés — signalement : on ne sait pas qui a fait quoi.",
        inconnu_msg="À confirmer : un humain = un compte, partout (élèves, équipe, admin).",
    )
    items.append(
        _item(
            "usages-comptes",
            "Comptes nominatifs vs sessions de salle",
            "Savoir qui fait quoi — base de tout le reste (et du RGPD)",
            st,
            f"comptes_individuels={cfg.get('comptes_individuels')} "
            f"salles={cfg.get('comptes_partages_salles')} public={cfg.get('public') or '—'}",
            msg,
            [
                "Un compte par personne ; fin des « salle 12 » / « stagiaire ».",
                "Les départs : désactivation, pas « on gardera au cas où ».",
            ],
        )
    )
    st_salle, msg_salle = _from_tri(
        str(cfg.get("comptes_partages_salles") or "inconnu"),
        oui_msg="Sessions de salle encore déclarées — signalement : imputabilité nulle.",
        non_msg="Pas de compte de salle déclaré. À recouper avec les postes réellement allumés.",
        inconnu_msg="À confirmer s'il reste des sessions de salle.",
        signal_if_oui=True,
        signal_if_non=False,
    )
    items.append(
        _item(
            "usages-salles",
            "Comptes / sessions de salle",
            "Imputabilité — essentiel écoles, salles de formation, ateliers",
            st_salle,
            f"comptes_partages_salles={cfg.get('comptes_partages_salles')}",
            msg_salle,
            [
                "Remplacer par un compte nominatif ou une session contrainte (kiosque).",
                "Pas d'admin local sur ces postes.",
            ],
        )
    )

    st_a, msg_a = _from_tri(
        str(cfg.get("users_admin_local") or "inconnu"),
        oui_msg="Utilisateurs admin local déclarés — signalement : les GPO / droits globaux ne tiennent plus.",
        non_msg="Pas d'admin local déclaré pour les utilisateurs. Bon réflexe — à vérifier par sondage sur 2-3 postes.",
        inconnu_msg="À confirmer : un élève ou un salarié est-il admin de SA machine ?",
        signal_if_oui=True,
        signal_if_non=False,
    )
    items.append(
        _item(
            "usages-admin-local",
            "Admin local sur les postes utilisateurs",
            "Si l'humain est admin du poste, le parc n'a plus de politique",
            st_a,
            f"users_admin_local={cfg.get('users_admin_local')}",
            msg_a,
            [
                "Retirer les utilisateurs du groupe Administrateurs local.",
                "Un compte d'assistance nominatif, pas « prof » admin partout.",
                "Sondage : 2 postes élèves, 2 postes équipe — pas un script kiddie.",
            ],
        )
    )

    st_v, msg_v = _from_tri(
        str(cfg.get("vlan_separes") or "inconnu"),
        oui_msg="Segmentation déclarée. Recouper avec la carte du parc (tout à plat = à revoir).",
        non_msg="Pas de VLAN / SSID séparés déclarés — signalement : tout le monde voit les mêmes portes.",
        inconnu_msg="À confirmer : élèves / atelier / admin / invités se voient-ils ?",
    )
    items.append(
        _item(
            "usages-vlan",
            "Séparation élèves (ou atelier) / admin / invités",
            "Les droits ne tiennent pas sur un LAN plat",
            st_v,
            f"vlan_separes={cfg.get('vlan_separes')} wifi_invite={cfg.get('wifi_invite')}",
            msg_v,
            [
                "SSID / VLAN distincts ; interdire SMB/RDP/LDAP depuis le VLAN élèves vers l'admin.",
                "Wi‑Fi invité isolé, pas un alias du métier.",
            ],
        )
    )

    st_old, msg_old = _from_tri(
        str(cfg.get("anciens_comptes") or "inconnu"),
        oui_msg="Départs déclarés désactivés. À sondage annuel (promotions, CDD, vacataires).",
        non_msg="Comptes de départs encore ouverts déclarés — signalement.",
        inconnu_msg="À confirmer : promotions, départs, vacataires.",
        signal_if_non=True,
    )
    items.append(
        _item(
            "usages-departs",
            "Comptes des départs / anciennes promotions",
            "Un compte qui reste = une session qui reste",
            st_old,
            f"anciens_comptes={cfg.get('anciens_comptes')}",
            msg_old,
            ["Procédure de départ écrite (élève, salarié, prestataire).", "Revue au moins à chaque rentrée / trimestre RH."],
        )
    )

    if ecole:
        items.append(
            _item(
                "usages-ecole-lecture",
                "École / fac : ce n'est pas « passer les PC un par un »",
                "Posture — droits, desserte, sessions",
                STATUT_DECLARE if not blank else STATUT_CONFIRMER,
                f"profil=ecole · hôtes={len(hosts)} · desserte={len(serveurs)}",
                "Inventorier chaque machine reste utile. Le risque métier, lui, est : "
                "qu'est-ce qu'une session élève ou enseignant peut atteindre si les droits "
                "ne sont pas tenus, et que fait la machine qui dessert les autres. "
                "On ne s'assoit pas à la place de l'élève. On éclaire les portes.",
                [
                    "Traiter d'abord le serveur de desserte et les partages ouverts.",
                    "Puis un sondage de 2-3 postes (droits locaux), pas 200 à la main sans méthode.",
                    "Segmentation élèves / profs / admin.",
                ],
            )
        )

    n_signales = sum(1 for i in items if i["statut"] == STATUT_NON_VU)
    n_confirmer = sum(1 for i in items if i["statut"] == STATUT_CONFIRMER)
    n_declares = sum(1 for i in items if i["statut"] == STATUT_DECLARE)

    findings: list[Finding] = []
    if admin_all:
        findings.append(
            Finding(
                id="usages-admin-share",
                titre="Partage admin (C$ / ADMIN$) visible sans compte fort",
                pourquoi_nuit=(
                    "Quelqu'un sur le LAN voit une porte d'administration. "
                    "On n'a pas ouvert les disques : la porte suffit."
                ),
                preuve=str(admin_all[:8]),
                remede_etapes=[
                    "Interdire l'anonyme / guest.",
                    "Restreindre les partages admin au VLAN d'assistance.",
                    "Vérifier les postes encore en SMBv1.",
                ],
                qui_peut="admin parc / prestataire / ÉOH en accompagnement",
                priorite="tout_de_suite",
                gravite=Gravite.CRITIQUE,
                hote=admin_all[0][0],
                preuve_repro=(
                    f"nmap -p 445 --script smb-enum-shares {admin_all[0][0]}  "
                    "# noms seulement, pas de lecture de fichiers"
                ),
            )
        )
    elif disks_all:
        findings.append(
            Finding(
                id="usages-partage-disque",
                titre="Partage disque visible sans mot de passe (nom seulement)",
                pourquoi_nuit=(
                    "Un élève, un visiteur ou un poste infecté voit le nom de la porte. "
                    "Notes, devoirs, paie : ça commence souvent comme ça."
                ),
                preuve=str(disks_all[:10]),
                remede_etapes=[
                    "Retirer guest / « Tout le monde ».",
                    "Groupes nominatifs.",
                    "Sortir ce partage du VLAN élèves / invité.",
                ],
                qui_peut="admin parc / prestataire",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote=disks_all[0][0],
                preuve_repro=(
                    f"nmap -p 445 --script smb-enum-shares {disks_all[0][0]}  "
                    "# lecture des noms, on n'entre pas"
                ),
            )
        )
    if serveurs:
        s0 = serveurs[0]
        findings.append(
            Finding(
                id="usages-desserte",
                titre=f"Serveur de desserte : {s0.get('hostname') or s0['ip']} ({', '.join(s0['roles'])})",
                pourquoi_nuit=s0["portee"],
                preuve=blast_sentence(serveurs),
                remede_etapes=[
                    "Traiter cette machine avant la liste des PC.",
                    "VLAN / filtrage : qui a le droit de la joindre.",
                    "Sauvegardes testées, comptes nominatifs, pas de guest.",
                ],
                qui_peut="direction / DSI / prestataire / ÉOH",
                priorite="tout_de_suite",
                gravite=Gravite.HAUTE,
                hote=s0["ip"],
                preuve_repro=(
                    f"nmap -sV -p 88,389,445,2049 {s0['ip']}  "
                    "# empreinte de desserte, pas de login"
                ),
            )
        )

    return {
        "nature": "usages_et_droits",
        "certificat": False,
        "disclaimer": DISCLAIMER,
        "config": cfg,
        "fiche_vide": blank,
        "serveurs_parc": serveurs,
        "portes": [
            {k: v for k, v in p.items() if k != "raw"} | {"raw": (p.get("raw") or "")[:240]}
            for p in portes
        ],
        "pass_done": pass_done,
        "pass_warns": list(pass_warns or []),
        "items": items,
        "compteurs": {
            "observes": sum(1 for i in items if i["statut"] == STATUT_VU),
            "declares": n_declares,
            "signales": n_signales,
            "a_confirmer": n_confirmer,
            "hors": sum(1 for i in items if i["statut"] == STATUT_HORS),
            "serveurs": len(serveurs),
            "portes": len(portes),
        },
        "findings": findings,
        "ecole": ecole,
    }
