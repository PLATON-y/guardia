"""Calibrage 0.4.0 — le scan initial décide des outils passifs à lancer.

Une visite : nmap voit les portes, Guardia enchaîne les programmes Kali
qui savent les lire, s'ils sont installés. Rien d'agressif. Rien d'inventé.
Les absents sont notés pour l'opérateur, pas comme un refus au client.
"""
from __future__ import annotations

import shutil
import subprocess
import time
from dataclasses import dataclass
from typing import Any, Callable

from guardia.core.models import Finding, Gravite, Host, Mission
from guardia.core.texte import legacy_tls_offered, strip_ansi
from guardia.engines.parc_roles import ports_of

MAX_HOTES = 8
TIMEOUT_DEFAUT = 12


@dataclass(frozen=True)
class Probe:
    id: str
    nom: str
    bins: tuple[str, ...]
    ports_any: tuple[int, ...]
    once: bool  # une fois sur le CIDR, pas par hôte
    comment: str
    argv: Callable[[str, str, str, str], list[str]]
    # argv(binaire, ip_or_cidr, iface, url)


def _which(bins: tuple[str, ...]) -> str | None:
    for b in bins:
        p = shutil.which(b)
        if p:
            return p
        for extra in (f"/usr/bin/{b}", f"/usr/sbin/{b}", f"/usr/share/{b}/{b}"):
            if shutil.which(extra) or _is_exe(extra):
                return extra if _is_exe(extra) else shutil.which(extra)
    return None


def _is_exe(path: str) -> bool:
    from pathlib import Path

    p = Path(path)
    try:
        return p.is_file()
    except OSError:
        return False


PROBES: tuple[Probe, ...] = (
    Probe(
        id="arp-scan",
        nom="arp-scan",
        bins=("arp-scan",),
        ports_any=(),
        once=True,
        comment="Inventaire L2 du CIDR. Complète nmap -sn.",
        argv=lambda b, cible, iface, _u: (
            [b, f"--interface={iface}", "--retry=1", "--timeout=400", cible]
            if iface
            else [b, "--localnet", "--retry=1", "--timeout=400"]
        ),
    ),
    Probe(
        id="nbtscan",
        nom="nbtscan",
        bins=("nbtscan",),
        ports_any=(137, 139),
        once=True,
        comment="Noms NetBIOS du parc.",
        argv=lambda b, cible, _i, _u: [b, "-r", cible],
    ),
    Probe(
        id="smb-shares",
        nom="nmap smb-enum-shares",
        bins=("nmap",),
        ports_any=(139, 445),
        once=False,
        comment="Noms de partages, pas de fichiers.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "445",
            "--script", "smb-enum-shares",
            ip,
        ],
    ),
    Probe(
        id="smbclient",
        nom="smbclient -L",
        bins=("smbclient",),
        ports_any=(445,),
        once=False,
        comment="Liste anonyme des partages.",
        argv=lambda b, ip, _i, _u: [b, "-L", f"//{ip}", "-N", "-g"],
    ),
    Probe(
        id="enum4linux",
        nom="enum4linux-ng (shares)",
        bins=("enum4linux-ng", "enum4linux"),
        ports_any=(139, 445),
        once=False,
        comment="Noms et partages. Pas -A, pas de dump.",
        argv=lambda b, ip, _i, _u: (
            [b, ip] if "enum4linux-ng" in b else [b, "-S", "-N", ip]
        ),
    ),
    Probe(
        id="showmount",
        nom="showmount -e",
        bins=("showmount",),
        ports_any=(111, 2049),
        once=False,
        comment="Exports NFS visibles.",
        argv=lambda b, ip, _i, _u: [b, "-e", "--no-headers", ip],
    ),
    Probe(
        id="ldapsearch",
        nom="ldapsearch rootDSE",
        bins=("ldapsearch",),
        ports_any=(389, 636, 3268),
        once=False,
        comment="namingContexts. Pas de dump d'annuaire.",
        argv=lambda b, ip, _i, _u: [
            b, "-x", "-LLL", "-H", f"ldap://{ip}", "-s", "base",
            "namingContexts", "defaultNamingContext", "dnsHostName",
        ],
    ),
    Probe(
        id="snmp-public",
        nom="snmpget public",
        bins=("snmpget", "snmpwalk"),
        ports_any=(161,),
        once=False,
        comment="Communauté public seulement. Lecture sysDescr.",
        argv=lambda b, ip, _i, _u: (
            [b, "-v2c", "-c", "public", "-t", "1", "-r", "0", "-Ovq", ip, "sysDescr.0"]
            if b.endswith("snmpget")
            else [b, "-v2c", "-c", "public", "-t", "1", "-r", "0", "-On", ip, "sysDescr.0"]
        ),
    ),
    Probe(
        id="snmpwalk-system",
        nom="snmpwalk system",
        bins=("snmpwalk",),
        ports_any=(161,),
        once=False,
        comment="Arbre system. Communauté public. Pas d'écriture.",
        argv=lambda b, ip, _i, _u: [
            b, "-v2c", "-c", "public", "-t", "2", "-r", "1", ip, "system",
        ],
    ),
    Probe(
        id="ike-scan",
        nom="ike-scan",
        bins=("ike-scan",),
        ports_any=(500,),
        once=False,
        comment="Handshake IKE. Identifie le concentrateur VPN.",
        argv=lambda b, ip, _i, _u: [b, "--sport=0", ip],
    ),
    Probe(
        id="ssh-audit",
        nom="ssh-audit",
        bins=("ssh-audit",),
        ports_any=(22,),
        once=False,
        comment="Algorithmes SSH visibles.",
        argv=lambda b, ip, _i, _u: [b, "-n", "-t", "8", ip],
    ),
    Probe(
        id="ftp-anon",
        nom="nmap ftp-anon",
        bins=("nmap",),
        ports_any=(21,),
        once=False,
        comment="Anonymous FTP.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "21", "--script", "ftp-anon", ip,
        ],
    ),
    Probe(
        id="smtp-open-relay",
        nom="nmap smtp-open-relay",
        bins=("nmap",),
        ports_any=(25, 587),
        once=False,
        comment="Relais SMTP ouvert — démonstration, pas d'envoi métier.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "25", "--script", "smtp-open-relay", ip,
        ],
    ),
    Probe(
        id="whatweb",
        nom="WhatWeb",
        bins=("whatweb",),
        ports_any=(80, 443, 8080, 8443),
        once=False,
        comment="Empreinte HTTP discrète.",
        argv=lambda b, ip, _i, url: [b, "-a", "1", "--color=never", url or f"http://{ip}"],
    ),
    Probe(
        id="sslscan",
        nom="sslscan",
        bins=("sslscan",),
        ports_any=(443, 8443),
        once=False,
        comment="Ciphers TLS.",
        argv=lambda b, ip, _i, _u: [b, "--no-failed", f"{ip}:443"],
    ),
    Probe(
        id="wafw00f",
        nom="wafw00f",
        bins=("wafw00f",),
        ports_any=(80, 443, 8080),
        once=False,
        comment="Présence d'un WAF.",
        argv=lambda b, ip, _i, url: [b, "-a", url or f"http://{ip}"],
    ),
    Probe(
        id="nuclei-info",
        nom="Nuclei tech/info/tls",
        bins=("nuclei",),
        ports_any=(80, 443, 8080, 8443),
        once=False,
        comment="Templates tech/info/tls. Exploit/RCE exclus.",
        argv=lambda b, ip, _i, url: [
            b, "-u", url or f"http://{ip}",
            "-silent", "-nc",
            "-tags", "tech,info,tls,ssl",
            "-etags", "exploit,rce,lfi,sqli,kev,takeover",
            "-rate-limit", "8", "-c", "4",
        ],
    ),
    Probe(
        id="nikto-info",
        nom="Nikto Tuning 1",
        bins=("nikto",),
        ports_any=(80, 443),
        once=False,
        comment="Fichiers intéressants, 20 s max, URL du mandat de préférence.",
        argv=lambda b, ip, _i, url: [
            b, "-h", url or f"http://{ip}", "-Tuning", "1", "-maxtime", "20",
            "-nointeractive",
        ],
    ),
    Probe(
        id="wpscan",
        nom="WPScan passive",
        bins=("wpscan",),
        ports_any=(80, 443),
        once=False,
        comment="WordPress, enum passive, pas de brute.",
        argv=lambda b, ip, _i, url: [
            b, "--url", url or f"http://{ip}",
            "--plugins-detection", "passive",
            "--disable-tls-checks", "--no-banner",
            "--format", "cli-no-color",
        ],
    ),
    Probe(
        id="testssl",
        nom="testssl.sh",
        bins=("testssl.sh", "testssl"),
        ports_any=(443, 8443),
        once=False,
        comment="Revue TLS rapide, URL du mandat de préférence.",
        argv=lambda b, ip, _i, url: [
            b, "--fast", "--quiet", "--color", "0",
            url or f"https://{ip}",
        ],
    ),
    Probe(
        id="nmap-http",
        nom="nmap http-title / ssl-cert",
        bins=("nmap",),
        ports_any=(80, 443, 8080, 8443),
        once=False,
        comment="Titre HTTP et certificat visibles.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "80,443,8080,8443",
            "--script", "http-title,http-headers,ssl-cert",
            ip,
        ],
    ),
    Probe(
        id="smb-sec",
        nom="nmap smb-security-mode",
        bins=("nmap",),
        ports_any=(445,),
        once=False,
        comment="Signing SMB, dialectes. Pas de dump.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "445",
            "--script", "smb-security-mode,smb-os-discovery,smb-protocols",
            ip,
        ],
    ),
    Probe(
        id="rdp-nla",
        nom="nmap rdp-enum-encryption",
        bins=("nmap",),
        ports_any=(3389,),
        once=False,
        comment="NLA et chiffrement RDP.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "3389",
            "--script", "rdp-enum-encryption,rdp-ntlm-info",
            ip,
        ],
    ),
    Probe(
        id="rpcinfo",
        nom="rpcinfo -p",
        bins=("rpcinfo",),
        ports_any=(111,),
        once=False,
        comment="Portmapper RPC. Pas de dump.",
        argv=lambda b, ip, _i, _u: [b, "-p", ip],
    ),
    Probe(
        id="avahi-browse",
        nom="avahi-browse",
        bins=("avahi-browse",),
        ports_any=(),
        once=True,
        comment="Services mDNS du LAN.",
        argv=lambda b, _c, _i, _u: [b, "-art", "-t"],
    ),
    Probe(
        id="db-info",
        nom="nmap mysql/mssql/redis-info",
        bins=("nmap",),
        ports_any=(1433, 3306, 5432, 6379, 27017),
        once=False,
        comment="Bannières bases. Pas de brute, pas de dump.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "1433,3306,5432,6379,27017",
            "--script", "ms-sql-info,mysql-info,redis-info,mongodb-info",
            ip,
        ],
    ),
    Probe(
        id="ssl-enum",
        nom="nmap ssl-enum-ciphers",
        bins=("nmap",),
        ports_any=(443, 8443),
        once=False,
        comment="Protocoles et ciphers TLS.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "443,8443",
            "--script", "ssl-enum-ciphers",
            ip,
        ],
    ),
    Probe(
        id="dns-axfr",
        nom="nmap dns-zone-transfer",
        bins=("nmap",),
        ports_any=(53,),
        once=False,
        comment="AXFR s'il est ouvert. Lecture.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "53",
            "--script", "dns-zone-transfer",
            ip,
        ],
    ),
    Probe(
        id="ntp-info",
        nom="nmap ntp-info",
        bins=("nmap",),
        ports_any=(123,),
        once=False,
        comment="Bannière NTP.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-sU", "-T3", "-p", "123",
            "--script", "ntp-info",
            ip,
        ],
    ),
    Probe(
        id="vnc-info",
        nom="nmap vnc-info",
        bins=("nmap",),
        ports_any=(5900, 5901),
        once=False,
        comment="VNC : auth visible.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-T3", "-p", "5900,5901",
            "--script", "vnc-info",
            ip,
        ],
    ),
    Probe(
        id="ipmi-version",
        nom="nmap ipmi-version",
        bins=("nmap",),
        ports_any=(623,),
        once=False,
        comment="IPMI / BMC version. Lecture.",
        argv=lambda b, ip, _i, _u: [
            b, "-Pn", "-n", "-sU", "-T3", "-p", "623",
            "--script", "ipmi-version",
            ip,
        ],
    ),
    Probe(
        id="smbmap",
        nom="smbmap",
        bins=("smbmap",),
        ports_any=(445,),
        once=False,
        comment="Noms de partages. Pas de dump.",
        argv=lambda b, ip, _i, _u: [b, "-H", ip],
    ),
    Probe(
        id="onesixtyone",
        nom="onesixtyone public",
        bins=("onesixtyone",),
        ports_any=(161,),
        once=False,
        comment="Communauté public seulement.",
        argv=lambda b, ip, _i, _u: [b, "-c", "public", ip],
    ),
    Probe(
        id="sslyze",
        nom="sslyze",
        bins=("sslyze",),
        ports_any=(443, 8443),
        once=False,
        comment="Revue TLS.",
        argv=lambda b, ip, _i, url: [b, url or f"{ip}:443"],
    ),
    Probe(
        id="curl-headers",
        nom="curl -sI",
        bins=("curl",),
        ports_any=(80, 443, 8080, 8443),
        once=False,
        comment="En-têtes HTTP. User-Agent Guardia. Pas de crawl.",
        argv=lambda b, ip, _i, url: [
            b, "-sI", "-m", "8", "-A",
            "Guardia (Echoes of Hackers; checkup defensif autorise)",
            url or f"http://{ip}",
        ],
    ),
)


def binaire_probe(p: Probe) -> str | None:
    return _which(p.bins)


def _http_url(host: Host, site_url: str) -> str:
    ports = ports_of(host)
    if 443 in ports or 8443 in ports:
        return f"https://{host.ip}"
    if 80 in ports or 8080 in ports:
        return f"http://{host.ip}"
    return (site_url or "").strip()


def plan_calibrage(
    hosts: list[Host],
    *,
    cidr: str = "",
    iface: str = "",
    site_url: str = "",
) -> list[dict[str, Any]]:
    """Décide quoi lancer. N'exécute rien."""
    jobs: list[dict[str, Any]] = []
    seen_once: set[str] = set()
    http_budget = 0
    for p in PROBES:
        bin_ = binaire_probe(p)
        installe = bool(bin_)
        if p.once:
            if p.id in seen_once:
                continue
            seen_once.add(p.id)
            if p.ports_any:
                if not any(ports_of(h) & set(p.ports_any) for h in hosts):
                    continue
            jobs.append(
                {
                    "id": p.id,
                    "nom": p.nom,
                    "cible": cidr or "LAN",
                    "ip": "",
                    "installe": installe,
                    "binaire": bin_ or "",
                    "comment": p.comment,
                    "once": True,
                }
            )
            continue
        n = 0
        for h in hosts:
            if n >= MAX_HOTES:
                break
            ports = ports_of(h)
            if p.ports_any and not (ports & set(p.ports_any)):
                continue
            if p.id in ("nuclei-info", "nikto-info", "wpscan", "wafw00f"):
                if http_budget >= 3:
                    continue
                http_budget += 1
            n += 1
            jobs.append(
                {
                    "id": p.id,
                    "nom": p.nom,
                    "cible": h.ip,
                    "ip": h.ip,
                    "installe": installe,
                    "binaire": bin_ or "",
                    "comment": p.comment,
                    "once": False,
                    "url": _http_url(h, site_url),
                }
            )
    return jobs


def _run(argv: list[str], timeout: int) -> dict[str, Any]:
    try:
        p = subprocess.run(
            argv,
            capture_output=True,
            text=True,
            timeout=timeout,
            check=False,
        )
    except FileNotFoundError:
        return {"ok": False, "extrait": "absent", "rc": 127}
    except subprocess.TimeoutExpired:
        return {"ok": False, "extrait": f"timeout {timeout}s", "rc": -1}
    except OSError as exc:
        return {"ok": False, "extrait": str(exc), "rc": -1}
    out = ((p.stdout or "") + "\n" + (p.stderr or "")).strip()
    return {"ok": p.returncode == 0, "extrait": out[:6000], "rc": p.returncode}


def _finding(iid: str, titre: str, nuit: str, preuve: str, etapes: list[str], hote: str, grav: Gravite) -> Finding:
    return Finding(
        id=iid,
        titre=titre,
        pourquoi_nuit=nuit,
        preuve=strip_ansi(preuve)[:400],
        remede_etapes=etapes,
        qui_peut="Référent IT / prestataire, avec le mandat",
        priorite="cette_semaine" if grav in (Gravite.CRITIQUE, Gravite.HAUTE) else "plus_tard",
        gravite=grav,
        hote=hote,
        preuve_repro=strip_ansi(preuve)[:200],
    )


def _parse(probe_id: str, cible: str, extrait: str) -> list[Finding]:
    low = (extrait or "").lower()
    if not extrait or low in ("absent",) or low.startswith("timeout"):
        return []
    out: list[Finding] = []
    if probe_id in ("smb-shares", "smbclient", "enum4linux"):
        interesting = [
            ln.strip() for ln in extrait.splitlines()
            if ln.strip() and not any(
                n in ln.lower() for n in ("ipc$", "print$", "smb-enum-shares:", "starting", "nmap scan")
            )
            and ("$" in ln or "disk" in ln.lower() or "share" in ln.lower() or "\\\\" in ln or "\t" in ln)
        ]
        if interesting or "admin$" in low or "c$" in low:
            out.append(_finding(
                "cal-smb-shares",
                "Partages de fichiers visibles depuis le réseau",
                "Une session trop large lit ou écrit hors de son rôle.",
                extrait[:300],
                [
                    "Restreindre les partages : plus de « Tout le monde ».",
                    "Masquer ADMIN$ / C$ hors VLAN d'admin.",
                    "Vérifier les ACL du disque métier lundi.",
                ],
                cible,
                Gravite.HAUTE if ("admin$" in low or "c$" in low) else Gravite.MOYENNE,
            ))
    elif probe_id == "showmount" and ("/" in extrait) and "clnt" not in low:
        if any(x.strip().startswith("/") for x in extrait.splitlines()):
            out.append(_finding(
                "cal-nfs",
                "Exports NFS visibles",
                "Un export trop large est un disque ouvert sur le LAN.",
                extrait[:300],
                ["Restreindre showmount aux réseaux d'admin.", "Passer en NFSv4 + Kerberos si le parc le permet."],
                cible,
                Gravite.HAUTE,
            ))
    elif probe_id == "ldapsearch" and ("namingcontext" in low or "dc=" in low):
        out.append(_finding(
            "cal-ldap",
            "Annuaire joignable (rootDSE)",
            "L'annuaire ouvre le parc. S'il répond depuis le LAN métier, trop de monde le voit.",
            extrait[:300],
            [
                "Cantonner LDAP/Kerberos au VLAN d'admin ou aux serveurs membres.",
                "Couper l'anonyme. Garder LDAPS.",
            ],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id == "snmp-public":
        if "timeout" not in low and "no response" not in low and len(extrait.strip()) > 8:
            out.append(_finding(
                "cal-snmp-public",
                "SNMP répond avec la communauté public",
                "Qui lit SNMP lit souvent le nom, le modèle, parfois plus.",
                extrait[:300],
                [
                    "Changer la communauté. Désactiver SNMPv1/v2c si possible.",
                    "SNMPv3, VLAN d'admin.",
                ],
                cible,
                Gravite.HAUTE,
            ))
    elif probe_id == "ftp-anon" and "anonymous" in low and "logged in" in low:
        out.append(_finding(
            "cal-ftp-anon",
            "FTP anonyme ouvert",
            "Sans mot de passe, le dossier FTP est une porte.",
            extrait[:300],
            ["Désactiver anonymous.", "Passer en SFTP, comptes nominatifs."],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id == "smtp-open-relay" and "open relay" in low and "not an open" not in low:
        out.append(_finding(
            "cal-smtp-relay",
            "Relais SMTP ouvert",
            "Un relais ouvert envoie du courrier au nom de la structure.",
            extrait[:300],
            ["Restreindre le relais aux réseaux internes authentifiés.", "Vérifier SPF/DKIM ensuite."],
            cible,
            Gravite.CRITIQUE,
        ))
    elif probe_id == "ike-scan" and ("handshake" in low or "sa=" in low or "vendor" in low):
        out.append(_finding(
            "cal-ike",
            "Concentrateur VPN IKE visible",
            "La porte VPN se voit. À durcir, pas à cacher.",
            extrait[:300],
            ["IKEv2, certificats, plus de PSK faible.", "Filtrer 500/4500 hors besoin."],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "ssh-audit" and ("fail" in low or "warn" in low or "cbc" in low):
        out.append(_finding(
            "cal-ssh",
            "SSH : algorithmes trop anciens",
            "Un SSH trop permissif est une porte d'admin durable.",
            extrait[:300],
            ["Couper les ciphers CBC / SHA-1.", "Clés ed25519, fail2ban ou équivalent."],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "smb-sec" and (
        "message_signing: disabled" in low
        or "message signing: disabled" in low
        or "signing enabled but not required" in low
    ):
        out.append(_finding(
            "cal-smb-signing",
            "SMB : signature non exigée",
            "Sans signing obligatoire, une session peut se faire passer pour le fichier.",
            extrait[:300],
            [
                "Exiger SMB signing (GPO : Microsoft network server: Digitally sign communications).",
                "SMBv1 : le couper partout.",
            ],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id == "rdp-nla" and (
        "nla: false" in low
        or "nla disabled" in low
        or "native rdp" in low
        or "security layer: rdp" in low
    ):
        out.append(_finding(
            "cal-rdp-nla",
            "Bureau à distance sans NLA",
            "RDP sans NLA ouvre une porte d'admin avant même le mot de passe.",
            extrait[:300],
            [
                "Activer NLA (Authentification au niveau du réseau).",
                "Cantonner 3389 au VLAN d'admin ou à un VPN.",
            ],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id in ("testssl", "nmap-http") and (
        "expired" in low or "self signed" in low or "self-signed" in low
        or "not ok" in low and "cert" in low
    ):
        out.append(_finding(
            "cal-tls",
            "Certificat TLS à reprendre",
            "Un certificat périmé ou auto-signé, vu depuis le LAN, casse la confiance.",
            extrait[:300],
            [
                "Renouveler le certificat, ou en poser un (Let's Encrypt / interne).",
                "Couper TLS 1.0 / 1.1 s'ils sont encore offerts.",
            ],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "db-info" and (
        "authentication: disabled" in low
        or "no authentication" in low
        or "unauthorized" in low and "redis" in low
        or "empty password" in low
    ):
        out.append(_finding(
            "cal-db-ouverte",
            "Base de données joignable sans authentification nette",
            "Une base qui répond en clair sur le LAN est un dossier ouvert.",
            extrait[:300],
            [
                "Exiger un mot de passe. Bind localhost ou VLAN métier.",
                "Couper le port depuis le Wi‑Fi invité / les salles.",
            ],
            cible,
            Gravite.CRITIQUE,
        ))
    elif probe_id == "rpcinfo" and ("nfs" in low or "100003" in extrait):
        out.append(_finding(
            "cal-nfs",
            "Exports NFS visibles",
            "Un export trop large est un disque ouvert sur le LAN.",
            extrait[:300],
            ["Restreindre showmount aux réseaux d'admin.", "Passer en NFSv4 + Kerberos si le parc le permet."],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id == "dns-axfr" and ("axfr" in low or "xfr" in low) and "failed" not in low:
        if "soa" in low or "zone" in low:
            out.append(_finding(
                "cal-dns-axfr",
                "Transfert de zone DNS ouvert",
                "AXFR livre le plan d'adressage. À fermer hors serveurs de nom autorisés.",
                extrait[:300],
                ["Interdire AXFR sauf aux secondaires nommés.", "DNS interne : pas depuis le LAN métier."],
                cible,
                Gravite.HAUTE,
            ))
    elif probe_id in ("vnc-info",) and ("none" in low or "no authentication" in low):
        out.append(_finding(
            "cal-vnc",
            "VNC sans authentification nette",
            "Un écran joignable sans mot de passe est une prise de poste.",
            extrait[:300],
            ["Exiger un mot de passe VNC fort, ou couper 5900.", "Cantonner au VLAN d'admin."],
            cible,
            Gravite.CRITIQUE,
        ))
    elif probe_id == "ipmi-version" and ("ipmi" in low or "bmc" in low):
        out.append(_finding(
            "cal-ipmi",
            "IPMI / BMC joignable",
            "La carte d'admin matériel (iLO, iDRAC, IPMI) se voit depuis le LAN.",
            extrait[:300],
            ["VLAN d'admin hors métier.", "IPMI 2.0, plus de cipher 0."],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id == "ssl-enum" and legacy_tls_offered(extrait):
        out.append(_finding(
            "cal-tls",
            "TLS trop ancien offert",
            "SSLv3 / TLS 1.0 encore proposés : à couper.",
            extrait[:300],
            ["N'offrir que TLS 1.2+ (idéalement 1.3).", "Retirer les ciphers CBC / SHA-1."],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "smbmap":
        interesting = [
            ln.strip() for ln in extrait.splitlines()
            if ln.strip() and ("read" in ln.lower() or "write" in ln.lower() or "disk" in ln.lower())
        ]
        if interesting or "admin$" in low:
            out.append(_finding(
                "cal-smb-shares",
                "Partages de fichiers visibles depuis le réseau",
                "Une session trop large lit ou écrit hors de son rôle.",
                extrait[:300],
                [
                    "Restreindre les partages : plus de « Tout le monde ».",
                    "Masquer ADMIN$ / C$ hors VLAN d'admin.",
                ],
                cible,
                Gravite.HAUTE if "write" in low or "admin$" in low else Gravite.MOYENNE,
            ))
    elif probe_id == "onesixtyone" and len(extrait.strip()) > 8 and "timeout" not in low:
        out.append(_finding(
            "cal-snmp-public",
            "SNMP répond avec la communauté public",
            "Qui lit SNMP lit souvent le nom, le modèle, parfois plus.",
            extrait[:300],
            ["Changer la communauté. Désactiver SNMPv1/v2c si possible.", "SNMPv3, VLAN d'admin."],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id in ("snmpwalk-system",) and len(extrait.strip()) > 12 and "timeout" not in low and "no response" not in low:
        out.append(_finding(
            "cal-snmp-public",
            "SNMP répond avec la communauté public",
            "Qui lit SNMP lit souvent le nom, le modèle, parfois plus.",
            extrait[:300],
            ["Changer la communauté. Désactiver SNMPv1/v2c si possible.", "SNMPv3, VLAN d'admin."],
            cible,
            Gravite.HAUTE,
        ))
    elif probe_id in ("sslscan", "sslyze", "testssl") and legacy_tls_offered(extrait):
        out.append(_finding(
            "cal-tls",
            "TLS trop ancien offert",
            "SSLv3 / TLS 1.0 encore proposés : à couper.",
            extrait[:300],
            ["N'offrir que TLS 1.2+ (idéalement 1.3).", "Retirer les ciphers CBC / SHA-1."],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "whatweb" and ("wordpress" in low or "joomla" in low or "drupal" in low):
        out.append(_finding(
            "cal-cms",
            "CMS visible depuis le réseau",
            "Le CMS se présente. À tenir à jour, pas à cacher.",
            extrait[:300],
            ["Mettre à jour le CMS et les extensions.", "Couper les pages d'install / readme."],
            cible,
            Gravite.INFO,
        ))
    elif probe_id == "wafw00f" and ("is behind" in low or "is protected" in low):
        out.append(_finding(
            "cal-waf",
            "Un WAF se présente devant le site",
            "Observation. Un WAF n'est pas une garantie, c'est une couche.",
            extrait[:300],
            ["Garder le WAF. Vérifier les exceptions trop larges."],
            cible,
            Gravite.INFO,
        ))
    elif probe_id in ("nuclei-info", "nikto-info") and (
        "[critical]" in low or "[high]" in low or "osvdb" in low or "cve-2" in low
    ):
        out.append(_finding(
            "cal-http-info",
            "Le site montre des fichiers ou versions intéressantes",
            "Lecture Tuning 1 / templates info. Pas un exploit.",
            extrait[:300],
            ["Retirer les fichiers d'install, les backups, les versions apparentes.", "Tenir le CMS à jour."],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "wpscan" and ("vulnerab" in low or "outdated" in low):
        out.append(_finding(
            "cal-wp",
            "WordPress : version ou extension visible",
            "Enumération passive. Pas de brute.",
            extrait[:300],
            ["Mettre à jour WordPress, thèmes et extensions.", "Masquer wp-login hors VPN si possible."],
            cible,
            Gravite.MOYENNE,
        ))
    elif probe_id == "ntp-info" and ("ntp" in low or "version" in low):
        out.append(_finding(
            "cal-ntp",
            "NTP répond depuis le LAN",
            "Un NTP trop ouvert sert parfois d'amplificateur. Observation.",
            extrait[:300],
            ["Restreindre NTP aux clients internes.", "NTP authentifié si le parc le permet."],
            cible,
            Gravite.BASSE,
        ))
    elif probe_id == "curl-headers" and (
        "server:" in low and ("apache/" in low or "nginx/" in low or "iis/" in low)
    ):
        out.append(_finding(
            "cal-http-banner",
            "Le serveur HTTP se présente avec sa version",
            "Une bannière précise aide un attaquant à choisir son outil. À réduire.",
            extrait[:300],
            ["ServerTokens Prod / server_tokens off.", "Couper les en-têtes X-Powered-By."],
            cible,
            Gravite.BASSE,
        ))
    return out


def run_calibrage(
    hosts: list[Host],
    *,
    cidr: str = "",
    iface: str = "",
    site_url: str = "",
    timeout_total: float = 180.0,
    on_job: Callable[[dict[str, Any]], None] | None = None,
    verbose: bool = True,
    skip_ids: list[str] | None = None,
) -> dict[str, Any]:
    """Lance les probes installées, attache les findings, rend le journal propre."""
    jobs = plan_calibrage(hosts, cidr=cidr, iface=iface, site_url=site_url)
    by_ip = {h.ip: h for h in hosts}
    lances: list[dict[str, Any]] = []
    absents: list[str] = []
    findings_n = 0
    spent = 0.0
    t0 = time.monotonic()
    skip = set(skip_ids or [])

    probes = {p.id: p for p in PROBES}
    seen_absent: set[str] = set()

    for job in jobs:
        p = probes.get(job["id"])
        if p is None:
            continue
        if job.get("id") in skip:
            job["lance"] = False
            job["etat"] = "prune"
            job["extrait"] = "cerveau : branche écartée"
            lances.append(job)
            if verbose:
                print(f"  {p.nom}: prune — cerveau, branche inutile", flush=True)
            if on_job:
                on_job(job)
            continue
        if not job.get("installe"):
            if p.nom not in seen_absent:
                seen_absent.add(p.nom)
                absents.append(p.nom)
                if verbose:
                    print(f"  {p.nom}: absent — on continue", flush=True)
            job["lance"] = False
            job["etat"] = "absent"
            if on_job:
                on_job(job)
            continue
        if spent >= timeout_total:
            job["lance"] = False
            job["extrait"] = "budget calibrage atteint"
            job["etat"] = "budget"
            lances.append(job)
            if verbose:
                print(f"  {p.nom}: budget — on enchaîne", flush=True)
            if on_job:
                on_job(job)
            continue
        to = 20 if job["id"] in ("nuclei-info", "nikto-info", "wpscan", "sslscan", "testssl", "nmap-http", "db-info", "sslyze") else TIMEOUT_DEFAUT
        to = min(to, max(6, int(timeout_total - spent)))
        bin_ = job["binaire"]
        cible = job.get("ip") or cidr
        url = job.get("url") or site_url
        argv = p.argv(bin_, cible or cidr, iface, url)
        result = _run(argv, to)
        spent = time.monotonic() - t0
        job["lance"] = True
        job["rc"] = result.get("rc")
        job["extrait"] = (result.get("extrait") or "")[:800]
        job["commande"] = " ".join(argv)
        etat = "ok" if result.get("ok") else "note"
        job["etat"] = etat
        found = _parse(job["id"], job.get("ip") or cidr, result.get("extrait") or "")
        job["n_findings"] = len(found)
        findings_n += len(found)
        h = by_ip.get(job.get("ip") or "")
        if h is not None:
            for f in found:
                if f not in h.findings:
                    h.findings.append(f)
        lances.append(job)
        if verbose:
            extra = f" · {len(found)} obs." if found else ""
            print(f"  {p.nom} {job.get('cible') or ''}: {etat}{extra}", flush=True)
        if on_job:
            on_job(job)

    return {
        "version": "1.0.0",
        "jobs": jobs,
        "lances": [j for j in lances if j.get("lance")],
        "absents": sorted(set(absents)),
        "n_lances": sum(1 for j in lances if j.get("lance")),
        "n_findings": findings_n,
        "outils": sorted({j["nom"] for j in lances if j.get("lance")}),
    }
