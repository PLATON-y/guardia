"""Fiche opérateur — usages & droits (élèves, équipe, comptes).

Déclarations, pas une preuve d'Active Directory, pas un audit IAM.
Le réseau ne dit pas ce qu'un élève *fait* sur le poste : l'opérateur le pose.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Mission

TRI_CHOICES = ("inconnu", "oui", "non")

USAGES_FIELDS: list[dict[str, str]] = [
    {
        "key": "public",
        "kind": "text",
        "label": "Qui utilise le parc ? (élèves, profs, équipe, mixte…)",
        "help": "Libre. Ça oriente le chapitre, ça n'identifie personne.",
    },
    {
        "key": "comptes_individuels",
        "kind": "tri",
        "label": "Comptes nominatifs (un humain = un compte) ?",
        "help": "Non = sessions « salle 12 », stagiaire, compte atelier — surface partagée.",
    },
    {
        "key": "comptes_partages_salles",
        "kind": "tri",
        "label": "Des sessions / comptes de salle encore en service ?",
        "help": "Typique écoles / salles de formation. Impossible de savoir qui a fait quoi.",
    },
    {
        "key": "users_admin_local",
        "kind": "tri",
        "label": "Les utilisateurs sont-ils administrateurs locaux de leur poste ?",
        "help": "Élève / salarié admin local = ils installent, ils persistent, les droits globaux ne tiennent plus.",
    },
    {
        "key": "vlan_separes",
        "kind": "tri",
        "label": "VLAN / SSID séparés (élèves ou atelier ≠ admin / direction) ?",
        "help": "Sans ça, ce que voit le réseau plat, tout le monde le voit.",
    },
    {
        "key": "wifi_invite",
        "kind": "tri",
        "label": "Wi‑Fi invité isolé (pas le même LAN que les postes métier) ?",
        "help": "Un visiteur sur le métier = les mêmes portes.",
    },
    {
        "key": "usb_libre",
        "kind": "tri",
        "label": "Clés USB / disques externes libres sur les postes ?",
        "help": "Déclaration. Guardia ne lit pas les postes.",
    },
    {
        "key": "partages_ouverts_connus",
        "kind": "tri",
        "label": "Savez-vous si des partages sont ouverts à tout le LAN / guest ?",
        "help": "Oui = vous le savez déjà. Non = à observer (noms de partages, pas les fichiers).",
    },
    {
        "key": "serveur_central",
        "kind": "tri",
        "label": "Une machine dessert-elle les autres (annuaire, fichiers, ENT, impression) ?",
        "help": "C'est souvent LE point. Un trou ici n'est pas « une machine de plus ».",
    },
    {
        "key": "serveur_central_role",
        "kind": "text",
        "label": "Rôle déclaré de cette machine (si connue)",
        "help": "Ex. fichiers, AD / Samba, ENT, impression. Pas de nom de site.",
    },
    {
        "key": "anciens_comptes",
        "kind": "tri",
        "label": "Les comptes des départs (élèves, salariés) sont-ils désactivés ?",
        "help": "Déclaration. Un compte qui reste = une session qui reste.",
    },
    {
        "key": "politique_mdp",
        "kind": "tri",
        "label": "Une politique de mot de passe / expiration est-elle réellement appliquée ?",
        "help": "Pas un dump AD. Oui / non / inconnu.",
    },
]


def empty_config() -> dict[str, Any]:
    out: dict[str, Any] = {}
    for f in USAGES_FIELDS:
        out[f["key"]] = "" if f["kind"] == "text" else "inconnu"
    return out


def _tri(v: Any) -> str:
    if v is True or v == 1:
        return "oui"
    if v is False or v == 0:
        return "non"
    s = str(v or "").strip().lower()
    if s in ("oui", "yes", "true", "1", "o"):
        return "oui"
    if s in ("non", "no", "false", "0", "n"):
        return "non"
    return "inconnu"


def normalize_config(raw: Any) -> dict[str, Any]:
    base = empty_config()
    if not isinstance(raw, dict):
        return base
    kinds = {f["key"]: f["kind"] for f in USAGES_FIELDS}
    for k, v in raw.items():
        if k not in kinds:
            continue
        if kinds[k] == "tri":
            base[k] = _tri(v)
        else:
            base[k] = str(v or "").strip()
    return base


def raw_config_from_mission(mission: Mission) -> dict[str, Any]:
    extras = dict(mission.extras or {})
    raw = extras.get("usages_config")
    if raw is None:
        raw = extras.get("usages_cfg")
    return normalize_config(raw)


def load_usages_config(mission: Mission) -> dict[str, Any]:
    cfg = raw_config_from_mission(mission)
    typ = (mission.type_structure or "").lower()
    profil = (mission.profil_moteur or "").lower()
    if not cfg.get("public"):
        if profil == "ecole" or typ == "ecole":
            cfg["public"] = "élèves / enseignants / admin"
        elif profil == "pme" or typ in ("pme", "parc_entreprise", "association"):
            cfg["public"] = "équipe / direction"
    return cfg


def config_is_blank(cfg: dict[str, Any]) -> bool:
    for f in USAGES_FIELDS:
        k = f["key"]
        if f["kind"] == "tri" and cfg.get(k) not in (None, "", "inconnu"):
            return False
        if f["kind"] == "text" and k != "public" and str(cfg.get(k) or "").strip():
            return False
    return True


def summary_line(cfg: dict[str, Any]) -> str:
    filled: list[str] = []
    for f in USAGES_FIELDS:
        k = f["key"]
        if f["kind"] == "tri" and cfg.get(k) not in (None, "", "inconnu"):
            filled.append(k)
        elif f["kind"] == "text" and k != "public" and str(cfg.get(k) or "").strip():
            filled.append(k)
    if not filled:
        return "fiche vide (tout à inconnu)"
    shown = ", ".join(filled[:8])
    extra = f" (+{len(filled) - 8})" if len(filled) > 8 else ""
    return f"{len(filled)} champ(s) renseigné(s) : {shown}{extra}"


def _yaml_scalar(v: Any) -> str:
    if v is True:
        return "true"
    if v is False:
        return "false"
    if v is None:
        return "null"
    s = str(v)
    if s == "":
        return '""'
    special = set(":#{}[]&*!|>'\"%@`")
    if any(c in s for c in special) or s.lower() in (
        "true", "false", "null", "yes", "no", "on", "off",
    ):
        return '"' + s.replace("\\", "\\\\").replace('"', '\\"') + '"'
    return s


def _splice_usages_block(text: str, cfg: dict[str, Any]) -> str:
    lines = text.splitlines()
    out: list[str] = []
    skip_indent = False
    for line in lines:
        stripped = line.lstrip()
        if skip_indent:
            if line.startswith((" ", "\t")) or not stripped:
                continue
            skip_indent = False
        if stripped.startswith("usages_config:"):
            skip_indent = True
            continue
        if stripped.startswith("usages:") and not stripped.startswith("usages_"):
            continue
        out.append(line)
    while out and out[-1] == "":
        out.pop()
    out.append("usages: true")
    out.append("usages_config:")
    norm = normalize_config(cfg)
    for f in USAGES_FIELDS:
        out.append(f"  {f['key']}: {_yaml_scalar(norm.get(f['key']))}")
    return "\n".join(out) + "\n"


def patch_mission_yaml(path: Any, cfg: dict[str, Any]) -> None:
    from pathlib import Path

    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(str(p))
    try:
        import yaml  # type: ignore
    except ImportError:
        yaml = None
    text = p.read_text(encoding="utf-8")
    if yaml:
        data = yaml.safe_load(text) or {}
        if not isinstance(data, dict):
            raise ValueError(f"mission invalide: {p}")
        data["usages"] = True
        data["usages_config"] = normalize_config(cfg)
        p.write_text(
            yaml.dump(data, allow_unicode=True, sort_keys=False),
            encoding="utf-8",
        )
        return
    p.write_text(_splice_usages_block(text, cfg), encoding="utf-8")
