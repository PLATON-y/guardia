"""Classification heuristique d'équipements (hostname / MAC / ports)."""
from __future__ import annotations

import logging
import re

from guardia.core.models import Host

log = logging.getLogger("guardia.classify")

VENDOR_KIND = [
    (re.compile(r"apple|iphone|ipad", re.I), "phone"),
    (re.compile(r"samsung|xiaomi|huawei|oneplus|google.?pixel", re.I), "phone"),
    (re.compile(r"espressif|tuya|shelly|sonoff|tp-?link.*iot", re.I), "iot"),
    (re.compile(r"hikvision|dahua|axis|reolink|ezviz", re.I), "camera"),
    (re.compile(r"hewlett.?packard|epson|canon|brother|xerox|kyocera", re.I), "imprimante"),
    (re.compile(r"synology|qnap|netgear.*ready|western digital|seagate", re.I), "nas"),
    (re.compile(r"sony|microsoft|nintendo|xbox|playstation", re.I), "console"),
    (re.compile(r"samsung.*(elec|tv)|lg electronics|vizio|roku|chromecast|amazon.?technologies", re.I), "tv"),
    # Matériel réseau (L2/L3) — avant box générique
    (re.compile(r"cisco.*(switch|systems)|catalyst|aruba|juniper|extreme.?networks|hp.*(switch|enterprise|networking)|hpe|procurve|netgear.*(switch|gs|ms)|d-?link.*(switch|dgs)|tplink.*(switch|tl-sg)|zyxel.*(switch)", re.I), "switch"),
    (re.compile(r"ubiquiti|unifi|mikrotik|ruckus|meraki|engenius|openwrt|fortinet|fortigate|sophos|pfsense|opnsense", re.I), "router"),
    (re.compile(r"ubiquiti.*ap|unifi.?ap|access.?point|aruba.?ap|tp-?link.*(eap|omada)|mikrotik.*cap|cisco.*aironet|meraki.?mr", re.I), "ap"),
    (re.compile(r"livebox|freebox|sfr|bbox|cisco|mikrotik|ubiquiti|netgear|asus.*rout|zyxel|huawei.*tech", re.I), "box"),
    (re.compile(r"intel|dell|lenovo|hp inc|asrock|gigabyte|vmware|parallels", re.I), "pc"),
    (re.compile(r"raspberry|odroid", re.I), "iot"),
    (re.compile(r"siemens|schneider|allen-?bradley|rockwell|omron|beckhoff|wago|codesys|phoenix.?contact", re.I), "ot"),
]

HOST_KIND = [
    (re.compile(r"iphone|ipad|android|galaxy|pixel(?:[\s-]?\d|$)", re.I), "phone"),
    (re.compile(r"print|imprimante|laserjet|deskjet", re.I), "imprimante"),
    (re.compile(r"nas|synology|qnap|diskstation", re.I), "nas"),
    (re.compile(r"cam|camera|nvr|dvr", re.I), "camera"),
    (re.compile(r"xbox|playstation|ps[345]|nintendo", re.I), "console"),
    (re.compile(r"bouygtel|chromecast|firestick|apple-?tv|smart-?tv|\btv\b", re.I), "tv"),
    # Matériel réseau / relais
    (re.compile(r"\bswitch\b|catalyst|procurve|tl-sg|dgs-|gs1\d|ms\d{3}", re.I), "switch"),
    (re.compile(r"\bap[-_]|\bwap\b|access.?point|unifi-?ap|eap\d|omada|cap-", re.I), "ap"),
    (re.compile(r"router|gateway|relais|relay|pfsense|opnsense|mikrotik|edge.?router|fortigate", re.I), "router"),
    (re.compile(r"livebox|freebox|bbox|box-", re.I), "box"),
    (re.compile(r"\b(dc[-_]?|pdc|adc[-_]|ad[-_]|srv[-_]|serveur|fileserver|samba|ldap)\b", re.I), "serveur"),
    (re.compile(r"desktop|laptop|pc-|macbook|pixel-?book|chromebook|imac|workstation|win-|ubuntu", re.I), "pc"),
    (re.compile(r"esp32|shelly|tuya|sonoff|hue", re.I), "iot"),
    (re.compile(r"plc|s7-?\d|modbus|opc-?ua|scada|automate", re.I), "ot"),
]

# Ports typiques -> indices
PORT_HINTS = {
    9100: "imprimante",
    515: "imprimante",
    631: "imprimante",
    548: "nas",
    2049: "nas",
    5000: "nas",  # synology DSM souvent
    5001: "nas",
    554: "camera",
    8554: "camera",
    8000: "camera",
    37777: "camera",
    62078: "phone",  # lockdownd iOS
    161: "switch",  # SNMP souvent switch/AP/routeur
    8291: "router",  # WinBox Mikrotik
    502: "ot",
    102: "ot",
    4840: "ot",
    44818: "ot",
    47808: "ot",
    20000: "ot",
}


def classify_host(host: Host, gateway: str = "") -> str:
    """Détermine host.kind et le retourne."""
    try:
        kind = "inconnu"
        blob_v = f"{host.vendor} {host.hostname}"
        for rx, k in HOST_KIND:
            if host.hostname and rx.search(host.hostname):
                kind = k
                break
        if kind == "inconnu":
            for rx, k in VENDOR_KIND:
                if blob_v and rx.search(blob_v):
                    kind = k
                    break
        if kind == "inconnu":
            ports = {int(p.get("port", 0)) for p in host.ports}
            for port, k in PORT_HINTS.items():
                if port in ports:
                    kind = k
                    break
        if gateway and host.ip == gateway:
            # gateway officielle = box (même si vendor switch)
            kind = "box"
        # Annuaire : Kerberos / LDAP / GC → serveur de desserte, pas un poste
        if kind in ("inconnu", "pc"):
            openp = {int(p.get("port", 0) or 0) for p in host.ports}
            if openp & {88, 389, 636, 3268, 3269}:
                kind = "serveur"
        # services web admin sur .1 souvent box
        if kind == "inconnu" and host.ip.endswith(".1"):
            openp = {int(p.get("port", 0)) for p in host.ports}
            if openp & {80, 443, 8080, 8443}:
                kind = "box"
        # SNMP + admin web + vendor réseau → switch plutôt qu'inconnu
        if kind == "inconnu":
            openp = {int(p.get("port", 0)) for p in host.ports}
            vend = (host.vendor or "").lower()
            if 161 in openp and openp & {22, 80, 443, 8080}:
                if any(x in vend for x in ("cisco", "netgear", "hp", "hpe", "d-link", "tp-link", "zyxel", "ubiquiti", "mikrotik")):
                    kind = "switch"
        if kind == "inconnu" and host.kind and host.kind != "inconnu":
            kind = host.kind
        host.kind = kind
        return kind
    except Exception as exc:  # noqa: BLE001
        log.warning("classify %s: %s", host.ip, exc)
        host.kind = host.kind or "inconnu"
        host.errors.append(f"classify: {exc}")
        return host.kind


def classify_all(hosts: list[Host], gateway: str = "") -> None:
    for h in hosts:
        try:
            classify_host(h, gateway=gateway)
        except Exception as exc:  # noqa: BLE001
            h.errors.append(str(exc))
            log.warning("classify_all %s: %s", h.ip, exc)
