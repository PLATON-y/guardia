"""Pistes à explorer — catalogue + matching, PAS des findings.

Le polish LLM reformule ce qui est déjà vu. Ici on *conseille* la suite :
familles de failles selon le type de structure et ce qui est déjà visible
(ports, kinds, fiche usages). Rien n'est inventé comme preuve.

Grande structure : le catalogue est plus large (desserte, admin, OT Ethernet
industriel, impressions, hyperviseurs…). Le LLM, s'il est allumé, priorise
et peut proposer au plus 3 pistes hors catalogue, toujours lecture seule.

La veille (modeles/veille-pistes.yaml) est collée par l'opérateur après un
Grok hors-build — toujours des pistes, jamais des findings.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from guardia.core.models import CheckupResult, Mission
from guardia.core.paths import MODELES


def _taille(mission: Mission, n_hosts: int) -> str:
    t = str((mission.extras or {}).get("taille_parc") or "").lower()
    if t in ("l", "large", "xl", "centaines", "gros", "grande") or n_hosts >= 40:
        return "grande"
    if t in ("m", "moyenne") or n_hosts >= 12:
        return "moyenne"
    return "petite"

# structures : foyer | pme | ecole | organisme | all
# tailles    : petite | moyenne | grande | all
CATALOGUE: list[dict[str, Any]] = [
    {
        "id": "desserte-annuaire",
        "structures": ("pme", "ecole", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Annuaire / Kerberos visible depuis le LAN bureautique",
        "pourquoi": "Si 88/389/636 sont joignables depuis les sessions, un compte faible ouvre tout le parc.",
        "ports_any": (88, 389, 636, 3268, 3269),
        "commande": "nmap -sV -p 88,389,636 {ip}  # empreinte, pas de dump",
        "hors": "Pas de BloodHound, pas de dump NTDS, pas de Kerberoast.",
    },
    {
        "id": "desserte-fichiers",
        "structures": ("pme", "ecole", "organisme", "foyer"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Partages de fichiers (SMB / NFS) trop larges",
        "pourquoi": "Une session élève / salarié / invité qui voit ADMIN$ ou un disque commun lit ou écrit hors de son rôle.",
        "ports_any": (139, 445, 2049, 111),
        "commande": "nmap -p 445 --script smb-enum-shares {ip}  # noms seulement",
        "hors": "Pas de lecture de fichiers, pas de montage.",
    },
    {
        "id": "admin-local-partage",
        "structures": ("pme", "ecole", "organisme"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Même admin local / même mot de passe de service sur plusieurs postes",
        "pourquoi": "Un poste compromis = mouvement latéral. Fréquent en petite PME et en salles de classe.",
        "ports_any": (445, 3389, 5985, 22),
        "commande": "nmap -sV -p 445,3389,5985 {ip}  # surface admin, pas de login",
        "hors": "Pas de spray, pas de pass-the-hash.",
    },
    {
        "id": "rdp-plat",
        "structures": ("pme", "ecole", "organisme"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Bureau à distance (RDP / VNC) à plat sur le LAN",
        "pourquoi": "Session graphique ouverte = prise de poste. En école : salles. En PME : télémaintenance.",
        "ports_any": (3389, 5900, 5800),
        "commande": "nmap -sV -p 3389,5900 {ip}  # présence, pas de login",
        "hors": "Pas de brute-force RDP.",
    },
    {
        "id": "impression-spool",
        "structures": ("pme", "ecole", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Serveur d'impression / spooler exposé",
        "pourquoi": "L'impression dessert tout le monde ; un spooler trop ouvert est un relais de parc.",
        "ports_any": (515, 631, 9100),
        "commande": "nmap -sV -p 515,631,9100 {ip}",
        "hors": "Pas d'envoi de job de test destructeur.",
    },
    {
        "id": "hyperviseur-idrac",
        "structures": ("pme", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Console hors-bande (iLO / iDRAC / IPMI / AMT) sur le VLAN bureau",
        "pourquoi": "Qui tient le BMC tient la machine en dessous de l'OS.",
        "ports_any": (623, 16992, 16993, 5900),
        "kinds_any": ("serveur",),
        "commande": "nmap -sV -p 443,623,16992 {ip}  # console constructeur, pas de login",
        "hors": "Pas de default-password brute.",
    },
    {
        "id": "wsus-sccm",
        "structures": ("pme", "ecole", "organisme"),
        "tailles": ("grande",),
        "titre": "WSUS / SCCM / Intune : qui pousse les mises à jour",
        "pourquoi": "Un relais de patch compromis ou oublié sert du code à tout le parc.",
        "ports_any": (8530, 8531, 445),
        "commande": "nmap -sV -p 8530,8531,445 {ip}  # présence du relais, pas d'auth",
        "hors": "Pas de push de package.",
    },
    {
        "id": "messagerie-onprem",
        "structures": ("pme", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Messagerie on-prem (IMAP/SMTP/EWS) joignable du LAN",
        "pourquoi": "Boîte partagée, relais ouvert, autodiscover interne.",
        "ports_any": (25, 110, 143, 587, 993, 995),
        "commande": "nmap -sV -p 25,143,587,993 {ip}  # bannière, pas d'envoi",
        "hors": "Pas d'envoi de mail, pas de lecture de BAL.",
    },
    {
        "id": "base-donnees",
        "structures": ("pme", "organisme", "ecole"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Moteur de données (SQL / Postgres / Redis / ES) vu du LAN métier",
        "pourquoi": "Datastore joignable = données élèves / clients / paie à un clic d'une session.",
        "ports_any": (1433, 1521, 3306, 5432, 6379, 9200, 27017),
        "commande": "nmap -sV -p 1433,3306,5432,6379,9200 {ip}  # présence, pas de dump",
        "hors": "Pas de SELECT, pas de dump.",
    },
    {
        "id": "wifi-invite-pont",
        "structures": ("pme", "ecole", "organisme", "foyer"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Wi‑Fi invité / salles qui pontent vers le LAN interne",
        "pourquoi": "VLAN séparé déclaré, mais la box ou l'AP route quand même.",
        "kinds_any": ("ap", "box", "router"),
        "commande": "nmap -sn {cidr}  # inventaire ; la fiche usages dit si le VLAN est séparé",
        "hors": "Pas de cassage Wi‑Fi, pas de deauth.",
    },
    {
        "id": "comptes-salles",
        "structures": ("ecole",),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Comptes salles / prof partagés encore valides",
        "pourquoi": "Un mot de passe au tableau = session enseignante pour n'importe qui.",
        "ports_any": (88, 389, 445),
        "commande": "observation portes (smb-enum-shares, ldap-rootDSE) — pas les identités",
        "hors": "Pas d'enum users, pas de dump élèves.",
        "always_if_structure": True,
    },
    {
        "id": "anciens-comptes",
        "structures": ("pme", "ecole", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Anciens comptes (stagiaires, élèves partis, prestataires)",
        "pourquoi": "Compte oublié = porte nominative qui n'a plus de titulaire.",
        "fiche": "anciens_comptes",
        "commande": "fiche usages (déclaration) — Guardia ne liste pas les identités",
        "hors": "Pas d'enum AD.",
    },
    {
        "id": "ot-it-plat",
        "structures": ("pme", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Automates / IHM (Ethernet industriel) sur le même LAN que le bureau",
        "pourquoi": "Modbus TCP, S7, OPC-UA, EtherNet/IP, Profinet joignables = arrêt machine depuis une session bureautique.",
        "ports_any": (102, 502, 4840, 44818, 2222, 34962, 34964, 2404, 20000),
        "commande": "nmap -sV -p 102,502,4840,44818,34962 {ip}  # Ethernet industriel, pas d'écriture automate",
        "hors": "Pas d'écriture registre, pas de téléchargement de programme PLC.",
    },
    {
        "id": "vpn-concentre",
        "structures": ("pme", "organisme"),
        "tailles": ("moyenne", "grande"),
        "titre": "Concentrateur VPN / accès distant sur le LAN scanné",
        "pourquoi": "Un VPN mal segmenté pose l'extérieur dans le VLAN desserte.",
        "ports_any": (1194, 1723, 4500, 500, 443),
        "kinds_any": ("box", "router", "firewall"),
        "commande": "nmap -sV -p 443,1194,1723 {ip}  # présence, pas de login VPN",
        "hors": "Pas de tentative d'auth VPN.",
    },
    {
        "id": "sauvegarde",
        "structures": ("pme", "ecole", "organisme", "foyer"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "NAS / cible de sauvegarde joignable en écriture trop large",
        "pourquoi": "Qui écrit la sauvegarde peut aussi l'effacer. En grande structure : une cible, tout le parc.",
        "ports_any": (445, 2049, 548, 873),
        "kinds_any": ("nas", "serveur"),
        "commande": "nmap -sV -p 445,2049,873 {ip}  # desserte backup, pas de montage",
        "hors": "Pas de lecture des archives.",
    },
    {
        "id": "k8s-api",
        "structures": ("pme", "organisme"),
        "tailles": ("grande",),
        "titre": "API cluster (Kubernetes / Docker) vue du LAN",
        "pourquoi": "API 6443 / 2375 sans réseau d'admin = prestataire ou stagiaire pilote les conteneurs.",
        "ports_any": (2375, 2376, 6443, 8443, 10250),
        "commande": "nmap -sV -p 2375,6443,10250 {ip}  # présence API, pas de kubectl",
        "hors": "Pas d'exec dans un pod.",
    },
    {
        "id": "certificats-adcs",
        "structures": ("pme", "organisme"),
        "tailles": ("grande",),
        "titre": "Autorité de certification interne (AD CS) visible",
        "pourquoi": "Modèles de certificats trop permissifs = impersonation de machine.",
        "ports_any": (88, 445),
        "commande": "nmap -sV -p 88,445 {ip}  # desserte ; modèles = avenant, pas Guardia",
        "hors": "Pas d'ESC1/ESC8, pas d'enrollment.",
    },
    {
        "id": "site-web-prod",
        "structures": ("pme", "organisme", "ecole"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Site public : TLS, cookies, mentions, traceurs",
        "pourquoi": "Vitrine et formulaires. Signalement RGPD à part, pas un certificat.",
        "always_if_site": True,
        "commande": "module --site (en-têtes / TLS)",
        "hors": "Pas de scanner vuln, pas de fuzzing.",
    },
    {
        "id": "usb-salles",
        "structures": ("ecole", "pme"),
        "tailles": ("petite", "moyenne", "grande"),
        "titre": "Clés USB libres sur postes salles / accueil",
        "pourquoi": "Droit d'exécution amovible = logiciel non inventorié.",
        "fiche": "usb_libre",
        "commande": "fiche usages (déclaration) + observation physique",
        "hors": "Pas d'analyse forensics de clé.",
    },
    {
        "id": "shadow-it",
        "structures": ("pme", "organisme"),
        "tailles": ("grande",),
        "titre": "SaaS / shadow IT hors inventaire (partages cloud, télémaintenance)",
        "pourquoi": "Une grande structure a des outils que l'IT n'a pas mandaté. Guardia ne les voit que s'ils écoutent sur le LAN.",
        "commande": "inventaire humain + ports inattendus 443/22 sur postes",
        "hors": "Pas d'interception HTTPS.",
    },
]


def _as_tuple(val: Any) -> tuple[str, ...]:
    if val is None:
        return ()
    if isinstance(val, (list, tuple)):
        return tuple(str(x).strip() for x in val if str(x).strip())
    s = str(val).strip()
    if not s:
        return ()
    if "," in s:
        return tuple(p.strip() for p in s.split(",") if p.strip())
    return (s,)


def _as_ports(val: Any) -> tuple[int, ...]:
    out: list[int] = []
    if val is None:
        return ()
    seq = val if isinstance(val, (list, tuple)) else str(val).split(",")
    for x in seq:
        try:
            n = int(x)
        except (TypeError, ValueError):
            continue
        if 0 < n < 65536:
            out.append(n)
    return tuple(out)


def coerce_piste(raw: Any, *, source: str = "veille") -> dict[str, Any] | None:
    """Une entrée de veille / extra mission → même forme que le catalogue."""
    if not isinstance(raw, dict):
        return None
    pid = str(raw.get("id") or "").strip().lower().replace(" ", "-")
    titre = str(raw.get("titre") or "").strip()
    if not pid or not titre:
        return None
    if pid.startswith("audit-") or pid.startswith("usages-") or pid.startswith("ot-finding"):
        # ids de findings — on refuse, une piste n'est pas un finding
        return None
    commande = str(raw.get("commande") or "").strip()
    low = commande.lower()
    banned = ("msf", "exploit", "burp", "sqlmap", "hydra", "hashcat", "bloodhound", "mimikatz")
    if any(b in low for b in banned):
        return None
    return {
        "id": pid,
        "structures": _as_tuple(raw.get("structures")) or ("all",),
        "tailles": _as_tuple(raw.get("tailles")) or ("all",),
        "titre": titre,
        "pourquoi": str(raw.get("pourquoi") or "").strip(),
        "ports_any": _as_ports(raw.get("ports_any")),
        "kinds_any": _as_tuple(raw.get("kinds_any")),
        "fiche": str(raw.get("fiche") or "").strip(),
        "commande": commande,
        "hors": str(raw.get("hors") or "Lecture seule. Pas d'exploit.").strip(),
        "always_if_site": bool(raw.get("always_if_site")),
        "always_if_structure": bool(raw.get("always_if_structure")),
        "_source": source,
    }


def _read_veille_file(path: Path) -> list[Any]:
    if not path.is_file():
        return []
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return []
    data: Any = None
    if path.suffix.lower() == ".json" or path.name.endswith(".json"):
        try:
            data = json.loads(text)
        except json.JSONDecodeError:
            return []
    else:
        try:
            import yaml  # type: ignore

            data = yaml.safe_load(text)
        except Exception:
            return []
    if isinstance(data, list):
        return data
    if isinstance(data, dict):
        block = data.get("pistes") or data.get("items") or []
        return block if isinstance(block, list) else []
    return []


def load_veille_catalog(extra: Any = None) -> list[dict[str, Any]]:
    """Veille association (fichier) + extra mission. Soft-fail."""
    raw: list[Any] = []
    raw.extend(_read_veille_file(MODELES / "veille-pistes.yaml"))
    raw.extend(_read_veille_file(MODELES / "veille-pistes.json"))
    if isinstance(extra, list):
        raw.extend(extra)
    elif isinstance(extra, dict) and isinstance(extra.get("pistes"), list):
        raw.extend(extra["pistes"])
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for item in raw:
        entry = coerce_piste(item, source="veille")
        if not entry or entry["id"] in seen:
            continue
        seen.add(entry["id"])
        out.append(entry)
    return out


def catalogue_effectif(extra: Any = None) -> list[dict[str, Any]]:
    """Catalogue interne + veille, ids internes d'abord."""
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for src, source in ((CATALOGUE, "catalogue"), (load_veille_catalog(extra), "veille")):
        for entry in src:
            eid = str(entry.get("id") or "")
            if not eid or eid in seen:
                continue
            seen.add(eid)
            item = dict(entry)
            item.setdefault("_source", source)
            out.append(item)
    return out



def _ports_of(host) -> set[int]:
    out: set[int] = set()
    for p in host.ports or []:
        try:
            n = int(p.get("port") or 0)
        except (TypeError, ValueError):
            continue
        if n:
            out.add(n)
    return out


def _finding_ids(result: CheckupResult) -> set[str]:
    ids: set[str] = set()
    for h in result.hosts or []:
        for f in h.findings or []:
            if f.id:
                ids.add(f.id)
    for block_name in ("usages", "rgpd", "website", "machines", "restructure"):
        block = getattr(result, block_name, None) or {}
        for f in block.get("findings") or []:
            fid = f.get("id") if isinstance(f, dict) else getattr(f, "id", "")
            if fid:
                ids.add(str(fid))
    return ids


def _covered(entry: dict[str, Any], fids: set[str]) -> bool:
    eid = entry["id"]
    hints = {
        "desserte-annuaire": ("usages-desserte",),
        "desserte-fichiers": ("usages-admin-share", "usages-partage-disque"),
        "rdp-plat": ("audit-remote-3389", "audit-remote-5900", "net-ecole-rdp"),
        "ot-it-plat": ("ot-",),
        "site-web-prod": ("web-",),
        "base-donnees": ("audit-db-",),
    }
    for h in hints.get(eid, ()):
        if any(i == h or i.startswith(h) for i in fids):
            return True
    return False


def _structure(mission: Mission) -> str:
    p = (mission.profil_moteur or "").lower()
    t = (mission.type_structure or "").lower()
    if p == "ecole" or t in ("ecole", "fac", "universite", "université"):
        return "ecole"
    if t in ("organisme", "association", "collectivite", "sante", "caserne", "pompiers"):
        return "organisme"
    if p == "pme" or t in ("pme", "parc_entreprise", "grande", "eti", "industrie", "industriel", "tpe", "msp"):
        return "pme"
    return "foyer"


def _structure_tags(mission: Mission) -> set[str]:
    """Tags de matching : primaire + type brut + alias (fac, industrie…)."""
    primary = _structure(mission)
    t = (mission.type_structure or "").lower()
    p = (mission.profil_moteur or "").lower()
    tags = {primary, "all"}
    if t:
        tags.add(t)
    if p:
        tags.add(p)
    if primary == "ecole":
        tags.update({"ecole", "fac"})
    if primary == "pme":
        tags.update({"pme", "tpe", "grande", "industrie"})
    if primary == "organisme":
        tags.update({"organisme", "association", "collectivite", "sante", "caserne"})
    extras = mission.extras or {}
    if str(extras.get("taille_parc") or "").lower() in ("l", "large", "xl", "grande", "gros"):
        tags.add("grande")
    return {x for x in tags if x}


def build_pistes(result: CheckupResult) -> dict[str, Any]:
    m = result.mission
    hosts = result.hosts or []
    n = len(hosts)
    taille = _taille(m, n)
    struct = _structure(m)
    fids = _finding_ids(result)
    all_ports: set[int] = set()
    kinds: set[str] = set()
    for h in hosts:
        all_ports |= _ports_of(h)
        if h.kind:
            kinds.add(h.kind)
    extras = m.extras or {}
    fiche = extras.get("usages_config") if isinstance(extras.get("usages_config"), dict) else {}
    has_site = bool((result.website or {}).get("url") or (result.plan or {}).get("site_url"))
    tags = _structure_tags(m)
    catalog = catalogue_effectif(extras.get("pistes_extra"))

    items: list[dict[str, Any]] = []
    for entry in catalog:
        structs = entry.get("structures") or ("all",)
        tailles = entry.get("tailles") or ("all",)
        if "all" not in structs and not (set(structs) & tags):
            continue
        if "all" not in tailles and taille not in tailles:
            continue

        ports_need = set(entry.get("ports_any") or ())
        kinds_need = set(entry.get("kinds_any") or ())
        vu_ports = sorted(all_ports & ports_need) if ports_need else []
        vu_kinds = sorted(kinds & kinds_need) if kinds_need else []
        fiche_key = entry.get("fiche")
        fiche_val = str(fiche.get(fiche_key) or "") if fiche_key else ""
        always_site = bool(entry.get("always_if_site")) and has_site
        always_struct = bool(entry.get("always_if_structure"))

        visible = bool(vu_ports or vu_kinds or always_site or (fiche_key and fiche_val in ("oui", "non")))
        # grande : on liste même sans preuve, comme piste à confirmer
        if not visible and taille != "grande" and not always_site and not always_struct:
            if fiche_key and not fiche_val:
                # déclaration manquante → à confirmer
                pass
            elif not ports_need and not kinds_need and not fiche_key:
                pass
            else:
                continue

        if entry.get("always_if_site") and not has_site and taille != "grande":
            continue

        covered = _covered(entry, fids)
        if visible and (vu_ports or vu_kinds or always_site):
            statut = "déjà vu" if covered else "indices sur le LAN"
            priorite = "cette_semaine" if not covered else "plus_tard"
        elif taille == "grande":
            statut = "à explorer (grande structure)"
            priorite = "plus_tard"
        else:
            statut = "à confirmer"
            priorite = "plus_tard"

        preuve = []
        if vu_ports:
            preuve.append("ports : " + ", ".join(str(x) for x in vu_ports))
        if vu_kinds:
            preuve.append("kinds : " + ", ".join(vu_kinds))
        if fiche_key and fiche_val:
            preuve.append(f"fiche usages.{fiche_key}={fiche_val}")
        if always_site:
            preuve.append("module site demandé")
        if not preuve:
            preuve.append("pas d'indice LAN pour l'instant — catalogue seulement")

        items.append(
            {
                "id": entry["id"],
                "titre": entry["titre"],
                "pourquoi": entry["pourquoi"],
                "statut": statut,
                "priorite": priorite,
                "indices": " ; ".join(preuve),
                "commande": entry.get("commande") or "",
                "hors": entry.get("hors") or "",
                "source": entry.get("_source") or "catalogue",
            }
        )

    # tri : indices d'abord
    order = {"indices sur le LAN": 0, "déjà vu": 1, "à confirmer": 2, "à explorer (grande structure)": 3}
    items.sort(key=lambda x: (order.get(x["statut"], 9), x["titre"]))

    return {
        "disclaimer": (
            "Pistes à explorer — ce ne sont PAS des findings. "
            "Pas de preuve d'incident. Pas d'exploit."
        ),
        "structure": struct,
        "taille": taille,
        "items": items,
        "compteurs": {
            "catalogue": len(items),
            "indices": sum(1 for i in items if i["statut"] == "indices sur le LAN"),
            "conseil_llm": 0,
            "veille": sum(1 for i in items if i.get("source") == "veille"),
        },
    }


def merge_llm_pistes(block: dict[str, Any], extra: list[dict[str, Any]]) -> dict[str, Any]:
    """Ajoute des pistes LLM déjà validées (ids conseil-*)."""
    items = list(block.get("items") or [])
    seen = {i.get("id") for i in items}
    added = 0
    for it in extra:
        iid = str(it.get("id") or "")
        if not iid or iid in seen:
            continue
        items.append(it)
        seen.add(iid)
        added += 1
    block = dict(block)
    block["items"] = items
    c = dict(block.get("compteurs") or {})
    c["conseil_llm"] = int(c.get("conseil_llm") or 0) + added
    block["compteurs"] = c
    return block
