"""Moteurs défensifs Guardia."""
