"""Cartographie défensive des observations par couches OSI (L1–L7).

Lecture seule. Pas de scan inventé : on étiquette ce que Guardia voit déjà
(iface, ARP/MAC, CIDR/routes, ports, bannières/TLS/HTTP/SMB/OT).
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Host

# Ports → couches applicatives / session / présentation (défensif)
HTTP_PORTS = {80, 81, 443, 8000, 8080, 8443, 8888, 3000}
TLS_PORTS = {443, 8443, 993, 995, 636, 990}
SMB_PORTS = {139, 445}
RDP_PORTS = {3389, 5900}
OT_PORTS = {102, 502, 4840, 44818, 34962}
LDAP_PORTS = {389, 636}
DNS_PORTS = {53}
SSH_PORTS = {22}

LAYER_LABELS = {
    "L1": "Physique / interface (indice local)",
    "L2": "Liaison (MAC, ARP, voisinage)",
    "L3": "Réseau (CIDR, routes, passerelles)",
    "L4": "Transport (ports TCP/UDP)",
    "L5": "Session (indices protocole)",
    "L6": "Présentation (TLS, certificats)",
    "L7": "Application (HTTP, SMB, bannières, OT lecture)",
}


def _ports_of(h: Host | dict[str, Any]) -> list[int]:
    raw = h.ports if isinstance(h, Host) else (h.get("ports") or [])
    out: list[int] = []
    for p in raw or []:
        if isinstance(p, dict):
            try:
                n = int(p.get("port") or 0)
            except (TypeError, ValueError):
                continue
        else:
            try:
                n = int(p)
            except (TypeError, ValueError):
                continue
        if n:
            out.append(n)
    return out


def layers_for_host(
    host: Host | dict[str, Any],
    *,
    iface: str = "",
    gateway: str = "",
    cidr: str = "",
) -> list[str]:
    """Couches OSI touchées pour un hôte (observations déjà présentes)."""
    layers: set[str] = set()
    if isinstance(host, Host):
        mac = host.mac or ""
        vendor = host.vendor or ""
        notes = list(host.notes or [])
        kind = host.kind or ""
    else:
        mac = str(host.get("mac") or "")
        vendor = str(host.get("vendor") or "")
        notes = list(host.get("notes") or [])
        kind = str(host.get("kind") or "")

    if iface:
        layers.add("L1")
    if mac or vendor or any("ARP" in n or "NetBIOS" in n or "mDNS" in n for n in notes):
        layers.add("L2")
    if kind in ("ap", "switch", "box", "router"):
        layers.add("L2")
        if kind in ("box", "router"):
            layers.add("L3")
    if cidr or gateway:
        layers.add("L3")
    ports = _ports_of(host)
    if ports:
        layers.add("L4")
    for port in ports:
        if port in TLS_PORTS:
            layers.update({"L5", "L6", "L7"})
        if port in HTTP_PORTS:
            layers.update({"L5", "L7"})
        if port in SMB_PORTS or port in RDP_PORTS or port in LDAP_PORTS:
            layers.update({"L5", "L7"})
        if port in OT_PORTS:
            layers.update({"L5", "L7"})
        if port in DNS_PORTS or port in SSH_PORTS:
            layers.update({"L5", "L7"})
        # bannières / product dans ports
    raw_ports = host.ports if isinstance(host, Host) else (host.get("ports") or [])
    for p in raw_ports or []:
        if not isinstance(p, dict):
            continue
        if p.get("product") or p.get("version") or p.get("extrainfo") or p.get("name"):
            layers.add("L7")
            if (p.get("name") or "").lower() in ("ssl", "https", "tls"):
                layers.add("L6")
    return sorted(layers, key=lambda x: int(x[1:]))


def layers_for_event(event: dict[str, Any]) -> list[str]:
    """Étiquette un événement cerveau par couches OSI."""
    typ = str(event.get("type") or "")
    port = int(event.get("port") or 0)
    layers: set[str] = set()
    if typ in ("scope",):
        layers.add("L3")
    if typ in ("host_discovered",):
        layers.update({"L2", "L3"})
    if typ in ("port_open", "dns_seen"):
        layers.add("L4")
    if typ in ("tls_seen",):
        layers.update({"L4", "L5", "L6", "L7"})
    if typ in ("http_seen", "smb_seen", "rdp_seen", "ldap_seen", "ot_seen", "exposed_admin_service"):
        layers.update({"L4", "L5", "L7"})
        if typ == "http_seen" and port in TLS_PORTS:
            layers.add("L6")
    if typ in ("url_mandatee",):
        layers.update({"L6", "L7"})
    if port:
        layers.add("L4")
        if port in TLS_PORTS:
            layers.update({"L5", "L6", "L7"})
        if port in HTTP_PORTS | SMB_PORTS | OT_PORTS | LDAP_PORTS | RDP_PORTS:
            layers.update({"L5", "L7"})
    return sorted(layers, key=lambda x: int(x[1:]))


def attach_host_osi(
    hosts: list[Host],
    *,
    iface: str = "",
    gateway: str = "",
    cidr: str = "",
) -> None:
    """Attache ``osi_layers`` sur chaque Host (in-place)."""
    for h in hosts or []:
        layers = layers_for_host(h, iface=iface, gateway=gateway, cidr=cidr)
        h.osi_layers = layers


def tag_events(events: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Ajoute ``osi_layers`` sur chaque événement (copie shallow)."""
    out: list[dict[str, Any]] = []
    for ev in events or []:
        e = dict(ev)
        e["osi_layers"] = layers_for_event(e)
        out.append(e)
    return out


def couverture_osi(
    hosts: list[Host] | None = None,
    events: list[dict[str, Any]] | None = None,
    *,
    iface: str = "",
    gateway: str = "",
    cidr: str = "",
    website: dict[str, Any] | None = None,
    rgpd: dict[str, Any] | None = None,
) -> dict[str, Any]:
    """Résumé « Couverture OSI » : couches touchées / lacunes.

    Vouvoiement pour libellés client-facing.
    """
    touched: set[str] = set()
    detail: dict[str, list[str]] = {k: [] for k in LAYER_LABELS}

    if iface:
        touched.add("L1")
        detail["L1"].append(f"Interface locale observée : {iface}")
    if gateway:
        touched.add("L3")
        detail["L3"].append(f"Passerelle : {gateway}")
    if cidr:
        touched.add("L3")
        detail["L3"].append(f"CIDR du mandat / détecté : {cidr}")

    for h in hosts or []:
        layers = getattr(h, "osi_layers", None) or layers_for_host(
            h, iface=iface, gateway=gateway, cidr=cidr
        )
        for ly in layers:
            touched.add(ly)
            tip = h.ip + (f" ({h.hostname})" if h.hostname else "")
            if tip not in detail[ly]:
                detail[ly].append(tip)

    for ev in events or []:
        for ly in ev.get("osi_layers") or layers_for_event(ev):
            touched.add(ly)
            why = f"{ev.get('type')} @ {ev.get('asset')}:{ev.get('port') or '—'}"
            if why not in detail[ly]:
                detail[ly].append(why)

    if website:
        touched.update({"L6", "L7"})
        detail["L6"].append("Contrôle TLS / certificat (site mandaté)")
        detail["L7"].append("Audit web lecture (en-têtes, cookies)")
    if rgpd:
        touched.add("L7")
        detail["L7"].append("Signalement RGPD (observé / déclaré — pas un certificat)")

    all_layers = [f"L{i}" for i in range(1, 8)]
    gaps = [ly for ly in all_layers if ly not in touched]
    resume = (
        "Couches touchées : "
        + (", ".join(sorted(touched, key=lambda x: int(x[1:]))) or "aucune")
        + ". Lacunes : "
        + (", ".join(gaps) if gaps else "aucune (dans le périmètre observé)")
        + ". Ceci décrit la couverture d'observation défensive, pas une conformité."
    )
    return {
        "titre": "Couverture OSI",
        "couches_touchees": sorted(touched, key=lambda x: int(x[1:])),
        "lacunes": gaps,
        "detail": {k: v for k, v in detail.items() if v},
        "labels": {k: LAYER_LABELS[k] for k in all_layers},
        "resume": resume,
        "disclaimer": (
            "Cartographie défensive des observations Guardia. "
            "Ce n'est ni une qualification ANSSI, ni un certificat CNIL/RGPD."
        ),
    }


def next_layer_propositions(
    events: list[dict[str, Any]],
    *,
    budget_left: int = 10,
) -> list[dict[str, Any]]:
    """Propositions parcimonieuses de couche suivante (après préconditions validées).

    Ex. L4:443 → TLS+web ; L4:445 → SMB hygiène ; OT → machines lecture ; URL → web+rgpd.
    """
    props: list[dict[str, Any]] = []
    seen: set[str] = set()
    types = {str(e.get("type") or "") for e in events or []}

    def _add(key: str, layer: str, outil: str, why: str) -> None:
        if key in seen or len(props) >= budget_left:
            return
        seen.add(key)
        props.append(
            {
                "id": key,
                "layer": layer,
                "outil": outil,
                "why": why,
                "status": "proposed",
            }
        )

    if "tls_seen" in types or "http_seen" in types:
        _add("next-tls-web", "L6-L7", "web_audit", "Port web/TLS vu → contrôle TLS et en-têtes HTTP (lecture)")
    if "smb_seen" in types:
        _add("next-smb", "L7", "hygiene/smb_read", "Port SMB vu → hygiène SMB lecture (pas d'exploit)")
    if "ot_seen" in types:
        _add("next-ot", "L7", "machines", "Ports OT vus → inventaire OT lecture seule")
    if "url_mandatee" in types:
        _add("next-web-rgpd", "L7", "web_audit+rgpd_signal", "URL au mandat → audit web + signalement RGPD")
    if "rdp_seen" in types or "exposed_admin_service" in types:
        _add("next-admin", "L7", "admin_surface", "Surface admin vue → empreinte HTTP passive")
    if "ldap_seen" in types:
        _add("next-ldap", "L7", "identites", "LDAP vu → lecture identité (BloodHound derrière avenant)")
    return props


# --- Surfaces non protégées (lecture) + vision full L1–L7 ---

_CLEARTEXT_PORTS = {21, 23, 69, 80, 110, 143, 161, 512, 513, 514}
_ADMIN_PORTS = {22, 23, 135, 139, 445, 3389, 5900, 5901, 8291, 8080, 8443, 9443}
_DATASTORE_PORTS = {1433, 3306, 5432, 6379, 27017, 9200}


def surfaces_non_protegees(hosts: list[Host] | None = None) -> list[dict[str, Any]]:
    """Liste des surfaces exposées / faibles observées (pas d'entrée, pas d'auth bypass)."""
    out: list[dict[str, Any]] = []
    for h in hosts or []:
        ip = h.ip
        for p in h.ports or []:
            if not isinstance(p, dict):
                continue
            try:
                num = int(p.get("port") or 0)
            except (TypeError, ValueError):
                continue
            if not num:
                continue
            name = str(p.get("name") or "")
            product = str(p.get("product") or "")
            scripts = p.get("scripts") or {}
            blob = " ".join(
                [name, product, str(p.get("version") or "")]
                + ([f"{k} {v}" for k, v in scripts.items()] if isinstance(scripts, dict) else [])
            ).lower()
            kinds: list[str] = []
            layers: list[str] = ["L4"]
            if num in _CLEARTEXT_PORTS or name.lower() in ("telnet", "ftp", "http"):
                kinds.append("protocole_clair_ou_faible")
                layers.extend(["L5", "L7"])
            if num in _ADMIN_PORTS:
                kinds.append("admin_expose")
                layers.append("L7")
            if num in _DATASTORE_PORTS:
                kinds.append("datastore_expose")
                layers.append("L7")
            if num in TLS_PORTS or "tls" in blob or "ssl" in blob:
                layers.append("L6")
                if any(x in blob for x in ("tlsv1.0", "tls 1.0", "tlsv1.1", "sslv3", "ssl 3")):
                    kinds.append("tls_faible")
            if num in SMB_PORTS and any(x in blob for x in ("smb1", "smbv1", "signing: disabled", "message_signing: disabled")):
                kinds.append("smb_hygiene_faible")
                layers.append("L7")
            if num in OT_PORTS:
                kinds.append("ot_lecture")
                layers.append("L7")
            if not kinds:
                continue
            out.append(
                {
                    "hote": ip,
                    "hostname": h.hostname or "",
                    "port": num,
                    "service": name or product or "tcp",
                    "kinds": kinds,
                    "osi_layers": sorted(set(layers), key=lambda x: int(x[1:]) if x[1:].isdigit() else 99),
                    "lecture_seule": True,
                    "note": "Surface observée en lecture — aucune authentification forcée, aucune entrée.",
                }
            )
    return out


def vision_osi_full(
    hosts: list[Host] | None = None,
    *,
    iface: str = "",
    gateway: str = "",
    cidr: str = "",
    website: dict[str, Any] | None = None,
    rgpd: dict[str, Any] | None = None,
    cve_correlation: dict[str, Any] | None = None,
    events: list[dict[str, Any]] | None = None,
    mode_full: bool = False,
) -> dict[str, Any]:
    """Vision large L1–L7 : couverture + lacunes + surfaces non protégées + CVE (hypothèses)."""
    cov = couverture_osi(
        hosts,
        events,
        iface=iface,
        gateway=gateway,
        cidr=cidr,
        website=website,
        rgpd=rgpd,
    )
    surfaces = surfaces_non_protegees(hosts)
    cve = cve_correlation or {}
    n_cve = int(cve.get("n_findings") or 0)
    # Enrichissement lacunes en mode full : rappeler ce qui manque encore
    lacunes = list(cov.get("lacunes") or [])
    lectures_ouvertes = [
        "netinfo (L1/L3)",
        "découverte / ARP (L2)",
        "nmap -sV ports (L4)",
        "bannières / scripts info (L5–L7)",
        "TLS ssl-enum-ciphers / cert (L6) si ports TLS",
        "SMB security-mode / shares noms (L7) si 445",
        "HTTP headers lecture (L7) si web",
        "OT lecture si ports industriels",
        "corrélation CVE catalogue local",
    ]
    return {
        "titre": "Vision large OSI + surfaces non protégées (lecture)",
        "mode_full": bool(mode_full),
        "couverture": cov,
        "couches_touchees": cov.get("couches_touchees") or [],
        "lacunes": lacunes,
        "surfaces_non_protegees": surfaces,
        "n_surfaces": len(surfaces),
        "cve_n": n_cve,
        "cve_note": cve.get("note") or "",
        "lectures_visees": lectures_ouvertes if mode_full else lectures_ouvertes[:5],
        "resume": (
            cov.get("resume")
            or ""
        )
        + (
            f" Surfaces non protégées observées : {len(surfaces)}. "
            f"Hypothèses CVE (catalogue local) : {n_cve}. "
            "Lecture seule — aucune exploitation, aucun payload, aucune entrée."
        ),
        "disclaimer": (
            "Mode full / audit-full : profondeur de *lecture* maximale sur les surfaces "
            "exposées (L1–L7 dans le budget). Ce n'est ni un bypass d'authentification, "
            "ni une intrusion. Aucune exploitation exécutée."
        ),
    }


def next_layer_propositions_full(
    hosts: list[Host] | None = None,
    events: list[dict[str, Any]] | None = None,
    *,
    budget_left: int = 24,
) -> list[dict[str, Any]]:
    """En mode full : ouvrir toutes les lectures sûres pour ports exposés (pas d'exploit)."""
    base = next_layer_propositions(events or [], budget_left=budget_left)
    seen = {p["id"] for p in base}
    props = list(base)

    def _add(key: str, layer: str, outil: str, why: str) -> None:
        if key in seen or len(props) >= budget_left:
            return
        seen.add(key)
        props.append(
            {
                "id": key,
                "layer": layer,
                "outil": outil,
                "why": why,
                "status": "proposed",
                "nature_action": "démonstration d'exposition (lecture)",
            }
        )

    ports: set[int] = set()
    for h in hosts or []:
        for p in h.ports or []:
            if isinstance(p, dict):
                try:
                    ports.add(int(p.get("port") or 0))
                except (TypeError, ValueError):
                    pass
    if ports & HTTP_PORTS:
        _add("full-http-headers", "L7", "web_audit/http-headers", "HTTP vu → en-têtes lecture")
    if ports & TLS_PORTS:
        _add("full-tls-ciphers", "L6", "ssl-enum-ciphers", "TLS vu → inventaire protocoles/suites (lecture)")
        _add("full-tls-cert", "L6", "ssl-cert", "TLS vu → certificat (lecture)")
    if ports & SMB_PORTS:
        _add("full-smb-security", "L7", "smb-security-mode", "SMB vu → signing / SMBv1 (lecture)")
        _add("full-smb-shares", "L7", "smb-enum-shares", "SMB vu → noms de partages (pas les fichiers)")
    if ports & RDP_PORTS:
        _add("full-rdp-banner", "L7", "nmap -sV 3389/5900", "RDP/VNC vu → présence lecture, pas de login")
    if ports & OT_PORTS:
        _add("full-ot-read", "L7", "machines", "OT vu → inventaire Ethernet industriel lecture")
    if ports & LDAP_PORTS:
        _add("full-ldap-rootdse", "L7", "ldap-rootdse", "LDAP vu → rootDSE lecture")
    if 22 in ports:
        _add("full-ssh-hostkey", "L5-L7", "ssh-hostkey", "SSH vu → empreinte clé hôte (lecture)")
    if any(p in ports for p in _DATASTORE_PORTS):
        _add("full-datastore-banner", "L7", "nmap -sV datastore", "Datastore vu → bannière lecture, pas de dump")
    if any(p in ports for p in (21, 23, 69)):
        _add("full-cleartext", "L7", "cve_correlate", "Clairtext vu → corrélation catalogue + remède")
    _add("full-cve-catalog", "L4-L7", "cve_correlate", "Corrélation CVE catalogue local (hypothèses + remèdes)")
    return props
