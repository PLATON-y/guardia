"""Hygiène ANSSI — signalement, pas un certificat.

Socle public : 13 mesures TPE/PME, essentiels mobiles, gestion des
identités (objectif 13 type NIS2). On croise ce qui est *vu* sur le
parc et ce qui est *déclaré*. On ne dit pas « conforme ANSSI ».
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import CheckupResult, Host
from guardia.core.parc import parc_de

STATUT_VU = "observé"
STATUT_NON = "non observé — signalé"
STATUT_DECL = "déclaré — pas un certificat"
STATUT_HORS = "hors visite — à confirmer avec vous"

MESURES: tuple[tuple[str, str, str, str, str], ...] = (
    # id, titre, source, parc (personnel|professionnel|tous), comment_observer
    ("h-inventaire", "Inventaire des équipements allumés", "ANSSI TPE/PME — inventaire", "tous", "nmap"),
    ("h-maj", "Mises à jour des systèmes et applications", "ANSSI TPE/PME — mises à jour", "tous", "banniere"),
    ("h-mdp", "Mots de passe robustes + gestionnaire", "ANSSI TPE/PME + CNIL MFA 2025", "tous", "declare"),
    ("h-mfa", "Authentification multifacteur là où c'est possible", "ANSSI TPE/PME · CNIL · NIS2 obj. 13", "tous", "declare"),
    ("h-sauvegarde", "Sauvegardes testées (3-2-1)", "ANSSI TPE/PME — sauvegardes", "tous", "declare"),
    ("h-parefeu", "Pare-feu / filtrage en bordure", "ANSSI TPE/PME — pare-feu", "tous", "declare"),
    ("h-wifi", "Wi-Fi distinct invité / métier", "ANSSI TPE/PME — Wi-Fi", "tous", "ap"),
    ("h-admin", "Comptes d'administration séparés des comptes du quotidien", "ANSSI PA-022 administration", "professionnel", "declare"),
    ("h-identites", "Identités nominatives, révocation, moindre privilège", "NIS2 obj. 13 · ANSSI identités", "professionnel", "porte"),
    ("h-mobile", "Téléphones : maj, verrouillage, séparation perso/pro", "ANSSI essentiels mobiles v1.1", "tous", "phone"),
    ("h-nomade", "Postes nomades : chiffrement, VPN, même niveau que le fixe", "ANSSI PA-054 nomadisme", "professionnel", "declare"),
    ("h-byod", "Équipements personnels non branchés sur le SI métier", "ANSSI hygiène — règle 5", "professionnel", "declare"),
    ("h-messagerie", "Messagerie : SPF / DKIM / DMARC, filtre", "ANSSI TPE/PME — messagerie", "professionnel", "hors"),
    ("h-incident", "Procédure d'incident (qui appeler, 24 h / 72 h si NIS2)", "ANSSI TPE/PME · NIS2", "professionnel", "declare"),
    ("h-sensib", "Sensibilisation des personnes du parc", "ANSSI TPE/PME — sensibilisation", "tous", "declare"),
)


def _blob(h: Host) -> str:
    parts = [h.kind, h.hostname, h.ip]
    for p in h.ports or []:
        if isinstance(p, dict):
            parts.append(str(p.get("port") or ""))
            parts.append(str(p.get("name") or ""))
            parts.append(str(p.get("product") or ""))
            parts.append(str(p.get("version") or ""))
    for f in h.findings or []:
        parts.append(f.id)
        parts.append(f.titre)
    return " ".join(parts).lower()


def build_hygiene(result: CheckupResult) -> dict[str, Any]:
    parc = parc_de(result.mission)
    hosts = result.hosts or []
    blob = " ".join(_blob(h) for h in hosts)
    n_hosts = len(hosts)
    phones = [h for h in hosts if h.kind in ("phone", "mobile", "tablette")]
    aps = [h for h in hosts if h.kind in ("ap", "box", "wifi")]
    vieux = [
        n
        for n in (
            "windows server 2008",
            "windows server 2012",
            "windows xp",
            "php/5",
            "openssh_7.",
            "tlsv1.0",
            "sslv3",
        )
        if n in blob
    ]
    ldap = any(x in blob for x in ("389", "ldap", "88", "kerberos"))
    items: list[dict[str, Any]] = []
    for iid, titre, source, pour, comment in MESURES:
        if pour not in ("tous", parc):
            continue
        if comment == "nmap":
            if n_hosts:
                statut, obs = STATUT_VU, f"{n_hosts} équipement(s) vus sur le CIDR mandaté."
            else:
                statut, obs = STATUT_NON, "Aucun hôte vu. Inventaire à refaire sur le lieu."
        elif comment == "banniere":
            if vieux:
                statut, obs = STATUT_NON, "Versions trop anciennes vues : " + ", ".join(vieux[:4])
            elif n_hosts:
                statut, obs = STATUT_HORS, "Bannières lues. L'état des correctifs, hors visite."
            else:
                statut, obs = STATUT_HORS, "Pas de bannière. Mises à jour : à déclarer."
        elif comment == "ap":
            if aps:
                statut, obs = STATUT_VU, f"Box / AP vu(s) : {', '.join(h.ip for h in aps[:4])}."
            else:
                statut, obs = STATUT_HORS, "Pas d'AP vu. Wi-Fi : à confirmer."
        elif comment == "phone":
            if phones:
                statut, obs = STATUT_VU, f"{len(phones)} téléphone(s) / tablette(s) sur le LAN."
            else:
                statut, obs = STATUT_HORS, "Pas de mobile vu. Hygiène téléphone : déclarative."
        elif comment == "porte":
            if ldap:
                statut, obs = (
                    STATUT_VU,
                    "Annuaire / Kerberos joignable depuis le VLAN visité. Pas un dump.",
                )
            else:
                statut, obs = STATUT_HORS, "Pas d'annuaire vu. Identités : hors visite."
        elif comment == "hors":
            statut, obs = STATUT_HORS, "Hors checkup LAN. DNS messagerie / SaaS : à confirmer."
        else:
            statut, obs = STATUT_DECL, "Mesure déclarative. Guardia ne s'assoit pas derrière chaque poste."
        items.append(
            {
                "id": iid,
                "titre": titre,
                "source": source,
                "statut": statut,
                "observation": obs,
            }
        )
    return {
        "titre": "Hygiène — recommandations publiques ANSSI",
        "limite": (
            "Signalement. Pas un certificat ANSSI, pas un audit PASSI, "
            "pas une conformité NIS2. Les mesures hors LAN restent déclaratives."
        ),
        "parc": parc,
        "items": items,
        "n_observes": sum(1 for i in items if i["statut"] == STATUT_VU),
        "n_total": len(items),
    }
