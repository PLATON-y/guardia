"""Chaîne PASSI : exigence → activité → contrôle → action → outil → résultat → preuve → constat → validation → rapport.

Chaque contrôle P-* est relié à une action du moteur (ou à une revue humaine).
Une preuve n'existe que si le moteur ou le dossier de mission l'a réellement
produite. Une validation humaine n'est jamais inférée.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Mission

# action / capacité / outil par défaut pour chaque contrôle.
LIENS: dict[str, dict[str, str]] = {
    "P-GEN-01": {"action": "passi-cadrage", "capability": "cadrage", "outil": "mission.yaml", "rapport": "#passi-assessment"},
    "P-GEN-02": {"action": "passi-cadrage", "capability": "cadrage", "outil": "mission.yaml", "rapport": "#passi-assessment"},
    "P-GEN-03": {"action": "passi-cadrage", "capability": "cadrage", "outil": "mission.yaml", "rapport": "#passi-assessment"},
    "P-GEN-04": {"action": "passi-discovery", "capability": "asset_discovery", "outil": "journal", "rapport": "#orchestre"},
    "P-GEN-05": {"action": "correlation", "capability": "correlation", "outil": "cerveau.evidence", "rapport": "#findings"},
    "P-GEN-06": {"action": "passi-cadrage", "capability": "opening_meeting", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-GEN-07": {"action": "passi-cadrage", "capability": "change_log", "outil": "journal", "rapport": "#orchestre"},
    "P-GEN-08": {"action": "passi-cadrage", "capability": "closure_check", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ARCH-01": {"action": "passi-archi-docs", "capability": "review_architecture_documents", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ARCH-02": {"action": "passi-archi-docs", "capability": "review_architecture_documents", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ARCH-03": {"action": "passi-archi-docs", "capability": "review_architecture_documents", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ARCH-04": {"action": "passi-archi-docs", "capability": "review_architecture_documents", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ARCH-05": {"action": "passi-archi-docs", "capability": "review_architecture_documents", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ARCH-06": {"action": "passi-archi-observe", "capability": "architecture_observation", "outil": "nmap", "rapport": "#cerveau"},
    "P-ARCH-07": {"action": "passi-archi-observe", "capability": "architecture_observation", "outil": "cerveau.graphe", "rapport": "#findings"},
    "P-CFG-01": {"action": "passi-config-reviews", "capability": "configuration_evidence_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CFG-02": {"action": "passi-config-reviews", "capability": "configuration_evidence_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CFG-03": {"action": "passi-config-baseline", "capability": "configuration_baseline", "outil": "nmap", "rapport": "#services"},
    "P-CFG-04": {"action": "passi-config-baseline", "capability": "configuration_baseline", "outil": "testssl/sslscan", "rapport": "#services"},
    "P-CFG-05": {"action": "passi-config-baseline", "capability": "configuration_baseline", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CFG-06": {"action": "passi-config-baseline", "capability": "configuration_baseline", "outil": "lynis", "rapport": "#lynis"},
    "P-CFG-07": {"action": "passi-config-baseline", "capability": "configuration_baseline", "outil": "greenbone", "rapport": "#greenbone"},
    "P-CFG-08": {"action": "passi-config-reviews", "capability": "configuration_evidence_review", "outil": "trivy", "rapport": "#trivy"},
    "P-CFG-09": {"action": "passi-config-reviews", "capability": "configuration_evidence_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CFG-10": {"action": "correlation", "capability": "correlation", "outil": "cerveau.evidence", "rapport": "#findings"},
    "P-CODE-01": {"action": "passi-code-intake", "capability": "code_intake", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-02": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-03": {"action": "passi-code-sast", "capability": "safe_static_analysis", "outil": "trivy", "rapport": "#trivy"},
    "P-CODE-04": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-05": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-06": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-07": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-08": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-09": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-10": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-11": {"action": "passi-code-review", "capability": "human_code_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-CODE-12": {"action": "passi-code-review", "capability": "human_code_review", "outil": "cerveau.evidence", "rapport": "#passi-assessment"},
    "P-INTR-01": {"action": "passi-pentest-blackbox", "capability": "pentest_blackbox", "outil": "avenant", "rapport": "#passi-assessment"},
    "P-INTR-02": {"action": "passi-pentest-graybox", "capability": "pentest_graybox", "outil": "avenant", "rapport": "#passi-assessment"},
    "P-INTR-03": {"action": "passi-pentest-whitebox", "capability": "pentest_whitebox", "outil": "avenant", "rapport": "#passi-assessment"},
    "P-INTR-04": {"action": "passi-pentest-prep", "capability": "pentest_preconditions", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-INTR-05": {"action": "passi-pentest-prep", "capability": "pentest_preconditions", "outil": "autorisations", "rapport": "#pack-autorisations"},
    "P-INTR-06": {"action": "passi-pentest-prep", "capability": "pentest_preconditions", "outil": "policy", "rapport": "#cerveau"},
    "P-INTR-07": {"action": "passi-pentest-report", "capability": "pentest_evidence_review", "outil": "journal", "rapport": "#orchestre"},
    "P-INTR-08": {"action": "passi-pentest-report", "capability": "pentest_evidence_review", "outil": "revue humaine", "rapport": "#findings"},
    "P-INTR-09": {"action": "passi-pentest-report", "capability": "pentest_evidence_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ORG-01": {"action": "passi-org-docs", "capability": "document_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ORG-02": {"action": "passi-org-docs", "capability": "document_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ORG-03": {"action": "passi-org-interviews", "capability": "interviews", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ORG-04": {"action": "passi-org-physical", "capability": "physical_observation", "outil": "revue humaine", "rapport": "#passi-assessment"},
    "P-ORG-05": {"action": "passi-org-docs", "capability": "document_review", "outil": "usages", "rapport": "#usages"},
    "P-ORG-06": {"action": "passi-org-docs", "capability": "document_review", "outil": "revue humaine", "rapport": "#passi-assessment"},
}


def _n_hosts(result: dict[str, Any]) -> int:
    return len(result.get("hosts") or [])


def _n_ports(result: dict[str, Any]) -> int:
    n = 0
    for h in result.get("hosts") or []:
        n += len(getattr(h, "ports", None) or [])
    return n


def _preuve_pour(cid: str, result: dict[str, Any], status: str) -> str:
    if status in ("not_applicable", "not_covered"):
        return ""
    hosts = _n_hosts(result)
    ports = _n_ports(result)
    journal = result.get("journal") or {}
    if cid == "P-ARCH-06" and hosts:
        return "observations:{h}-hotes/{p}-ports".format(h=hosts, p=ports)
    if cid == "P-CFG-03" and ports:
        return "services:{p}-ports".format(p=ports)
    if cid == "P-CFG-06" and result.get("lynis"):
        return "lynis:present"
    if cid == "P-CFG-07" and result.get("greenbone"):
        return "greenbone:present"
    if cid in ("P-GEN-04", "P-INTR-07") and journal:
        etapes = (journal.get("etapes") if isinstance(journal, dict) else None) or journal.get("phases") or []
        return "journal:{n}-entrees".format(n=len(etapes) if isinstance(etapes, list) else 1)
    if cid in ("P-GEN-05", "P-CFG-10") and (result.get("correlation") or result.get("findings")):
        findings = result.get("findings") or []
        return "findings:{n}".format(n=len(findings) if isinstance(findings, list) else 1)
    adapt = result.get("adaptatif") or {}
    if cid == "P-ARCH-06" and adapt.get("graphe"):
        return "graphe:actifs"
    if status in ("verified", "pending_human"):
        return "mission:{cid}".format(cid=cid)
    return ""


def _resultat_pour(cid: str, result: dict[str, Any], status: str) -> str:
    if status == "not_applicable":
        return "activité non demandée"
    if status == "not_covered":
        return "aucune preuve"
    hosts = _n_hosts(result)
    ports = _n_ports(result)
    if cid == "P-ARCH-06":
        return "{h} actif(s), {p} service(s) observé(s)".format(h=hosts, p=ports)
    if cid == "P-GEN-04":
        return "journal d'exécution présent" if result.get("journal") else "journal attendu"
    if cid.startswith("P-INTR-") and cid not in ("P-INTR-07",):
        return "avenant — jamais auto"
    if status == "pending_human":
        return "preuve candidate — revue humaine"
    if status == "verified":
        return "contrôle vérifié sur preuves présentes"
    return status


def _constat_pour(cid: str, result: dict[str, Any]) -> str:
    findings = result.get("findings") or []
    if not findings:
        adapt = result.get("adaptatif") or {}
        n = len(adapt.get("findings_candidats") or [])
        return "{n} candidat(s) cerveau".format(n=n) if n else ""
    if cid in ("P-GEN-05", "P-ARCH-07", "P-CFG-10", "P-INTR-08"):
        return "{n} finding(s)".format(n=len(findings))
    return ""


def attacher_chaines(rows: list[dict[str, Any]], mission: Mission, result: dict[str, Any]) -> list[dict[str, Any]]:
    """Une ligne par contrôle demandé : la chaîne complète, ou vide si N/A."""
    out: list[dict[str, Any]] = []
    for row in rows:
        cid = str(row.get("id") or "")
        status = str(row.get("status") or "")
        lien = LIENS.get(cid) or {"action": "", "capability": "", "outil": "", "rapport": "#passi-assessment"}
        preuve = _preuve_pour(cid, result, status)
        out.append(
            {
                "exigence": row.get("ref") or "",
                "activite": row.get("activity") or "",
                "controle": cid,
                "titre": row.get("title") or "",
                "action": lien.get("action") or "",
                "capability": lien.get("capability") or "",
                "outil": lien.get("outil") or "",
                "resultat": _resultat_pour(cid, result, status),
                "preuve": preuve,
                "constat": _constat_pour(cid, result),
                "validation": status,
                "rapport": lien.get("rapport") or "#passi-assessment",
                "automatique": bool(row.get("automated")),
                "human_gate": bool(row.get("human_gate")),
            }
        )
    return out
