"""Bootstrap GGUF — au démarrage si le modèle local manque.

Propose à l'opérateur :
  [1] chemin existant (.gguf) → symlink ou copie dans ROOT/models/
  [2] télécharger via wget / urllib (~1,8 Go)
  [3] continuer avec la garde locale seule

Non-interactif (pas de TTY) : pas de prompt, note via GUARDIA_LLM_NOTE, garde autorisée.
Override : GUARDIA_LLM_MODEL=/chemin/vers/modele.gguf
URL     : GUARDIA_GGUF_URL (sinon constante officielle).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import sys
import urllib.error
import urllib.request
from pathlib import Path
from typing import Any

GGUF_NAME = "cybersec-assistant-3b-Q4_K_M.gguf"
GUARDIA_GGUF_URL = (
    "https://huggingface.co/AYI-NEDJIMI/CyberSec-Assistant-3B-GGUF"
    "/resolve/main/cybersec-assistant-3b-Q4_K_M.gguf"
)
# Alternates documentés dans models/LIRE.txt si le resolve principal 404.
ALT_GGUF_NAMES = (
    "cybersec-assistant-3b-Q4_K_M.gguf",
    "cybersec-assistant-3b.Q4_K_M.gguf",
    "CyberSec-Assistant-3B-Q4_K_M.gguf",
    "cybersec-assistant-3b-q4_k_m.gguf",
)
EXPECTED_SIZE_HINT = "~1,8 Go"


def _root() -> Path:
    try:
        from guardia.core.paths import ROOT

        return ROOT
    except Exception:
        return Path(__file__).resolve().parents[2]


def default_gguf_path() -> Path:
    """ROOT/models/cybersec-assistant-3b-Q4_K_M.gguf"""
    return _root() / "models" / GGUF_NAME


def gguf_url() -> str:
    return (os.environ.get("GUARDIA_GGUF_URL") or GUARDIA_GGUF_URL).strip()


def find_gguf() -> Path | None:
    """Réutilise resolve_model (env GUARDIA_LLM_MODEL, candidats, parcours)."""
    from guardia.engines.llm_polish import resolve_model

    return resolve_model(None)


def _clear_model_cache() -> None:
    try:
        import guardia.engines.llm_polish as polish

        polish._cached_model = "unset"  # type: ignore[attr-defined]
    except Exception:
        pass


def _models_dir() -> Path:
    d = _root() / "models"
    d.mkdir(parents=True, exist_ok=True)
    return d


def install_existing(src: str | Path, *, dest: Path | None = None) -> Path:
    """Symlink (préféré) ou copie le .gguf vers ROOT/models/."""
    source = Path(src).expanduser().resolve()
    if not source.is_file():
        raise FileNotFoundError("fichier introuvable : {p}".format(p=source))
    if not source.name.lower().endswith(".gguf"):
        raise ValueError("attendu un fichier .gguf : {p}".format(p=source))
    target = dest or default_gguf_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() or target.is_symlink():
        try:
            target.unlink()
        except OSError:
            pass
    try:
        target.symlink_to(source)
        mode = "symlink"
    except OSError:
        shutil.copy2(source, target)
        mode = "copie"
    _clear_model_cache()
    print(
        "LLM : modèle installé ({m}) → {t}".format(m=mode, t=target),
        flush=True,
    )
    return target


def download_gguf(
    dest: Path | None = None,
    url: str | None = None,
    *,
    progress: bool = True,
) -> Path:
    """Télécharge le GGUF (wget -c si dispo, sinon urllib)."""
    target = Path(dest) if dest else default_gguf_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    u = (url or gguf_url()).strip()
    if not u:
        raise ValueError("URL GGUF vide")

    wget = shutil.which("wget")
    if wget:
        cmd = [wget, "-c", "-O", str(target), u]
        if progress:
            print(
                "LLM : téléchargement wget ({hint}) → {t}".format(
                    hint=EXPECTED_SIZE_HINT, t=target
                ),
                flush=True,
            )
            print("  URL : {u}".format(u=u), flush=True)
        r = subprocess.run(cmd, check=False)
        if r.returncode != 0:
            raise RuntimeError(
                "wget a échoué (code {c}) pour {u}".format(c=r.returncode, u=u)
            )
    else:
        if progress:
            print(
                "LLM : téléchargement urllib ({hint}) → {t}".format(
                    hint=EXPECTED_SIZE_HINT, t=target
                ),
                flush=True,
            )
            print("  URL : {u}".format(u=u), flush=True)
        _download_urllib(u, target, progress=progress)

    if not target.is_file() or target.stat().st_size < 10_000_000:
        raise RuntimeError(
            "téléchargement incomplet ou trop petit : {t}".format(t=target)
        )
    _clear_model_cache()
    print(
        "LLM : GGUF prêt ({n} Mo) → {t}".format(
            n=target.stat().st_size // 1_000_000, t=target
        ),
        flush=True,
    )
    return target


def _download_urllib(url: str, dest: Path, *, progress: bool = True) -> None:
    tmp = dest.with_suffix(dest.suffix + ".part")
    try:
        req = urllib.request.Request(url, method="GET")
        with urllib.request.urlopen(req, timeout=120) as resp:
            total = resp.headers.get("Content-Length")
            total_i = int(total) if total and total.isdigit() else 0
            done = 0
            chunk = 1024 * 256
            with open(tmp, "wb") as out:
                while True:
                    buf = resp.read(chunk)
                    if not buf:
                        break
                    out.write(buf)
                    done += len(buf)
                    if progress and total_i:
                        pct = min(100, done * 100 // total_i)
                        print(
                            "\r  {p}% ({m} / {t} Mo)".format(
                                p=pct,
                                m=done // 1_000_000,
                                t=total_i // 1_000_000,
                            ),
                            end="",
                            flush=True,
                        )
            if progress and total_i:
                print(flush=True)
        tmp.replace(dest)
    except (OSError, urllib.error.URLError) as exc:
        try:
            if tmp.exists():
                tmp.unlink()
        except OSError:
            pass
        raise RuntimeError("échec téléchargement : {e}".format(e=exc)) from exc


def _is_interactive() -> bool:
    try:
        return bool(sys.stdin and sys.stdin.isatty() and sys.stdout and sys.stdout.isatty())
    except Exception:
        return False


def _set_note(msg: str) -> None:
    os.environ["GUARDIA_LLM_NOTE"] = msg


def prompt_cli_missing() -> Path | None:
    """Interactif CLI : [1] chemin [2] télécharger [3] garde locale."""
    print("", flush=True)
    print("══════════════════════════════════════════════════", flush=True)
    print("  Guardia — modèle LLM (.gguf) introuvable", flush=True)
    print("══════════════════════════════════════════════════", flush=True)
    print(
        "  Cible : {p}".format(p=default_gguf_path()),
        flush=True,
    )
    print(
        "  Taille attendue : {h}".format(h=EXPECTED_SIZE_HINT),
        flush=True,
    )
    print(
        "  URL officielle : {u}".format(u=gguf_url()),
        flush=True,
    )
    print("", flush=True)
    print("  [1] Indiquer un chemin existant (.gguf) — symlink/copie", flush=True)
    print("  [2] Télécharger ici (~1,8 Go, HuggingFace)", flush=True)
    print("  [3] Continuer avec la garde locale seule", flush=True)
    print("", flush=True)
    try:
        choice = input("Choix [1/2/3] : ").strip() or "3"
    except EOFError:
        choice = "3"
    if choice == "1":
        try:
            path = input("Chemin du fichier .gguf : ").strip()
        except EOFError:
            path = ""
        if not path:
            print("Annulé — garde locale.", flush=True)
            _set_note("gguf manquant ; opérateur a annulé le chemin")
            return None
        try:
            return install_existing(path)
        except (OSError, ValueError) as exc:
            print("Erreur : {e}".format(e=exc), flush=True)
            _set_note("échec install GGUF : {e}".format(e=exc))
            return None
    if choice == "2":
        try:
            confirm = input(
                "Confirmer le téléchargement (~1,8 Go) ? [o/N] : "
            ).strip().lower()
        except EOFError:
            confirm = ""
        if confirm not in ("o", "oui", "y", "yes"):
            print("Téléchargement annulé — garde locale.", flush=True)
            _set_note("téléchargement GGUF annulé")
            return None
        try:
            return download_gguf()
        except (OSError, RuntimeError, ValueError) as exc:
            print("Erreur téléchargement : {e}".format(e=exc), flush=True)
            _set_note("échec téléchargement GGUF : {e}".format(e=exc))
            return None
    print("Garde locale seule — pas de modèle embarqué.", flush=True)
    _set_note(
        "gguf manquant ; garde locale. "
        "Pose un .gguf dans models/ ou GUARDIA_LLM_MODEL=… "
        "ou relance `guardia llm`."
    )
    return None


def prompt_ui_missing(parent: Any = None) -> Path | None:
    """Dialogue tkinter : mêmes 3 options ; filedialog pour le chemin."""
    try:
        import tkinter as tk
        from tkinter import filedialog, messagebox
    except ImportError:
        _set_note("tkinter indisponible pour prompt GGUF")
        return None

    own_root = False
    root = parent
    if root is None:
        root = tk.Tk()
        root.withdraw()
        own_root = True

    result: dict[str, Any] = {"path": None}

    def _close_own() -> None:
        if own_root:
            try:
                root.destroy()
            except Exception:
                pass

    try:
        dlg = tk.Toplevel(root)
        dlg.title("Guardia — modèle LLM manquant")
        dlg.resizable(False, False)
        dlg.grab_set()
        frm = tk.Frame(dlg, padx=16, pady=12)
        frm.pack(fill="both", expand=True)
        tk.Label(
            frm,
            text="Modèle LLM (.gguf) introuvable",
            font=("Sans", 11, "bold"),
        ).pack(anchor="w")
        tk.Label(
            frm,
            text="Cible : {p}\nTaille : {h}\nURL : {u}".format(
                p=default_gguf_path(),
                h=EXPECTED_SIZE_HINT,
                u=gguf_url(),
            ),
            justify="left",
            wraplength=480,
        ).pack(anchor="w", pady=(6, 10))

        def on_path() -> None:
            p = filedialog.askopenfilename(
                parent=dlg,
                title="Choisir un fichier .gguf",
                filetypes=[("GGUF", "*.gguf"), ("Tous", "*.*")],
            )
            if not p:
                return
            try:
                result["path"] = install_existing(p)
                dlg.destroy()
            except (OSError, ValueError) as exc:
                messagebox.showerror("Guardia", str(exc), parent=dlg)

        def on_dl() -> None:
            ok = messagebox.askyesno(
                "Téléchargement GGUF",
                "Télécharger cybersec-assistant-3b-Q4_K_M.gguf (~1,8 Go)\n"
                "depuis HuggingFace vers models/ ?\n\n"
                "{u}".format(u=gguf_url()),
                parent=dlg,
            )
            if not ok:
                return
            try:
                dlg.withdraw()
                result["path"] = download_gguf()
                dlg.destroy()
            except (OSError, RuntimeError, ValueError) as exc:
                messagebox.showerror("Guardia", str(exc), parent=root)
                try:
                    dlg.destroy()
                except Exception:
                    pass

        def on_garde() -> None:
            _set_note(
                "gguf manquant ; garde locale (UI). "
                "Pose un .gguf dans models/ ou GUARDIA_LLM_MODEL=…"
            )
            result["path"] = None
            dlg.destroy()

        bf = tk.Frame(frm)
        bf.pack(fill="x", pady=(4, 0))
        tk.Button(bf, text="1 — Chemin existant…", command=on_path, width=28).pack(
            pady=2
        )
        tk.Button(bf, text="2 — Télécharger ici (~1,8 Go)", command=on_dl, width=28).pack(
            pady=2
        )
        tk.Button(bf, text="3 — Garde locale seule", command=on_garde, width=28).pack(
            pady=2
        )
        dlg.protocol("WM_DELETE_WINDOW", on_garde)
        dlg.wait_window()
    finally:
        _close_own()

    return result.get("path")


def ensure_gguf(
    *,
    interactive: bool | None = None,
    ui: bool = False,
    parent: Any = None,
) -> Path | None:
    """Vérifie / obtient le GGUF. Retourne le chemin ou None (garde locale).

    - Déjà présent → chemin
    - Non-interactif → None + GUARDIA_LLM_NOTE
    - ui=True → dialogue tkinter
    - sinon TTY → prompt CLI
    """
    found = find_gguf()
    if found:
        return found

    if interactive is None:
        interactive = _is_interactive() if not ui else True

    if not interactive and not ui:
        note = (
            "GGUF absent — mode non-interactif. "
            "export GUARDIA_LLM_MODEL=/chemin/vers/modele.gguf "
            "ou placez {n} dans models/ "
            "ou : wget -c -O models/{n} \"$GUARDIA_GGUF_URL\" "
            "(défaut catalogue HuggingFace)."
        ).format(n=GGUF_NAME)
        _set_note(note)
        print("LLM : " + note, flush=True)
        return None

    if ui:
        return prompt_ui_missing(parent)
    if _is_interactive():
        return prompt_cli_missing()

    _set_note("GGUF absent ; pas de TTY — garde locale")
    return None


def head_check_url(url: str | None = None, timeout: float = 8.0) -> dict[str, Any]:
    """HEAD rapide sur l'URL catalogue (suivi limité des redirects)."""
    u = (url or gguf_url()).strip()
    try:
        req = urllib.request.Request(u, method="HEAD")
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            code = getattr(resp, "status", 200)
            size = resp.headers.get("Content-Length") or resp.headers.get("X-Linked-Size")
            return {
                "ok": 200 <= int(code) < 400,
                "status": int(code),
                "url": u,
                "size": size,
            }
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "status": 0, "url": u, "why": str(exc)}
