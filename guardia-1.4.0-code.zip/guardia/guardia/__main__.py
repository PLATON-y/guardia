from guardia.cli import main
raise SystemExit(main())
