"""Graphe d'actifs + chemins d'exposition (hypothèses, pas d'exploit)."""
from __future__ import annotations

from typing import Any

from guardia.core.models import Host, Mission

ADMIN_PORTS = {3389, 5900, 5985, 8443, 8834, 9090, 10000}
SMB_PORTS = {139, 445}
HTTP_PORTS = {80, 81, 8000, 8080, 8888, 3000, 443, 8443}


def _ports(h: Host) -> list[int]:
    out: list[int] = []
    for p in h.ports or []:
        if isinstance(p, dict):
            try:
                out.append(int(p.get("port") or 0))
            except (TypeError, ValueError):
                continue
        else:
            try:
                out.append(int(p))
            except (TypeError, ValueError):
                continue
    return [x for x in out if x]


def construire(hosts: list[Host], mission: Mission | None = None) -> dict[str, Any]:
    m = mission or Mission()
    ex = m.extras or {}
    url = str(ex.get("site_url") or "")
    nodes: list[dict[str, Any]] = []
    edges: list[dict[str, Any]] = []
    if url:
        nodes.append({"id": "internet", "kind": "internet", "label": "Internet"})
        nodes.append({"id": "url", "kind": "url", "label": url})
        edges.append({"src": "internet", "dst": "url", "via": "https", "kind": "public"})
    gw = next((h for h in hosts if (h.kind or "") in ("box", "passerelle", "router")), None)
    if not gw and hosts:
        gw = next((h for h in hosts if h.ip.endswith(".1") or h.ip.endswith(".254")), hosts[0])
    if gw:
        nodes.append(
            {
                "id": gw.ip,
                "kind": gw.kind or "box",
                "label": gw.hostname or gw.ip,
                "ip": gw.ip,
                "role": "passerelle",
            }
        )
        if url:
            edges.append({"src": "url", "dst": gw.ip, "via": "wan", "kind": "lien"})
    for h in hosts:
        if gw and h.ip == gw.ip:
            continue
        nodes.append(
            {
                "id": h.ip,
                "kind": h.kind or "inconnu",
                "label": h.hostname or h.ip,
                "ip": h.ip,
                "role": h.kind or "poste",
            }
        )
        if gw:
            edges.append({"src": gw.ip, "dst": h.ip, "via": "lan", "kind": "lien"})
        for port in _ports(h):
            sid = f"{h.ip}:{port}"
            role = "admin" if port in ADMIN_PORTS else "service"
            nodes.append(
                {
                    "id": sid,
                    "kind": "service",
                    "label": str(port),
                    "ip": h.ip,
                    "role": role,
                    "port": port,
                }
            )
            edges.append({"src": h.ip, "dst": sid, "via": str(port), "kind": "service"})
    return {
        "n_actifs": len(hosts),
        "n_services": sum(1 for n in nodes if n.get("kind") == "service"),
        "nodes": nodes,
        "edges": edges,
    }


def chemins(hosts: list[Host], graphe: dict[str, Any] | None = None) -> list[dict[str, Any]]:
    """Hypothèses d'exposition. On montre la porte. On n'entre pas."""
    _ = graphe
    out: list[dict[str, Any]] = []
    kinds = {h.kind or "inconnu" for h in hosts}
    segmente = len(kinds) <= 2
    for h in hosts:
        ports = _ports(h)
        admins = sorted(p for p in ports if p in ADMIN_PORTS)
        smbs = sorted(p for p in ports if p in SMB_PORTS)
        if admins:
            out.append(
                {
                    "id": f"path-admin-{h.ip}",
                    "entree": "LAN",
                    "actif": h.ip,
                    "service": ",".join(str(p) for p in admins),
                    "faiblesse": "interface d'administration visible depuis le LAN",
                    "impact": "prise de contrôle potentielle si le mot de passe est faible — non testé",
                    "hypothese": True,
                    "exploitation": False,
                    "etapes": [
                        "LAN",
                        h.ip,
                        f"port {admins[0]}",
                        "interface administration",
                        "impact potentiel",
                    ],
                }
            )
        if smbs and not segmente:
            out.append(
                {
                    "id": f"path-smb-{h.ip}",
                    "entree": "LAN non segmenté",
                    "actif": h.ip,
                    "service": "445",
                    "faiblesse": "partages visibles, VLAN unique",
                    "impact": "un poste compromis voit les fichiers — noms seulement ici",
                    "hypothese": True,
                    "exploitation": False,
                    "etapes": [
                        "LAN",
                        "parc non segmenté",
                        h.ip,
                        "SMB 445",
                        "impact potentiel",
                    ],
                }
            )
    return out[:8]
