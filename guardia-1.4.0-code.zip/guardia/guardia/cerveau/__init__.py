"""Cerveau Guardia — orchestrateur de raisonnement d'audit.

Guardia n'est pas un simulateur PASSI.
Le mandat décide, les événements ouvrent des branches, un résultat
inutile les ferme. Les outils sont des capacités interchangeables.
"""
from guardia.cerveau.adaptatif import (
    ecrire_checkpoint,
    lire_checkpoint,
    observer,
    raisonner,
    reprendre,
)
from guardia.cerveau.policy import CAPACITES, autoriser, contexte
from guardia.cerveau.directives_passi_cnil import emit_directives, schedule_within_budget

__all__ = [
    "CAPACITES",
    "emit_directives",
    "schedule_within_budget",
    "autoriser",
    "contexte",
    "ecrire_checkpoint",
    "lire_checkpoint",
    "observer",
    "raisonner",
    "reprendre",
]
