"""DAG adaptatif — trigger → décision → action.

Mission → observer → décider → tester → réévaluer → corréler → valider → rapporter.
Un résultat inutile arrête une branche. Un outil manquant n'arrête rien.
"""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any

from guardia.core.models import Host, Mission
from guardia.cerveau.evidence import collecter, normaliser_findings
from guardia.cerveau.graphe import construire, chemins
from guardia.cerveau.policy import CAP_BY_ID, CAPACITES, autoriser, contexte

HTTP_PORTS = {80, 81, 443, 8000, 8080, 8443, 8888, 3000}
TLS_PORTS = {443, 8443, 993, 995, 636, 990}
SMB_PORTS = {139, 445}
RDP_PORTS = {3389, 5900}
ADMIN_PORTS = {3389, 5900, 5985, 8443, 8834, 9090, 10000}
OT_PORTS = {102, 502, 4840, 44818, 34962}
LDAP_PORTS = {389, 636}
DNS_PORTS = {53}

# Branches du DAG : événement requis → capacité.
BRANCHES: tuple[tuple[str, str, str], ...] = (
    ("tls_seen", "tls_assessment", "TLS"),
    ("http_seen", "http_headers", "WEB"),
    ("http_seen", "nuclei_web", "WEB"),
    ("smb_seen", "smb_read", "SMB"),
    ("rdp_seen", "rdp_read", "ADMIN"),
    ("ot_seen", "ot_safe", "OT"),
    ("exposed_admin_service", "admin_surface", "ADMIN"),
    ("ldap_seen", "bloodhound", "IDENTITY"),
)

RESEAU_PLAFOND = 20
INTRUSIVITE_PLAFOND = 0  # moteur lecture


def _ports(h: Host) -> list[int]:
    out: list[int] = []
    for p in h.ports or []:
        if isinstance(p, dict):
            try:
                n = int(p.get("port") or 0)
            except (TypeError, ValueError):
                continue
        else:
            try:
                n = int(p)
            except (TypeError, ValueError):
                continue
        if n:
            out.append(n)
    return out


def observer(hosts: list[Host], mission: Mission | None = None) -> list[dict[str, Any]]:
    """Les portes vues deviennent des événements. Pas un plan figé."""
    events: list[dict[str, Any]] = []
    m = mission or Mission()
    if m.cidr:
        events.append(
            {"type": "scope", "asset": m.cidr, "port": 0, "confidence": 1.0, "why": "CIDR du mandat"}
        )
    url = str((m.extras or {}).get("site_url") or "")
    if url:
        events.append(
            {"type": "url_mandatee", "asset": url, "port": 0, "confidence": 1.0, "why": "URL du mandat"}
        )
    for h in hosts or []:
        events.append(
            {
                "type": "host_discovered",
                "asset": h.ip,
                "port": 0,
                "confidence": 0.9,
                "why": h.hostname or h.kind or "hôte",
            }
        )
        for port in _ports(h):
            events.append(
                {
                    "type": "port_open",
                    "asset": h.ip,
                    "port": port,
                    "confidence": 0.95,
                    "why": f"{port}/tcp",
                }
            )
            kinds: list[str] = []
            if port in ADMIN_PORTS:
                kinds.append("exposed_admin_service")
            if port in TLS_PORTS:
                kinds.append("tls_seen")
            if port in HTTP_PORTS:
                kinds.append("http_seen")
            if port in SMB_PORTS:
                kinds.append("smb_seen")
            if port in RDP_PORTS:
                kinds.append("rdp_seen")
            if port in OT_PORTS:
                kinds.append("ot_seen")
            if port in LDAP_PORTS:
                kinds.append("ldap_seen")
            if port in DNS_PORTS:
                kinds.append("dns_seen")
            for kind in kinds:
                events.append(
                    {
                        "type": kind,
                        "asset": h.ip,
                        "port": port,
                        "confidence": 0.9 if kind != "exposed_admin_service" else 0.92,
                        "why": f"{port}/tcp ouvert",
                    }
                )
    try:
        from guardia.engines.osi_map import tag_events

        events = tag_events(events)
    except Exception:
        pass
    return events


def _has(events: list[dict[str, Any]], typ: str) -> bool:
    return any(e.get("type") == typ for e in events)


def _budget_init(temps: float = 7200.0) -> dict[str, Any]:
    return {
        "intrusivite": INTRUSIVITE_PLAFOND,
        "reseau": RESEAU_PLAFOND,
        "temps": temps,
        "parallelisme": 8,
        "collecte": "low",
        "spent_reseau": 0,
        "spent_intrusivite": 0,
    }


def _consomme(budget: dict[str, Any], cap: dict[str, Any]) -> tuple[bool, str]:
    if int(cap.get("intrusivite") or 0) > int(budget.get("intrusivite") or 0):
        return False, "budget intrusivité saturé (moteur lecture)"
    need = int(cap.get("reseau") or 0)
    if budget["spent_reseau"] + need > int(budget.get("reseau") or 0):
        return False, f"budget réseau saturé ({budget['spent_reseau']}+{need}/{budget['reseau']})"
    budget["spent_reseau"] += need
    budget["spent_intrusivite"] = max(
        int(budget["spent_intrusivite"]), int(cap.get("intrusivite") or 0)
    )
    return True, "budget ok"


def _decision(
    *,
    noeud: str,
    cap_id: str,
    events: list[dict[str, Any]],
    ctx: dict[str, Any],
    budget: dict[str, Any],
    deja: set[str],
    need_event: str = "",
) -> dict[str, Any]:
    if cap_id in deja or noeud in deja:
        return {
            "noeud": noeud,
            "cap": cap_id,
            "etat": "repris",
            "why": "checkpoint — déjà joué",
        }
    cap = CAP_BY_ID.get(cap_id) or {"id": cap_id, "authorization": "lecture"}
    pol = autoriser(cap, ctx)
    if not pol["ok"]:
        return {
            "noeud": noeud,
            "cap": cap_id,
            "etat": pol["etat"],
            "why": pol["why"],
            "outil": pol.get("outil"),
            "avenant": bool(pol.get("avenant")),
        }
    if need_event and not _has(events, need_event):
        return {
            "noeud": noeud,
            "cap": cap_id,
            "etat": "prune",
            "why": f"précondition absente : {need_event}",
            "outil": cap.get("outil"),
        }
    ok_b, why_b = _consomme(budget, cap)
    if not ok_b:
        return {
            "noeud": noeud,
            "cap": cap_id,
            "etat": "budget",
            "why": why_b,
            "outil": cap.get("outil"),
        }
    etat = "porte" if pol.get("gate") else "ouvre"
    # Évite de re-décider la même capacité (ex. branche SMB puis osi-next)
    # ce qui saturait le budget réseau et faisait échouer les labs.
    deja.add(cap_id)
    return {
        "noeud": noeud,
        "cap": cap_id,
        "etat": etat,
        "why": pol["why"],
        "outil": cap.get("outil"),
        "sondes": list(cap.get("sondes") or ()),
        "gate": bool(pol.get("gate")),
    }


def raisonner(
    mission: Mission | None = None,
    *,
    hosts: list[Host] | None = None,
    plan: dict[str, Any] | None = None,
    equipe: str = "blue",
    autorisations: dict[str, Any] | None = None,
    temps: float = 7200.0,
    checkpoint: dict[str, Any] | None = None,
    journal: Any | None = None,
) -> dict[str, Any]:
    """Un cycle de raisonnement. Les outils ne sont que des capacités."""
    m = mission or Mission()
    hosts = hosts or []
    plan = plan or {}
    ctx = contexte(m, equipe=equipe, autorisations=autorisations, plan=plan)
    events = observer(hosts, m)
    budget = _budget_init(temps)
    deja = set(str(x) for x in ((checkpoint or {}).get("nodes_done") or []))
    decisions: list[dict[str, Any]] = []

    if journal is not None:
        journal.phase("Cerveau adaptatif")
        journal.note(
            "Orchestrateur de raisonnement. Pas un simulateur PASSI. "
            "Les outils sont des capacités interchangeables."
        )

    # Racine : périmètre, découverte, classification (toujours si mandat).
    for noeud, cap_id, need in (
        ("scope", "nmap_discover", ""),
        ("priority", "nmap_priority", "host_discovered" if hosts else ""),
        ("fingerprint", "nmap_fingerprint", "port_open" if hosts else ""),
    ):
        # Sans hôtes, discover reste « ouvre » (à jouer). Priority/fingerprint
        # attendent un événement — si le checkup n'a pas encore tourné, on ouvre
        # discover seulement.
        if cap_id == "nmap_discover" and not ctx.get("mandat"):
            d = {
                "noeud": noeud,
                "cap": cap_id,
                "etat": "refuse",
                "why": "mandat absent",
            }
        elif cap_id != "nmap_discover" and not hosts:
            d = _decision(
                noeud=noeud,
                cap_id=cap_id,
                events=events,
                ctx=ctx,
                budget=budget,
                deja=deja,
                need_event="host_discovered",
            )
            if d["etat"] == "prune":
                d["why"] = "pas encore d'hôtes — en attente de discover"
        else:
            d = _decision(
                noeud=noeud,
                cap_id=cap_id,
                events=events,
                ctx=ctx,
                budget=budget,
                deja=deja,
                need_event=need,
            )
        decisions.append(d)
        if journal is not None:
            _journaliser(journal, d)

    # Branches conditionnelles.
    for ev, cap_id, noeud in BRANCHES:
        d = _decision(
            noeud=noeud.lower() + ":" + cap_id,
            cap_id=cap_id,
            events=events,
            ctx=ctx,
            budget=budget,
            deja=deja,
            need_event=ev,
        )
        decisions.append(d)
        if journal is not None:
            _journaliser(journal, d)

    # Capacités hors branche : lynis / gvm si plan, avenant toujours refusé.
    if plan.get("lynis"):
        d = _decision(
            noeud="systeme",
            cap_id="lynis_operator",
            events=events,
            ctx=ctx,
            budget=budget,
            deja=deja,
        )
        decisions.append(d)
        if journal is not None:
            _journaliser(journal, d)
    if plan.get("greenbone"):
        d = _decision(
            noeud="vulns",
            cap_id="gvm_read",
            events=events,
            ctx=ctx,
            budget=budget,
            deja=deja,
        )
        decisions.append(d)
        if journal is not None:
            _journaliser(journal, d)

    for cap_id in ("zap_active", "metasploit", "ffuf", "impacket"):
        d = _decision(
            noeud="avenant:" + cap_id,
            cap_id=cap_id,
            events=events,
            ctx=ctx,
            budget=budget,
            deja=deja,
        )
        decisions.append(d)
        if journal is not None:
            _journaliser(journal, d)


    # Couches suivantes (parcimonieux) après préconditions validées
    try:
        from guardia.engines.osi_map import attach_host_osi, couverture_osi, next_layer_propositions

        attach_host_osi(
            hosts,
            cidr=str(m.cidr or ""),
        )
        next_props = next_layer_propositions(
            events,
            budget_left=max(0, int(budget.get("reseau") or 0) - int(budget.get("spent_reseau") or 0)),
        )
        for np in next_props:
            # Ouvre une décision logique sans inventer de scanner
            cap_hint = {
                "next-tls-web": "http_headers",
                "next-smb": "smb_read",
                "next-ot": "ot_safe",
                "next-web-rgpd": "http_headers",
                "next-admin": "admin_surface",
                "next-ldap": "bloodhound",
            }.get(np["id"], "")
            if not cap_hint or cap_hint in deja:
                continue
            need_map = {
                "http_headers": "http_seen",
                "smb_read": "smb_seen",
                "ot_safe": "ot_seen",
                "admin_surface": "exposed_admin_service",
                "bloodhound": "ldap_seen",
            }
            # url_mandatee suffit pour http_headers si pas encore http_seen
            need = need_map.get(cap_hint, "")
            if cap_hint == "http_headers" and _has(events, "url_mandatee"):
                need = ""
            d = _decision(
                noeud="osi-next:" + np["id"],
                cap_id=cap_hint,
                events=events,
                ctx=ctx,
                budget=budget,
                deja=deja,
                need_event=need,
            )
            d["osi_layer"] = np.get("layer")
            d["nature_action"] = "démonstration d'exposition (lecture)"
            d["why"] = (d.get("why") or "") + " · " + (np.get("why") or "") + " · démo lecture (pas d'exploit)"
            decisions.append(d)
            if journal is not None:
                _journaliser(journal, d)
    except Exception as exc:  # noqa: BLE001
        if journal is not None:
            journal.skip("osi-next", str(exc))

    # Directives PASSI / CNIL lorsque flags validés
    directives: list = []
    try:
        from guardia.cerveau.directives_passi_cnil import emit_directives, schedule_within_budget

        ex = m.extras or {}
        want_p = bool(ex.get("passi") or plan.get("passi") or ex.get("offre_passi"))
        want_r = bool(ex.get("rgpd") or plan.get("rgpd") or plan.get("site_url") or ex.get("site_url"))
        if want_p or want_r:
            mandat_ok = bool(ctx.get("mandat"))
            directives = emit_directives(
                m,
                hosts=hosts,
                events=events,
                plan=plan,
                mandat_ok=mandat_ok,
            )
            directives = schedule_within_budget(directives)
            for ddir in directives:
                if journal is not None:
                    st = ddir.get("status") or ""
                    nom = f"dir:{ddir.get('id')}"
                    if st in ("opened", "proposed", "done"):
                        journal.outil(nom, st, "ok")
                    else:
                        journal.skip(nom, f"{st} — {ddir.get('why')}")
                # Reflet dans décisions (traçabilité)
                decisions.append(
                    {
                        "noeud": "dir:" + str(ddir.get("id")),
                        "cap": ddir.get("outil"),
                        "etat": {
                            "proposed": "porte",
                            "opened": "ouvre",
                            "blocked": "bloque_policy",
                            "done": "repris",
                        }.get(str(ddir.get("status")), "prune"),
                        "why": ddir.get("why"),
                        "outil": ddir.get("outil"),
                        "osi_layer": ddir.get("layer"),
                        "passi_activity": ddir.get("passi_activity"),
                        "cnil_theme": ddir.get("cnil_theme"),
                        "nature_action": ddir.get("nature_action"),
                        "directive": True,
                    }
                )
    except Exception as exc:  # noqa: BLE001
        if journal is not None:
            journal.skip("directives PASSI/CNIL", str(exc))

    groq_pack: dict = {}
    try:
        from guardia.engines.llm_groq_directives import interrogate, want_groq

        if want_groq(None, m) or bool(plan.get("llm_groq")):
            findings_flat = []
            for h in hosts or []:
                for f in h.findings or []:
                    findings_flat.append(f.to_dict() if hasattr(f, "to_dict") else f)
            groq_pack = interrogate(
                m,
                hosts=hosts,
                findings=findings_flat,
                directives_locales=directives,
                osi_couverture=None,
                plan=plan,
            )
            # Fusionne propositions Groq (après locales) — toujours « à valider »
            for gd in groq_pack.get("directives") or []:
                if not isinstance(gd, dict):
                    continue
                gid = str(gd.get("id") or "")
                if any(str(x.get("id")) == gid for x in directives):
                    continue
                directives.append(gd)
                decisions.append(
                    {
                        "noeud": "groq:" + gid,
                        "cap": gd.get("outil"),
                        "etat": "porte",
                        "why": (gd.get("why") or "") + " · proposition opérateur / à valider",
                        "outil": gd.get("outil"),
                        "osi_layer": gd.get("layer"),
                        "nature_action": gd.get("nature_action")
                        or "démonstration d'exposition (lecture)",
                        "directive": True,
                        "source": "groq",
                    }
                )
            if journal is not None:
                if groq_pack.get("ok"):
                    journal.outil("llm_groq", groq_pack.get("model") or "groq", "ok")
                else:
                    journal.skip("llm_groq", groq_pack.get("skipped") or "indisponible")
    except Exception as exc:  # noqa: BLE001
        if journal is not None:
            journal.skip("llm_groq", str(exc))
        groq_pack = {}

    osi_cov = {}
    try:
        from guardia.engines.osi_map import couverture_osi

        osi_cov = couverture_osi(
            hosts,
            events,
            cidr=str(m.cidr or ""),
            website={"ok": True} if (plan.get("site_url") or (m.extras or {}).get("site_url")) else None,
            rgpd={"ok": True} if (plan.get("rgpd") or (m.extras or {}).get("rgpd")) else None,
        )
        if journal is not None and osi_cov.get("resume"):
            journal.note(osi_cov["resume"])
    except Exception:
        osi_cov = {}

    graphe = construire(hosts, m)
    paths = chemins(hosts, graphe)
    evid = collecter(hosts, m)
    candidats = normaliser_findings(hosts)

    portes: list[dict[str, Any]] = []
    for d in decisions:
        if d.get("etat") == "porte":
            portes.append(
                {
                    "id": f"G-{d.get('cap')}",
                    "kind": "approfondir",
                    "proposition": f"{d.get('cap')} — {d.get('why')}",
                    "etat": "propose",
                    "confiance": 0.9,
                }
            )
        if d.get("etat") == "bloque_policy":
            portes.append(
                {
                    "id": f"G-{d.get('cap')}",
                    "kind": "avenant",
                    "proposition": f"{d.get('outil')} bloqué",
                    "etat": "bloque_policy",
                    "confiance": 1.0,
                    "motif": d.get("why"),
                }
            )
    for ev in events:
        if ev.get("type") == "exposed_admin_service":
            portes.append(
                {
                    "id": f"G-admin-{ev.get('asset')}-{ev.get('port')}",
                    "kind": "approfondir",
                    "proposition": (
                        f"Interface d'administration sur {ev.get('asset')}:{ev.get('port')}. "
                        "Fingerprint HTTP passif proposé."
                    ),
                    "etat": "propose",
                    "confiance": ev.get("confidence") or 0.9,
                    "impact": "eleve",
                    "asset": ev.get("asset"),
                }
            )

    skip_sondes: list[str] = []
    play_sondes: list[str] = []
    for d in decisions:
        for s in d.get("sondes") or []:
            if d.get("etat") in ("ouvre", "porte"):
                play_sondes.append(s)
            elif d.get("etat") in ("prune", "budget", "refuse", "bloque_policy"):
                skip_sondes.append(s)

    n_ouvre = sum(1 for d in decisions if d.get("etat") in ("ouvre", "porte"))
    n_prune = sum(1 for d in decisions if d.get("etat") == "prune")
    n_refuse = sum(1 for d in decisions if d.get("etat") in ("refuse", "bloque_policy"))
    n_budget = sum(1 for d in decisions if d.get("etat") == "budget")
    n_repris = sum(1 for d in decisions if d.get("etat") == "repris")

    synthese = (
        f"{len(hosts)} actif(s) · "
        f"{sum(1 for e in events if e.get('type') == 'port_open')} service(s) observé(s) · "
        f"{n_ouvre} chemin(s) d'analyse ouvert(s) · "
        f"{n_prune} écarté(s) · "
        f"{n_refuse} refusé(s) par policy · "
        f"{len(candidats)} finding(s) candidat(s) · "
        f"{len(paths)} chemin(s) d'exposition · "
        f"{len([p for p in portes if p.get('etat') == 'propose'])} action(s) proposée(s) à l'auditeur"
    )
    if journal is not None:
        journal.note(synthese)

    nodes_done = [d["noeud"] for d in decisions if d.get("etat") in ("ouvre", "repris")]
    brain = {
        "version": "1.2.6",
        "nature": (
            "Orchestrateur de raisonnement d'audit défensif. "
            "Pas un simulateur PASSI. "
            "Les capacités logicielles ne sont pas une qualification organisationnelle."
        ),
        "passi_qualifie": False,
        "certificat": False,
        "ctx": ctx,
        "budget": budget,
        "evenements": events,
        "n_evenements": len(events),
        "decisions": decisions,
        "n_ouverts": n_ouvre,
        "n_ecartes": n_prune,
        "n_refuses_policy": n_refuse,
        "n_budget": n_budget,
        "n_repris": n_repris,
        "graphe": graphe,
        "chemins": paths,
        "evidence": evid,
        "findings_candidats": candidats,
        "portes": portes,
        "skip_sondes": sorted(set(skip_sondes)),
        "play_sondes": sorted(set(play_sondes)),
        "synthese": synthese,
        "nodes_done": nodes_done,
        "osi_couverture": osi_cov,
        "directives_passi_cnil": directives,
        "llm_groq": groq_pack,
        "capacites": [
            {
                "id": c["id"],
                "outil": c["outil"],
                "authorization": c["authorization"],
                "reseau": c["reseau"],
                "avenant": bool(c.get("avenant")),
            }
            for c in CAPACITES
        ],
    }
    return brain


def _journaliser(journal: Any, d: dict[str, Any]) -> None:
    nom = f"{d.get('noeud')} {d.get('cap')}"
    etat = d.get("etat") or ""
    why = d.get("why") or ""
    if etat in ("ouvre", "porte", "repris"):
        journal.outil(nom, etat, "ok")
    else:
        journal.skip(nom, f"{etat} — {why}")


def ecrire_checkpoint(brain: dict[str, Any], path: Path) -> Path:
    path.parent.mkdir(parents=True, exist_ok=True)
    slim = {
        "version": brain.get("version"),
        "nodes_done": brain.get("nodes_done") or [],
        "budget": brain.get("budget") or {},
        "n_evenements": brain.get("n_evenements") or 0,
        "synthese": brain.get("synthese") or "",
    }
    path.write_text(json.dumps(slim, ensure_ascii=False, indent=2), encoding="utf-8")
    return path


def lire_checkpoint(path: Path) -> dict[str, Any]:
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return {}
    return data if isinstance(data, dict) else {}


def reprendre(
    mission: Mission | None = None,
    *,
    checkpoint: dict[str, Any] | Path | None = None,
    **kwargs: Any,
) -> dict[str, Any]:
    """Une mission interrompue reprend les nœuds restants."""
    ck: dict[str, Any] = {}
    if isinstance(checkpoint, Path):
        ck = lire_checkpoint(checkpoint)
    elif isinstance(checkpoint, dict):
        ck = checkpoint
    return raisonner(mission, checkpoint=ck, **kwargs)
