"""Preuve d'abord — jamais un outil qui devient finding tout seul."""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from typing import Any

from guardia.core.models import Finding, Host, Mission


def _sha(blob: str) -> str:
    return hashlib.sha256(blob.encode("utf-8", errors="replace")).hexdigest()[:16]


def _now() -> str:
    return datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def from_finding(
    f: Finding | dict[str, Any],
    *,
    mission: Mission | None = None,
    asset: str = "",
    action: str = "",
) -> dict[str, Any]:
    if isinstance(f, dict):
        cmd = str(f.get("commande") or f.get("preuve_repro") or f.get("preuve") or "")
        fid = str(f.get("id") or "")
        titre = str(f.get("titre") or "")
        hote = str(f.get("hote") or asset)
        preuve = str(f.get("preuve") or "")
    else:
        cmd = str(getattr(f, "commande", "") or getattr(f, "preuve_repro", "") or getattr(f, "preuve", "") or "")
        fid = str(getattr(f, "id", "") or "")
        titre = str(getattr(f, "titre", "") or "")
        hote = str(getattr(f, "hote", "") or asset)
        preuve = str(getattr(f, "preuve", "") or "")
    client = mission.client if mission else ""
    raw = f"{client}|{hote}|{action}|{cmd}|{preuve}"
    return {
        "id": f"E-{_sha(raw)}",
        "mission": client,
        "asset": hote,
        "action": action or fid,
        "timestamp": _now(),
        "operator": (mission.operateur_nom if mission else "") or "",
        "command": cmd,
        "stdout": preuve[:400],
        "stderr": "",
        "exit_code": None,
        "tool_version": "",
        "environment": "lecture",
        "scope": (mission.cidr if mission else "") or "",
        "sha256": _sha(raw),
        "finding_id": fid,
        "observation": titre,
    }


def collecter(hosts: list[Host], mission: Mission | None = None) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    seen: set[str] = set()
    for h in hosts or []:
        for f in h.findings or []:
            ev = from_finding(f, mission=mission, asset=h.ip)
            if ev["id"] in seen:
                continue
            seen.add(ev["id"])
            out.append(ev)
    return out


def normaliser_findings(hosts: list[Host]) -> list[dict[str, Any]]:
    """Candidats : un thème, plusieurs preuves. La corrélation décide ensuite."""
    by: dict[str, dict[str, Any]] = {}
    for h in hosts or []:
        for f in h.findings or []:
            key = (getattr(f, "id", "") or "")[:24] or getattr(f, "titre", "")
            item = by.setdefault(
                str(key),
                {
                    "id": str(getattr(f, "id", "") or key),
                    "titre": getattr(f, "titre", ""),
                    "hotes": [],
                    "preuves": [],
                    "gravite": getattr(getattr(f, "gravite", None), "value", None)
                    or str(getattr(f, "gravite", "") or "info"),
                    "confiance": 0.5,
                    "n": 0,
                },
            )
            item["n"] += 1
            if h.ip not in item["hotes"]:
                item["hotes"].append(h.ip)
            preuve = getattr(f, "preuve", "") or ""
            if preuve and preuve not in item["preuves"]:
                item["preuves"].append(preuve)
            item["confiance"] = min(0.95, 0.5 + 0.12 * item["n"])
            if item["n"] >= 2:
                item["niveau"] = "finding_candidat"
            else:
                item["niveau"] = "observation"
    return list(by.values())
