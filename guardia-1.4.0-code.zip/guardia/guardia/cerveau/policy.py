"""Policy engine + registre de capacités.

Ce n'est plus le développeur qui décide dans le code si un outil peut
tourner. C'est le mandat, le périmètre, le niveau, l'avenant.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Mission

# Niveaux d'autorisation. Le moteur actuel s'arrête à lecture.
NIVEAUX_AUTH = (
    "lecture",
    "web_read",
    "web_intrusive",
    "identity",
    "exploitation",
)

# Outils = capacités interchangeables. Coût réseau 0-30. Intrusivité 0 = lecture.
CAPACITES: tuple[dict[str, Any], ...] = (
    {
        "id": "nmap_discover",
        "outil": "nmap",
        "cap": "decouverte",
        "intrusivite": 0,
        "reseau": 2,
        "temps": 30,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("mandat", "cidr"),
        "produit": ("host_discovered",),
    },
    {
        "id": "nmap_priority",
        "outil": "nmap",
        "cap": "ports_prioritaires",
        "intrusivite": 0,
        "reseau": 5,
        "temps": 90,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("host_discovered",),
        "produit": ("port_open",),
    },
    {
        "id": "nmap_fingerprint",
        "outil": "nmap",
        "cap": "empreinte",
        "intrusivite": 0,
        "reseau": 4,
        "temps": 60,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("port_open",),
        "produit": ("service_fingerprint",),
    },
    {
        "id": "arp_scan",
        "outil": "arp-scan",
        "cap": "l2",
        "intrusivite": 0,
        "reseau": 1,
        "temps": 15,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("mandat", "cidr"),
        "produit": ("host_discovered",),
    },
    {
        "id": "tls_assessment",
        "outil": "testssl.sh",
        "cap": "tls",
        "intrusivite": 0,
        "reseau": 3,
        "temps": 40,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("tls_seen",),
        "produit": ("tls_weak",),
        "sondes": ("testssl", "sslscan"),
    },
    {
        "id": "http_headers",
        "outil": "curl",
        "cap": "http",
        "intrusivite": 0,
        "reseau": 2,
        "temps": 15,
        "mode": "non_intrusive",
        "scope": "url",
        "authorization": "web_read",
        "preconditions": ("http_seen",),
        "produit": ("http_surface",),
        "sondes": ("curl", "whatweb", "nmap-http"),
    },
    {
        "id": "nuclei_web",
        "outil": "nuclei",
        "cap": "web_info",
        "intrusivite": 0,
        "reseau": 4,
        "temps": 40,
        "mode": "non_intrusive",
        "scope": "url",
        "authorization": "web_read",
        "preconditions": ("http_seen",),
        "produit": ("web_info",),
        "sondes": ("nuclei-info", "nikto-info"),
    },
    {
        "id": "smb_read",
        "outil": "smbmap",
        "cap": "smb",
        "intrusivite": 0,
        "reseau": 3,
        "temps": 25,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("smb_seen",),
        "produit": ("share_names",),
        "sondes": ("smb-shares", "smbclient", "enum4linux"),
    },
    {
        "id": "rdp_read",
        "outil": "nmap",
        "cap": "rdp",
        "intrusivite": 0,
        "reseau": 2,
        "temps": 15,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("rdp_seen",),
        "produit": ("rdp_surface",),
        "sondes": ("rdp",),
    },
    {
        "id": "ot_safe",
        "outil": "nmap",
        "cap": "ot",
        "intrusivite": 0,
        "reseau": 2,
        "temps": 20,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("ot_seen",),
        "produit": ("ot_surface",),
        "sondes": ("ot-modbus", "ot-s7", "ot-opcua"),
    },
    {
        "id": "admin_surface",
        "outil": "curl",
        "cap": "admin",
        "intrusivite": 0,
        "reseau": 2,
        "temps": 15,
        "mode": "non_intrusive",
        "scope": "cidr",
        "authorization": "lecture",
        "preconditions": ("exposed_admin_service",),
        "produit": ("admin_banner",),
        "human_gate": "approfondir",
    },
    {
        "id": "lynis_operator",
        "outil": "lynis",
        "cap": "systeme",
        "intrusivite": 0,
        "reseau": 0,
        "temps": 40,
        "mode": "non_intrusive",
        "scope": "operator",
        "authorization": "lecture",
        "preconditions": ("mandat",),
        "produit": ("hygiene_poste",),
    },
    {
        "id": "gvm_read",
        "outil": "gvm-cli",
        "cap": "vulns_lecture",
        "intrusivite": 0,
        "reseau": 8,
        "temps": 30,
        "mode": "non_intrusive",
        "scope": "operator",
        "authorization": "lecture",
        "preconditions": ("mandat",),
        "produit": ("gvm_feeds",),
        "note": "lecture GMP, pas un Full and Fast",
    },
    {
        "id": "zap_active",
        "outil": "zaproxy",
        "cap": "web_intrusive",
        "intrusivite": 2,
        "reseau": 30,
        "temps": 600,
        "mode": "intrusive",
        "scope": "url",
        "authorization": "web_intrusive",
        "preconditions": ("http_seen",),
        "produit": ("zap_alerts",),
        "avenant": True,
        "human_approval": True,
    },
    {
        "id": "bloodhound",
        "outil": "bloodhound",
        "cap": "identity",
        "intrusivite": 2,
        "reseau": 10,
        "temps": 300,
        "mode": "intrusive",
        "scope": "directory",
        "authorization": "identity",
        "preconditions": ("ldap_seen",),
        "produit": ("ad_paths",),
        "avenant": True,
        "human_approval": True,
        "data_export": True,
    },
    {
        "id": "impacket",
        "outil": "impacket-scripts",
        "cap": "identity",
        "intrusivite": 2,
        "reseau": 8,
        "temps": 120,
        "mode": "intrusive",
        "scope": "directory",
        "authorization": "identity",
        "preconditions": ("smb_seen",),
        "produit": ("ad_auth",),
        "avenant": True,
        "human_approval": True,
    },
    {
        "id": "metasploit",
        "outil": "metasploit-framework",
        "cap": "exploitation",
        "intrusivite": 3,
        "reseau": 20,
        "temps": 300,
        "mode": "exploitation",
        "scope": "cidr",
        "authorization": "exploitation",
        "preconditions": ("host_discovered",),
        "produit": ("exploit",),
        "avenant": True,
        "human_approval": True,
        "emergency_stop": True,
    },
    {
        "id": "ffuf",
        "outil": "ffuf",
        "cap": "web_fuzz",
        "intrusivite": 1,
        "reseau": 15,
        "temps": 180,
        "mode": "intrusive",
        "scope": "url",
        "authorization": "web_intrusive",
        "preconditions": ("http_seen",),
        "produit": ("dirs",),
        "avenant": True,
        "human_approval": True,
    },
)

CAP_BY_ID = {c["id"]: c for c in CAPACITES}


def contexte(
    mission: Mission | None,
    *,
    equipe: str = "blue",
    autorisations: dict[str, Any] | None = None,
    plan: dict[str, Any] | None = None,
) -> dict[str, Any]:
    m = mission or Mission()
    ex = m.extras or {}
    auth = autorisations or {}
    plan = plan or {}
    url = str(ex.get("site_url") or plan.get("site_url") or "")
    interdit = ex.get("interdit") or []
    if isinstance(interdit, str):
        interdit = [interdit]
    exclusions = [str(x) for x in interdit] or [
        "exploitation",
        "hors_perimetre",
        "dump_annuaire",
        "brute_force",
    ]
    yaml_auth = ex.get("authorization") if isinstance(ex.get("authorization"), dict) else {}
    return {
        "client": m.client,
        "cidr": m.cidr or "",
        "url": url,
        "mandat": bool(m.mandat_nda_signes),
        "operateur": m.operateur_nom or "",
        "operateur_signe": bool(m.operateur_signe),
        "equipe": equipe,
        "red": equipe == "red",
        "liasse": bool(auth.get("complet")),
        "exclusions": exclusions,
        "fenetre": str(ex.get("date") or ex.get("fenetre") or ""),
        "lynis": bool(plan.get("lynis")),
        "greenbone": bool(plan.get("greenbone")),
        "site": bool(url),
        "machines": bool(plan.get("machines")),
        "network_scan": yaml_auth.get("network_scan", True) is not False,
        "service_detection": yaml_auth.get("service_detection", True) is not False,
        "web_readonly": bool(yaml_auth.get("web_readonly") or yaml_auth.get("web_read") or url),
        "intrusive_testing": bool(yaml_auth.get("intrusive_testing")),
        "exploitation": bool(yaml_auth.get("exploitation")),
    }


def _auth_ok(need: str, ctx: dict[str, Any]) -> tuple[bool, str]:
    if need == "lecture":
        if not ctx.get("mandat"):
            return False, "mandat absent"
        if ctx.get("network_scan") is False:
            return False, "network_scan interdit par le mandat"
        return True, "lecture — mandat"
    if need == "web_read":
        if not ctx.get("mandat"):
            return False, "mandat absent"
        if not ctx.get("url"):
            return False, "URL absente du mandat"
        if ctx.get("web_readonly") is False:
            return False, "web_readonly interdit par le mandat"
        return True, "web_read — URL du mandat"
    if need in ("web_intrusive", "identity", "exploitation"):
        # Même si le YAML demande l'exploitation : jamais auto. Avenant.
        return False, f"{need} — avenant, jamais auto"
    return False, f"autorisation inconnue : {need}"


def autoriser(cap: dict[str, Any] | str, ctx: dict[str, Any]) -> dict[str, Any]:
    """Une action, une décision. Pas un if dispersé dans le CLI."""
    if isinstance(cap, str):
        cap = CAP_BY_ID.get(cap) or {"id": cap, "authorization": "lecture"}
    cid = str(cap.get("id") or "")
    need = str(cap.get("authorization") or "lecture")
    ok, why = _auth_ok(need, ctx)
    if cap.get("avenant") or cap.get("human_approval"):
        ok = False
        why = cap.get("note") or "avenant — jamais lancé auto"
        return {
            "id": cid,
            "ok": False,
            "etat": "bloque_policy",
            "why": why,
            "gate": True,
            "avenant": True,
            "outil": cap.get("outil") or cid,
        }
    if not ok:
        return {
            "id": cid,
            "ok": False,
            "etat": "refuse",
            "why": why,
            "gate": False,
            "avenant": False,
            "outil": cap.get("outil") or cid,
        }
    return {
        "id": cid,
        "ok": True,
        "etat": "autorise",
        "why": why,
        "gate": bool(cap.get("human_gate")),
        "avenant": False,
        "outil": cap.get("outil") or cid,
    }
