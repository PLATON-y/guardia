"""Directives orchestrateur PASSI (dossier d'appui) + CNIL/RGPD (signalement).

Émises après validation des préconditions (mandat, observations).
Jamais une qualification ANSSI, jamais un certificat de conformité CNIL.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Host, Mission

# Bundles d'activité PASSI v2.2 (appui prestation) → outils Guardia existants
PASSI_BUNDLES: tuple[dict[str, Any], ...] = (
    {
        "id": "passi-orga",
        "passi_activity": "organisationnel_physique",
        "layer": "L1-L7",
        "outil": "passi_assessment",
        "precondition": "passi_flag",
        "why": "Bundle orga/physique — preuves documentaires et observations",
    },
    {
        "id": "passi-archi",
        "passi_activity": "architecture",
        "layer": "L2-L3",
        "outil": "passi_alignment",
        "precondition": "host_or_cidr",
        "why": "Architecture observée (cartographie, flux) — dossier d'appui",
    },
    {
        "id": "passi-conf",
        "passi_activity": "configuration",
        "layer": "L4-L7",
        "outil": "hygiene+audit_pass",
        "precondition": "port_open",
        "why": "Configuration à partir des ports/TLS/SMB/web observés",
    },
    {
        "id": "passi-code",
        "passi_activity": "code_source",
        "layer": "L7",
        "outil": "passi_assessment",
        "precondition": "code_scope_or_human",
        "why": "Revue de code — porte humaine / corpus nommé",
    },
    {
        "id": "passi-intrusion-read",
        "passi_activity": "intrusion",
        "layer": "L4-L7",
        "outil": "passi_assessment",
        "precondition": "avenant_human",
        "why": "Tests d'intrusion encadrés — lecture autorisée uniquement, validation humaine",
    },
)

CNIL_DIRECTIVES: tuple[dict[str, Any], ...] = (
    {
        "id": "cnil-web-tls",
        "cnil_theme": "securite_traitement_https",
        "layer": "L6",
        "outil": "web_audit",
        "precondition": "url_or_https",
        "why": "Contrôle TLS / HTTPS du site mandaté (signalement, pas certificat)",
    },
    {
        "id": "cnil-headers-cookies",
        "cnil_theme": "cookies_en_tetes",
        "layer": "L7",
        "outil": "web_audit",
        "precondition": "url_or_http",
        "why": "En-têtes HTTP et cookies observés — éléments de signalement RGPD",
    },
    {
        "id": "cnil-rgpd-signal",
        "cnil_theme": "signalement_rgpd",
        "layer": "L7",
        "outil": "rgpd_signal",
        "precondition": "rgpd_flag_or_url",
        "why": "Fiche signalement RGPD (observé / déclaré / non observé)",
    },
)


def _extras(mission: Mission) -> dict[str, Any]:
    return mission.extras if isinstance(mission.extras, dict) else {}


def _truthy(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    if v is None:
        return False
    s = str(v).strip().lower()
    return s in ("1", "true", "oui", "yes", "on")


def _has_ports(hosts: list[Host]) -> bool:
    for h in hosts or []:
        if h.ports:
            return True
    return False


def _event_types(events: list[dict[str, Any]]) -> set[str]:
    return {str(e.get("type") or "") for e in events or []}


def _url(mission: Mission, plan: dict[str, Any] | None) -> str:
    plan = plan or {}
    u = str(plan.get("site_url") or "").strip()
    if u:
        return u
    ex = _extras(mission)
    for k in ("site_url", "site", "urls"):
        v = ex.get(k)
        if isinstance(v, list) and v:
            return str(v[0]).strip()
        if v and str(v).strip().lower() not in ("1", "true", "oui", "yes"):
            return str(v).strip()
    # mission.scope.urls éventuel dans extras.mission
    scope = (ex.get("mission") or {}).get("scope") if isinstance(ex.get("mission"), dict) else None
    if isinstance(scope, dict):
        urls = scope.get("urls") or []
        if urls:
            return str(urls[0]).strip()
    return ""


def emit_directives(
    mission: Mission | None = None,
    *,
    hosts: list[Host] | None = None,
    events: list[dict[str, Any]] | None = None,
    plan: dict[str, Any] | None = None,
    mandat_ok: bool = False,
    budget: int = 12,
) -> list[dict[str, Any]]:
    """Liste ordonnée de directives PASSI/CNIL (proposed|opened|blocked|done).

    ``status`` :
    - proposed : préconditions OK, à planifier
    - opened : branche déjà ouverte par le cerveau (événement présent)
    - blocked : mandat absent ou avenant requis
    - done : outil déjà joué (plan / résultat)
    """
    m = mission or Mission()
    hosts = hosts or []
    events = events or []
    plan = plan or {}
    ex = _extras(m)
    types = _event_types(events)
    url = _url(m, plan)
    want_passi = _truthy(ex.get("passi")) or _truthy(plan.get("passi")) or _truthy(ex.get("offre_passi"))
    want_rgpd = (
        _truthy(ex.get("rgpd"))
        or _truthy(plan.get("rgpd"))
        or bool(url)
        or _truthy(ex.get("audit_full"))
    )
    # Si ni passi ni rgpd demandés, rien — sauf URL qui peut ouvrir le volet CNIL léger
    if not want_passi and not want_rgpd and not url:
        return []

    out: list[dict[str, Any]] = []

    def _push(d: dict[str, Any], status: str, note: str = "", *, exploitation: bool = False) -> None:
        if len(out) >= budget:
            return
        # Lecture / démo vs exploitation bloquée
        if exploitation or status == "blocked" and "avenant" in (note or d.get("why") or "").lower():
            nature = "exploitation (bloquée — avenant + validation humaine)"
        elif "intrusion" in str(d.get("passi_activity") or ""):
            nature = (
                "exploitation (bloquée — avenant + validation humaine)"
                if status == "blocked"
                else "démonstration d'exposition (lecture)"
            )
        else:
            nature = "démonstration d'exposition (lecture)"
        item = {
            "id": d["id"],
            "layer": d.get("layer") or "",
            "passi_activity": d.get("passi_activity"),
            "cnil_theme": d.get("cnil_theme"),
            "outil": d.get("outil") or "",
            "precondition": d.get("precondition") or "",
            "status": status,
            "why": note or d.get("why") or "",
            "nature_action": nature,
            "fenetre": "plage d'audit (temps de charge) — time-box mission",
        }
        out.append(item)

    if want_passi:
        for b in PASSI_BUNDLES:
            pre = b["precondition"]
            if not mandat_ok:
                _push(b, "blocked", "Mandat non validé — directive PASSI bloquée")
                continue
            if pre == "passi_flag":
                _push(b, "proposed")
            elif pre == "host_or_cidr":
                if hosts or m.cidr or types.intersection({"host_discovered", "scope"}):
                    st = "opened" if hosts else "proposed"
                    _push(b, st)
                else:
                    _push(b, "proposed", "En attente d'inventaire / CIDR")
            elif pre == "port_open":
                if _has_ports(hosts) or "port_open" in types:
                    _push(b, "opened", b["why"] + " — ports observés")
                else:
                    _push(b, "proposed", "En attente de services (L4)")
            elif pre == "code_scope_or_human":
                if ex.get("code_scope") or ex.get("code"):
                    _push(b, "proposed", "Corpus nommé — revue humaine")
                else:
                    _push(b, "blocked", "Corpus code absent — porte humaine")
            elif pre == "avenant_human":
                _push(b, "blocked", "Intrusion : avenant + validation humaine (jamais auto)", exploitation=True)
            else:
                _push(b, "proposed")

    if want_rgpd or url:
        for c in CNIL_DIRECTIVES:
            if not mandat_ok and c["id"] != "cnil-rgpd-signal":
                # signalement déclaratif peut se préparer hors scan ; web TLS exige mandat
                if c["outil"] == "web_audit":
                    _push(c, "blocked", "Mandat non validé — contrôle web bloqué")
                    continue
            pre = c["precondition"]
            if pre in ("url_or_https", "url_or_http"):
                if url or "url_mandatee" in types or "tls_seen" in types or "http_seen" in types:
                    st = "opened" if (url or "http_seen" in types or "tls_seen" in types) else "proposed"
                    if plan.get("site_url") or plan.get("website_done"):
                        st = "done" if plan.get("website_done") else st
                    _push(c, st)
                else:
                    _push(c, "proposed", "URL absente — préremplir site_url (ex. https://pctamalou.fr)")
            elif pre == "rgpd_flag_or_url":
                if plan.get("rgpd_done"):
                    _push(c, "done", "Signalement déjà produit")
                elif want_rgpd or url:
                    _push(c, "proposed" if mandat_ok else "proposed", c["why"])
                else:
                    _push(c, "blocked", "rgpd: false et pas d'URL")
            else:
                _push(c, "proposed")

    # Enrichissement configuration depuis observations live (ports TLS/SMB/web)
    if want_passi and mandat_ok and (_has_ports(hosts) or types):
        if "tls_seen" in types or any(
            isinstance(p, dict) and int(p.get("port") or 0) in (443, 8443)
            for h in hosts
            for p in (h.ports or [])
        ):
            out.append(
                {
                    "id": "passi-conf-tls",
                    "layer": "L6",
                    "passi_activity": "configuration",
                    "cnil_theme": None,
                    "outil": "web_audit",
                    "precondition": "tls_seen",
                    "status": "opened",
                    "why": "TLS observé → alimente contrôles configuration / preuves PASSI",
                    "nature_action": "démonstration d'exposition (lecture)",
                    "fenetre": "plage d'audit (temps de charge) — time-box mission",
                }
            )
        if "smb_seen" in types:
            out.append(
                {
                    "id": "passi-conf-smb",
                    "layer": "L7",
                    "passi_activity": "configuration",
                    "cnil_theme": None,
                    "outil": "hygiene",
                    "precondition": "smb_seen",
                    "status": "opened",
                    "why": "SMB observé → hygiène configuration (lecture)",
                    "nature_action": "démonstration d'exposition (lecture)",
                    "fenetre": "plage d'audit (temps de charge) — time-box mission",
                }
            )
        if url or "http_seen" in types:
            out.append(
                {
                    "id": "passi-conf-web-headers",
                    "layer": "L7",
                    "passi_activity": "configuration",
                    "cnil_theme": "cookies_en_tetes",
                    "outil": "web_audit",
                    "precondition": "http_or_url",
                    "status": "opened",
                    "why": "HTTP/URL → en-têtes web pour couverture configuration + signalement",
                    "nature_action": "démonstration d'exposition (lecture)",
                    "fenetre": "plage d'audit (temps de charge) — time-box mission",
                }
            )


    # Mode full / audit-full : ouvrir lectures sûres max (pas d'exploit)
    mode_full = (
        _truthy(ex.get("audit_full"))
        or _truthy(ex.get("parc_inconnu"))
        or (m.profondeur or "") == "full"
        or _truthy(plan.get("profond"))
        or _truthy(ex.get("cve"))
    )
    if mode_full and mandat_ok and hosts:
        try:
            from guardia.engines.osi_map import next_layer_propositions_full

            for prop in next_layer_propositions_full(hosts, events, budget_left=max(4, budget - len(out))):
                if len(out) >= budget:
                    break
                out.append(
                    {
                        "id": prop["id"],
                        "layer": prop.get("layer") or "",
                        "passi_activity": "configuration",
                        "cnil_theme": None,
                        "outil": prop.get("outil") or "",
                        "precondition": "full_read_surface",
                        "status": "proposed",
                        "why": prop.get("why") or "Lecture max surface exposée",
                        "nature_action": "démonstration d'exposition (lecture)",
                        "fenetre": "plage d'audit (temps de charge) — time-box mission",
                    }
                )
        except Exception:
            pass

    return out[:budget]


def schedule_within_budget(
    directives: list[dict[str, Any]],
    *,
    max_open: int = 6,
) -> list[dict[str, Any]]:
    """Ordonne pour la plage d'audit : opened puis proposed ; ne tronque pas.

    Au-delà de ``max_open`` playables, les ``proposed`` restent listées
    (time-box / report dans la fenêtre). Les ``blocked`` (exploitation) restent
    visibles en fin de liste, non jouées.
    """
    prio = {"opened": 0, "proposed": 1, "done": 2, "blocked": 3}
    ordered = sorted(
        directives,
        key=lambda d: (prio.get(str(d.get("status")), 9), d.get("id") or ""),
    )
    playable_idx = 0
    out: list[dict[str, Any]] = []
    for d in ordered:
        item = dict(d)
        if item.get("status") in ("opened", "proposed"):
            playable_idx += 1
            if playable_idx > max_open and item.get("status") == "proposed":
                why = item.get("why") or ""
                if "budget directives" not in why:
                    item["why"] = (why + " · reporté dans la plage d'audit (budget directives)").strip(" ·")
            item.setdefault("fenetre", "plage d'audit (temps de charge) — time-box mission")
            item.setdefault("nature_action", "démonstration d'exposition (lecture)")
        out.append(item)
    return out
