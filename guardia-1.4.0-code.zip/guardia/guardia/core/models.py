from __future__ import annotations

from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any


class Gravite(str, Enum):
    CRITIQUE = "critique"
    HAUTE = "haute"
    MOYENNE = "moyenne"
    BASSE = "basse"
    INFO = "info"


class Posture(str, Enum):
    OK = "ok"
    SURVEILLANCE = "surveillance"
    RISQUE = "risque"
    CRITIQUE = "critique"
    INCONNU = "inconnu"


@dataclass
class Finding:
    id: str
    titre: str
    pourquoi_nuit: str
    preuve: str
    remede_etapes: list[str]
    qui_peut: str
    priorite: str  # tout_de_suite | cette_semaine | plus_tard
    gravite: Gravite
    hote: str = ""
    preuve_repro: str = ""  # commande lecture seule, pas un exploit
    observation: str = ""
    commande: str = ""
    interpretation: str = ""
    statut_auditeur: str = "a_investiguer"  # confirmee | non_reproductible | faux_positif | a_investiguer

    def to_dict(self) -> dict[str, Any]:
        d = asdict(self)
        d["gravite"] = self.gravite.value
        return d


@dataclass
class Host:
    ip: str
    hostname: str = ""
    mac: str = ""
    vendor: str = ""
    kind: str = "inconnu"  # box, pc, tv, phone, printer, nas, iot, console...
    ports: list[dict[str, Any]] = field(default_factory=list)
    posture: Posture = Posture.INCONNU
    findings: list[Finding] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    osi_layers: list[str] = field(default_factory=list)  # L1–L7 observés (défensif)

    def to_dict(self) -> dict[str, Any]:
        return {
            "ip": self.ip,
            "hostname": self.hostname,
            "mac": self.mac,
            "vendor": self.vendor,
            "kind": self.kind,
            "ports": self.ports,
            "posture": self.posture.value,
            "findings": [f.to_dict() for f in self.findings],
            "notes": self.notes,
            "errors": self.errors,
            "osi_layers": list(self.osi_layers or []),
        }


@dataclass
class Mission:
    client: str = "Client"
    personne_commune: str = ""
    type_structure: str = "foyer"
    profil_moteur: str = "maison"
    profondeur: str = "standard"  # doux|standard|approfondi
    cidr: str | None = None
    mandat_nda_signes: bool = False
    ton_rapport: str = "tutoiement"
    signature: str = "Platon-Y / Echoes of Hackers"
    operateur_nom: str = "Platon-Y"
    operateur_signe: bool = False
    extras: dict[str, Any] = field(default_factory=dict)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> "Mission":
        from guardia.core.mission_yaml import flatten

        data = flatten(data)
        known = {f.name for f in cls.__dataclass_fields__.values()}  # type: ignore
        kwargs = {k: v for k, v in data.items() if k in known}
        extras = {k: v for k, v in data.items() if k not in known}
        m = cls(**kwargs)
        m.extras = extras
        if not m.personne_commune:
            m.personne_commune = m.client
        return m


def _findings_to_dicts(items: Any) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    for f in items or []:
        if hasattr(f, "to_dict"):
            out.append(f.to_dict())
        elif isinstance(f, dict):
            out.append(f)
    return out


@dataclass
class CheckupResult:
    mission: Mission
    hosts: list[Host] = field(default_factory=list)
    errors: list[str] = field(default_factory=list)
    started: str = ""
    finished: str = ""
    cidr: str = ""
    gateway: str = ""
    iface: str = ""
    timings: dict = field(default_factory=dict)
    # Modules parcimonieux (vides = non demandés / non joués)
    website: dict[str, Any] = field(default_factory=dict)
    rgpd: dict[str, Any] = field(default_factory=dict)
    restructure: dict[str, Any] = field(default_factory=dict)
    machines: dict[str, Any] = field(default_factory=dict)
    usages: dict[str, Any] = field(default_factory=dict)
    plan: dict[str, Any] = field(default_factory=dict)
    direction: dict[str, Any] = field(default_factory=dict)
    pistes: dict[str, Any] = field(default_factory=dict)
    recap: dict[str, Any] = field(default_factory=dict)
    journal: dict[str, Any] = field(default_factory=dict)
    burp: dict[str, Any] = field(default_factory=dict)
    programme: dict[str, Any] = field(default_factory=dict)
    identite: dict[str, Any] = field(default_factory=dict)
    calibrage: dict[str, Any] = field(default_factory=dict)
    equipe: str = "blue"
    regard: dict[str, Any] = field(default_factory=dict)
    parc: str = "professionnel"
    dossier: dict[str, Any] = field(default_factory=dict)
    hygiene: dict[str, Any] = field(default_factory=dict)
    identites: dict[str, Any] = field(default_factory=dict)
    autorisation: dict[str, Any] = field(default_factory=dict)
    correlation: dict[str, Any] = field(default_factory=dict)
    cve_correlation: dict[str, Any] = field(default_factory=dict)
    lynis: dict[str, Any] = field(default_factory=dict)
    greenbone: dict[str, Any] = field(default_factory=dict)
    trivy: dict[str, Any] = field(default_factory=dict)
    orchestre: dict[str, Any] = field(default_factory=dict)
    passi: dict[str, Any] = field(default_factory=dict)
    autorisations: dict[str, Any] = field(default_factory=dict)
    adaptatif: dict[str, Any] = field(default_factory=dict)
    passi_alignment: dict[str, Any] = field(default_factory=dict)
    passi_assessment: dict[str, Any] = field(default_factory=dict)
    poste_operateur: dict[str, Any] = field(default_factory=dict)
