"""État d'autorisation — un seul discours, jamais deux.

Sans mandat coché et sans attestation opérateur (--yes, CIDR local) :
aucune opération. Avec --yes seulement : attestation, pas une double
signature. Les modules lourds (audit-full, OT, regard Red) restent fermés
tant que le mandat n'est pas coché dans la mission.
"""
from __future__ import annotations

from typing import Any

ETAT_VALIDEE = "validee"
ETAT_ATTESTATION = "attestation_operateur"
ETAT_NON = "non_validee"

BANDEAU_NON = (
    "AUTORISATION — NON VALIDÉE\n"
    "Guardia n'autorise aucune opération d'évaluation\n"
    "tant que l'autorisation requise n'est pas validée.\n"
    "État actuel : démonstration / brouillon — pas un rapport d'audit exécuté."
)

BANDEAU_ATTESTATION = (
    "AUTORISATION — ATTESTATION OPÉRATEUR\n"
    "Le mandat n'est pas coché dans la mission. L'opérateur atteste "
    "une autorisation locale (--yes, CIDR privé). Ce n'est pas une double "
    "signature. Modules limités : pas d'audit-full, pas d'OT, pas de regard Red."
)

BANDEAU_VALIDEE = (
    "AUTORISATION — VALIDÉE\n"
    "Mandat et NDA cochés dans la mission. Périmètre : CIDR et/ou URL du jour."
)


def _truthy(v: Any) -> bool:
    if v is True:
        return True
    if v is False or v is None:
        return False
    return str(v).strip().lower() in ("1", "true", "oui", "yes", "on")


def etat(mission: Any, args: Any = None) -> dict[str, Any]:
    """Un seul état, pour le CLI, le JSON et le HTML."""
    mandat = bool(getattr(mission, "mandat_nda_signes", False))
    extras = getattr(mission, "extras", None) or {}
    if not isinstance(extras, dict):
        extras = {}
    yes = False
    if args is not None:
        yes = bool(getattr(args, "yes", False))
    yes = yes or _truthy(extras.get("attestation_operateur")) or _truthy(extras.get("yes"))
    from guardia.core.identite import operateur_a_signe

    op = operateur_a_signe(mission)
    if mandat:
        return {
            "etat": ETAT_VALIDEE,
            "libelle": "Autorisation validée (mandat et NDA cochés).",
            "bandeau": BANDEAU_VALIDEE,
            "mandat_coche": True,
            "attestation_operateur": False,
            "operateur_signe": op,
            "double_signature": bool(op),
            "modules_limites": False,
            "peut_evaluer": True,
        }
    if yes:
        return {
            "etat": ETAT_ATTESTATION,
            "libelle": "Attestation opérateur. Mandat non coché dans la mission.",
            "bandeau": BANDEAU_ATTESTATION,
            "mandat_coche": False,
            "attestation_operateur": True,
            "operateur_signe": op,
            "double_signature": False,
            "modules_limites": True,
            "peut_evaluer": True,
        }
    return {
        "etat": ETAT_NON,
        "libelle": "Autorisation non validée.",
        "bandeau": BANDEAU_NON,
        "mandat_coche": False,
        "attestation_operateur": False,
        "operateur_signe": op,
        "double_signature": False,
        "modules_limites": True,
        "peut_evaluer": False,
    }


def limiter_plan(plan: dict[str, Any], auth: dict[str, Any]) -> dict[str, Any]:
    """Sans mandat coché : pas d'audit-full, pas d'OT, pas de Red."""
    out = dict(plan or {})
    if not auth.get("modules_limites"):
        return out
    out["machines"] = False
    out["audit_full"] = False
    out["passi"] = False
    out["autorisations"] = False
    if out.get("equipe") == "red":
        out["equipe"] = "blue"
        out["red_limite"] = "regard Red refusé : mandat non coché"
    out["modules_limites"] = True
    return out


def phrase_signature(auth: dict[str, Any]) -> str:
    """Jamais « signé des deux côtés » si ce n'est pas le cas."""
    if auth.get("double_signature"):
        return (
            "Autorisation écrite. Opérateur identifié. "
            "Paraphe habilité et paraphe opérateur ÉOH."
        )
    if auth.get("etat") == ETAT_VALIDEE:
        return (
            "Mandat coché dans la mission. "
            "Paraphe opérateur ÉOH à compléter sur la liasse."
        )
    if auth.get("etat") == ETAT_ATTESTATION:
        return (
            "Attestation opérateur (--yes). Mandat non coché dans la mission. "
            "Pas une double signature."
        )
    return (
        "Autorisation non validée. Ce document n'est pas un rapport d'évaluation exécuté."
    )
