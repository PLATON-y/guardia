"""Cadre légal — constantes partagées UI / rapport / CLI.

Pas un avis d'avocat. Rappel opérateur : on n'opère qu'avec mandat.
Opérateur identifié : ÉOH paraphe, le trafic se présente (User-Agent Guardia).
"""
from __future__ import annotations

# Chrome UI — barre d'identité (logo gouttes). Ne défile pas.
# Ce n'est PAS l'article 323-1 : l'article est dans les docs et le rapport.
IDENTITE_BARRE = "Évaluation défensive LAN  ·  Platon-Y / Echoes of Hackers"

# Phrase docs / rapport (mandat, HTML, CADRE-LEGAL) — pas le chrome de l'UI.
BANNER_COURT = (
    "Art. 323-1 CP — accès à un système : uniquement avec mandat écrit. "
    "Guardia = lecture, sans exploitation, périmètre signé, opérateur identifié. "
    "ESS Echoes of Hackers."
)

# Phrase unique de l'évaluation — ce qu'on fait.
PROGRAMME = (
    "Évaluation défensive non intrusive : mandat écrit, CIDR et URL du jour, "
    "outils Kali en lecture, sans exploitation. "
    "Guardia lance ce qui est installé, selon les portes vues. "
    "Chaque observation porte une preuve et un comment faire."
)

# RGPD art. 32 : obligation de TESTER, pas un certificat.
RGPD_32 = (
    "RGPD art. 32 : l'organisme doit tester, analyser et évaluer régulièrement "
    "l'efficacité des mesures de sécurité. Cette évaluation y contribue. "
    "Elle n'est pas un certificat, ni une « conformité »."
)

# Code pénal — phrase rapport (première page).
CP_323 = (
    "Code pénal art. 323-1 et suivants : l'accès ou le maintien frauduleux "
    "dans un système de traitement automatisé de données est un délit. "
    "Le caractère frauduleux disparaît si une personne habilitée a donné "
    "une autorisation écrite, datée, périmétrée. Sans mandat, Guardia s'arrête. "
    "L'opérateur ÉOH paraphe. Le trafic est nominatif (User-Agent Guardia, pas de decoy)."
)

ESS = (
    "Echoes of Hackers — association déclarée et entreprise de l'ESS "
    "(loi n° 2014-856). Finalité : aider les structures à se protéger. "
    "Gouvernance associative."
)

SOUS_AVENANT: tuple[tuple[str, str], ...] = ()
HORS_MOTEUR: tuple[tuple[str, str], ...] = ()

OUTILS_LECTURE = (
    "nmap -sV — empreinte LAN, opérateur identifié",
    "calibrage : arp-scan, nbtscan, smbclient, showmount, ldapsearch, snmpget/snmpwalk public, ike-scan, ssh-audit, rdp-nla, smb-security-mode",
    "scripts nmap : smb-enum-shares (noms), ftp-anon, smtp-open-relay, ssl-cert, http-title",
    "curl / openssl / testssl.sh / sslscan / sslyze / whatweb / wafw00f — URL du mandat",
    "nuclei tech/info/tls, nikto Tuning 1, wpscan (enum passive) — si HTTP vu et outil installé",
    "optionnel Kali : Greenbone/GVM (invitation), Lynis (Linux local), Trivy (conteneurs / FS)",
)
