import logging
import sys
from pathlib import Path


def setup_logging(verbose: bool = False, log_file: Path | None = None) -> logging.Logger:
    level = logging.DEBUG if verbose else logging.INFO
    log = logging.getLogger("guardia")
    log.handlers.clear()
    log.setLevel(level)
    fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", "%H:%M:%S")
    sh = logging.StreamHandler(sys.stderr)
    sh.setFormatter(fmt)
    log.addHandler(sh)
    if log_file:
        try:
            log_file.parent.mkdir(parents=True, exist_ok=True)
            fh = logging.FileHandler(log_file, encoding="utf-8")
            fh.setFormatter(fmt)
            log.addHandler(fh)
        except OSError as exc:
            log.warning("journal fichier indisponible: %s", exc)
    return log
