"""Ports TCP/UDP critiques — inventaire Guardia (lecture / priorisation)."""
from __future__ import annotations

from typing import Iterable

# port -> (proto hint, service)
_PORT_META: dict[int, tuple[str, str]] = {}

def _add(cat: str, items: list[tuple[int, str, str]]) -> list[int]:
    ports: list[int] = []
    for port, proto, svc in items:
        ports.append(port)
        _PORT_META.setdefault(port, (proto, svc))
    return ports

CATEGORIES: dict[str, list[int]] = {}

CATEGORIES["web"] = _add("web", [
    (80, "tcp", "HTTP"), (443, "tcp", "HTTPS"), (8000, "tcp", "HTTP alt / Django"),
    (8008, "tcp", "HTTP alt"), (8080, "tcp", "HTTP alt / Tomcat / Jenkins"),
    (8081, "tcp", "HTTP alt / Nexus"), (8443, "tcp", "HTTPS alt / admin"),
    (8888, "tcp", "HTTP alt / Jupyter"), (9000, "tcp", "SonarQube / Portainer"),
])
CATEGORIES["mail"] = _add("mail", [
    (25, "tcp", "SMTP"), (110, "tcp", "POP3"), (143, "tcp", "IMAP"),
    (465, "tcp", "SMTPS"), (587, "tcp", "SMTP submission"),
    (993, "tcp", "IMAPS"), (995, "tcp", "POP3S"),
])
CATEGORIES["dns_dhcp_ntp"] = _add("dns", [
    (53, "tcp+udp", "DNS"), (67, "udp", "DHCP serveur"), (68, "udp", "DHCP client"),
    (123, "udp", "NTP"), (853, "tcp", "DNS over TLS"), (5353, "udp", "mDNS"),
])
CATEGORIES["remote"] = _add("remote", [
    (22, "tcp", "SSH"), (23, "tcp", "Telnet"), (2222, "tcp", "SSH alt"),
    (3389, "tcp+udp", "RDP"), (5900, "tcp", "VNC"), (5901, "tcp", "VNC"),
    (5902, "tcp", "VNC"), (5903, "tcp", "VNC"), (5904, "tcp", "VNC"),
    (5905, "tcp", "VNC"), (5906, "tcp", "VNC"), (5938, "tcp", "TeamViewer"),
    (6568, "tcp", "AnyDesk"), (6000, "tcp", "X11"), (6001, "tcp", "X11"),
])
CATEGORIES["files"] = _add("files", [
    (20, "tcp", "FTP data"), (21, "tcp", "FTP"), (69, "udp", "TFTP"),
    (111, "tcp+udp", "RPC portmapper"), (137, "tcp+udp", "NetBIOS"),
    (138, "tcp+udp", "NetBIOS"), (139, "tcp+udp", "NetBIOS"),
    (445, "tcp", "SMB"), (873, "tcp", "rsync"), (989, "tcp", "FTPS"),
    (990, "tcp", "FTPS"), (2049, "tcp+udp", "NFS"),
])
CATEGORIES["database"] = _add("db", [
    (1433, "tcp", "MSSQL"), (1434, "tcp+udp", "MSSQL"), (1521, "tcp", "Oracle"),
    (3306, "tcp", "MySQL / MariaDB"), (5432, "tcp", "PostgreSQL"),
    (5984, "tcp", "CouchDB"), (6379, "tcp", "Redis"), (7474, "tcp", "Neo4j HTTP"),
    (7687, "tcp", "Neo4j Bolt"), (9042, "tcp", "Cassandra"),
    (9200, "tcp", "Elasticsearch HTTP"), (9300, "tcp", "Elasticsearch transport"),
    (11211, "udp+tcp", "Memcached"), (27017, "tcp", "MongoDB"),
])
CATEGORIES["directory"] = _add("dir", [
    (88, "tcp+udp", "Kerberos"), (389, "tcp+udp", "LDAP"),
    (464, "tcp+udp", "Kerberos kpasswd"), (636, "tcp", "LDAPS"),
    (749, "tcp+udp", "Kerberos admin"), (750, "tcp+udp", "Kerberos admin"),
    (3268, "tcp", "Global Catalog"), (3269, "tcp", "Global Catalog SSL"),
])
CATEGORIES["vpn"] = _add("vpn", [
    (500, "udp", "IKE / IPsec"), (1194, "tcp+udp", "OpenVPN"),
    (1701, "udp", "L2TP"), (1723, "tcp", "PPTP"), (4500, "udp", "IPsec NAT-T"),
    (51820, "udp", "WireGuard"),
])
CATEGORIES["containers"] = _add("ctr", [
    (2375, "tcp", "Docker API (non chiffré)"), (2376, "tcp", "Docker API TLS"),
    (2377, "tcp", "Docker Swarm"), (2379, "tcp", "etcd"), (2380, "tcp", "etcd"),
    (6443, "tcp", "Kubernetes API"), (10250, "tcp", "Kubelet"),
    (10255, "tcp", "Kubelet read-only"), (10256, "tcp", "Kube-proxy health"),
])
CATEGORIES["monitoring"] = _add("mon", [
    (161, "udp", "SNMP"), (162, "udp", "SNMP trap"), (623, "udp", "IPMI"),
    (3000, "tcp", "Grafana"), (514, "tcp+udp", "Syslog"), (5666, "tcp", "NRPE"),
    (8086, "tcp", "InfluxDB"), (9090, "tcp", "Prometheus"),
    (10050, "tcp", "Zabbix"), (10051, "tcp", "Zabbix"),
])
CATEGORIES["messaging"] = _add("msg", [
    (2181, "tcp", "Zookeeper"), (5672, "tcp", "RabbitMQ AMQP"),
    (9092, "tcp", "Kafka"), (15672, "tcp", "RabbitMQ management"),
])
CATEGORIES["proxy"] = _add("proxy", [
    (1080, "tcp", "SOCKS"), (3128, "tcp", "Squid"),
])
CATEGORIES["print"] = _add("print", [
    (515, "tcp", "LPD"), (631, "tcp+udp", "IPP / CUPS"), (9100, "tcp", "Raw print"),
])
CATEGORIES["ot"] = _add("ot", [
    (102, "tcp", "S7comm Siemens"), (502, "tcp", "Modbus"),
    (4840, "tcp", "OPC UA"), (20000, "tcp+udp", "DNP3"),
    (44818, "tcp", "EtherNet/IP"), (47808, "udp", "BACnet"),
])
CATEGORIES["gaming"] = _add("game", [
    (25565, "tcp", "Minecraft"), (27015, "tcp+udp", "Steam / Source"),
    (27016, "tcp+udp", "Steam"), (27050, "tcp+udp", "Steam"),
])


def critical() -> list[int]:
    """Ports prioritaires checkup (web, remote, smb, dns, db courants)."""
    prio = (
        CATEGORIES["web"][:4]
        + [22, 3389, 445, 53, 3306, 5432, 6379, 27017, 2375, 6443, 161]
    )
    return sorted(set(prio))


def by_category(name: str) -> list[int]:
    return list(CATEGORIES.get(name, []))


def service_of(port: int, proto: str = "tcp") -> str:
    meta = _PORT_META.get(int(port))
    if not meta:
        return "inconnu"
    _p, svc = meta
    return svc


def all_ports() -> list[int]:
    s: set[int] = set()
    for ports in CATEGORIES.values():
        s.update(ports)
    return sorted(s)


__all__ = ["CATEGORIES", "critical", "by_category", "service_of", "all_ports"]
