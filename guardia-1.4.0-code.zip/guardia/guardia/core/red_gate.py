"""Porte Red Team — mot de passe opérateur + attestation document signé.

Ce module n'ouvre AUCUNE capacité d'exploitation. Il gate uniquement des
moteurs défensifs déjà présents (audit_full, rgpd, passi, all_ports, etc.).
Human-in-the-loop : les deux cases (demander + document signé) sont requises.
"""
from __future__ import annotations

import hashlib
import os
import re
import secrets
from pathlib import Path
from typing import Any, Iterable

# Catalogue défensif uniquement — jamais d'exploit / C2 / brute-force.
RED_ACTIONS: dict[str, dict[str, str]] = {
    "audit_full": {
        "label": "Audit full ports/scripts (nmap défensif élargi)",
        "maps_to": "audit_full",
        "help": "Allume --audit-full : scripts lecture (headers, ssh-hostkey, ciphers).",
    },
    "web_profond": {
        "label": "Web profond (headers / TLS / lecture catalogue)",
        "maps_to": "site",
        "help": "Allume l'audit site défensif (headers, TLS, chemins légaux). Pas de fuzz.",
    },
    "smb_hygiene": {
        "label": "SMB hygiene profond (lecture défensive)",
        "maps_to": "calibrage",
        "help": "Approfondit le calibrage / hygiène SMB en lecture seule.",
    },
    "rgpd": {
        "label": "RGPD signalement (observé / déclaré — pas un certificat)",
        "maps_to": "rgpd",
        "help": "Allume le signalement RGPD. Jamais un tampon CNIL.",
    },
    "passi": {
        "label": "PASSI dossier (appui prestation — pas une qualification)",
        "maps_to": "passi",
        "help": "Allume le mode dossier PASSI. Pas une qualification ANSSI.",
    },
    "ot_lecture": {
        "label": "OT lecture (machines / protocoles visibles)",
        "maps_to": "machines",
        "help": "Allume --machines : inventaire OT en lecture. Pas de commande automate.",
    },
    "inventaire_all_ports": {
        "label": "Inventaire all-ports (nmap -p- défensif, long)",
        "maps_to": "all_ports",
        "help": "Allume --all-ports. Très long ; repli budget si besoin.",
    },
}

# Correspondance maps_to → attributs CLI / extras YAML
MAP_TO_FLAGS: dict[str, tuple[str, ...]] = {
    "audit_full": ("audit_full", "audit"),
    "site": ("site",),
    "calibrage": ("calibrage",),
    "rgpd": ("rgpd",),
    "passi": ("passi",),
    "machines": ("machines",),
    "all_ports": ("all_ports",),
}


def config_dir() -> Path:
    return Path.home() / ".config" / "guardia"


def pass_file() -> Path:
    return config_dir() / "red.pass"


def _sha256_hex(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def hash_password(password: str, salt: str | None = None) -> str:
    """Retourne salt_hex$hash_hex (SHA-256 de salt+password)."""
    pwd = (password or "").strip()
    if not pwd:
        raise ValueError("mot de passe vide")
    if salt is None:
        salt = secrets.token_hex(16)
    salt = salt.strip().lower()
    digest = _sha256_hex((salt + pwd).encode("utf-8"))
    return f"{salt}${digest}"


def hash_password_unsalted(password: str) -> str:
    """SHA-256 du mot de passe seul (compat env / tests)."""
    return _sha256_hex((password or "").strip().encode("utf-8"))


def _parse_stored(raw: str) -> tuple[str | None, str]:
    """(salt, digest) ou (None, digest) si hash nu."""
    s = (raw or "").strip()
    if not s or s.startswith("#"):
        return (None, "")
    if "=" in s and "$" not in s and not re.fullmatch(r"[0-9a-fA-F]{64}", s):
        _, _, rest = s.partition("=")
        s = rest.strip().strip('"').strip("'")
    if "$" in s:
        salt, _, digest = s.partition("$")
        salt, digest = salt.strip().lower(), digest.strip().lower()
        if re.fullmatch(r"[0-9a-f]+", salt) and re.fullmatch(r"[0-9a-f]{64}", digest):
            return (salt, digest)
    s = s.lower()
    if re.fullmatch(r"[0-9a-f]{64}", s):
        return (None, s)
    return (None, "")


def _read_file_hash(path: Path) -> str:
    try:
        if not path.is_file():
            return ""
        for line in path.read_text(encoding="utf-8").splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            return line
    except OSError:
        pass
    return ""


def _read_queen_hash(root: Path | None = None) -> str:
    """Lit RED_TEAM_PASSWORD_HASH= depuis queen_decide (jamais committer la clé)."""
    candidates: list[Path] = []
    if root is not None:
        candidates.append(root / "queen_decide")
    here = Path(__file__).resolve()
    repo = here.parents[2]
    candidates.append(repo / "queen_decide")
    candidates.append(Path.cwd() / "queen_decide")
    for p in candidates:
        try:
            if not p.is_file():
                continue
            for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if not line or line.startswith("#"):
                    continue
                if line.upper().startswith("RED_TEAM_PASSWORD_HASH="):
                    return line.split("=", 1)[1].strip().strip('"').strip("'")
        except OSError:
            continue
    return ""


def configured_hash_raw() -> str:
    """Ordre : env GUARDIA_RED_PASSWORD_HASH → ~/.config/guardia/red.pass → queen_decide."""
    env = (os.environ.get("GUARDIA_RED_PASSWORD_HASH") or "").strip()
    if env:
        return env
    f = _read_file_hash(pass_file())
    if f:
        return f
    return _read_queen_hash()


def has_configured_hash() -> bool:
    _salt, digest = _parse_stored(configured_hash_raw())
    return bool(digest)


def write_password_hash(password: str, path: Path | None = None) -> Path:
    """Écrit salt$hash dans le fichier opérateur (chmod 600)."""
    target = path or pass_file()
    target.parent.mkdir(parents=True, exist_ok=True)
    stored = hash_password(password)
    target.write_text(
        "# Guardia red.pass — SHA-256(salt+password). Ne jamais committer.\n"
        f"{stored}\n",
        encoding="utf-8",
    )
    try:
        os.chmod(target, 0o600)
    except OSError:
        pass
    return target


def verifier_red(mot: str, *, stored: str | None = None) -> bool:
    """Vérifie le mot de passe contre le hash configuré (jamais de clair en dépôt)."""
    pwd = (mot or "").strip()
    if not pwd:
        return False
    raw = stored if stored is not None else configured_hash_raw()
    salt, digest = _parse_stored(raw)
    if not digest:
        return False
    if salt is None:
        return hash_password_unsalted(pwd) == digest
    return _sha256_hex((salt + pwd).encode("utf-8")) == digest


def normalize_action_id(action: str) -> str | None:
    a = (action or "").strip().lower().replace("-", "_").replace(" ", "_")
    aliases = {
        "audit": "audit_full",
        "web": "web_profond",
        "smb": "smb_hygiene",
        "hygiene_smb": "smb_hygiene",
        "ot": "ot_lecture",
        "machines": "ot_lecture",
        "all_ports": "inventaire_all_ports",
        "inventaire": "inventaire_all_ports",
        "ports": "inventaire_all_ports",
    }
    a = aliases.get(a, a)
    return a if a in RED_ACTIONS else None


def parse_signed_actions(raw: Any) -> list[str]:
    """Parse liste YAML / CLI (virgules) → ids normalisés uniques."""
    out: list[str] = []
    if raw is None:
        return out
    if isinstance(raw, str):
        items: Iterable[Any] = [x.strip() for x in raw.replace(";", ",").split(",") if x.strip()]
    elif isinstance(raw, (list, tuple, set)):
        items = raw
    else:
        items = [raw]
    seen: set[str] = set()
    for it in items:
        nid = normalize_action_id(str(it))
        if nid and nid not in seen:
            seen.add(nid)
            out.append(nid)
    return out


def red_team_requested(args: Any = None, mission: Any = None) -> bool:
    if args is not None and getattr(args, "red_team", False):
        return True
    if mission is not None:
        extras = getattr(mission, "extras", None) or {}
        if isinstance(extras, dict) and extras.get("red_team") not in (None, False, "", 0, "0"):
            return True
    return False


def red_ok_attested(args: Any = None, mission: Any = None) -> bool:
    """Attestation CLI --red-ok, env GUARDIA_RED_OK=1, ou YAML red_actions_signed non vide."""
    if args is not None and getattr(args, "red_ok", False):
        return True
    env = (os.environ.get("GUARDIA_RED_OK") or "").strip().lower()
    if env in ("1", "true", "yes", "oui", "ok"):
        return True
    if mission is not None:
        extras = getattr(mission, "extras", None) or {}
        if isinstance(extras, dict):
            signed = parse_signed_actions(extras.get("red_actions_signed"))
            if signed and extras.get("red_team"):
                return True
    return False


def signed_actions_from(args: Any = None, mission: Any = None) -> list[str]:
    collected: list[str] = []
    if args is not None:
        collected.extend(parse_signed_actions(getattr(args, "red_actions_signed", None)))
    if mission is not None:
        extras = getattr(mission, "extras", None) or {}
        if isinstance(extras, dict):
            collected.extend(parse_signed_actions(extras.get("red_actions_signed")))
    seen: set[str] = set()
    out: list[str] = []
    for a in collected:
        if a not in seen:
            seen.add(a)
            out.append(a)
    return out


def apply_signed_actions(args: Any, mission: Any, signed: list[str]) -> list[str]:
    """Allume uniquement les flags défensifs mappés. Retourne les ids appliqués."""
    applied: list[str] = []
    extras = getattr(mission, "extras", None)
    if not isinstance(extras, dict):
        extras = {}
        try:
            mission.extras = extras
        except Exception:
            pass
    for aid in signed:
        meta = RED_ACTIONS.get(aid)
        if not meta:
            continue
        maps_to = meta["maps_to"]
        flags = MAP_TO_FLAGS.get(maps_to, (maps_to,))
        for flag in flags:
            if args is not None and hasattr(args, flag):
                try:
                    if flag == "site":
                        cur = getattr(args, flag, None)
                        if cur is None:
                            from guardia.core.defaults import DEFAULT_SITE_URL

                            setattr(args, flag, DEFAULT_SITE_URL)
                    else:
                        setattr(args, flag, True)
                except Exception:
                    pass
            if flag == "site":
                extras["web_profond"] = True
            else:
                extras[flag] = True
        extras.setdefault("red_actions_opened", [])
        if isinstance(extras["red_actions_opened"], list) and aid not in extras["red_actions_opened"]:
            extras["red_actions_opened"].append(aid)
        applied.append(aid)
    extras["red_team"] = True
    extras["red_actions_signed"] = list(signed)
    return applied


def gate_message_want_without_signed(action_label: str) -> str:
    return (
        f"Action refusee : « {action_label} » est demandee sans attestation "
        "« Document signe valide ».\n\n"
        "Le ROE / avenant signe doit couvrir explicitement cette action "
        "avant activation. Guardia n'ouvre aucun outil d'exploitation."
    )
