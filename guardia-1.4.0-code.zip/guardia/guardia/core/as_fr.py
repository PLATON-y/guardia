"""AS / FAI français et transit — classification Guardia."""
from __future__ import annotations

from typing import Any

FAI_FR: dict[int, dict[str, str]] = {
    3215: {"name": "Orange", "type": "FAI FR"},
    15557: {"name": "SFR", "type": "FAI FR"},
    12322: {"name": "Free / Proxad", "type": "FAI FR"},
    5410: {"name": "Bouygues Telecom", "type": "FAI FR"},
    12670: {"name": "Completel", "type": "FAI FR entreprise"},
    198985: {"name": "Aquilenet", "type": "FAI associatif FR"},
    20766: {"name": "Gitoyen", "type": "FAI associatif FR"},
}

HE_HYPERSCALE: dict[int, dict[str, str]] = {
    16276: {"name": "OVHcloud", "type": "Hébergeur FR"},
    12876: {"name": "Scaleway / Online", "type": "Hébergeur FR"},
    24940: {"name": "Hetzner", "type": "Hébergeur DE (fréquent FR)"},
}

TRANSIT: dict[int, dict[str, str]] = {
    174: {"name": "Cogent", "type": "Transit mondial"},
    1299: {"name": "Telia / Arelion", "type": "Transit mondial"},
    3356: {"name": "Lumen / Level3", "type": "Transit mondial"},
    3257: {"name": "GTT", "type": "Transit mondial"},
    6939: {"name": "Hurricane Electric", "type": "Transit mondial"},
}

CLOUD: dict[int, dict[str, str]] = {
    13335: {"name": "Cloudflare", "type": "CDN"},
    15169: {"name": "Google", "type": "Cloud / CDN"},
    16509: {"name": "Amazon AWS", "type": "Cloud"},
    8075: {"name": "Microsoft / Azure", "type": "Cloud"},
}

_ALL: dict[int, dict[str, str]] = {}
for d in (FAI_FR, HE_HYPERSCALE, TRANSIT, CLOUD):
    _ALL.update(d)


def is_french_isp(asn: int) -> bool:
    return int(asn) in FAI_FR


def lookup_asn(asn: int) -> dict[str, Any]:
    a = int(asn)
    if a in _ALL:
        info = dict(_ALL[a])
        info["asn"] = a
        info["known"] = True
        info["french_isp"] = a in FAI_FR
        return info
    return {"asn": a, "known": False, "name": None, "type": None, "french_isp": False}


__all__ = [
    "FAI_FR", "TRANSIT", "CLOUD", "HE_HYPERSCALE",
    "is_french_isp", "lookup_asn",
]
