"""Erreurs Guardia — jamais fatales pour tout le run si évitable."""

class GuardiaError(Exception):
    """Erreur métier Guardia."""


class ToolMissingError(GuardiaError):
    """Outil système absent (nmap, etc.)."""


class MandateRequiredError(GuardiaError):
    """Mandat / NDA non confirmés."""


class PartialFailure(GuardiaError):
    """Échec partiel non bloquant."""
