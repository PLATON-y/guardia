"""Deux parcs. Pas un troisième.

Personnel : particulier, foyer — à quelques appareils près, tous pareils.
Professionnel : tout le reste (entreprise, association, collectivité, école,
caserne, atelier…). Le type exact est dans les documents de la mission.
"""
from __future__ import annotations

from typing import Any, Literal

Parc = Literal["personnel", "professionnel"]

_PERSONNEL = frozenset(
    {
        "foyer",
        "maison",
        "particulier",
        "personnel",
        "domicile",
        "famille",
    }
)


def parc_de(mission: Any = None, valeur: Any = None) -> Parc:
    if valeur:
        v = str(valeur).strip().lower()
        if v in _PERSONNEL or v in ("personnel", "perso"):
            return "personnel"
        if v in ("professionnel", "pro", "entreprise"):
            return "professionnel"
    if mission is None:
        return "professionnel"
    extras = getattr(mission, "extras", None) or {}
    if isinstance(extras, dict):
        raw = extras.get("parc") or extras.get("parc_type")
        if raw:
            return parc_de(None, raw)
    typ = str(getattr(mission, "type_structure", "") or "").strip().lower()
    if typ in _PERSONNEL:
        return "personnel"
    if typ and typ not in ("inconnu",):
        return "professionnel"
    profil = str(getattr(mission, "profil_moteur", "") or "").strip().lower()
    if profil in ("maison", "foyer"):
        return "personnel"
    return "professionnel"


def libelle(parc: Parc) -> str:
    return "Parc personnel" if parc == "personnel" else "Parc professionnel"
