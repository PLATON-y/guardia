"""Firefox ESR profil « neutre » — ouverture HTML OPSEC pour Guardia.

Profil dédié (sans sync / WebRTC typiquement) pour rapports HTML et hub
documents à signer. Fonctionne aussi si l'UI tourne en root : on emprunte
la session graphique de l'opérateur (SUDO_USER).
"""
from __future__ import annotations

import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any

DESKTOP_NAME = "firefox-neutre.desktop"
PROFILE_NAME = "neutre"
FIREFOX_BIN = "firefox-esr"


def _which(name: str) -> str | None:
    return shutil.which(name)


def _session_home() -> Path:
    """Home de l'opérateur (même si euid=0)."""
    try:
        from guardia.core.open_links import session_user

        sess = session_user()
        home = str(sess.get("home") or "")
        if home:
            return Path(home)
    except Exception:  # noqa: BLE001
        pass
    sudo = (os.environ.get("SUDO_USER") or "").strip()
    if sudo and hasattr(os, "geteuid") and os.geteuid() == 0:
        return Path(f"/home/{sudo}")
    return Path.home()


def desktop_dir() -> Path:
    """Bureau opérateur : $XDG_DESKTOP_DIR ou ~/Bureau / ~/Desktop."""
    home = _session_home()
    xdg = (os.environ.get("XDG_DESKTOP_DIR") or "").strip()
    if xdg:
        p = Path(xdg).expanduser()
        if p.is_dir():
            return p
    # user-dirs.dirs
    cfg = home / ".config" / "user-dirs.dirs"
    if cfg.is_file():
        try:
            for line in cfg.read_text(encoding="utf-8", errors="replace").splitlines():
                line = line.strip()
                if line.startswith("XDG_DESKTOP_DIR="):
                    raw = line.split("=", 1)[1].strip().strip('"').strip("'")
                    raw = raw.replace("$HOME", str(home)).replace("${HOME}", str(home))
                    p = Path(raw)
                    if p.is_dir():
                        return p
        except OSError:
            pass
    for name in ("Bureau", "Desktop"):
        p = home / name
        if p.is_dir():
            return p
    return home / "Bureau"


def desktop_shortcut_path() -> Path | None:
    """Chemin du raccourci s'il existe, sinon None."""
    cand = desktop_dir() / DESKTOP_NAME
    if cand.is_file():
        return cand
    # parfois sur le Bureau courant même si XDG pointe ailleurs
    for base in (Path.home() / "Bureau", Path.home() / "Desktop", Path("/home/platon-y/Bureau")):
        p = base / DESKTOP_NAME
        try:
            if p.is_file():
                return p
        except OSError:
            continue
    return None


def profiles_ini_path() -> Path:
    return _session_home() / ".mozilla" / "firefox" / "profiles.ini"


def neutre_profile_exists() -> bool:
    ini = profiles_ini_path()
    if not ini.is_file():
        return False
    try:
        text = ini.read_text(encoding="utf-8", errors="replace")
    except OSError:
        return False
    # Name=neutre dans un bloc Profile
    for line in text.splitlines():
        if line.strip().lower() == f"name={PROFILE_NAME}".lower():
            return True
    return False


def _desktop_file_content() -> str:
    return f"""[Desktop Entry]
Name=Firefox neutre
Comment=Profil OPSEC Guardia / ÉOH — sans sync
Exec={FIREFOX_BIN} -P {PROFILE_NAME} --no-remote
Icon=firefox-esr
Terminal=false
Type=Application
Categories=Network;WebBrowser;
"""


def write_desktop_shortcut(*, force: bool = False) -> Path:
    """Écrit ~/Bureau/firefox-neutre.desktop (ou XDG)."""
    dest = desktop_dir() / DESKTOP_NAME
    dest.parent.mkdir(parents=True, exist_ok=True)
    if dest.is_file() and not force:
        return dest
    dest.write_text(_desktop_file_content(), encoding="utf-8")
    try:
        dest.chmod(dest.stat().st_mode | 0o755)
    except OSError:
        pass
    return dest


def _run_as_session(argv: list[str], *, env: dict[str, str] | None = None) -> subprocess.Popen[Any]:
    from guardia.core.open_links import _as_user_cmd, _gui_env, session_user

    sess = session_user()
    gui = _gui_env(sess)
    if env:
        gui.update(env)
    cmd = _as_user_cmd(argv, sess)
    return subprocess.Popen(
        cmd,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        env=gui,
        start_new_session=True,
    )


def ensure_neutre_profile(*, create_desktop: bool = True) -> dict[str, Any]:
    """Crée le profil Firefox « neutre » s'il manque + raccourci Bureau.

    Returns:
        dict avec keys: ok, created, profile_exists, desktop, detail, firefox
    """
    ff = _which(FIREFOX_BIN) or _which("firefox")
    out: dict[str, Any] = {
        "ok": False,
        "created": False,
        "profile_exists": neutre_profile_exists(),
        "desktop": None,
        "detail": "",
        "firefox": ff,
    }
    if not ff:
        out["detail"] = "firefox-esr absent (sudo apt install firefox-esr)"
        return out

    if not out["profile_exists"]:
        # firefox-esr -CreateProfile "neutre <path>" ou -CreateProfile neutre
        try:
            proc = _run_as_session([ff, "-CreateProfile", PROFILE_NAME])
            try:
                proc.wait(timeout=25)
            except subprocess.TimeoutExpired:
                proc.kill()
            # parfois CreateProfile est sync et rapide
            time.sleep(0.3)
        except OSError as exc:
            out["detail"] = f"CreateProfile : {exc}"
            return out
        out["profile_exists"] = neutre_profile_exists()
        out["created"] = out["profile_exists"]
        if not out["profile_exists"]:
            # Fallback : créer à la main un dossier + entrée profiles.ini
            try:
                _create_profile_manual()
                out["profile_exists"] = neutre_profile_exists()
                out["created"] = out["profile_exists"]
            except OSError as exc:
                out["detail"] = f"profil manuel : {exc}"
                return out

    desk = None
    if create_desktop:
        try:
            desk = write_desktop_shortcut(force=False)
            out["desktop"] = str(desk)
        except OSError as exc:
            out["detail"] = f"raccourci Bureau : {exc}"
            # profil peut être OK quand même

    out["ok"] = bool(out["profile_exists"])
    if out["ok"] and not out["detail"]:
        out["detail"] = (
            f"profil {PROFILE_NAME} OK"
            + (f" · desktop {desk.name}" if desk else "")
            + (" · créé" if out["created"] else "")
        )
    elif not out["ok"] and not out["detail"]:
        out["detail"] = "profil neutre introuvable après CreateProfile"
    return out


def _create_profile_manual() -> Path:
    """Crée ~/.mozilla/firefox/neutre.parano + entrée profiles.ini."""
    home = _session_home()
    ff_dir = home / ".mozilla" / "firefox"
    ff_dir.mkdir(parents=True, exist_ok=True)
    profile_dir = ff_dir / "neutre.parano"
    profile_dir.mkdir(parents=True, exist_ok=True)
    ini = ff_dir / "profiles.ini"
    block = (
        "\n[ProfileNeutre]\n"
        f"Name={PROFILE_NAME}\n"
        "IsRelative=1\n"
        "Path=neutre.parano\n"
    )
    if ini.is_file():
        text = ini.read_text(encoding="utf-8", errors="replace")
        if f"Name={PROFILE_NAME}" not in text and "Name=neutre" not in text:
            ini.write_text(text.rstrip() + "\n" + block, encoding="utf-8")
    else:
        ini.write_text(
            "[General]\nStartWithLastProfile=1\nVersion=2\n" + block,
            encoding="utf-8",
        )
    return profile_dir


def open_html(path_or_url: str | Path) -> tuple[bool, str]:
    """Ouvre un HTML/URL dans Firefox ESR profil neutre (OPSEC Guardia)."""
    ff = _which(FIREFOX_BIN) or _which("firefox")
    if not ff:
        return False, "firefox-esr absent"

    target: str
    s = str(path_or_url).strip()
    if s.startswith(("http://", "https://", "file://")):
        target = s
    else:
        p = Path(s).expanduser()
        try:
            resolved = p.resolve()
        except OSError:
            resolved = p
        if not resolved.is_file() and not s.startswith("file:"):
            return False, f"fichier introuvable : {resolved}"
        target = resolved.as_uri() if resolved.is_file() else s

    # S'assurer que le profil existe (best-effort, silencieux)
    if not neutre_profile_exists():
        ensure_neutre_profile(create_desktop=True)

    from guardia.core.open_links import _alive

    # Tentatives : new-window (réutilise le profil), puis --no-remote (instance dédiée)
    attempts = [
        [ff, "-P", PROFILE_NAME, "--new-window", target],
        [ff, "-P", PROFILE_NAME, "--no-remote", "--new-window", target],
        [ff, "-P", PROFILE_NAME, "--no-remote", target],
    ]
    last_err = ""
    for argv in attempts:
        try:
            proc = _run_as_session(argv)
            time.sleep(0.55)
            if _alive(proc):
                return True, " ".join(argv[1:4])  # -P neutre …
            last_err = f"code {proc.returncode}"
        except OSError as exc:
            last_err = str(exc)
            continue
    return False, f"{FIREFOX_BIN} profil {PROFILE_NAME} : {last_err or 'échec'}"


def status_line() -> str:
    """Une ligne pour checkup / journal."""
    exists = neutre_profile_exists()
    desk = desktop_shortcut_path()
    ff = _which(FIREFOX_BIN) or _which("firefox") or "absent"
    return (
        f"firefox-neutre : profil={'OK' if exists else 'KO'} · "
        f"desktop={'OK' if desk else 'absent'} · bin={ff}"
    )
