"""Contrôle opérateur : passer la phase en cours, continuer le checkup.

CLI : Ctrl+1 (TTY) ou touche « 1 », ou signal SIGUSR1.
UI  : bouton « Passer phase » → SIGUSR1 au process enfant.
"""
from __future__ import annotations

import logging
import os
import signal
import sys
import threading
import time
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any

log = logging.getLogger("guardia.operator")

# Processus nmap / sous-commande à tuer lors d'un skip (soft)
_active_proc_lock = threading.Lock()
_active_proc: Any = None


@dataclass
class OperatorEvent:
    at: str
    phase: str
    kind: str  # "skip_phase" | "abort_all"
    note: str = ""


@dataclass
class OperatorControl:
    current_phase: str = ""
    skip_phase: bool = False
    abort_all: bool = False
    events: list[OperatorEvent] = field(default_factory=list)
    _installed: bool = False
    _tty_thread: threading.Thread | None = None

    def begin_phase(self, name: str) -> None:
        self.current_phase = name
        self.skip_phase = False

    def request_skip_phase(self, source: str = "signal") -> None:
        phase = self.current_phase or "?"
        self.skip_phase = True
        ev = OperatorEvent(
            at=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            phase=phase,
            kind="skip_phase",
            note=f"Arrêt opérateur ({source}) — phase « {phase} » tronquée, suite du checkup",
        )
        self.events.append(ev)
        log.warning("%s", ev.note)
        print(f"\n⚠ {ev.note}", flush=True)
        kill_active_subprocess()

    def request_abort_all(self, source: str = "signal") -> None:
        self.abort_all = True
        self.skip_phase = True
        ev = OperatorEvent(
            at=datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            phase=self.current_phase or "?",
            kind="abort_all",
            note=f"Arrêt total opérateur ({source})",
        )
        self.events.append(ev)
        kill_active_subprocess()

    def should_stop_phase(self) -> bool:
        return self.skip_phase or self.abort_all

    def consume_skip(self) -> bool:
        """True si un skip était demandé (et le consomme)."""
        if self.skip_phase and not self.abort_all:
            self.skip_phase = False
            return True
        return self.skip_phase

    def summary(self) -> dict:
        return {
            "events": [
                {"at": e.at, "phase": e.phase, "kind": e.kind, "note": e.note}
                for e in self.events
            ],
            "operator_interrupt": bool(self.events),
        }


_CTRL = OperatorControl()


def get_operator() -> OperatorControl:
    return _CTRL


def set_active_subprocess(proc: Any | None) -> None:
    global _active_proc
    with _active_proc_lock:
        _active_proc = proc


def kill_active_subprocess() -> None:
    with _active_proc_lock:
        proc = _active_proc
    if proc is None:
        return
    try:
        if proc.poll() is None:
            proc.terminate()
            try:
                proc.wait(timeout=2)
            except Exception:
                proc.kill()
    except Exception as exc:  # noqa: BLE001
        log.debug("kill subprocess: %s", exc)


def _on_sigusr1(_signum: int, _frame: Any) -> None:
    get_operator().request_skip_phase(source="SIGUSR1/Ctrl+1")


def _tty_listener() -> None:
    """Lit /dev/tty en mode cbreak : '1' ou Ctrl+1 → skip phase."""
    if not sys.stdin.isatty():
        return
    try:
        import termios
        import tty
    except ImportError:
        return
    try:
        fd = os.open("/dev/tty", os.O_RDONLY | os.O_NONBLOCK)
    except OSError:
        try:
            fd = sys.stdin.fileno()
        except Exception:
            return
    try:
        old = termios.tcgetattr(fd)
    except termios.error:
        try:
            os.close(fd)
        except Exception:
            pass
        return
    try:
        tty.setcbreak(fd)
        while not get_operator().abort_all:
            try:
                ch = os.read(fd, 1)
            except BlockingIOError:
                time.sleep(0.05)
                continue
            except OSError:
                break
            if not ch:
                time.sleep(0.05)
                continue
            # '1' ou Ctrl+A.. rarement Ctrl+1 ; certains terminaux envoient b'1'
            # Ctrl+1 n'a souvent pas de code : on accepte aussi b'\x11' (DC1) au cas où
            if ch in (b"1", b"\x11"):
                get_operator().request_skip_phase(source="TTY Ctrl+1 / touche 1")
            time.sleep(0.01)
    finally:
        try:
            termios.tcsetattr(fd, termios.TCSADRAIN, old)
        except Exception:
            pass
        try:
            if fd != sys.stdin.fileno():
                os.close(fd)
        except Exception:
            pass


def install_operator_controls(*, tty_keys: bool = True) -> None:
    """À appeler au début de `run` (pas discover seul)."""
    ctrl = get_operator()
    if ctrl._installed:
        return
    try:
        signal.signal(signal.SIGUSR1, _on_sigusr1)
    except (ValueError, OSError) as exc:
        log.debug("SIGUSR1: %s", exc)
    if tty_keys and sys.stdin.isatty():
        t = threading.Thread(target=_tty_listener, name="guardia-op-tty", daemon=True)
        t.start()
        ctrl._tty_thread = t
        print(
            "Opérateur : Ctrl+1 ou touche « 1 » (TTY) = passer la phase en cours ; "
            f"ou kill -USR1 {os.getpid()}",
            flush=True,
        )
    else:
        print(
            f"Opérateur : kill -USR1 {os.getpid()} = passer la phase en cours",
            flush=True,
        )
    ctrl._installed = True
