"""Constantes produit — Kali / opérateur ÉOH."""
from __future__ import annotations

# Préremplissage lab / démo (example.test). Jamais scanné si le module site est off.
DEFAULT_SITE_URL = "https://example.test"

# Secondes à garder après l'empreinte services pour classify / rules / rapport.
RESERVE_AFTER_SERVICES_SEC = 180
RESERVE_AFTER_SERVICES_AUDIT_SEC = 260
