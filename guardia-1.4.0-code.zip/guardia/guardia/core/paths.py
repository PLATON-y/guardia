from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
MISSIONS = ROOT / "missions"
RAPPORTS = ROOT / "rapports"
MODELES = ROOT / "modeles"
DOCS = ROOT / "docs"

for _p in (MISSIONS, RAPPORTS):
    _p.mkdir(parents=True, exist_ok=True)
