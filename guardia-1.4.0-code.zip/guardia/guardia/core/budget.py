"""Budget temps du SCAN seulement.

LLM, HTML, JSON, PDF, classify, rules, rapport : hors horloge.
Si une phase scan dépasse le reste, on l'arrête et on enchaîne.
Les phases cheap (must_run / post) ne sont jamais sautées pour cause de budget.
"""
from __future__ import annotations

import logging
import time
from contextlib import contextmanager
from dataclasses import dataclass, field
from typing import Iterator

log = logging.getLogger("guardia.budget")

DEFAULT_LIMIT_SEC = 7200  # 2 heures — scan seulement

SCAN_PHASES = frozenset(
    {
        "discover",
        "enrich",
        "services",
        "machines",
        "audit",
        "web",
        "calibrage",
        "usages_pass",
    }
)
POST_PHASES = frozenset(
    {
        "classify",
        "rules",
        "programme",
        "restructure",
        "rgpd",
        "usages",
        "llm",
        "rapport",
        "pdf",
        "json",
        "direction",
        "pistes",
        "hygiene",
        "dossier",
        "identites",
    }
)


@dataclass
class RunBudget:
    limit_sec: float = DEFAULT_LIMIT_SEC
    t0: float = field(default_factory=time.monotonic)
    timings: dict[str, float] = field(default_factory=dict)
    kinds: dict[str, str] = field(default_factory=dict)
    skipped: list[str] = field(default_factory=list)
    truncated: list[str] = field(default_factory=list)
    operator_truncated: list[str] = field(default_factory=list)
    _phase: str = ""
    _phase_kind: str = "scan"
    _phase_t1: float = 0.0

    def _kind_of(self, name: str, kind: str | None) -> str:
        if kind in ("scan", "post"):
            return kind
        if name in POST_PHASES:
            return "post"
        return "scan"

    def elapsed(self) -> float:
        return max(0.0, time.monotonic() - self.t0)

    def elapsed_scan(self) -> float:
        s = sum(v for k, v in self.timings.items() if self.kinds.get(k, "scan") == "scan")
        if self._phase and self._phase_kind == "scan" and self._phase_t1:
            s += max(0.0, time.monotonic() - self._phase_t1)
        return s

    def remaining(self) -> float:
        return max(0.0, self.limit_sec - self.elapsed_scan())

    def expired(self) -> bool:
        return self.remaining() <= 0.05

    def cap(self, wanted: float, minimum: float = 5.0) -> float:
        rem = self.remaining()
        if rem <= 0:
            return 0.0
        return max(minimum, min(float(wanted), rem)) if rem >= minimum else rem

    def can_start(self, phase: str, *, must_run: bool = False, kind: str | None = None) -> bool:
        k = self._kind_of(phase, kind)
        if k == "post" or must_run:
            return True
        if self.expired():
            self.skipped.append(phase)
            log.warning("budget scan épuisé — phase « %s » sautée", phase)
            return False
        return True

    @contextmanager
    def phase(
        self, name: str, *, must_run: bool = False, kind: str | None = None
    ) -> Iterator["RunBudget"]:
        k = self._kind_of(name, kind)
        post = k == "post"
        if post:
            must_run = True
        if self.expired() and not must_run and not post:
            if name not in self.skipped:
                self.skipped.append(name)
                log.warning("budget scan épuisé — phase « %s » sautée", name)
            yield self
            return
        if self.expired() and must_run and not post:
            log.warning(
                "budget scan épuisé — phase « %s » jouée quand même (must_run)",
                name,
            )
        self._phase = name
        self._phase_kind = k
        self._phase_t1 = time.monotonic()
        try:
            from guardia.core.operator import get_operator

            get_operator().begin_phase(name)
            yield self
        finally:
            dt = time.monotonic() - self._phase_t1
            self.timings[name] = round(dt, 2)
            self.kinds[name] = k
            self._phase = ""
            self._phase_kind = "scan"
            self._phase_t1 = 0.0
            log.info(
                "timing %s [%s]: %.1fs (scan %.0fs / plafond %.0fs)",
                name,
                k,
                dt,
                self.elapsed_scan(),
                self.limit_sec,
            )
            if k == "scan" and self.expired() and name not in self.truncated and not must_run:
                self.truncated.append(name)
            try:
                from guardia.core.operator import get_operator

                op = get_operator()
                if op.events and name not in self.operator_truncated:
                    for ev in op.events:
                        if (
                            ev.phase == name
                            and ev.kind == "skip_phase"
                            and name not in self.operator_truncated
                        ):
                            self.operator_truncated.append(name)
                            if name not in self.truncated:
                                self.truncated.append(name)
            except Exception:
                pass

    def summary(self) -> dict:
        scan = round(self.elapsed_scan(), 2)
        post = round(
            sum(v for k, v in self.timings.items() if self.kinds.get(k) == "post"),
            2,
        )
        return {
            "limit_sec": int(self.limit_sec),
            "elapsed_sec": round(self.elapsed(), 2),
            "elapsed_scan_sec": scan,
            "elapsed_post_sec": post,
            "remaining_sec": round(self.remaining(), 2),
            "timings": dict(self.timings),
            "kinds": dict(self.kinds),
            "truncated_phases": list(self.truncated),
            "skipped_phases": list(self.skipped),
            "operator_truncated_phases": list(self.operator_truncated),
            "budget_hit": bool(self.skipped or self.truncated),
            "operator_interrupt": bool(self.operator_truncated),
        }
