"""Dossier d'audit Guardia — le Red est un contrat, pas un bouton.

Huit pièces. Hash SHA-256. Sans liasse complète, pas de regard
sur un parc professionnel. L'intrusion (niveaux 2-3) n'est pas
dans le moteur : les documents existent, Guardia refuse de les
exécuter. Relu avec le cadre de l'association.
"""
from __future__ import annotations

import hashlib
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from guardia.core.parc import parc_de

PIECES = (
    ("01-convention-audit", "Convention d'audit", True, True),
    ("02-autorisation-test", "Autorisation expresse de test", True, True),
    ("03-rules-of-engagement", "Règles d'engagement", False, True),
    ("04-autorisation-red-team", "Autorisation spécifique Red team", False, True),
    ("05-annexe-rgpd", "Annexe RGPD / sous-traitance", True, True),
    ("06-charte-confidentialite", "Charte de confidentialité opérateur", True, True),
    ("07-procedure-arret", "Procédure d'arrêt d'urgence", True, True),
    ("08-notice-rapport", "Notice rapport + conservation", True, True),
)

NIVEAUX = (
    (0, "Observation", "Lecture seule. Portes, bannières, configurations visibles. Aucune exploitation."),
    (1, "Scan de sécurité", "Identification de services et versions. Pas d'exploit. Le moteur actuel s'arrête ici."),
    (2, "Validation technique", "Preuve de concept contrôlée. Documentée, pas exécutée par Guardia aujourd'hui."),
    (3, "Red team", "Accès, privilèges, latéral — uniquement si le cadre judiciaire ET le moteur le permettent. Pas avant."),
)

PASSI = (
    "Ce document est un rapport de test de sécurité informatique, "
    "établi avec l'outil professionnel Guardia par Echoes of Hackers "
    "(association déclarée, ESS). "
    "Il ne constitue ni une certification ANSSI/PASSI, ni une certification RGPD, "
    "ni une certification de conformité réglementaire, ni un document délivré "
    "par la CNIL, l'ANSSI ou toute autre autorité publique. "
    "Méthodologie inspirée des recommandations publiques ANSSI. "
    "Si un mode PASSI a été exécuté, les cinq domaines et les six briques "
    "ont été joués en lecture, avec autorisations signées, périmètre, "
    "traçabilité et validation humaine. Cela n'est pas un certificat. "
    "Les capacités logicielles ne sont pas une qualification organisationnelle."
)

MOTIF = (
    "Art. 323-1, 323-2, 323-3 CP. Art. 323-3-1 : motif légitime "
    "(recherche / sécurité informatique) pour les outils. "
    "Guardia n'est pas « j'ai Kali donc je peux ». "
    "Guardia est « j'ai une mission signée, limitée, traçable »."
)


def _extras(mission: Any) -> dict[str, Any]:
    ex = getattr(mission, "extras", None) or {}
    return ex if isinstance(ex, dict) else {}


def _dossier_raw(mission: Any) -> dict[str, Any]:
    d = _extras(mission).get("dossier") or {}
    return d if isinstance(d, dict) else {}


def niveau_de(mission: Any) -> int:
    try:
        n = int(_dossier_raw(mission).get("niveau") or 0)
    except (TypeError, ValueError):
        n = 0
    return max(0, min(3, n))


def llm_local(mission: Any) -> bool:
    mode = str(_dossier_raw(mission).get("llm") or _extras(mission).get("llm_mode") or "local")
    return mode.strip().lower() not in ("externe", "api", "cloud")


def etat(mission: Any) -> dict[str, Any]:
    parc = parc_de(mission)
    raw = _dossier_raw(mission)
    pieces: list[dict[str, Any]] = []
    manquantes: list[str] = []
    for ident, titre, need_perso, need_pro in PIECES:
        requis = need_perso if parc == "personnel" else need_pro
        if ident == "04-autorisation-red-team":
            requis = bool(raw.get("red_autorise")) or niveau_de(mission) >= 2
        signe = bool(raw.get(ident)) or bool(raw.get(ident.split("-", 1)[-1].replace("-", "_")))
        # alias courts
        alias = {
            "01-convention-audit": ("convention",),
            "02-autorisation-test": ("autorisation",),
            "03-rules-of-engagement": ("roe",),
            "04-autorisation-red-team": ("red_autorise", "red"),
            "05-annexe-rgpd": ("rgpd_annexe",),
            "06-charte-confidentialite": ("confidentialite", "charte"),
            "07-procedure-arret": ("arret",),
            "08-notice-rapport": ("notice",),
        }
        for a in alias.get(ident, ()):
            if raw.get(a):
                signe = True
        if ident in ("01-convention-audit", "02-autorisation-test") and getattr(
            mission, "mandat_nda_signes", False
        ):
            # mandat+NDA existants = convention + autorisation pour le personnel
            if parc == "personnel":
                signe = True
        item = {"id": ident, "titre": titre, "requis": requis, "signe": signe}
        pieces.append(item)
        if requis and not signe:
            manquantes.append(titre)
    n = niveau_de(mission)
    return {
        "parc": parc,
        "niveau": n,
        "niveau_libelle": NIVEAUX[n][1],
        "pieces": pieces,
        "manquantes": manquantes,
        "complet": not manquantes,
        "llm_local": llm_local(mission),
        "passi": PASSI,
        "motif": MOTIF,
        "red_test_moteur": False,
    }


def peut_red_regard(mission: Any) -> tuple[bool, str]:
    """Regard (niveau 0) : lecture seule. Personnel : mandat. Professionnel : liasse hors pièce 04."""
    if not getattr(mission, "mandat_nda_signes", False):
        return False, "Mandat / NDA non signés."
    parc = parc_de(mission)
    if parc == "personnel":
        return True, "Parc personnel — mandat + NDA."
    st = etat(mission)
    # pièce 04 seulement si on a demandé du red test
    manq = [p["titre"] for p in st["pieces"] if p["requis"] and not p["signe"] and p["id"] != "04-autorisation-red-team"]
    if manq:
        return False, "Dossier professionnel incomplet : " + ", ".join(manq)
    return True, "Dossier professionnel — regard autorisé."


def peut_red_test(mission: Any) -> tuple[bool, str]:
    """Niveaux 2-3. Le moteur refuse toujours. Les documents existent."""
    del mission
    return False, (
        "Niveaux 2-3 : documents prévus, moteur inerte. "
        "Pas d'intrusion tant que le cadre d'exécution n'est pas posé — pas avant."
    )


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256_file(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def generer(mission: Any, dest: Path) -> dict[str, Any]:
    """Copie les modèles, remplit l'en-tête, écrit MANIFEST.sha256."""
    from guardia.core.paths import ROOT

    src = ROOT / "modeles" / "dossier"
    dest.mkdir(parents=True, exist_ok=True)
    st = etat(mission)
    client = getattr(mission, "client", "Client") or "Client"
    cidr = getattr(mission, "cidr", "") or _extras(mission).get("cidr") or ""
    hashes: list[tuple[str, str]] = []
    for ident, titre, _a, _b in PIECES:
        body = _entete(mission, ident, titre, client, cidr, st)
        modele = src / f"{ident}.txt"
        if modele.is_file():
            body += "\n\n" + modele.read_text(encoding="utf-8")
        out = dest / f"{ident}.txt"
        data = body.encode("utf-8")
        out.write_bytes(data)
        hashes.append((out.name, sha256_bytes(data)))
    man = dest / "MANIFEST.sha256"
    lines = [f"{h}  {n}" for n, h in hashes]
    man.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return {
        "dossier": str(dest),
        "parc": st["parc"],
        "pieces": len(hashes),
        "hashes": [{"fichier": n, "sha256": h} for n, h in hashes],
        "manifest": str(man),
    }


def _entete(mission: Any, ident: str, titre: str, client: str, cidr: Any, st: dict[str, Any]) -> str:
    now = datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return (
        f"GUARDIA — {titre}\n"
        f"Pièce {ident}\n"
        f"Client : {client}\n"
        f"Parc : {st['parc']}\n"
        f"Niveau d'engagement demandé : {st['niveau']} ({st['niveau_libelle']})\n"
        f"Périmètre CIDR : {cidr or '(à renseigner)'}\n"
        f"Opérateur : {getattr(mission, 'operateur_nom', '') or 'Platon-Y'}\n"
        f"Echoes of Hackers — RNA W882005217 · SIREN 933496234 · NAF 8020Z\n"
        f"Date de génération : {now}\n"
        f"{PASSI}\n"
    )
