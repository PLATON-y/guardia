"""Commandes de surveillance lecture seule — Guardia (map, ne pas emprunter)."""
from __future__ import annotations

from typing import Any

# safe=True : lecture seule, aucune écriture sur la cible, aucun exploit.
COMMANDS: list[dict[str, Any]] = [
    {"name": "nmap_discover", "category": "discover", "cmd": "nmap -sn {cidr}", "target": "cidr", "safe": True,
     "why": "Découverte hôtes vivants (ping sweep)"},
    {"name": "nmap_services", "category": "services", "cmd": "nmap -sV -p {ports} {host}", "target": "host", "safe": True,
     "why": "Versions services (lecture)"},
    {"name": "nmap_tls", "category": "tls", "cmd": "nmap -p 443 --script ssl-enum-ciphers {host}", "target": "host", "safe": True,
     "why": "Enumération chiffrements TLS"},
    {"name": "arp_scan", "category": "discover", "cmd": "arp-scan --localnet", "target": "local", "safe": True,
     "why": "Inventaire L2 local"},
    {"name": "nbtscan", "category": "discover", "cmd": "nbtscan {cidr}", "target": "cidr", "safe": True,
     "why": "Noms NetBIOS"},
    {"name": "curl_headers", "category": "web", "cmd": "curl -sI -m 12 {url}", "target": "url", "safe": True,
     "why": "En-têtes HTTP"},
    {"name": "openssl_sclient", "category": "tls",
     "cmd": "openssl s_client -connect {host}:443 -servername {host} </dev/null", "target": "host", "safe": True,
     "why": "Chaîne certificat TLS"},
    {"name": "ss_listen", "category": "local", "cmd": "ss -tulpn", "target": "local", "safe": True,
     "why": "Sockets écoute poste opérateur"},
    {"name": "lsof_net", "category": "local", "cmd": "lsof -i -P -n", "target": "local", "safe": True,
     "why": "Processus réseau locaux"},
    {"name": "tcpdump_sample", "category": "capture",
     "cmd": "tcpdump -i {iface} -nn -c 500 -w {cap_path}", "target": "local", "safe": True,
     "why": "Échantillon passif (fichier local)"},
    {"name": "ufw_status", "category": "local", "cmd": "ufw status verbose", "target": "local", "safe": True,
     "why": "État pare-feu local"},
    {"name": "iptables_list", "category": "local", "cmd": "iptables -L -n -v", "target": "local", "safe": True,
     "why": "Règles iptables locales"},
    {"name": "ip_route", "category": "local", "cmd": "ip -4 route; ip -6 route", "target": "local", "safe": True,
     "why": "Routes pour détecter CIDR local"},
    {"name": "nc_probe", "category": "ssh_preflight", "cmd": "nc -zv -w 5 {host} {port}", "target": "host", "safe": True,
     "why": "Préflight SSH : port ouvert"},
    {"name": "ssh_keyscan", "category": "ssh_preflight", "cmd": "ssh-keyscan -p {port} {host}", "target": "host", "safe": True,
     "why": "Préflight SSH : empreinte serveur"},
]


def by_name(name: str) -> dict[str, Any] | None:
    for c in COMMANDS:
        if c["name"] == name:
            return dict(c)
    return None


def safe_only() -> list[dict[str, Any]]:
    return [dict(c) for c in COMMANDS if c.get("safe")]


def assert_no_offensive() -> None:
    """Garde-fou : aucune commande offensive dans le catalogue."""
    banned = ("exploit", "hydra", "sqlmap", "metasploit", "msfconsole", "ffuf", "impacket", "reverse", "payload")
    for c in COMMANDS:
        blob = (c.get("cmd") or "").lower() + " " + (c.get("name") or "").lower()
        for b in banned:
            if b in blob:
                raise AssertionError(f"commande interdite dans catalogue : {c['name']} ({b})")


__all__ = ["COMMANDS", "by_name", "safe_only", "assert_no_offensive"]
