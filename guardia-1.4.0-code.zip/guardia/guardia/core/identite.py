"""Identité de l'opérateur — ÉOH paraphe, le trafic se présente.

Pendant une évaluation, l'opérateur Echoes of Hackers n'est pas un scanner
anonyme. Il a un mandat, il paraphe, le User-Agent dit Guardia. Les outils
servent à trouver une exposition et à expliquer comment la corriger — pas à entrer.
"""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from guardia import __signature__, __version__
from guardia.core.models import Mission

ASSOCIATION = "Echoes of Hackers"
SIGLE = "ÉOH"
OPERATEUR_DEFAUT = "Platon-Y"
RNA = "W882005217"
SIREN = "933496234"
NAF = "8020Z"
ESS_LOI = "loi n° 2014-856"

VISAGE_DECOUVERT = (
    "Opérateur identifié. Le trafic HTTP se présente "
    "(User-Agent Guardia / Echoes of Hackers). "
    "Pas de decoy nmap, pas d'usurpation d'adresse, pas de scan furtif. "
    "Intervention sur autorisation écrite, datée et périmétrée."
)

NMAP_HONNETE = (
    "Pas de -D (decoy), pas de --spoof-mac, pas de -sI (idle), pas de -f (frag). "
    "Découverte -sn puis empreinte -sV. Le journal dit qui a lancé, quand, sur quel CIDR."
)

# Flags qui feraient de Guardia un scanner furtif. Interdits.
STEALTH_FLAGS = (
    "-D",
    "--spoof-mac",
    "-sI",
    "-f",
    "--badsum",
    "--source-port",
    "--data-length",
    "--ttl",
    "--randomize-hosts",
    "-g",
)


def user_agent(version: str | None = None) -> str:
    v = version or __version__
    return (
        f"Guardia/{v} (Echoes of Hackers; evaluation defensive autorisee; "
        "pas d'exploit; operateur identifie)"
    )


def operateur_de(mission: Mission) -> str:
    nom = (getattr(mission, "operateur_nom", None) or "").strip()
    if nom:
        return nom
    extra = (mission.extras or {}).get("operateur_nom")
    if extra:
        return str(extra).strip()
    sig = (mission.signature or "").split("/")[0].strip()
    return sig or OPERATEUR_DEFAUT


def operateur_a_signe(mission: Mission) -> bool:
    if getattr(mission, "operateur_signe", False):
        return True
    extra = mission.extras or {}
    val = extra.get("operateur_signe")
    if val is True or str(val).lower() in ("true", "oui", "yes", "1"):
        return True
    return False


def assert_nmap_honnete(argv: list[str]) -> None:
    """Refuse les flags de furtivité — opérateur identifié."""
    for a in argv:
        low = a.split("=", 1)[0]
        if low in STEALTH_FLAGS:
            raise ValueError(
                f"nmap furtif interdit ({a}) — Guardia identifie l'opérateur. "
                "Pas de decoy, pas d'adresse usurpée, pas de fragment."
            )


def bloc_signature(mission: Mission, *, date: str | None = None) -> dict[str, Any]:
    """Double paraphe rapport : habilité (client) + opérateur ÉOH."""
    jour = date or datetime.now(timezone.utc).strftime("%Y-%m-%d")
    return {
        "client": mission.client,
        "habilite": mission.personne_commune or mission.client,
        "operateur": operateur_de(mission),
        "association": ASSOCIATION,
        "sigle": SIGLE,
        "rna": RNA,
        "siren": SIREN,
        "naf": NAF,
        "signature": mission.signature or __signature__,
        "operateur_signe": operateur_a_signe(mission),
        "mandat": bool(mission.mandat_nda_signes),
        "date": jour,
        "visage_decouvert": VISAGE_DECOUVERT,
        "user_agent": user_agent(),
    }


def banniere_run(mission: Mission, cidr: str) -> str:
    op = operateur_de(mission)
    signe = "paraphé" if operateur_a_signe(mission) else "à parapher"
    return (
        f"{ASSOCIATION} ({SIGLE}) — évaluation défensive, opérateur identifié\n"
        f"Opérateur : {op} · RNA {RNA} · {signe}\n"
        f"Client : {mission.client} · CIDR {cidr}\n"
        f"User-Agent : {user_agent()}\n"
        f"{VISAGE_DECOUVERT}"
    )


def identite_dict(mission: Mission | None = None) -> dict[str, Any]:
    m = mission or Mission()
    return {
        "association": ASSOCIATION,
        "sigle": SIGLE,
        "operateur": operateur_de(m),
        "rna": RNA,
        "siren": SIREN,
        "naf": NAF,
        "ess": ESS_LOI,
        "version": __version__,
        "user_agent": user_agent(),
        "visage_decouvert": VISAGE_DECOUVERT,
        "nmap_honnete": NMAP_HONNETE,
        "operateur_signe": operateur_a_signe(m),
        "signature": m.signature or __signature__,
    }
