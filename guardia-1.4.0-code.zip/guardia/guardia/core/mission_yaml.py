"""Normalise le YAML de mission — plat historique ou imbriqué (produit)."""
from __future__ import annotations

from typing import Any


def flatten(raw: dict[str, Any] | None) -> dict[str, Any]:
    """Accepte le schéma plat *et* le schéma imbriqué.

    Imbriqué ::

        mission:
          id: …
          cidr: 192.168.1.0/24
          scope: { cidr: […], urls: […] }
        authorization:
          network_scan: true
          exploitation: false
    """
    if not raw or not isinstance(raw, dict):
        return {}
    if "mission" not in raw or not isinstance(raw.get("mission"), dict):
        return dict(raw)
    m = dict(raw["mission"])
    scope = m.pop("scope", None) or {}
    if not isinstance(scope, dict):
        scope = {}
    cidr = scope.get("cidr")
    if isinstance(cidr, list):
        cidr = cidr[0] if cidr else None
    if cidr and not m.get("cidr"):
        m["cidr"] = cidr
    urls = scope.get("urls") if scope.get("urls") is not None else scope.get("url")
    if urls:
        m["site_url"] = urls[0] if isinstance(urls, list) else urls
    if scope.get("exclusions") and not m.get("interdit"):
        m["interdit"] = list(scope.get("exclusions") or [])
    auth = raw.get("authorization")
    if isinstance(auth, dict):
        m["authorization"] = dict(auth)
        if auth.get("exploitation") is False:
            interdit = [str(x) for x in (m.get("interdit") or [])]
            if "exploitation" not in interdit:
                interdit.append("exploitation")
            m["interdit"] = interdit
        if auth.get("intrusive_testing") is False:
            m["intrusive_testing"] = False
    profile = raw.get("profile")
    if isinstance(profile, dict):
        m["profile"] = profile
        pid = str(profile.get("id") or "")
        if pid and not m.get("profil_moteur"):
            m["profil_moteur"] = pid
    for k, v in raw.items():
        if k in ("mission", "authorization", "profile"):
            continue
        if k not in m or m.get(k) in (None, "", [], {}):
            m[k] = v
    if not m.get("cidr") and raw.get("cidr"):
        m["cidr"] = raw["cidr"]
    if not m.get("site_url") and raw.get("site_url"):
        m["site_url"] = raw["site_url"]
    if raw.get("id") and not m.get("id"):
        m["id"] = raw["id"]
    return m
