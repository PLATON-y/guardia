"""Plages CIDR connues — inventaire Guardia (lecture / classification).

Listes exhaustives pour cartographie LAN défensive (Echoes of Hackers).
Ne lance aucun scan : classification et itération d'hôtes uniquement.
"""
from __future__ import annotations

import ipaddress
from typing import Iterator

# --- RFC 1918 — Privé (LAN) ---
PRIVATE_V4_RFC1918: tuple[str, ...] = (
    "10.0.0.0/8",
    "172.16.0.0/12",
    "192.168.0.0/16",
)

# Sous-plages 192.168.x courantes
PRIVATE_V4_192168: tuple[str, ...] = (
    "192.168.0.0/24",    # SFR, Bouygues
    "192.168.1.0/24",    # Free, Orange
    "192.168.1.0/25",
    "192.168.1.128/25",
    "192.168.1.0/26",
    "192.168.1.64/26",
    "192.168.1.128/26",
    "192.168.1.192/26",
    "192.168.100.0/24",  # Modems câble bridge
)

# Sous-plages 10.x courantes
PRIVATE_V4_10: tuple[str, ...] = (
    "10.0.0.0/24",       # LAN entreprise
    "10.10.10.0/24",     # HackTheBox lab
    "10.10.11.0/24",     # HackTheBox lab
    "10.129.0.0/16",     # HackTheBox lab
    "10.8.0.0/24",       # OpenVPN défaut
    "10.42.0.0/24",      # Nomad / k3s
    "10.88.0.0/16",      # Podman default
    "10.244.0.0/16",     # Flannel CNI
)

# Sous-plages 172.16–31.x courantes
PRIVATE_V4_172: tuple[str, ...] = (
    "172.16.0.0/24",
    "172.17.0.0/16",     # Docker bridge
    "172.18.0.0/16",     # Docker custom
    "172.20.0.0/16",     # Docker swarm
    "172.22.0.0/16",     # Kubernetes kind
    "172.30.0.0/16",     # OpenShift
)

PRIVATE_V4: tuple[str, ...] = (
    PRIVATE_V4_RFC1918
    + PRIVATE_V4_192168
    + PRIVATE_V4_10
    + PRIVATE_V4_172
)

# RFC 6598 — CGNAT
CGNAT: tuple[str, ...] = (
    "100.64.0.0/10",
)

# Boucle, local, réservé
LOOPBACK: tuple[str, ...] = (
    "127.0.0.0/8",
    "127.0.0.1/32",
    "::1/128",
)

LINK_LOCAL: tuple[str, ...] = (
    "169.254.0.0/16",    # APIPA
    "fe80::/10",
)

MULTICAST: tuple[str, ...] = (
    "224.0.0.0/4",
    "224.0.0.1/32",      # All hosts
    "224.0.0.251/32",    # mDNS
    "224.0.0.252/32",    # LLMNR
    "239.255.255.250/32",  # SSDP
    "ff00::/8",
)

RESERVED: tuple[str, ...] = (
    "240.0.0.0/4",
    "255.255.255.255/32",
)

# Documentation, lab, benchmark
DOCUMENTATION: tuple[str, ...] = (
    "192.0.2.0/24",      # TEST-NET-1
    "198.51.100.0/24",   # TEST-NET-2
    "203.0.113.0/24",    # TEST-NET-3
    "198.18.0.0/15",     # Benchmark
    "2001:db8::/32",
)

# IPv6 ULA / divers
PRIVATE_V6: tuple[str, ...] = (
    "fc00::/7",
    "fd00::/8",
)

IPV6_MISC: tuple[str, ...] = (
    "2002::/16",         # 6to4 obsolète
)

# Hyperviseurs / virtualisation
VIRTUALIZATION: tuple[str, ...] = (
    "192.168.56.0/24",   # VirtualBox host-only
    "192.168.122.0/24",  # libvirt/KVM
    "192.168.64.0/24",   # Multipass
    "192.168.99.0/24",   # Docker Toolbox legacy
)

ALL_KNOWN: tuple[str, ...] = tuple(
    dict.fromkeys(
        PRIVATE_V4
        + CGNAT
        + LOOPBACK
        + LINK_LOCAL
        + MULTICAST
        + RESERVED
        + DOCUMENTATION
        + PRIVATE_V6
        + IPV6_MISC
        + VIRTUALIZATION
    )
)

# Usage hints (optionnel, pour rapports)
USAGE: dict[str, str] = {
    "10.0.0.0/8": "RFC 1918 privé",
    "172.16.0.0/12": "RFC 1918 privé",
    "192.168.0.0/16": "RFC 1918 privé",
    "192.168.0.0/24": "SFR, Bouygues (courant)",
    "192.168.1.0/24": "Free, Orange (courant)",
    "192.168.100.0/24": "Modems câble bridge",
    "10.0.0.0/24": "LAN entreprise",
    "10.10.10.0/24": "HackTheBox lab",
    "10.10.11.0/24": "HackTheBox lab",
    "10.129.0.0/16": "HackTheBox lab",
    "10.8.0.0/24": "OpenVPN défaut",
    "10.42.0.0/24": "Nomad / k3s",
    "10.88.0.0/16": "Podman default",
    "10.244.0.0/16": "Flannel CNI",
    "172.17.0.0/16": "Docker bridge",
    "172.18.0.0/16": "Docker custom",
    "172.20.0.0/16": "Docker swarm",
    "172.22.0.0/16": "Kubernetes kind",
    "172.30.0.0/16": "OpenShift",
    "100.64.0.0/10": "RFC 6598 CGNAT / Tailscale",
    "127.0.0.0/8": "Loopback",
    "169.254.0.0/16": "APIPA / link-local",
    "192.168.56.0/24": "VirtualBox host-only",
    "192.168.122.0/24": "libvirt/KVM",
    "192.168.64.0/24": "Multipass",
    "192.168.99.0/24": "Docker Toolbox (legacy)",
    "fc00::/7": "ULA IPv6",
    "fd00::/8": "ULA courant",
    "fe80::/10": "Link-local IPv6",
    "2001:db8::/32": "Documentation IPv6",
}


def _parse(ip: str) -> ipaddress._BaseAddress:
    return ipaddress.ip_address(ip.strip())


def _nets(cidrs: tuple[str, ...]) -> list[ipaddress._BaseNetwork]:
    return [ipaddress.ip_network(c, strict=False) for c in cidrs]


def _in_any(ip: str, cidrs: tuple[str, ...]) -> bool:
    try:
        addr = _parse(ip)
    except ValueError:
        return False
    for net in _nets(cidrs):
        if addr.version == net.version and addr in net:
            return True
    return False


def is_private(ip: str) -> bool:
    """RFC 1918 / ULA (et sous-plages listées)."""
    try:
        addr = _parse(ip)
    except ValueError:
        return False
    if addr.is_private:
        return True
    return _in_any(ip, PRIVATE_V4 + PRIVATE_V6)


def is_loopback(ip: str) -> bool:
    try:
        return _parse(ip).is_loopback
    except ValueError:
        return False


def is_multicast(ip: str) -> bool:
    try:
        return _parse(ip).is_multicast
    except ValueError:
        return False


def is_cgnat(ip: str) -> bool:
    return _in_any(ip, CGNAT)


def is_link_local(ip: str) -> bool:
    try:
        addr = _parse(ip)
    except ValueError:
        return False
    if addr.is_link_local:
        return True
    return _in_any(ip, LINK_LOCAL)


def is_documentation(ip: str) -> bool:
    return _in_any(ip, DOCUMENTATION)


def is_virtualization(ip: str) -> bool:
    return _in_any(ip, VIRTUALIZATION)


def classify(ip: str) -> str:
    """Classe une IP : private | cgnat | loopback | link_local | multicast |
    documentation | virtualization | reserved | public | invalid.
    """
    try:
        addr = _parse(ip)
    except ValueError:
        return "invalid"
    if addr.is_loopback or _in_any(ip, LOOPBACK):
        return "loopback"
    if addr.is_multicast or _in_any(ip, MULTICAST):
        return "multicast"
    if is_link_local(ip):
        return "link_local"
    if is_documentation(ip):
        return "documentation"
    if is_cgnat(ip):
        return "cgnat"
    if is_virtualization(ip):
        return "virtualization"
    if _in_any(ip, RESERVED) or getattr(addr, "is_reserved", False):
        return "reserved"
    if is_private(ip):
        return "private"
    return "public"


def iterate_hosts(cidr: str) -> Iterator[str]:
    """Itère les adresses hôtes d'un CIDR (exclut réseau/broadcast en IPv4)."""
    net = ipaddress.ip_network(cidr, strict=False)
    for host in net.hosts():
        yield str(host)


def usage_of(cidr: str) -> str | None:
    return USAGE.get(cidr)




# Plages à tester quand le CIDR UI est vide (catalogue opérateur).
AUTO_SCAN_CIDRS: tuple[str, ...] = tuple(
    dict.fromkeys(
        PRIVATE_V4_192168
        + PRIVATE_V4_10
        + PRIVATE_V4_172
        + VIRTUALIZATION
        + CGNAT
    )
)


def auto_scan_cidrs() -> list[str]:
    """Liste ordonnée des CIDR à sonder si l'opérateur laisse le champ vide."""
    return list(AUTO_SCAN_CIDRS)

__all__ = [
    "PRIVATE_V4",
    "AUTO_SCAN_CIDRS",
    "auto_scan_cidrs",
    "PRIVATE_V4_RFC1918",
    "PRIVATE_V4_192168",
    "PRIVATE_V4_10",
    "PRIVATE_V4_172",
    "PRIVATE_V6",
    "LOOPBACK",
    "LINK_LOCAL",
    "MULTICAST",
    "DOCUMENTATION",
    "CGNAT",
    "VIRTUALIZATION",
    "RESERVED",
    "ALL_KNOWN",
    "USAGE",
    "is_private",
    "is_loopback",
    "is_multicast",
    "is_cgnat",
    "is_link_local",
    "is_documentation",
    "is_virtualization",
    "classify",
    "iterate_hosts",
    "usage_of",
]
