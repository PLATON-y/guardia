"""Orchestration : le YAML allume, Guardia enchaîne, un outil absent n'arrête rien.

Le plan n'est pas un décor. Chaque action prévue est jouée, sautée ou
notée absente — jamais seulement « appelée ». Un binaire manquant n'arrête
rien. Greenbone / Lynis / Trivy : Guardia les orchestre (lecture), elle
n'invite plus en silence.
"""
from __future__ import annotations

from typing import Any, Callable

from guardia.core.defaults import DEFAULT_SITE_URL
from guardia.core.models import Mission


_PARC_TYPES = {
    "pme",
    "ecole",
    "association",
    "organisme",
    "parc_entreprise",
}

_OT_EQUIP = {
    "industriel",
    "industriels",
    "automate",
    "automates",
    "ot",
    "plc",
    "machine",
    "machines",
    "scada",
    "hmi",
    "profinet",
    "ethernet-ip",
    "ethernetip",
    "modbus",
    "s7",
    "opcua",
    "opc-ua",
    "melsec",
}

# Flags YAML → args (s'ils ne sont pas déjà posés en CLI)
_YAML_FLAGS = (
    "llm",
    "pdf",
    "all_ports",
    "lynis",
    "rgpd",
    "usages",
    "machines",
    "pistes",
    "audit",
    "audit_full",
    "verbose",
    "full",
    "greenbone",
    "trivy",
    "passi",
    "autorisations",
    "cve",
)


def _red(args: Any, mission: Mission) -> bool:
    from guardia.core.equipe import est_red

    return est_red(args, mission)


def _truthy(v: Any) -> bool:
    if v is True:
        return True
    if v is False or v is None:
        return False
    if isinstance(v, (int, float)):
        return v != 0
    s = str(v).strip().lower()
    return s in ("1", "true", "oui", "yes", "on", "full")


def _extras(mission: Mission) -> dict[str, Any]:
    return dict(mission.extras or {})


def _equipements(mission: Mission) -> list[str]:
    ex = _extras(mission)
    raw = ex.get("equipements_attendus") or []
    if isinstance(raw, str):
        raw = [raw]
    return [str(x).strip().lower() for x in raw]


def appliquer_yaml(args: Any, mission: Mission) -> None:
    """Le YAML n'est pas un décor : il allume vraiment les actions."""
    ex = _extras(mission)
    for key in _YAML_FLAGS:
        # Cases UI décochées (--no-*) : ne pas rallumer depuis le YAML
        _no_attr = {
            "rgpd": "no_rgpd",
            "usages": "no_usages",
            "pistes": "no_pistes",
            "passi": "no_passi",
            "lynis": "no_lynis",
            "greenbone": "no_greenbone",
            "trivy": "no_trivy",
            "machines": "no_machines",
            "autorisations": "no_autorisations",
            "audit": "no_audit",
            "llm": "no_llm",
            "pdf": "no_pdf",
            "cve": "no_cve",
            "calibrage": "no_calibrage",
            "lan": "no_lan",
        }.get(key)
        if _no_attr and getattr(args, _no_attr, False):
            continue
        if _truthy(ex.get(key)) and not getattr(args, key, False):
            try:
                setattr(args, key, True)
            except Exception:  # noqa: BLE001
                pass
    if (
        not getattr(args, "no_passi", False)
        and (_truthy(ex.get("passi")) or getattr(args, "passi", False) or _truthy(ex.get("offre_passi")))
    ):
        # PASSI = liasse signée + lecture configuration. Pas Trivy, pas avenant.
        for flag in ("autorisations", "lynis", "greenbone"):
            if getattr(args, f"no_{flag}", False):
                continue
            if not getattr(args, flag, False):
                try:
                    setattr(args, flag, True)
                except Exception:  # noqa: BLE001
                    pass
    if not getattr(args, "no_full", False) and (_truthy(ex.get("parc_inconnu")) or (mission.profondeur or "") == "full"):
        try:
            setattr(args, "full", True)
        except Exception:  # noqa: BLE001
            pass
        mission.profondeur = "full"
        mission.extras["parc_inconnu"] = True
        mission.extras["mode"] = "full"
    if not getattr(args, "no_all_ports", False) and _truthy(ex.get("all_ports")):
        mission.extras["all_ports"] = True
    workers = ex.get("workers")
    if workers not in (None, "", "auto") and not getattr(args, "workers", None):
        try:
            setattr(args, "workers", workers)
        except Exception:  # noqa: BLE001
            pass
    if not getattr(args, "no_site", False) and getattr(args, "site", None) in (None, "") and (ex.get("site_url") or ex.get("site")):
        site = want_site(args, mission)
        if site:
            try:
                setattr(args, "site", site)
            except Exception:  # noqa: BLE001
                pass


def want_site(args: Any, mission: Mission) -> str | None:
    """URL à auditer, ou None si le module reste éteint.

    CLI ``--site`` (sans valeur) → example.test.
    YAML ``site_url`` / ``site`` honoré si pas de --site.
    ``--no-site`` coupe (case UI décochée).
    """
    if getattr(args, "no_site", False):
        return None
    cli = getattr(args, "site", None)
    if cli is not None:
        url = str(cli).strip()
        return url or DEFAULT_SITE_URL
    ex = _extras(mission)
    for key in ("site_url", "site"):
        val = ex.get(key)
        if val:
            s = str(val).strip()
            if s.lower() in ("1", "true", "oui", "yes", "on"):
                return DEFAULT_SITE_URL
            return s
    return None


def want_rgpd(args: Any, mission: Mission) -> bool:
    """Signalement RGPD = sur demande. Jamais un certificat.

    Allumé par ``--rgpd``, YAML ``rgpd: true``, ou audit full
    (le volet est dans les options full). ``--no-rgpd`` coupe tout.
    """
    if getattr(args, "no_rgpd", False):
        return False
    if getattr(args, "rgpd", False):
        return True
    ex = _extras(mission)
    if _truthy(ex.get("rgpd")):
        return True
    if _truthy(ex.get("audit_full")) or getattr(args, "audit_full", False):
        return True
    audit_val = ex.get("audit")
    if isinstance(audit_val, str) and audit_val.strip().lower() == "full":
        return True
    return False


def want_restructure(args: Any, mission: Mission) -> bool:
    """Chapitre « où restructurer » : parcs / entreprises, pas le foyer simple."""
    if getattr(args, "restructure", False):
        return True
    ex = _extras(mission)
    if _truthy(ex.get("restructure")):
        return True
    if (mission.profil_moteur or "").lower() in ("pme", "ecole"):
        return True
    if (mission.type_structure or "").lower() in _PARC_TYPES:
        return True
    if _truthy(ex.get("audit")) or _truthy(ex.get("audit_full")):
        return True
    return False


def want_machines(args: Any, mission: Mission) -> bool:
    """Scan machines / OT — red team, sur demande."""
    if getattr(args, "no_machines", False):
        return False
    if not _red(args, mission):
        return False
    if getattr(args, "machines", False):
        return True
    ex = _extras(mission)
    if _truthy(ex.get("machines")) or _truthy(ex.get("ot")):
        return True
    if any(e in _OT_EQUIP for e in _equipements(mission)):
        return True
    return False


def want_usages(args: Any, mission: Mission) -> bool:
    """Usages & droits : auto école, sinon sur demande. ``--no-usages`` coupe."""
    if getattr(args, "no_usages", False):
        return False
    if getattr(args, "usages", False):
        return True
    ex = _extras(mission)
    if _truthy(ex.get("usages")):
        return True
    if (mission.profil_moteur or "").lower() == "ecole":
        return True
    if (mission.type_structure or "").lower() == "ecole":
        return True
    return False


def want_pistes(args: Any, mission: Mission) -> bool:
    """Catalogue de pistes (pas des findings). Red team."""
    if not _red(args, mission):
        return False
    if getattr(args, "no_pistes", False):
        return False
    if getattr(args, "pistes", False) or getattr(args, "llm", False):
        return True
    ex = _extras(mission)
    if _truthy(ex.get("pistes")) or _truthy(ex.get("llm")):
        return True
    taille = str(ex.get("taille_parc") or "").lower()
    if taille in ("l", "large", "xl", "centaines", "gros", "grande"):
        return True
    if (mission.profil_moteur or "").lower() in ("pme", "ecole"):
        return True
    if (mission.type_structure or "").lower() in _PARC_TYPES:
        return True
    return False


def want_burp(args: Any, mission: Mission) -> bool:
    """API du plan : toujours éteint."""

    _ = args, mission
    return False


def want_calibrage(args: Any, mission: Mission) -> bool:
    """Calibrage Kali : red team. Blue : inventaire nmap seulement."""
    if not _red(args, mission):
        return False
    if getattr(args, "no_calibrage", False):
        return False
    if getattr(args, "calibrage", False):
        return True
    ex = _extras(mission)
    if "calibrage" in ex:
        return _truthy(ex.get("calibrage"))
    return True


def want_lan(args: Any, mission: Mission) -> bool:
    """Scan LAN (nmap + calibrage). Décoche / --no-lan = actions ciblées seulement."""
    if getattr(args, "no_lan", False):
        return False
    if getattr(args, "lan", False):
        return True
    ex = _extras(mission)
    if "lan" in ex:
        return _truthy(ex.get("lan"))
    return True


def want_audit(args: Any, mission: Mission) -> str | None:
    """None / 'standard' / 'full'. Red team."""
    if not _red(args, mission):
        return None
    if getattr(args, "audit_full", False) or _truthy(_extras(mission).get("audit_full")):
        return "full"
    audit_val = _extras(mission).get("audit")
    if getattr(args, "audit", False) or _truthy(audit_val):
        if isinstance(audit_val, str) and audit_val.strip().lower() == "full":
            return "full"
        if _extras(mission).get("audit_level") == "full":
            return "full"
        return "full" if getattr(args, "audit_full", False) else "standard"
    return None


def want_llm(args: Any, mission: Mission) -> bool:
    if getattr(args, "no_llm", False):
        return False
    if getattr(args, "llm", False):
        return True
    ex = _extras(mission)
    if "llm" in ex:
        return _truthy(ex.get("llm"))
    st = getattr(args, "llm_status", None) or {}
    return (st.get("mode") or "") in ("llama", "openai-compat", "ollama")


def want_pdf(args: Any, mission: Mission) -> bool:
    if getattr(args, "no_pdf", False):
        return False
    if getattr(args, "pdf", False):
        return True
    return _truthy(_extras(mission).get("pdf"))


def want_lynis(args: Any, mission: Mission) -> bool:
    """Lynis = poste opérateur, pas le LAN client. YAML lynis: true ou --lynis."""
    if getattr(args, "no_lynis", False):
        return False
    if getattr(args, "lynis", False):
        return True
    return _truthy(_extras(mission).get("lynis"))


def want_greenbone(args: Any, mission: Mission) -> bool:
    """Greenbone / OpenVAS — red team. Guardia parle à GVM (version, feeds)."""
    if getattr(args, "no_greenbone", False):
        return False
    if not _red(args, mission):
        return False
    if getattr(args, "greenbone", False) or getattr(args, "gvm", False):
        return True
    ex = _extras(mission)
    if _truthy(ex.get("greenbone")) or _truthy(ex.get("gvm")) or _truthy(ex.get("openvas")):
        return True
    if _truthy(ex.get("audit_full")) or getattr(args, "audit_full", False):
        return True
    return False


def want_trivy(args: Any, mission: Mission) -> bool:
    """Trivy = poste opérateur, red team."""
    if getattr(args, "no_trivy", False):
        return False
    if not _red(args, mission):
        return False
    if getattr(args, "trivy", False):
        return True
    return _truthy(_extras(mission).get("trivy"))


def want_passi(args: Any, mission: Mission) -> bool:
    """Offre PASSI : red team + YAML/--passi. ``--no-passi`` coupe (UI)."""
    if getattr(args, "no_passi", False):
        return False
    if not _red(args, mission):
        return False
    if getattr(args, "passi", False) or getattr(args, "offre_passi", False):
        return True
    ex = _extras(mission)
    return _truthy(ex.get("passi")) or _truthy(ex.get("offre_passi"))


def want_autorisations(args: Any, mission: Mission) -> bool:
    """Pack autorisations red. YAML autorisations: true."""
    if getattr(args, "no_autorisations", False):
        return False
    if not _red(args, mission):
        return False
    if getattr(args, "autorisations", False):
        return True
    return _truthy(_extras(mission).get("autorisations"))


def want_cve(args: Any, mission: Mission) -> bool:
    """Corrélation CVE catalogue local (lecture). Auto si audit/full/passi."""
    from guardia.engines.cve_correlate import want_cve as _want

    return _want(args, mission)




def summarize_plan(args: Any, mission: Mission) -> dict[str, Any]:
    site = want_site(args, mission)
    burp = want_burp(args, mission)
    lan = want_lan(args, mission)
    from guardia.core.equipe import normaliser

    equipe_demandee = normaliser(
        _extras(mission).get("equipe") or getattr(args, "equipe", None) or "blue"
    )
    return {
        "lan": lan,
        "site_url": site,
        "rgpd": want_rgpd(args, mission),
        "restructure": want_restructure(args, mission) if lan else False,
        "machines": want_machines(args, mission) if lan else False,
        "usages": want_usages(args, mission),
        "pistes": want_pistes(args, mission) if lan else False,
        "burp": burp,
        "programme": True,
        "calibrage": want_calibrage(args, mission) if lan else False,
        "audit": want_audit(args, mission),
        "llm": want_llm(args, mission),
        "pdf": want_pdf(args, mission),
        "lynis": want_lynis(args, mission),
        "greenbone": want_greenbone(args, mission),
        "trivy": want_trivy(args, mission),
        "passi": want_passi(args, mission),
        "autorisations": want_autorisations(args, mission),
        "cve": want_cve(args, mission),
        "equipe_demandee": equipe_demandee,
        "equipe": "red" if _red(args, mission) else "blue",
        "profond": bool(
            _red(args, mission)
            and (
                getattr(args, "full", False)
                or (mission.profondeur or "") == "full"
                or _truthy(_extras(mission).get("parc_inconnu"))
            )
        ),
    }


_PLAN_LABELS: tuple[tuple[str, str], ...] = (
    ("lan", "LAN nmap"),
    ("calibrage", "Calibrage Kali"),
    ("site_url", "Site web"),
    ("rgpd", "Signalement RGPD"),
    ("usages", "Usages & droits"),
    ("restructure", "Restructuration"),
    ("machines", "Machines / OT"),
    ("pistes", "Pistes"),
    ("audit", "Audit"),
    ("llm", "LLM (hors scan)"),
    ("pdf", "PDF (hors scan)"),
    ("lynis", "Lynis opérateur"),
    ("greenbone", "Greenbone / GVM"),
    ("trivy", "Trivy opérateur"),
    ("passi", "Offre PASSI (red)"),
    ("autorisations", "Autorisations (red)"),
    ("cve", "Corrélation CVE (lecture)"),
    ("equipe_demandee", "Équipe"),
    ("profond", "Approfondir"),
)

# Clés d'action que le journal doit couvrir (pas l'équipe / profond).
CLES_ACTION: tuple[str, ...] = (
    "lan",
    "calibrage",
    "site_url",
    "rgpd",
    "usages",
    "restructure",
    "machines",
    "pistes",
    "audit",
    "llm",
    "pdf",
    "lynis",
    "greenbone",
    "trivy",
    "passi",
    "autorisations",
    "programme",
)


def annoncer_plan(plan: dict[str, Any]) -> list[str]:
    """Imprime le plan AVANT de jouer — ce n'est plus une liste décorative."""
    lignes: list[str] = []
    print("── Plan de visite ──", flush=True)
    allumes = 0
    for key, label in _PLAN_LABELS:
        val = plan.get(key)
        if not val:
            print(f"  {label}: éteint", flush=True)
            lignes.append(f"{key}:off")
            continue
        allumes += 1
        if val is True:
            shown = "allumé"
        else:
            shown = str(val)
        print(f"  {label}: {shown}", flush=True)
        lignes.append(f"{key}:{shown}")
    print(f"  → {allumes} action(s) à enchaîner. Un outil absent = on continue.", flush=True)
    return lignes


class JournalOrchestre:
    """Trace ce qui a vraiment tourné, pas seulement ce qui était prévu."""

    def __init__(self) -> None:
        self.etapes: list[dict[str, Any]] = []

    def phase(self, titre: str) -> None:
        print(f"── {titre} ──", flush=True)
        self.etapes.append({"type": "phase", "titre": titre, "etat": "joue"})

    def outil(self, nom: str, cible: str, etat: str) -> None:
        cible_s = f" {cible}" if cible else ""
        print(f"  {nom}{cible_s}: {etat}", flush=True)
        self.etapes.append({"type": "outil", "nom": nom, "cible": cible, "etat": etat})

    def skip(self, nom: str, why: str) -> None:
        print(f"  {nom}: sauté — {why}", flush=True)
        self.etapes.append({"type": "skip", "nom": nom, "etat": "sauté", "why": why})

    def note(self, text: str) -> None:
        print(f"  {text}", flush=True)
        self.etapes.append({"type": "note", "titre": text, "etat": "note"})

    def deja(self, *mots: str) -> bool:
        blob = " ".join(
            f"{e.get('nom') or ''} {e.get('titre') or ''}".lower() for e in self.etapes
        )
        return any(m.lower() in blob for m in mots if m)

    def as_dict(self) -> dict[str, Any]:
        joues = sum(1 for e in self.etapes if e.get("etat") in ("joue", "ok", "note"))
        absents = sum(1 for e in self.etapes if e.get("etat") in ("absent", "sauté"))
        return {
            "n": len(self.etapes),
            "joues": joues,
            "absents_ou_sautes": absents,
            "etapes": self.etapes,
        }

    def couvrir(self, plan: dict[str, Any]) -> None:
        """Filet : une action prévue sans trace = skip tardif, jamais un oubli silencieux."""
        labels = {k: lab for k, lab in _PLAN_LABELS}
        aliases = {
            "lan": ("lan nmap", "nmap discover", "nmap -sn"),
            "calibrage": ("calibrage",),
            "site_url": ("site web", "curl", "lecture url"),
            "rgpd": ("rgpd",),
            "usages": ("usages",),
            "restructure": ("restructure",),
            "machines": ("machines", "ot"),
            "pistes": ("pistes",),
            "audit": ("audit",),
            "llm": ("llm",),
            "pdf": ("pdf",),
            "lynis": ("lynis",),
            "greenbone": ("greenbone", "gvm"),
            "trivy": ("trivy",),
            "passi": ("passi", "offre passi"),
            "autorisations": ("autorisations", "liasse"),
            "programme": ("programme", "outils de la visite"),
        }
        for key in CLES_ACTION:
            allume = bool(plan.get(key))
            if self.deja(*(aliases.get(key) or (key,))):
                continue
            label = labels.get(key, key)
            if allume:
                self.skip(label, "prévu — pas de trace (filet orchestre)")
            else:
                self.skip(label, "plan éteint")


def brancher_calibrage(journal: JournalOrchestre) -> Callable[[dict[str, Any]], None]:
    """Chaque sonde Kali rapporte son état au journal — pas un print orphelin."""

    def on_job(job: dict[str, Any]) -> None:
        nom = str(job.get("nom") or job.get("id") or "sonde")
        cible = str(job.get("cible") or job.get("ip") or "")
        etat = str(job.get("etat") or ("ok" if job.get("lance") else "absent"))
        journal.outil(nom, cible, etat)

    return on_job


def jouer(
    nom: str,
    fn: Callable[[], Any],
    errors: list[str],
    *,
    journal: JournalOrchestre | None = None,
    cible: str = "",
) -> Any:
    """Exécute une étape. Exception → on note, on enchaîne. Succès → journal ok."""
    try:
        out = fn()
        if journal is not None:
            journal.outil(nom, cible, "ok")
        return out
    except Exception as exc:  # noqa: BLE001
        errors.append(f"{nom}: {exc}")
        if journal is not None:
            journal.skip(nom, str(exc))
        else:
            print(f"  {nom}: on continue ({exc})", flush=True)
        return None
