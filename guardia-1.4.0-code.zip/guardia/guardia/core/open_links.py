"""Ouvrir fichiers / dossiers et checkup des liens — machine unique ÉOH.

Le premier zip ouvrait Thunar / Firefox / Okular depuis l'UI. En root (scans nmap)
xdg-open et les file managers meurent tout de suite : D-Bus session absent,
Popen renvoyait True dès que le binaire existait. Ici on emprunte la session
graphique de l'opérateur, on ne déclare succès que si le helper tient, et un
checkup au démarrage dit ce qui est cassé (une seule machine Kali).
"""
from __future__ import annotations

import os
import pwd
import shutil
import stat
import subprocess
import sys
import time
from pathlib import Path
from typing import Any

from guardia.core.paths import DOCS, MISSIONS, MODELES, RAPPORTS, ROOT

_LAUNCHERS = (
    ROOT / "lancer-ui.sh",
    ROOT / "lancer-cli.sh",
    ROOT / "bin" / "guardia",
    ROOT / "bin" / "guardia-wizard.py",
)


def _which(name: str) -> str | None:
    return shutil.which(name)


def session_user() -> dict[str, Any]:
    """Qui possède l'écran — même si Guardia tourne en root pour nmap."""
    euid = os.geteuid() if hasattr(os, "geteuid") else 0
    sudo = (os.environ.get("SUDO_USER") or "").strip()
    login = (os.environ.get("USER") or "").strip()
    name = sudo or (login if euid != 0 else "")
    uid = euid
    home = str(Path.home())
    if euid == 0 and sudo:
        try:
            pw = pwd.getpwnam(sudo)
            uid = int(pw.pw_uid)
            home = pw.pw_dir or f"/home/{sudo}"
            name = sudo
        except KeyError:
            uid = int(os.environ.get("SUDO_UID") or 0)
            home = f"/home/{sudo}"
            name = sudo
    display = os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY") or ""
    if not display:
        for cand in (":0", ":1"):
            if Path(f"/tmp/.X11-unix/X{cand[1:]}").exists():
                display = cand
                break
    runtime = os.environ.get("XDG_RUNTIME_DIR") or (f"/run/user/{uid}" if uid else "")
    bus = os.environ.get("DBUS_SESSION_BUS_ADDRESS") or ""
    bus_path = Path(runtime) / "bus" if runtime else None
    if not bus and bus_path is not None and bus_path.exists():
        bus = f"unix:path={bus_path}"
    xauth = os.environ.get("XAUTHORITY") or ""
    if not xauth:
        for p in (Path(home) / ".Xauthority", Path("/home/platon-y/.Xauthority")):
            try:
                if p.is_file():
                    xauth = str(p)
                    break
            except OSError:
                continue
    return {
        "euid": euid,
        "uid": uid,
        "user": name or ("root" if euid == 0 else login or "inconnu"),
        "home": home,
        "display": display,
        "wayland": os.environ.get("WAYLAND_DISPLAY") or "",
        "runtime": runtime,
        "bus": bus,
        "xauth": xauth,
        "root": euid == 0,
    }


def _gui_env(sess: dict[str, Any] | None = None) -> dict[str, str]:
    sess = sess or session_user()
    env = dict(os.environ)
    if sess.get("display") and not env.get("DISPLAY"):
        env["DISPLAY"] = str(sess["display"])
    if sess.get("wayland") and not env.get("WAYLAND_DISPLAY"):
        env["WAYLAND_DISPLAY"] = str(sess["wayland"])
    if sess.get("runtime"):
        env["XDG_RUNTIME_DIR"] = str(sess["runtime"])
    if sess.get("bus"):
        env["DBUS_SESSION_BUS_ADDRESS"] = str(sess["bus"])
    if sess.get("xauth"):
        env["XAUTHORITY"] = str(sess["xauth"])
    env.setdefault("GDK_BACKEND", "x11")
    return env


def _as_user_cmd(argv: list[str], sess: dict[str, Any]) -> list[str]:
    """Si root : lancer le helper sous l'utilisateur de session (D-Bus / X)."""
    if not sess.get("root"):
        return argv
    user = str(sess.get("user") or "")
    if not user or user == "root":
        return argv
    env_pairs = []
    if sess.get("display"):
        env_pairs.append(f"DISPLAY={sess['display']}")
    if sess.get("wayland"):
        env_pairs.append(f"WAYLAND_DISPLAY={sess['wayland']}")
    if sess.get("runtime"):
        env_pairs.append(f"XDG_RUNTIME_DIR={sess['runtime']}")
    if sess.get("bus"):
        env_pairs.append(f"DBUS_SESSION_BUS_ADDRESS={sess['bus']}")
    if sess.get("xauth"):
        env_pairs.append(f"XAUTHORITY={sess['xauth']}")
    wrapper: list[str] = []
    if _which("runuser"):
        wrapper = ["runuser", "-u", user, "--"]
    elif _which("sudo"):
        wrapper = ["sudo", "-u", user, "-H"]
    if not wrapper:
        return argv
    return wrapper + ["env", *env_pairs, *argv]


def _helpers(folder: bool, path: str) -> list[list[str]]:
    low = path.lower()
    if folder:
        names = ("thunar", "exo-open", "pcmanfm", "dolphin", "nautilus", "gio", "xdg-open")
        cmds: list[list[str]] = []
        for n in names:
            if n == "gio":
                cmds.append(["gio", "open", path])
            else:
                cmds.append([n, path])
        return cmds
    if low.endswith(".pdf"):
        # Okular d'abord, puis Firefox neutre (via open_path → open_html), puis fallbacks
        names = ("okular", "evince", "firefox-esr", "firefox", "xdg-open", "gio")
    elif low.endswith((".html", ".htm")):
        # Preferé : firefox_neutre.open_html (appelé avant _helpers dans open_path)
        names = ("firefox-esr", "firefox", "xdg-open", "gio", "okular")
    else:
        names = ("xdg-open", "exo-open", "gio", "firefox-esr")
    cmds = []
    for n in names:
        if n == "gio":
            cmds.append(["gio", "open", path])
        elif n in ("firefox-esr", "firefox") and low.endswith((".html", ".htm", ".pdf")):
            # -P neutre --no-remote pour HTML/PDF si open_html n'a pas déjà réussi
            cmds.append([n, "-P", "neutre", "--no-remote", path])
        else:
            cmds.append([n, path])
    return cmds


def _alive(proc: subprocess.Popen[Any]) -> bool:
    code = proc.poll()
    if code is None:
        return True
    return code == 0


def open_path(path: str | Path, *, folder: bool = False) -> tuple[bool, str]:
    """Ouvre un fichier ou un dossier. (ok, message)."""
    p = Path(path).expanduser()
    try:
        target = str(p.resolve())
    except OSError:
        target = str(p)
    if folder:
        if not p.is_dir():
            return False, f"dossier introuvable : {target}"
    else:
        if not p.is_file():
            return False, f"fichier introuvable : {target}"

    if sys.platform == "darwin":
        try:
            subprocess.Popen(["open", target], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
            return True, f"open {target}"
        except OSError as exc:
            return False, str(exc)
    if not sys.platform.startswith("linux"):
        try:
            os.startfile(target)  # type: ignore[attr-defined]
            return True, f"startfile {target}"
        except OSError as exc:
            return False, str(exc)

    # HTML : Firefox ESR profil neutre en priorité (rapports + hub docs)
    if not folder and target.lower().endswith((".html", ".htm")):
        try:
            from guardia.core.firefox_neutre import open_html as _open_html_neutre

            ok_n, msg_n = _open_html_neutre(target)
            if ok_n:
                return True, msg_n
            last_neutre = msg_n
        except Exception as exc:  # noqa: BLE001
            last_neutre = str(exc)
    else:
        last_neutre = ""

    # PDF : Okular d'abord, puis Firefox neutre
    if not folder and target.lower().endswith(".pdf"):
        sess_pre = session_user()
        env_pre = _gui_env(sess_pre)
        if _which("okular"):
            raw_ok = ["okular", target]
            cmd_ok = _as_user_cmd(raw_ok, sess_pre)
            try:
                proc = subprocess.Popen(
                    cmd_ok,
                    stdout=subprocess.DEVNULL,
                    stderr=subprocess.DEVNULL,
                    cwd=str(ROOT),
                    env=env_pre,
                    start_new_session=True,
                )
                time.sleep(0.45)
                if _alive(proc):
                    who = (
                        f" (via {sess_pre['user']})"
                        if sess_pre.get("root") and sess_pre.get("user") != "root"
                        else ""
                    )
                    return True, f"okular{who}"
            except OSError:
                pass
        try:
            from guardia.core.firefox_neutre import open_html as _open_html_neutre

            ok_n, msg_n = _open_html_neutre(target)
            if ok_n:
                return True, msg_n
        except Exception:  # noqa: BLE001
            pass

    sess = session_user()
    env = _gui_env(sess)
    last = last_neutre or "aucun helper graphique (thunar / exo-open / firefox-esr / xdg-open)"
    for raw in _helpers(folder, target):
        bin_name = raw[0]
        if bin_name not in ("env", "runuser", "sudo") and not _which(bin_name):
            continue
        cmd = _as_user_cmd(raw, sess)
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                cwd=str(ROOT),
                env=env,
                start_new_session=True,
            )
        except FileNotFoundError:
            last = f"{bin_name} absent"
            continue
        except OSError as exc:
            last = f"{bin_name}: {exc}"
            continue
        time.sleep(0.45)
        if _alive(proc):
            who = f" (via {sess['user']})" if sess.get("root") and sess.get("user") != "root" else ""
            return True, f"{' '.join(raw)}{who}"
        last = f"{bin_name} s'est arrêté tout de suite (code {proc.returncode})"
    return False, last


def repair_exec_bits() -> list[str]:
    """Rétablit +x sur les lanceurs (zip Python perd parfois le bit)."""
    done: list[str] = []
    for p in _LAUNCHERS:
        try:
            if not p.is_file():
                continue
            mode = p.stat().st_mode
            if mode & stat.S_IXUSR:
                continue
            p.chmod(mode | 0o755)
            if p.stat().st_mode & stat.S_IXUSR:
                done.append(str(p.relative_to(ROOT)))
        except OSError:
            continue
    return done


def _item(key: str, statut: str, detail: str) -> dict[str, str]:
    return {"id": key, "statut": statut, "detail": detail}


def _dir_item(key: str, path: Path, *, mkdir: bool = False) -> dict[str, str]:
    try:
        if mkdir:
            path.mkdir(parents=True, exist_ok=True)
        if path.is_dir():
            return _item(key, "ok", str(path))
        return _item(key, "ko", f"absent : {path}")
    except OSError as exc:
        return _item(key, "ko", f"{path} : {exc}")


def run_checkup(*, repair: bool = True) -> dict[str, Any]:
    """Checkup des liens — machine unique ÉOH, pas un scan réseau."""
    items: list[dict[str, str]] = []
    sess = session_user()
    repaired = repair_exec_bits() if repair else []

    items.append(_item("racine", "ok" if ROOT.is_dir() else "ko", str(ROOT)))
    items.append(_dir_item("missions", MISSIONS, mkdir=True))
    items.append(_dir_item("rapports", RAPPORTS, mkdir=True))
    items.append(_dir_item("modeles", MODELES))
    items.append(_dir_item("docs", DOCS))
    assets = ROOT / "assets"
    items.append(_dir_item("assets", assets))

    py = sys.executable or "python3"
    items.append(_item("python3", "ok", py))
    try:
        import tkinter  # noqa: F401

        items.append(_item("tkinter", "ok", "python3-tk"))
    except ImportError:
        items.append(_item("tkinter", "ko", "sudo apt install python3-tk"))

    nmap = _which("nmap")
    items.append(_item("nmap", "ok" if nmap else "ko", nmap or "sudo apt install nmap"))

    for name, label, level_if_missing in (
        ("thunar", "thunar", "warn"),
        ("exo-open", "exo-open (XFCE)", "warn"),
        ("xdg-open", "xdg-open", "ko"),
        ("gio", "gio", "warn"),
        ("firefox-esr", "firefox-esr", "warn"),
        ("okular", "okular", "warn"),
        ("dolphin", "dolphin", "warn"),
    ):
        w = _which(name)
        if w:
            items.append(_item(label, "ok", w))
        else:
            items.append(_item(label, level_if_missing, "absent du PATH"))

    try:
        from guardia.core.firefox_neutre import (
            desktop_shortcut_path,
            ensure_neutre_profile,
            neutre_profile_exists,
        )

        if not neutre_profile_exists():
            ensure_neutre_profile(create_desktop=True)
        if neutre_profile_exists():
            items.append(_item("firefox-neutre", "ok", "profil neutre"))
        else:
            items.append(
                _item(
                    "firefox-neutre",
                    "warn",
                    "profil absent — scripts/install-firefox-neutre.sh",
                )
            )
        desk = desktop_shortcut_path()
        if desk:
            items.append(_item("firefox-neutre.desktop", "ok", str(desk)))
        else:
            items.append(
                _item(
                    "firefox-neutre.desktop",
                    "warn",
                    "raccourci Bureau absent — install-firefox-neutre.sh",
                )
            )
    except Exception as exc:  # noqa: BLE001
        items.append(_item("firefox-neutre", "warn", str(exc)))

    for p in _LAUNCHERS:
        rel = str(p.relative_to(ROOT)) if p.exists() else p.name
        if not p.is_file():
            items.append(_item(rel, "warn", "fichier absent"))
            continue
        try:
            mode = p.stat().st_mode
            if mode & stat.S_IXUSR:
                items.append(_item(rel, "ok", f"+x {p}"))
            else:
                items.append(
                    _item(
                        rel,
                        "warn",
                        "pas +x ici — le zip Kali porte 755 ; chmod si besoin : chmod +x " + rel,
                    )
                )
        except OSError as exc:
            items.append(_item(rel, "ko", str(exc)))

    if repaired:
        items.append(_item("chmod", "ok", "bit +x rétabli : " + ", ".join(repaired)))

    if sess.get("display") or sess.get("wayland"):
        items.append(
            _item(
                "affichage",
                "ok",
                f"DISPLAY={sess.get('display') or '—'} WAYLAND={sess.get('wayland') or '—'}",
            )
        )
    else:
        items.append(_item("affichage", "ko", "pas de DISPLAY / WAYLAND_DISPLAY"))

    if sess.get("bus") or (sess.get("runtime") and Path(str(sess["runtime"]), "bus").exists()):
        items.append(_item("dbus", "ok", str(sess.get("bus") or f"{sess.get('runtime')}/bus")))
    else:
        items.append(
            _item(
                "dbus",
                "warn" if not sess.get("root") else "ko",
                "bus session introuvable — ouvrir un dossier en root échoue souvent",
            )
        )

    if sess.get("root"):
        if sess.get("user") and sess["user"] != "root":
            items.append(
                _item(
                    "root",
                    "warn",
                    f"UI en root — ouvertures via {sess['user']} (session graphique)",
                )
            )
        else:
            items.append(
                _item(
                    "root",
                    "ko",
                    "UI en root sans SUDO_USER — Thunar/xdg-open cassés. "
                    "Lance lancer-ui.sh depuis la session bureau, pas sudo pur.",
                )
            )
    else:
        items.append(_item("session", "ok", f"uid {sess.get('uid')} ({sess.get('user')})"))

    n_ok = sum(1 for i in items if i["statut"] == "ok")
    n_warn = sum(1 for i in items if i["statut"] == "warn")
    n_ko = sum(1 for i in items if i["statut"] == "ko")
    can_open = n_ko == 0 or (
        any(i["id"] == "xdg-open" and i["statut"] == "ok" for i in items)
        and any(i["id"] == "affichage" and i["statut"] == "ok" for i in items)
    )
    return {
        "items": items,
        "ok": n_ok,
        "warn": n_warn,
        "ko": n_ko,
        "session": sess,
        "repaired": repaired,
        "can_open_gui": can_open,
        "root": str(ROOT),
    }


def format_checkup(rep: dict[str, Any]) -> str:
    lines = [
        f"Checkup des liens — {rep.get('ok', 0)} OK · {rep.get('warn', 0)} warn · {rep.get('ko', 0)} KO",
        f"Racine : {rep.get('root')}",
    ]
    for it in rep.get("items") or []:
        mark = {"ok": "OK", "warn": "!!", "ko": "KO"}.get(it.get("statut"), "??")
        lines.append(f"  [{mark}] {it.get('id')}: {it.get('detail')}")
    return "\n".join(lines)
