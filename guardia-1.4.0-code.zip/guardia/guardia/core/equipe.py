"""Blue team / Red team — un moteur, deux regards.

Blue : checkup. Red regard : même lecture + chemins, si mot de passe
ET liasse (parc professionnel). Pas d'intrusion. Niveaux 2-3 : documents,
moteur inerte — pas avant.
"""
from __future__ import annotations

import os
from typing import Any, Literal

Equipe = Literal["blue", "red"]

# Indice opérateur uniquement — jamais dans le rapport client.
# Le hash n'est PLUS en dépôt : ~/.config/guardia/red.pass,
# GUARDIA_RED_PASSWORD_HASH, ou queen_decide RED_TEAM_PASSWORD_HASH=.
INDICE_RED = "échoes of hackers, marmelade — hash local/env (pas de clair en git)"

PALETTE = {
    "blue": {
        "accent": "#1E4F8A",
        "accent_clair": "#2B6CB0",
        "trough": "#152033",
        "rail": "#1A3A66",
        "thumb": "#1E4F8A",
        "thumb_mid": "#D5E0F0",
        "thumb_hi": "#F4F8FC",
        "border": "#2B6CB0",
    },
    "red": {
        "accent": "#9B1B1B",
        "accent_clair": "#C62828",
        "trough": "#3A1515",
        "rail": "#6B1212",
        "thumb": "#8B0000",
        "thumb_mid": "#E8D5D5",
        "thumb_hi": "#F5EEEE",
        "border": "#9B1B1B",
    },
}


# Capacités réservées au red regard (mot de passe + équipe red).
# Blue = checkup défensif. Red = même lecture + approfondissement attaquant.
RED_ONLY = (
    "full",
    "all_ports",
    "audit",
    "audit_full",
    "calibrage",
    "greenbone",
    "trivy",
    "machines",
    "pistes",
    "passi",
    "autorisations",
)


def verifier_red(mot: str) -> bool:
    """Délègue à red_gate (fichier local / env / queen_decide)."""
    from guardia.core.red_gate import verifier_red as _vr

    return _vr(mot)


def normaliser(valeur: Any) -> Equipe:
    v = str(valeur or "blue").strip().lower()
    return "red" if v in ("red", "rouge", "redteam", "red-team") else "blue"


def resoudre_equipe(args: Any = None, mission: Any = None) -> Equipe:
    """Red seulement si le mot de passe est bon. Sinon blue, sans bruit client."""
    want = "blue"
    if args is not None:
        want = normaliser(getattr(args, "equipe", None) or "blue")
    if want != "red" and mission is not None:
        extras = getattr(mission, "extras", None) or {}
        if isinstance(extras, dict):
            want = normaliser(extras.get("equipe") or want)
    if want != "red":
        return "blue"
    mot = ""
    if args is not None:
        mot = str(getattr(args, "red_pass", None) or "")
    if not mot:
        mot = os.environ.get("GUARDIA_RED_PASS") or ""
    if verifier_red(mot):
        return "red"
    return "blue"


def est_red(args: Any = None, mission: Any = None) -> bool:
    return resoudre_equipe(args, mission) == "red"


def restreindre_blue(args: Any = None, mission: Any = None) -> list[str]:
    """Si l'équipe réelle est blue : éteint les flags red. Retourne ce qui a été coupé."""
    if est_red(args, mission):
        return []
    coupes: list[str] = []
    for flag in RED_ONLY:
        if args is not None and getattr(args, flag, False):
            try:
                setattr(args, flag, False)
            except Exception:
                pass
            coupes.append(flag)
        if mission is not None:
            extras = getattr(mission, "extras", None)
            if isinstance(extras, dict) and extras.get(flag) not in (None, False, "", 0, "0"):
                extras[flag] = False
                if flag not in coupes:
                    coupes.append(flag)
    if args is not None:
        for no in ("no_calibrage", "no_pistes"):
            try:
                setattr(args, no, True)
            except Exception:
                pass
    if mission is not None:
        if (getattr(mission, "profondeur", "") or "") == "full":
            mission.profondeur = "standard"
            coupes.append("profondeur")
        extras = getattr(mission, "extras", None)
        if isinstance(extras, dict):
            extras["parc_inconnu"] = False
            extras["all_ports"] = False
            extras["audit_full"] = False
            if extras.get("mode") in ("full", "passi"):
                extras["mode"] = "visite"
            extras["equipe"] = "blue"
    return coupes
