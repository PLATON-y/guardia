"""Raccourci Bureau Guardia UI — créé au premier démarrage si absent."""
from __future__ import annotations

import os
import stat
import subprocess
from pathlib import Path
from typing import Any

from guardia import __version__
from guardia.core.paths import ROOT


def desktop_dir() -> Path:
    try:
        from guardia.core.firefox_neutre import desktop_dir as _dd

        return _dd()
    except Exception:  # noqa: BLE001
        pass
    env = (os.environ.get("XDG_DESKTOP_DIR") or "").strip()
    if env:
        return Path(env).expanduser()
    home = Path.home()
    for name in ("Bureau", "Desktop"):
        p = home / name
        if p.is_dir():
            return p
    return home / "Bureau"


def launcher_path() -> Path:
    return desktop_dir() / "Guardia-UI.desktop"


def _icon() -> str:
    for cand in (
        ROOT / "assets" / "guardia-ui.png",
        ROOT / "assets" / "guardia-ui-128.png",
    ):
        if cand.is_file():
            return str(cand)
    return "applications-system"


def desktop_content() -> str:
    exec_sh = ROOT / "lancer-ui.sh"
    return (
        "[Desktop Entry]\n"
        "Version=1.0\n"
        "Type=Application\n"
        "Name=Guardia UI\n"
        f"Comment=Guardia {__version__} — checkup défensif LAN · Echoes of Hackers / Platon-Y\n"
        f"Exec={exec_sh}\n"
        f"Path={ROOT}\n"
        f"Icon={_icon()}\n"
        "Terminal=false\n"
        "Categories=System;Security;\n"
        "StartupNotify=true\n"
        "Keywords=guardia;lan;securite;checkup;\n"
    )


def ensure_guardia_desktop(*, force: bool = False) -> dict[str, Any]:
    """Si aucun Guardia-UI.desktop sur le Bureau → le créer (premier démarrage)."""
    dest = launcher_path()
    out: dict[str, Any] = {
        "ok": True,
        "created": False,
        "path": str(dest),
        "existed": dest.is_file(),
    }
    if dest.is_file() and not force:
        out["detail"] = "lanceur Bureau déjà présent"
        return out
    try:
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_text(desktop_content(), encoding="utf-8")
        mode = dest.stat().st_mode
        dest.chmod(mode | stat.S_IXUSR | stat.S_IXGRP | stat.S_IXOTH)
        out["created"] = True
        out["detail"] = f"créé : {dest}"
        try:
            subprocess.run(
                ["gio", "set", str(dest), "metadata::trusted", "true"],
                check=False,
                capture_output=True,
                timeout=5,
            )
        except Exception:  # noqa: BLE001
            pass
    except Exception as exc:  # noqa: BLE001
        out["ok"] = False
        out["detail"] = str(exc)
    return out
