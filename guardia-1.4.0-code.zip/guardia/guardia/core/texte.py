"""Nettoyage de sorties d'outils — preuves lisibles, pas de faux positifs."""
from __future__ import annotations

from datetime import date
import re

_ANSI = re.compile(r"\x1b\[[0-9;?]*[A-Za-z]|\x1b\][^\x07\x1b]*[\x07\x1b]|\x1b[@-Z\\-_]")

_WEAK_CIPHER = re.compile(
    r"tls_[a-z0-9_]*null|_with_null|null_with|null-md5|null-sha"
    r"|rc4|des-cbc|\b3des\b|triple.?des|\bexport\b|exp-|\bmd5\b|anull|enull"
    r"|sslv?2|sslv?3",
    re.I,
)

_LEGACY_OFFERED = re.compile(
    r"(sslv2|sslv3|tlsv1\.0|tlsv1\.1|tls 1\.0|tls 1\.1|ssl 2|ssl 3)"
    r"\s*[:=]?\s*(offered|enabled|yes|accepted)",
    re.I,
)
_LEGACY_HEADER = re.compile(
    r"^\s*(sslv2|sslv3|tlsv1\.0|tlsv1\.1)\s*:",
    re.I | re.M,
)
_LEGACY_DISABLED_LINE = re.compile(
    r"(sslv2|sslv3|tlsv1\.0|tlsv1\.1|tls 1\.0|tls 1\.1).{0,40}"
    r"\b(disabled|not offered|no)\b",
    re.I,
)


def strip_ansi(s: object) -> str:
    return _ANSI.sub("", str(s if s is not None else ""))


def has_weak_cipher(ciphers: str) -> bool:
    """Vrai seulement si une suite faible est offerte — pas le compresseur NULL."""
    lines: list[str] = []
    skip = False
    for ln in (ciphers or "").splitlines():
        low = ln.lower()
        if "compressor" in low:
            skip = True
            continue
        if skip and ln.strip() and not ln[:1].isspace():
            skip = False
        if skip:
            continue
        lines.append(ln)
    blob = "\n".join(lines)
    return bool(_WEAK_CIPHER.search(blob))


def legacy_tls_offered(text: str) -> bool:
    """Vrai si SSLv3 / TLS 1.0 / 1.1 est réellement offert, pas seulement nommé."""
    cleaned = _LEGACY_DISABLED_LINE.sub("", text or "")
    return bool(_LEGACY_OFFERED.search(cleaned) or _LEGACY_HEADER.search(cleaned))


_AFTER = re.compile(r"not valid after:\s*(\d{4}-\d{2}-\d{2})", re.I)
_EXPIRED_PHRASE = re.compile(
    r"certificate has expired|\berror:.*\bexpired\b|\bssl-cert:.*\bexpired\b",
    re.I,
)


def ssl_cert_expired(ssl: str) -> bool:
    """Nmap écrit toujours « Not valid after » — ce n'est pas un certificat périmé."""
    text = ssl or ""
    m = _AFTER.search(text)
    if m:
        try:
            return date.fromisoformat(m.group(1)) < date.today()
        except ValueError:
            return False
    return bool(_EXPIRED_PHRASE.search(text))

