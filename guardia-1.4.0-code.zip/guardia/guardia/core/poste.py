"""Poste opérateur — vu au scan, retiré du parc client.

On découvre tout le CIDR, puis on écarte la machine qui lance Guardia :
ce n'est pas un actif du SI audité. Détection par adresses locales et
nom d'hôte, pas par une liste figée.
"""
from __future__ import annotations

import logging
import os
import re
import socket
from pathlib import Path
from typing import Any, Iterable

from guardia.core.models import Host, Mission

log = logging.getLogger("guardia.poste")

_LOOPBACK = re.compile(r"^127\.|^::1$|^0\.0\.0\.0$")
_LINKLOCAL = re.compile(r"^169\.254\.")
_GENERIQUE = {
    "",
    "localhost",
    "localhost.localdomain",
    "host",
    "pc",
    "desktop",
    "laptop",
    "unknown",
    "unknown-host",
    "none",
    "kali",
    "debian",
    "ubuntu",
    "linux",
}


def _truthy(v: Any) -> bool:
    if isinstance(v, bool):
        return v
    return str(v or "").strip().lower() in {"1", "true", "oui", "yes", "on"}


def _norm_nom(name: str) -> str:
    n = (name or "").strip().lower().rstrip(".")
    return n.split(".")[0] if n else ""


def adresses_locales() -> set[str]:
    """Toutes les IPv4 non-loopback de la machine qui exécute Guardia."""
    ips: set[str] = set()
    try:
        from guardia.engines.netinfo import _run

        blob = _run(["ip", "-4", "-o", "addr", "show"])
    except Exception:
        blob = ""
    for m in re.finditer(r"inet (\d+\.\d+\.\d+\.\d+)", blob or ""):
        ip = m.group(1)
        if _LOOPBACK.match(ip) or _LINKLOCAL.match(ip):
            continue
        ips.add(ip)
    return ips


def noms_locaux() -> set[str]:
    """Noms d'hôte de la machine opérateur (court + FQDN), hors génériques."""
    raw: set[str] = set()
    try:
        raw.add(socket.gethostname() or "")
    except OSError:
        pass
    try:
        raw.add(os.uname().nodename or "")
    except Exception:
        pass
    try:
        p = Path("/etc/hostname")
        if p.is_file():
            raw.add(p.read_text(encoding="utf-8").splitlines()[0].strip())
    except OSError:
        pass
    out: set[str] = set()
    for n in raw:
        full = (n or "").strip().lower().rstrip(".")
        short = _norm_nom(full)
        if full and full not in _GENERIQUE:
            out.add(full)
        if short and short not in _GENERIQUE:
            out.add(short)
    return out


def est_poste_operateur(
    host: Host,
    *,
    ips: Iterable[str] | None = None,
    noms: Iterable[str] | None = None,
) -> bool:
    ipset = {str(x) for x in (ips or ()) if x}
    nomset = {str(x).lower() for x in (noms or ()) if x}
    if host.ip and host.ip in ipset:
        return True
    hn = (host.hostname or "").strip().lower().rstrip(".")
    if not hn:
        return False
    short = _norm_nom(hn)
    if short in _GENERIQUE:
        return False
    if hn in nomset or (short and short in nomset):
        return True
    return False


def doit_retirer(mission: Mission | None) -> bool:
    """Par défaut on retire. YAML inclure_poste_operateur: true pour garder."""
    if mission is None:
        return True
    ex = mission.extras or {}
    if _truthy(ex.get("inclure_poste_operateur")):
        return False
    return True


def partitionner(
    hosts: list[Host],
    *,
    ips: Iterable[str] | None = None,
    noms: Iterable[str] | None = None,
    mission: Mission | None = None,
    local_ip: str = "",
) -> tuple[list[Host], list[Host]]:
    """(parc client, postes opérateur). Scan déjà fait : on trie, on n'invente pas."""
    if not doit_retirer(mission):
        return list(hosts), []
    ipset = set(ips or ())
    if local_ip:
        ipset.add(local_ip)
    extra = []
    if mission is not None:
        extra = (mission.extras or {}).get("ips_operateur") or []
        if isinstance(extra, str):
            extra = [extra]
        ipset.update(str(x) for x in extra if x)
    nomset = set(noms or ())
    parc: list[Host] = []
    operateur: list[Host] = []
    for h in hosts:
        if est_poste_operateur(h, ips=ipset, noms=nomset):
            operateur.append(h)
        else:
            parc.append(h)
    return parc, operateur


def resume(operateur: list[Host], mission: Mission | None = None) -> dict[str, Any]:
    items = [
        {
            "ip": h.ip,
            "hostname": h.hostname or "",
            "kind": h.kind,
        }
        for h in operateur
    ]
    struct = ""
    if mission is not None:
        struct = mission.type_structure or mission.profil_moteur or ""
    rec = " · ".join(
        (f"{i['hostname']} ({i['ip']})" if i["hostname"] else i["ip"]) for i in items
    )
    return {
        "retire": True,
        "n": len(operateur),
        "items": items,
        "resume": rec,
        "structure": struct,
        "motif": "machine de l'auditeur — hors périmètre client",
    }
