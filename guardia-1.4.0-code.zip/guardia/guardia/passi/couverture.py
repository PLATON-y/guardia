"""Matrice exigence / activité / preuve et métriques de couverture."""
from __future__ import annotations

from typing import Any

from guardia.passi.activites import ACTIVITES, CONTROLES

_VERIFIES = {"observe", "conforme", "ecart", "partiel", "non_conforme"}
_BLOQUES = {"non_autorise"}
_NV = {"non_verifiable"}


def _lignes_eval(ev: dict[str, Any]) -> list[dict[str, Any]]:
    out: list[dict[str, Any]] = []
    mapping = {
        "ARCHI": (ev.get("architecture") or {}).get("observations") or [],
        "CONF": (ev.get("configuration") or {}).get("controles") or [],
        "ORGAPHY": (ev.get("organisationnel") or {}).get("controles") or [],
        "CODE": (ev.get("code") or {}).get("controles") or [],
        "INTRUSION": (ev.get("intrusion") or {}).get("controles") or [],
    }
    by_id = {c["id"]: c for c in CONTROLES}
    seen: set[str] = set()
    for act, rows in mapping.items():
        for row in rows:
            cid = str(row.get("controle") or row.get("id") or "")
            if not cid:
                continue
            seen.add(cid)
            meta = by_id.get(cid) or {}
            resultat = str(row.get("resultat") or "non_verifiable")
            preuve = str(row.get("preuve") or "")
            out.append(
                {
                    "domaine": next((a["nom"] for a in ACTIVITES if a["id"] == act), act),
                    "activite": act,
                    "controle": cid,
                    "libelle": meta.get("libelle") or row.get("libelle") or row.get("observation") or cid,
                    "verifie": resultat in _VERIFIES,
                    "preuve": preuve,
                    "resultat": resultat,
                    "auditeur": str(row.get("reviewer") or ""),
                }
            )
    for c in CONTROLES:
        if c["id"] in seen:
            continue
        out.append(
            {
                "domaine": next((a["nom"] for a in ACTIVITES if a["id"] == c["activite"]), c["activite"]),
                "activite": c["activite"],
                "controle": c["id"],
                "libelle": c["libelle"],
                "verifie": False,
                "preuve": "",
                "resultat": "non_verifiable",
                "auditeur": "",
            }
        )
    return out


def matrice(evaluations: dict[str, Any], activites: list[dict[str, Any]] | None = None) -> list[dict[str, Any]]:
    wanted = {a["id"] for a in (activites or ACTIVITES)}
    rows = _lignes_eval(evaluations)
    if wanted:
        rows = [r for r in rows if r["activite"] in wanted]
    return rows


def _pct(num: int, den: int) -> int:
    if den <= 0:
        return 0
    return int(round(100 * num / den))


def couverture(
    mat: list[dict[str, Any]],
    *,
    perimetre: dict[str, Any] | None = None,
    aptitude: dict[str, Any] | None = None,
) -> dict[str, Any]:
    peri = perimetre or {}
    peri_ok = bool(peri.get("cidr") or peri.get("url"))
    par_act: dict[str, dict[str, int]] = {}
    for r in mat:
        act = r["activite"]
        slot = par_act.setdefault(act, {"n": 0, "verifie": 0, "nv": 0, "bloque": 0})
        slot["n"] += 1
        if r["resultat"] in _NV:
            slot["nv"] += 1
        elif r["resultat"] in _BLOQUES:
            slot["bloque"] += 1
        if r["verifie"]:
            slot["verifie"] += 1
    preuves_ok = sum(1 for r in mat if r.get("preuve"))
    n = len(mat) or 1
    arch = par_act.get("ARCHI") or {"n": 0, "verifie": 0}
    conf = par_act.get("CONF") or {"n": 0, "verifie": 0}
    org = par_act.get("ORGAPHY") or {"n": 0, "verifie": 0}
    code = par_act.get("CODE") or {"n": 0, "verifie": 0}
    intr = par_act.get("INTRUSION") or {"n": 0, "verifie": 0}
    n_nv = sum(1 for r in mat if r["resultat"] in _NV)
    n_bloque = sum(1 for r in mat if r["resultat"] in _BLOQUES)
    # Couverture globale : moyenne des activités demandées, périmètre 100 ou 0.
    act_pcts = [_pct(v["verifie"], v["n"]) for v in par_act.values() if v["n"]]
    prep = 100 if (aptitude or {}).get("verdict") == "complete" else 55 if (aptitude or {}).get("verdict") == "partielle" else 0
    globale = int(round(( (100 if peri_ok else 0) + prep + (sum(act_pcts) / len(act_pcts) if act_pcts else 0) ) / 3))
    return {
        "perimetre": 100 if peri_ok else 0,
        "preparation": prep,
        "architecture": _pct(arch["verifie"], arch["n"]),
        "configuration": _pct(conf["verifie"], conf["n"]),
        "organisationnelle": _pct(org["verifie"], org["n"]),
        "code": _pct(code["verifie"], code["n"]),
        "intrusion": _pct(intr["verifie"], intr["n"]),
        "preuves": _pct(preuves_ok, n),
        "non_verifiables": n_nv,
        "bloquees_mandat": n_bloque,
        "par_activite": par_act,
        "globale": globale,
        "justification": (
            f"Périmètre {'couvert' if peri_ok else 'incomplet'}. "
            f"Préparation {prep} %. "
            f"{n_nv} contrôle(s) non vérifiable(s) — non comptés conformes. "
            f"{n_bloque} action(s) bloquée(s) par mandat."
        ),
        "passi_qualifie": False,
    }


def cockpit(
    cov: dict[str, Any],
    aptitude: dict[str, Any],
    evaluations: dict[str, Any],
    mat: list[dict[str, Any]],
) -> dict[str, Any]:
    a_valider = [r for r in mat if r["resultat"] in ("partiel", "ecart", "observe") and not r.get("auditeur")]
    preuves_manq = [r for r in mat if r["verifie"] and not r.get("preuve")]
    nv = [r for r in mat if r["resultat"] == "non_verifiable"]
    hyps = list(((evaluations.get("intrusion") or {}).get("tests")) or [])
    findings_confirmer = [r for r in mat if r["resultat"] == "ecart"]
    recos = []
    for obs in (evaluations.get("architecture") or {}).get("observations") or []:
        if obs.get("recommandation"):
            recos.append(obs["recommandation"])
    return {
        "titre": "Cockpit auditeur",
        "verdict_aptitude": aptitude.get("verdict"),
        "conclusion_aptitude": aptitude.get("conclusion"),
        "metriques": {
            "perimetre": cov.get("perimetre") or 0,
            "preparation": cov.get("preparation") or 0,
            "architecture": cov.get("architecture") or 0,
            "configuration": cov.get("configuration") or 0,
            "organisation": cov.get("organisationnelle") or 0,
            "code": cov.get("code") or 0,
            "intrusion": cov.get("intrusion") or 0,
            "globale": cov.get("globale") or 0,
        },
        "alertes": {
            "a_valider": len(a_valider),
            "preuves_manquantes": len(preuves_manq),
            "non_verifiables": len(nv),
            "hypotheses": len(hyps),
            "findings_a_confirmer": len(findings_confirmer),
            "recommandations": len(recos),
        },
        "points_a_valider": a_valider[:12],
        "preuves_manquantes": preuves_manq[:12],
        "non_verifiables": nv[:12],
        "hypotheses": hyps[:8],
        "recommandations": recos[:8],
        "actions": ("poursuivre", "revoir", "ajouter_preuve", "valider"),
        "passi_qualifie": False,
        "note": (
            "Guardia n'est pas l'auditeur. "
            "Le cockpit oriente : ce qui est couvert, ce qui ne l'est pas, pourquoi, par quelle preuve."
        ),
    }
