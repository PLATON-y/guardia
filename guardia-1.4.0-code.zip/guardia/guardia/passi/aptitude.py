"""Qualification préalable d'aptitude — étape PASSI v2.2, pas un certificat."""
from __future__ import annotations

from typing import Any

from guardia.core.identite import ASSOCIATION, NAF, RNA, SIREN, SIGLE
from guardia.core.models import Mission
from guardia.passi.activites import ACTIVITES, activites_demandees

VERDICTS = ("complete", "partielle", "aucune")


def _ok(cle: str, label: str, statut: str, detail: str) -> dict[str, str]:
    return {"id": cle, "label": label, "statut": statut, "detail": detail}


def qualifier_aptitude(
    mission: Mission | None = None,
    *,
    autorisations: dict[str, Any] | None = None,
    equipe: str = "red",
    outils_etat: list[dict[str, Any]] | None = None,
    activites: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Verdict d'aptitude à *cette* prestation. Jamais « qualifié PASSI »."""
    m = mission or Mission()
    ex = m.extras or {}
    auth = autorisations or {}
    acts = list(activites) if activites is not None else activites_demandees(m)
    peri_ok = bool((m.cidr or "").strip() or str(ex.get("site_url") or "").strip())
    op_ok = bool((m.operateur_nom or "").strip())
    mandat_ok = bool(m.mandat_nda_signes and m.operateur_signe)
    liasse_ok = bool(auth.get("complet"))
    red_ok = equipe == "red"

    outils = outils_etat or []
    n_outils = len(outils)
    n_present = sum(1 for o in outils if o.get("present"))
    if n_outils == 0:
        outils_statut = "partiel"
        outils_detail = "Inventaire non fourni — l'aptitude ne présume pas les binaires."
    elif n_present == n_outils:
        outils_statut = "ok"
        outils_detail = f"{n_present}/{n_outils} outils utiles présents."
    elif n_present == 0:
        outils_statut = "ko"
        outils_detail = "Aucun outil utile présent sur ce poste."
    else:
        outils_statut = "partiel"
        outils_detail = f"{n_present}/{n_outils} outils utiles présents — on continue sans les absents."

    acts_moteur = [a for a in acts if a.get("moteur")]
    acts_doc = [a for a in acts if not a.get("moteur")]
    if not acts:
        act_statut = "ko"
        act_detail = "Aucune activité demandée."
    elif acts_doc and not acts_moteur:
        act_statut = "partiel"
        act_detail = "Activités demandées hors moteur lecture (CODE / INTRUSION) — documents, avenant."
    elif acts_doc:
        act_statut = "partiel"
        act_detail = (
            f"{len(acts_moteur)} activité(s) moteur, {len(acts_doc)} documentée(s) "
            "(CODE / INTRUSION : avenant, pas d'auto)."
        )
    else:
        act_statut = "ok"
        act_detail = ", ".join(a["id"] for a in acts) + " — lecture."

    if not peri_ok:
        peri_st, peri_d = "ko", "CIDR ou URL du mandat manquant."
    else:
        peri_st, peri_d = "ok", f"CIDR={m.cidr or '—'} URL={ex.get('site_url') or '—'}"

    if not op_ok:
        comp_st, comp_d = "ko", "Opérateur non identifié."
    else:
        comp_st, comp_d = "ok", f"Opérateur {m.operateur_nom} — compétences organisationnelles hors logiciel."

    if liasse_ok and mandat_ok:
        aut_st, aut_d = "ok", "Liasse signée, mandat et paraphe opérateur."
    elif mandat_ok:
        aut_st, aut_d = "partiel", "Mandat présent, liasse incomplète."
    else:
        aut_st, aut_d = "ko", "Autorisations non signées — la case à cocher ne suffit pas."

    if not red_ok:
        cap_st, cap_d = "partiel", "Blue team : regard attaquant éteint. Architecture / configuration restent possibles."
    else:
        cap_st, cap_d = "ok", "Capacités techniques lecture (niveaux 0-1). Niveaux 2-3 : documents."

    checks = [
        _ok("perimetre", "Périmètre", peri_st, peri_d),
        _ok("competences", "Compétences requises", comp_st, comp_d),
        _ok("capacites", "Capacités techniques", cap_st, cap_d),
        _ok("outils", "Outils nécessaires", outils_statut, outils_detail),
        _ok("autorisations", "Autorisations", aut_st, aut_d),
        _ok("activites", "Activités demandées", act_statut, act_detail),
    ]
    n_ko = sum(1 for c in checks if c["statut"] == "ko")
    n_partiel = sum(1 for c in checks if c["statut"] == "partiel")
    if n_ko:
        verdict = "aucune"
        conclusion = "Prestation non réalisable en l'état."
        glyphe = "non"
    elif n_partiel:
        verdict = "partielle"
        conclusion = "Prestation réalisable avec réserve."
        glyphe = "reserve"
    else:
        verdict = "complete"
        conclusion = "Prestation réalisable — aptitude préalable, pas une qualification."
        glyphe = "ok"

    niveau_orga = ""
    qual = ex.get("qualification") if isinstance(ex.get("qualification"), dict) else {}
    if qual.get("niveau"):
        niveau_orga = str(qual.get("niveau"))
    return {
        "etape": "qualification préalable d'aptitude",
        "referentiel": "PASSI v2.2 § préparation de la prestation",
        "verdict": verdict,
        "glyphe": glyphe,
        "conclusion": conclusion,
        "checks": checks,
        "n_ok": sum(1 for c in checks if c["statut"] == "ok"),
        "n_partiel": n_partiel,
        "n_ko": n_ko,
        "activites": [a["id"] for a in acts],
        "niveau_assurance_vise": niveau_orga,
        "niveau_assurance_note": (
            "Les niveaux substantiel / élevé du référentiel sont organisationnels. "
            "Guardia ne les attribue pas."
            if niveau_orga
            else "Aucun niveau d'assurance n'est attribué par le logiciel."
        ),
        "prestataire": {
            "nom": f"{ASSOCIATION} ({SIGLE})",
            "forme": "association déclarée, ESS",
            "rna": RNA,
            "siren": SIREN,
            "naf": NAF,
            "passi_qualifie": False,
        },
        "passi_qualifie": False,
        "certificat": False,
        "catalogue_activites": [a["id"] for a in ACTIVITES],
    }
