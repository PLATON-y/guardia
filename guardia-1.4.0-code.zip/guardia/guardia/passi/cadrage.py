"""Note de cadrage vivante — prévue par le référentiel PASSI v2.2."""
from __future__ import annotations

from typing import Any

from guardia.core.identite import ASSOCIATION, OPERATEUR_DEFAUT
from guardia.core.models import Mission
from guardia.passi.activites import ACTIVITES


def note_cadrage(
    mission: Mission | None = None,
    *,
    activites: list[dict[str, Any]] | None = None,
    aptitude: dict[str, Any] | None = None,
    autorisations: dict[str, Any] | None = None,
    limites: list[str] | None = None,
    changements: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Note opérationnelle. Elle évolue ; un avenant n'est jamais auto."""
    m = mission or Mission()
    ex = m.extras or {}
    acts = activites or []
    ident = ex.get("identification") if isinstance(ex.get("identification"), dict) else {}
    peri = {
        "cidr": m.cidr or "",
        "url": str(ex.get("site_url") or ""),
        "exclusions": list(ex.get("interdit") or ("exploitation", "hors_perimetre", "dump_annuaire", "brute_force")),
        "fenetre": str(ex.get("fenetre") or ex.get("date") or ""),
        "client": m.client or "",
        "lieu": str(ex.get("lieu") or ""),
    }
    objectifs = ex.get("objectifs") or (
        "Évaluer l'exposition du périmètre signé en lecture. "
        "Produire des preuves, une couverture et des recommandations actionnables."
    )
    criteres = ex.get("criteres") or (
        "Observation reproductible. Validation humaine des findings. "
        "Non vérifiable ≠ conforme. Avenant offensif jamais lancé automatiquement."
    )
    limites_l = list(limites or [])
    apt = aptitude or {}
    for c in apt.get("checks") or []:
        if c.get("statut") in ("partiel", "ko"):
            limites_l.append(f"{c.get('label')} : {c.get('detail')}")
    if any(a["id"] == "CODE" for a in acts):
        limites_l.append("CODE : SAST automatique ≠ audit de code PASSI. Dépôt nommé = avenant.")
    if any(a["id"] == "INTRUSION" for a in acts):
        limites_l.append("INTRUSION : regard lecture. Test intrusif seulement après avenant et approbation.")
    seen: list[str] = []
    uniq_lim = []
    for x in limites_l:
        if x not in seen:
            seen.append(x)
            uniq_lim.append(x)
    return {
        "vivante": True,
        "titre": "Note de cadrage opérationnelle",
        "referentiel": "PASSI v2.2 — note de cadrage, mise à jour pendant la prestation",
        "identification": {
            "commanditaire": ident.get("commanditaire") or m.client or "",
            "prestataire": ident.get("prestataire") or ASSOCIATION,
            "responsable_equipe": ident.get("responsable_equipe") or (m.operateur_nom or OPERATEUR_DEFAUT),
            "auditeurs": ident.get("auditeurs") or [m.operateur_nom or OPERATEUR_DEFAUT],
            "experts": ident.get("experts") or [],
        },
        "objectifs": objectifs if isinstance(objectifs, list) else [str(objectifs)],
        "criteres": criteres if isinstance(criteres, list) else [str(criteres)],
        "perimetre": peri,
        "activites": [
            {"id": a["id"], "nom": a["nom"], "moteur": bool(a.get("moteur"))}
            for a in acts
        ],
        "catalogue": [a["id"] for a in ACTIVITES],
        "environnement": {
            "parc": ex.get("parc") or m.type_structure or "",
            "profondeur": m.profondeur or "standard",
            "lecture": True,
            "niveaux_moteur": "0-1",
            "niveaux_documentes": "2-3",
        },
        "hypotheses": [
            "Le CIDR / l'URL du mandat sont ceux du titulaire.",
            "Les outils absents n'arrêtent pas la prestation : la branche est écartée.",
            "Un finding scanner n'est pas un verdict.",
        ],
        "exclusions": peri["exclusions"],
        "modalites": {
            "lecture": True,
            "exploitation": False,
            "avenant_auto": False,
            "validation_humaine": True,
            "arret_urgence": True,
        },
        "equipe": {
            "operateur": m.operateur_nom or OPERATEUR_DEFAUT,
            "paraphe": bool(m.operateur_signe),
            "equipe": "red" if (ex.get("equipe") == "red") else "selon mission",
        },
        "outils": {
            "moteur": "capacités lecture interchangeables",
            "avenant": "ZAP, Burp, BloodHound, Impacket, Metasploit, ffuf — jamais auto",
        },
        "limites": uniq_lim,
        "changements_valides": list(changements or []),
        "autorisations_completes": bool((autorisations or {}).get("complet")),
        "note": (
            "Toute extension de périmètre, d'activité ou d'intrusivité "
            "exige un changement validé (avenant). Jamais un lancement automatique."
        ),
        "passi_qualifie": False,
    }
