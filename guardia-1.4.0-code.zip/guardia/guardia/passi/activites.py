"""Cinq activités natives du référentiel PASSI v2.2."""
from __future__ import annotations

from typing import Any

from guardia.core.models import Mission

# Identifiants alignés sur les cinq domaines ANSSI (ARCHI, CONF, CODE, INTRUSION, ORGAPHY).
ACTIVITES: tuple[dict[str, Any], ...] = (
    {
        "id": "ARCHI",
        "alias": "architecture",
        "nom": "Audit d'architecture",
        "domaine_passi": "Architecture",
        "niveau_moteur": 1,
        "moteur": True,
        "role": (
            "Cartographier zones, flux, frontières de confiance, services exposés, "
            "administration et points critiques. Lecture. Pas d'OSINT hors URL signée."
        ),
        "livrable": "Architecture Security Assessment : observation → preuve → critère → impact → reco.",
        "capacites": ("nmap_discover", "nmap_priority", "arp", "http"),
        "avenant": (),
    },
    {
        "id": "CONF",
        "alias": "configuration",
        "nom": "Audit de configuration",
        "domaine_passi": "Configuration",
        "niveau_moteur": 1,
        "moteur": True,
        "role": (
            "Baselines (Linux, Windows, réseau, base, web). "
            "Non vérifiable n'est pas conforme. Lynis = poste opérateur, pas le parc client."
        ),
        "livrable": "Packs de contrôles : conforme / écart / non vérifiable / non applicable.",
        "capacites": ("tls", "http", "smb", "lynis", "gvm_read", "nuclei"),
        "avenant": (),
    },
    {
        "id": "CODE",
        "alias": "code_source",
        "nom": "Audit de code source",
        "domaine_passi": "Code source",
        "niveau_moteur": 2,
        "moteur": False,
        "role": (
            "Assister l'auditeur. Un SAST automatique n'équivaut pas à un audit de code PASSI. "
            "Dépôt nommé : avenant, poste autorisé."
        ),
        "livrable": "Détection → extrait → preuve → analyse → revue humaine → conclusion.",
        "capacites": (),
        "avenant": ("trivy", "depot_nomme"),
    },
    {
        "id": "INTRUSION",
        "alias": "intrusion",
        "nom": "Tests d'intrusion",
        "domaine_passi": "Tests d'intrusion",
        "niveau_moteur": 3,
        "moteur": False,
        "role": (
            "Observation → hypothèse → autorisation → test → preuve → validation. "
            "Jamais : port ouvert → exploit automatique."
        ),
        "livrable": "Hypothèses d'exposition, regard lecture, tests intrusifs seulement après avenant.",
        "capacites": ("nmap_discover", "nuclei"),
        "avenant": (
            "zaproxy",
            "burpsuite",
            "bloodhound",
            "impacket-scripts",
            "metasploit-framework",
            "ffuf",
        ),
    },
    {
        "id": "ORGAPHY",
        "alias": "organisationnel_physique",
        "nom": "Audit organisationnel et physique",
        "domaine_passi": "Organisationnel et physique",
        "niveau_moteur": 0,
        "moteur": True,
        "role": (
            "Politiques, procédures, habilitations, locaux. "
            "Questionnaire + document + observation technique → conclusion corrélée."
        ),
        "livrable": "Contrôles ORG/PHY avec preuve documentaire, entretien, observation.",
        "capacites": (),
        "avenant": (),
    },
)

PROFILS: dict[str, tuple[str, ...]] = {
    "passi_complet": ("ARCHI", "CONF", "CODE", "INTRUSION", "ORGAPHY"),
    "passi_technique": ("ARCHI", "CONF"),
    "passi_intrusion": ("ARCHI", "INTRUSION"),
    "passi_orga": ("ORGAPHY", "ARCHI"),
    "standard": ("ARCHI", "CONF", "ORGAPHY"),
}

_ALIAS = {a["alias"]: a["id"] for a in ACTIVITES}
_BY_ID = {a["id"]: a for a in ACTIVITES}

CONTROLES: tuple[dict[str, Any], ...] = (
    # Architecture
    {"id": "ARC-001", "activite": "ARCHI", "libelle": "Cartographie des zones et des actifs", "critere": "Chaque actif du périmètre est identifié et rattaché à une zone."},
    {"id": "ARC-002", "activite": "ARCHI", "libelle": "Flux inter-zones", "critere": "Les flux observés correspondent aux flux attendus du cadrage."},
    {"id": "ARC-003", "activite": "ARCHI", "libelle": "Frontières de confiance", "critere": "Les frontières Internet / LAN / administration sont identifiables."},
    {"id": "ARC-004", "activite": "ARCHI", "libelle": "Services exposés", "critere": "Les services publics et d'administration sont inventoriés."},
    {"id": "ARC-005", "activite": "ARCHI", "libelle": "Segmentation / cloisonnement", "critere": "Le parc n'est pas un VLAN plat sans justification."},
    {"id": "ARC-006", "activite": "ARCHI", "libelle": "Voie d'administration", "critere": "L'administration distante n'est pas exposée au même titre qu'un poste."},
    {"id": "ARC-007", "activite": "ARCHI", "libelle": "Accès externes", "critere": "Les accès depuis Internet (URL, VPN, télémaintenance) sont nommés."},
    {"id": "ARC-008", "activite": "ARCHI", "libelle": "Points critiques", "critere": "Passerelle, fichiers, annuaire, impression : rôle de desserte identifié."},
    # Configuration
    {"id": "CFG-SSH-001", "activite": "CONF", "libelle": "Durcissement SSH", "critere": "SSH du poste ou du service : bannière, algos, pas d'accès large non justifié.", "baseline": "linux_server"},
    {"id": "CFG-USR-001", "activite": "CONF", "libelle": "Comptes et privilèges", "critere": "Pas de compte d'administration exposé sans cloisonnement.", "baseline": "linux_server"},
    {"id": "CFG-PERM-001", "activite": "CONF", "libelle": "Permissions et partages", "critere": "Partages SMB / NFS nommés ; pas de « Everyone » observé.", "baseline": "linux_server"},
    {"id": "CFG-CRYPTO-001", "activite": "CONF", "libelle": "Cryptographie / TLS", "critere": "TLS observé sur les services HTTPS du périmètre.", "baseline": "web_server"},
    {"id": "CFG-SVC-001", "activite": "CONF", "libelle": "Services inutiles", "critere": "Ports d'administration et protocoles hérités justifiés.", "baseline": "linux_server"},
    {"id": "CFG-LOG-001", "activite": "CONF", "libelle": "Journalisation", "critere": "La journalisation n'est pas inférée conforme sans preuve.", "baseline": "linux_server"},
    {"id": "CFG-FW-001", "activite": "CONF", "libelle": "Filtrage", "critere": "Le filtrage inter-zones est observé ou déclaré non vérifiable.", "baseline": "network_device"},
    {"id": "CFG-UPD-001", "activite": "CONF", "libelle": "Mises à jour", "critere": "Non vérifiable depuis le LAN lecture, sauf preuve locale.", "baseline": "linux_server"},
    {"id": "CFG-WEB-001", "activite": "CONF", "libelle": "Serveur web", "critere": "En-têtes, cookies, TLS de l'URL du mandat.", "baseline": "web_server"},
    {"id": "CFG-WIN-001", "activite": "CONF", "libelle": "Windows / RDP", "critere": "RDP exposé = surface, pas un verdict d'exploitation.", "baseline": "windows_server"},
    {"id": "CFG-NET-001", "activite": "CONF", "libelle": "Équipement réseau", "critere": "Interface d'administration de la passerelle identifiée.", "baseline": "network_device"},
    {"id": "CFG-DB-001", "activite": "CONF", "libelle": "Base de données", "critere": "Port de base vu sur le LAN : écart de cloisonnement jusqu'à preuve contraire.", "baseline": "database"},
    # Organisationnel / physique
    {"id": "ORG-SEC-001", "activite": "ORGAPHY", "libelle": "Politique de sécurité formalisée", "question": "La politique de sécurité est-elle formalisée et portée ?"},
    {"id": "ORG-SEC-002", "activite": "ORGAPHY", "libelle": "Inventaire des actifs", "question": "Un inventaire à jour des actifs du périmètre existe-t-il ?"},
    {"id": "ORG-SEC-003", "activite": "ORGAPHY", "libelle": "Habilitations et comptes", "question": "Les habilitations sont-elles revues, y compris prestataires partis ?"},
    {"id": "ORG-SEC-004", "activite": "ORGAPHY", "libelle": "Sensibilisation", "question": "Une sensibilisation périodique des personnes est-elle en place ?"},
    {"id": "ORG-SEC-005", "activite": "ORGAPHY", "libelle": "Gestion des incidents", "question": "Une procédure d'incident (constat, escalade, 72 h) est-elle écrite ?"},
    {"id": "ORG-SEC-006", "activite": "ORGAPHY", "libelle": "Sauvegardes", "question": "Les sauvegardes sont-elles testées, hors du même VLAN métier ?"},
    {"id": "ORG-PHY-001", "activite": "ORGAPHY", "libelle": "Accès aux locaux", "question": "L'accès aux locaux métier est-il contrôlé ?"},
    {"id": "ORG-PHY-002", "activite": "ORGAPHY", "libelle": "Salle technique / baie", "question": "La baie / salle technique est-elle fermée et distincte de l'accueil ?"},
    {"id": "ORG-PRE-001", "activite": "ORGAPHY", "libelle": "Prestataires", "question": "Les accès prestataires sont-ils nominatifs, datés, révocables ?"},
    {"id": "ORG-DOC-001", "activite": "ORGAPHY", "libelle": "Procédures opérationnelles", "question": "Les procédures essentielles (arrêt, restauration, admin) sont-elles écrites ?"},
    # Code — assisté, jamais « SAST = PASSI »
    {"id": "COD-SEC-001", "activite": "CODE", "libelle": "Secrets en dépôt", "critere": "Revue humaine sur extraits. SAST ≠ audit PASSI."},
    {"id": "COD-SEC-002", "activite": "CODE", "libelle": "Cryptographie applicative", "critere": "Revue humaine. Dépôt nommé requis."},
    {"id": "COD-SEC-003", "activite": "CODE", "libelle": "Authentification", "critere": "Revue humaine. Dépôt nommé requis."},
    {"id": "COD-SEC-004", "activite": "CODE", "libelle": "Validation des entrées", "critere": "Revue humaine. Dépôt nommé requis."},
    {"id": "COD-SEC-005", "activite": "CODE", "libelle": "Injections", "critere": "Revue humaine. Dépôt nommé requis."},
    {"id": "COD-SEC-006", "activite": "CODE", "libelle": "Dépendances", "critere": "SCA assiste, ne conclut pas. Trivy : avenant."},
    {"id": "COD-REV-001", "activite": "CODE", "libelle": "Revue humaine obligatoire", "critere": "Aucune conclusion CODE sans auditeur."},
    # Intrusion — gates
    {"id": "PT-001", "activite": "INTRUSION", "libelle": "Hypothèses d'exposition", "critere": "Chemins hypothétiques, pas un exploit."},
    {"id": "PT-002", "activite": "INTRUSION", "libelle": "Autorisation expresse red team", "critere": "Pièce 04 + mot de passe opérateur. Sans ça : non autorisé."},
    {"id": "PT-003", "activite": "INTRUSION", "libelle": "Regard lecture", "critere": "Mêmes faits, par où ça casse. On n'entre pas."},
    {"id": "PT-004", "activite": "INTRUSION", "libelle": "Test intrusif", "critere": "Avenant nommé. Jamais auto. Approbation humaine."},
    {"id": "PT-005", "activite": "INTRUSION", "libelle": "Preuve et reproductibilité", "critere": "Commande lecture, hash, validation humaine."},
    {"id": "PT-006", "activite": "INTRUSION", "libelle": "Arrêt d'urgence", "critere": "Stop si instabilité, hors périmètre, mot d'ordre client."},
)


def _norm_id(raw: str) -> str:
    s = (raw or "").strip()
    up = s.upper().replace("-", "_")
    if up in _BY_ID:
        return up
    if s.lower() in _ALIAS:
        return _ALIAS[s.lower()]
    aliases = {
        "organisationnel": "ORGAPHY",
        "organisationnel_physique": "ORGAPHY",
        "org": "ORGAPHY",
        "code": "CODE",
        "intrusion": "INTRUSION",
        "tests_intrusion": "INTRUSION",
        "archi": "ARCHI",
        "conf": "CONF",
    }
    return aliases.get(s.lower(), "")


def activites_demandees(mission: Mission | None) -> list[dict[str, Any]]:
    """Profil YAML ou défaut : ARCHI + CONF + ORGAPHY. Complet si profile passi_complet."""
    m = mission or Mission()
    ex = m.extras or {}
    ids: list[str] = []
    profile = ex.get("profile") if isinstance(ex.get("profile"), dict) else {}
    qual = ex.get("qualification") if isinstance(ex.get("qualification"), dict) else {}
    raw = (
        profile.get("activities")
        or profile.get("activites")
        or qual.get("activites")
        or qual.get("activities")
        or ()
    )
    for item in raw or ():
        nid = _norm_id(str(item))
        if nid and nid not in ids:
            ids.append(nid)
    pid = str(profile.get("id") or ex.get("profil_moteur") or m.profil_moteur or "")
    if not ids and pid in PROFILS:
        ids = list(PROFILS[pid])
    if not ids:
        ids = list(PROFILS["standard"])
    return [{**_BY_ID[i]} for i in ids if i in _BY_ID]


def controles_pour(activite_id: str) -> list[dict[str, Any]]:
    return [dict(c) for c in CONTROLES if c["activite"] == activite_id]
