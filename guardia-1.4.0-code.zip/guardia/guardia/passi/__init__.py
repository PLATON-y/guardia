"""PASSI v2.2 — appui au processus, pas une qualification.

Guardia est une plateforme d'orchestration, d'exécution, de preuve,
de couverture et de restitution conçue pour accompagner des prestations
d'audit selon les activités couvertes par le référentiel PASSI v2.2
(ANSSI, 1er août 2024).

Le logiciel outille le processus. Il ne rend pas le prestataire
qualifié PASSI ANSSI. La qualification est organisationnelle
(prestataire, personnel, impartialité, protection des informations).
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import Mission
from guardia.passi.activites import ACTIVITES, CONTROLES, PROFILS, activites_demandees
from guardia.passi.aptitude import qualifier_aptitude
from guardia.passi.cadrage import note_cadrage
from guardia.passi.couverture import cockpit, couverture, matrice
from guardia.passi.evaluations import evaluer

POSITION = (
    "Guardia est une plateforme d'orchestration, d'exécution, de preuve, "
    "de couverture et de restitution conçue pour accompagner des prestations "
    "d'audit selon les activités couvertes par le référentiel PASSI v2.2. "
    "Ceci n'est pas une qualification PASSI ANSSI."
)

REFERENTIEL = "PASSI v2.2 — ANSSI, 1er août 2024"

PIPELINE = (
    "mandat",
    "aptitude_prealable",
    "note_de_cadrage",
    "autorisation",
    "activite",
    "orchestration",
    "preuves",
    "correlation",
    "validation_humaine",
    "rapport",
)


def construire_dossier(
    mission: Mission | None = None,
    *,
    autorisations: dict[str, Any] | None = None,
    equipe: str = "red",
    hosts: Any = None,
    chemins: list[dict[str, Any]] | None = None,
    execute: bool = False,
    outils_etat: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Dossier de mission PASSI v2.2 — aptitude, cadrage, activités, preuves."""
    m = mission or Mission()
    acts = activites_demandees(m)
    apt = qualifier_aptitude(
        m,
        autorisations=autorisations or {},
        equipe=equipe,
        outils_etat=outils_etat,
        activites=acts,
    )
    cad = note_cadrage(m, activites=acts, aptitude=apt, autorisations=autorisations)
    ev = evaluer(m, hosts=hosts, chemins=chemins, execute=execute, autorisations=autorisations)
    mat = matrice(ev, activites=acts)
    cov = couverture(mat, perimetre=cad.get("perimetre") or {}, aptitude=apt)
    cock = cockpit(cov, apt, ev, mat)
    return {
        "referentiel": REFERENTIEL,
        "position": POSITION,
        "passi_qualifie": False,
        "certificat": False,
        "pipeline": list(PIPELINE),
        "activites_demandees": [a["id"] for a in acts],
        "activites": acts,
        "aptitude": apt,
        "cadrage": cad,
        "evaluations": ev,
        "matrice": mat,
        "couverture": cov,
        "cockpit": cock,
    }


__all__ = [
    "ACTIVITES",
    "CONTROLES",
    "PIPELINE",
    "POSITION",
    "PROFILS",
    "REFERENTIEL",
    "activites_demandees",
    "construire_dossier",
    "cockpit",
    "couverture",
    "evaluer",
    "matrice",
    "note_cadrage",
    "qualifier_aptitude",
]
