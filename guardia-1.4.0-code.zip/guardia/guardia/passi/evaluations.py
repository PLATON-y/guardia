"""Évaluations natives : architecture, configuration, org, code, intrusion."""
from __future__ import annotations

from typing import Any

from guardia.core.models import Host, Mission
from guardia.passi.activites import CONTROLES, controles_pour

BASELINES: tuple[dict[str, Any], ...] = (
    {
        "id": "linux_server",
        "nom": "Serveur Linux",
        "kinds": ("serveur", "nas", "pc"),
        "controls": ("ssh", "users", "permissions", "crypto", "services", "logging", "firewall", "updates"),
    },
    {
        "id": "windows_server",
        "nom": "Serveur / poste Windows",
        "kinds": ("pc", "serveur"),
        "controls": ("rdp", "users", "shares", "crypto", "services", "logging", "updates"),
    },
    {
        "id": "network_device",
        "nom": "Équipement réseau",
        "kinds": ("box", "passerelle", "router", "ap", "switch"),
        "controls": ("admin_interface", "crypto", "services", "logging", "updates"),
    },
    {
        "id": "database",
        "nom": "Base de données",
        "kinds": (),
        "ports": (3306, 5432, 1433, 27017, 6379, 1521),
        "controls": ("bind", "crypto", "users", "logging"),
    },
    {
        "id": "web_server",
        "nom": "Serveur web",
        "kinds": (),
        "ports": (80, 443, 8080, 8443, 8000),
        "controls": ("headers", "tls", "cookies", "methods"),
    },
)

ORG_REPONSES = ("oui", "non", "partiel", "non_verifiable")

INTRUSION_GATES = (
    "observation",
    "hypothese",
    "autorisation",
    "test",
    "preuve",
    "validation",
)

STOP_ON = ("service_instability", "out_of_scope", "emergency_stop")

ADMIN_PORTS = {22, 3389, 5900, 5985, 8443, 8834, 9090, 10000}
HTTP_PORTS = {80, 81, 443, 8000, 8080, 8443, 8888, 3000}
SMB_PORTS = {139, 445}
DB_PORTS = {3306, 5432, 1433, 27017, 6379, 1521}


def _ports(h: Any) -> list[int]:
    raw = getattr(h, "ports", None) if not isinstance(h, dict) else h.get("ports")
    out: list[int] = []
    for p in raw or []:
        if isinstance(p, dict):
            try:
                out.append(int(p.get("port") or 0))
            except (TypeError, ValueError):
                continue
        else:
            try:
                out.append(int(p))
            except (TypeError, ValueError):
                continue
    return [x for x in out if x]


def _kind(h: Any) -> str:
    if isinstance(h, dict):
        return str(h.get("kind") or "")
    return str(getattr(h, "kind", "") or "")


def _ip(h: Any) -> str:
    if isinstance(h, dict):
        return str(h.get("ip") or "")
    return str(getattr(h, "ip", "") or "")


def _hostname(h: Any) -> str:
    if isinstance(h, dict):
        return str(h.get("hostname") or "")
    return str(getattr(h, "hostname", "") or "")


def _findings(h: Any) -> list[Any]:
    if isinstance(h, dict):
        return list(h.get("findings") or [])
    return list(getattr(h, "findings", None) or [])


def _hosts_list(hosts: Any) -> list[Any]:
    return list(hosts or [])


def evaluer_architecture(
    mission: Mission,
    hosts: Any = None,
    chemins: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Architecture Security Assessment à partir du graphe d'actifs."""
    from guardia.cerveau.graphe import construire

    typed: list[Host] = []
    for h in _hosts_list(hosts):
        if isinstance(h, Host):
            typed.append(h)
        elif isinstance(h, dict):
            typed.append(
                Host(
                    ip=str(h.get("ip") or ""),
                    hostname=str(h.get("hostname") or ""),
                    kind=str(h.get("kind") or "inconnu"),
                    ports=list(h.get("ports") or []),
                )
            )
    graph = construire(typed, mission)
    nodes = list(graph.get("nodes") or [])
    edges = list(graph.get("edges") or [])
    zones = {
        "internet": [n for n in nodes if n.get("kind") in ("internet", "url")],
        "frontiere": [n for n in nodes if n.get("role") == "passerelle" or n.get("kind") in ("box", "passerelle", "router")],
        "lan": [n for n in nodes if n.get("kind") not in ("internet", "url", "service") and n.get("role") != "passerelle"],
        "administration": [n for n in nodes if n.get("role") == "admin" or (n.get("kind") == "service" and int(n.get("port") or 0) in ADMIN_PORTS)],
        "exposes": [n for n in nodes if n.get("kind") == "service" and int(n.get("port") or 0) in HTTP_PORTS],
    }
    observations: list[dict[str, Any]] = []

    def obs(controle: str, titre: str, preuve: str, impact: str, risque: str, reco: str, resultat: str) -> None:
        observations.append(
            {
                "controle": controle,
                "observation": titre,
                "preuve": preuve,
                "critere": next((c["libelle"] for c in CONTROLES if c["id"] == controle), controle),
                "impact": impact,
                "risque": risque,
                "recommandation": reco,
                "resultat": resultat,
            }
        )

    n_actifs = len([n for n in nodes if n.get("kind") not in ("internet", "url", "service")])
    if n_actifs:
        obs(
            "ARC-001",
            f"{n_actifs} actif(s) cartographié(s) sur le périmètre signé.",
            f"graphe: {n_actifs} nœuds actifs, {len(edges)} flux",
            "Inventaire incomplet = angle mort.",
            "moyen" if n_actifs < 2 else "info",
            "Confronter la carte au déclaré du commanditaire.",
            "observe",
        )
    else:
        obs(
            "ARC-001",
            "Aucun actif observé — cartographie non établie.",
            "graphe vide",
            "Sans carte, pas d'architecture assessment.",
            "haute",
            "Lancer la découverte lecture sur le CIDR signé.",
            "non_verifiable",
        )

    admin = zones["administration"]
    if admin:
        obs(
            "ARC-006",
            f"{len(admin)} service(s) d'administration visible(s) depuis le LAN de visite.",
            ", ".join(str(n.get("id") or "") for n in admin[:8]),
            "Voie d'administration exposée au même titre qu'un poste.",
            "haute",
            "Cloisonner l'administration (bastion, VLAN, MFA).",
            "ecart",
        )
    elif n_actifs:
        obs(
            "ARC-006",
            "Pas de port d'administration observé sur cette visite.",
            "aucun 22/3389/5900/5985 vu",
            "Absence d'observation ≠ absence de voie d'administration.",
            "info",
            "Confirmer les sauts d'administration hors bande.",
            "non_verifiable",
        )

    kinds = {(_kind(h) or "") for h in _hosts_list(hosts)}
    plat = n_actifs >= 3 and not ({"ap", "switch"} & kinds)
    if plat:
        obs(
            "ARC-005",
            "Parc vu comme un LAN plat (pas d'équipement de cloisonnement observé).",
            f"kinds={sorted(k for k in kinds if k)}",
            "Un incident se propage.",
            "haute",
            "Séparer bureau / serveur / invité / administration.",
            "ecart",
        )
    elif n_actifs:
        obs(
            "ARC-005",
            "Cloisonnement non démontré depuis cette visite lecture.",
            "pas de preuve de VLAN / ACL",
            "Non vérifiable n'est pas conforme.",
            "moyen",
            "Demander le schéma et le confirmer par les flux.",
            "non_verifiable",
        )

    url = str((mission.extras or {}).get("site_url") or "")
    if url:
        obs(
            "ARC-007",
            f"Accès externe nommé : {url}",
            url,
            "Surface publique à traiter dans CONF / web lecture.",
            "info",
            "Restreindre l'OSINT à cette URL signée.",
            "observe",
        )
    else:
        obs(
            "ARC-007",
            "Aucun accès externe (URL) dans le mandat.",
            "site_url vide",
            "Hors URL signée : pas d'observation web.",
            "info",
            "Nommer l'URL dans un avenant si besoin.",
            "non_applicable",
        )

    points = []
    for h in _hosts_list(hosts):
        ps = set(_ports(h))
        role = []
        if SMB_PORTS & ps:
            role.append("fichiers")
        if {88, 389, 636} & ps:
            role.append("annuaire")
        if {631, 9100} & ps:
            role.append("impression")
        if role:
            points.append({"actif": _hostname(h) or _ip(h), "roles": role, "ip": _ip(h)})
    if points:
        obs(
            "ARC-008",
            f"{len(points)} point(s) critique(s) de desserte identifié(s).",
            "; ".join(f"{p['actif']}: {', '.join(p['roles'])}" for p in points[:6]),
            "Une desserte trop large = blast radius.",
            "moyenne",
            "Restreindre qui parle à l'annuaire, aux fichiers, à l'impression.",
            "observe",
        )

    return {
        "activite": "ARCHI",
        "titre": "Architecture Security Assessment",
        "zones": {k: [{"id": n.get("id"), "label": n.get("label"), "kind": n.get("kind")} for n in v] for k, v in zones.items()},
        "flux": edges[:80],
        "frontieres": ["internet", "frontiere", "lan", "administration"],
        "points_critiques": points,
        "chemins": list(chemins or graph.get("chemins") or []),
        "observations": observations,
        "graphe": {"n_noeuds": len(nodes), "n_flux": len(edges)},
        "passi_qualifie": False,
    }


def _map_finding_to_conf(finding: Any) -> str | None:
    blob = " ".join(
        str(x)
        for x in (
            finding.get("titre") if isinstance(finding, dict) else getattr(finding, "titre", ""),
            finding.get("id") if isinstance(finding, dict) else getattr(finding, "id", ""),
            finding.get("observation") if isinstance(finding, dict) else getattr(finding, "observation", ""),
        )
        if x
    ).lower()
    if any(k in blob for k in ("tls", "ssl", "https", "certificat", "crypto")):
        return "CFG-CRYPTO-001"
    if any(k in blob for k in ("rdp", "3389", "windows")):
        return "CFG-WIN-001"
    if any(k in blob for k in ("smb", "partage", "share", "nfs")):
        return "CFG-PERM-001"
    if any(k in blob for k in ("ssh", "22/")):
        return "CFG-SSH-001"
    if any(k in blob for k in ("http", "cookie", "header", "web")):
        return "CFG-WEB-001"
    if any(k in blob for k in ("admin", "8443", "10000")):
        return "CFG-NET-001"
    return None


def evaluer_configuration(mission: Mission, hosts: Any = None) -> dict[str, Any]:
    """Baselines. Non vérifiable ≠ conforme."""
    hs = _hosts_list(hosts)
    packs_appliques: list[str] = []
    for h in hs:
        kind = _kind(h)
        ports = set(_ports(h))
        for b in BASELINES:
            kinds = set(b.get("kinds") or ())
            bports = set(b.get("ports") or ())
            if (kinds and kind in kinds) or (bports and ports & bports):
                if b["id"] not in packs_appliques:
                    packs_appliques.append(b["id"])
    url = str((mission.extras or {}).get("site_url") or "")
    if url and "web_server" not in packs_appliques:
        packs_appliques.append("web_server")

    mapped: dict[str, str] = {}
    preuves: dict[str, str] = {}
    for h in hs:
        for f in _findings(h):
            cid = _map_finding_to_conf(f)
            if not cid:
                continue
            mapped[cid] = "ecart"
            preuves[cid] = str(
                (f.get("preuve") if isinstance(f, dict) else getattr(f, "preuve", "")) or ""
            )

    lignes = []
    n_conf = n_ecart = n_nv = n_na = 0
    for c in controles_pour("CONF"):
        bid = str(c.get("baseline") or "")
        applicable = (not bid) or (bid in packs_appliques) or (not hs and not url)
        if not applicable:
            resultat = "non_applicable"
            preuve = "pack non applicable à ce parc observé"
            n_na += 1
        elif c["id"] in mapped:
            resultat = mapped[c["id"]]
            preuve = preuves.get(c["id"]) or "finding local"
            n_ecart += 1
        else:
            # Jamais conforme par défaut.
            resultat = "non_verifiable"
            preuve = "Pas de preuve locale — non vérifiable ≠ conforme."
            n_nv += 1
        lignes.append(
            {
                "id": c["id"],
                "libelle": c["libelle"],
                "baseline": bid,
                "resultat": resultat,
                "preuve": preuve,
                "verifie": resultat in ("ecart", "conforme", "partiel"),
            }
        )
    return {
        "activite": "CONF",
        "titre": "Audit de configuration",
        "baselines": [dict(b) for b in BASELINES],
        "packs_appliques": packs_appliques,
        "controles": lignes,
        "counts": {
            "n": len(lignes),
            "conformes": n_conf,
            "non_conformes": n_ecart,
            "non_verifiables": n_nv,
            "non_applicables": n_na,
        },
        "regle": "non_verifiable ≠ conforme",
        "passi_qualifie": False,
    }


def evaluer_organisationnel(mission: Mission, hosts: Any = None) -> dict[str, Any]:
    """Questionnaires. Interview + document + observation → conclusion corrélée."""
    ex = mission.extras or {}
    answers = ex.get("org_reponses") if isinstance(ex.get("org_reponses"), dict) else {}
    lignes = []
    for c in controles_pour("ORGAPHY"):
        raw = answers.get(c["id"]) if isinstance(answers.get(c["id"]), dict) else {}
        reponse = str(raw.get("reponse") or "non_verifiable")
        if reponse not in ORG_REPONSES:
            reponse = "non_verifiable"
        evidence = [x for x in (raw.get("document_id"), raw.get("interview_id"), raw.get("observation_id")) if x]
        if reponse == "oui" and not evidence:
            # Oui sans preuve → partiel, pas conforme.
            resultat = "partiel"
            note = "Déclaré oui sans preuve documentaire — à compléter."
        elif reponse == "oui":
            resultat = "conforme"
            note = "Déclaration + preuve."
        elif reponse == "non":
            resultat = "ecart"
            note = "Écart déclaré."
        elif reponse == "partiel":
            resultat = "partiel"
            note = "Couverture partielle."
        else:
            resultat = "non_verifiable"
            note = "Non vérifiable ≠ conforme."
        lignes.append(
            {
                "id": c["id"],
                "libelle": c["libelle"],
                "question": c.get("question") or c["libelle"],
                "reponse": reponse,
                "resultat": resultat,
                "evidence": evidence,
                "reviewer": raw.get("reviewer") or mission.operateur_nom or "",
                "note": note,
            }
        )
    return {
        "activite": "ORGAPHY",
        "titre": "Audit organisationnel et physique",
        "controles": lignes,
        "reponses_possibles": list(ORG_REPONSES),
        "correlation": "interview + document + observation technique → conclusion",
        "n_non_verifiables": sum(1 for l in lignes if l["resultat"] == "non_verifiable"),
        "passi_qualifie": False,
    }


def evaluer_code(mission: Mission) -> dict[str, Any]:
    """Assister l'auditeur. SAST ≠ audit de code PASSI."""
    ex = mission.extras or {}
    depot = str(ex.get("depot") or ex.get("code_depot") or "")
    langs = ex.get("langages") or ("python", "javascript", "typescript")
    if isinstance(langs, str):
        langs = [langs]
    pipeline = (
        "detection_automatique",
        "extrait_de_code",
        "preuve",
        "analyse",
        "revue_humaine",
        "conclusion",
    )
    lignes = []
    for c in controles_pour("CODE"):
        if not depot:
            resultat = "non_applicable"
            preuve = "Aucun dépôt nommé dans le mandat."
        else:
            resultat = "non_verifiable"
            preuve = "Dépôt nommé : avenant requis. Pas de SAST auto. Revue humaine obligatoire."
        lignes.append(
            {
                "id": c["id"],
                "libelle": c["libelle"],
                "resultat": resultat,
                "preuve": preuve,
                "revue_humaine": True,
            }
        )
    return {
        "activite": "CODE",
        "titre": "Audit de code source (assisté)",
        "sast_egale_passi": False,
        "depot": depot,
        "depot_avenant": bool(depot),
        "langages": list(langs),
        "pipeline": list(pipeline),
        "controles": lignes,
        "note": (
            "Guardia n'équivaut pas un SAST à un audit de code PASSI. "
            "Il assiste : détection, extrait, preuve, puis l'auditeur conclut."
        ),
        "passi_qualifie": False,
    }


def evaluer_intrusion(
    mission: Mission,
    *,
    autorisations: dict[str, Any] | None = None,
    execute: bool = False,
    chemins: list[dict[str, Any]] | None = None,
) -> dict[str, Any]:
    """Gates. Jamais port ouvert → exploit auto."""
    auth = autorisations or {}
    pieces = list(auth.get("pieces") or []) + list(auth.get("extra") or [])
    piece04 = next((p for p in pieces if str(p.get("id") or "").startswith("04") or "red" in str(p.get("titre") or "").lower()), None)
    red_signe = bool(auth.get("complet")) and bool(piece04 and piece04.get("etat") == "ok")
    tests = []
    for i, ch in enumerate(list(chemins or [])[:8], start=1):
        tests.append(
            {
                "id": f"intrusion-{i:03d}",
                "cible": ch.get("id") or "chemin",
                "hypothese": ch.get("faiblesse") or " → ".join(ch.get("etapes") or []),
                "requires": ["explicit_red_team_authorization"],
                "approval_required": True,
                "etat": "hypothese",
                "exploitation": False,
            }
        )
    lignes = []
    for c in controles_pour("INTRUSION"):
        cid = c["id"]
        if cid == "PT-001":
            resultat = "observe" if tests else "non_verifiable"
            preuve = f"{len(tests)} hypothèse(s) d'exposition" if tests else "Pas de chemin observé."
        elif cid == "PT-002":
            resultat = "conforme" if red_signe else "non_autorise"
            preuve = "Pièce 04 + liasse" if red_signe else "Autorisation red team absente."
        elif cid == "PT-003":
            resultat = "observe" if execute else "non_verifiable"
            preuve = "Regard lecture (mêmes faits)." if execute else "Mode non exécuté."
        elif cid == "PT-004":
            resultat = "non_autorise"
            preuve = "Avenant requis. ZAP / Burp / BloodHound / Impacket / Metasploit / ffuf : jamais auto."
        elif cid == "PT-006":
            resultat = "observe"
            preuve = "Arrêt d'urgence armé : instabilité, hors périmètre, mot d'ordre."
        else:
            resultat = "non_verifiable"
            preuve = "Validation humaine encore ouverte."
        lignes.append({"id": cid, "libelle": c["libelle"], "resultat": resultat, "preuve": preuve})
    return {
        "activite": "INTRUSION",
        "titre": "Tests d'intrusion (gates)",
        "gates": list(INTRUSION_GATES),
        "interdit": "port ouvert → exploit automatique",
        "stop_on": list(STOP_ON),
        "approval_required": True,
        "tests": tests,
        "controles": lignes,
        "avenant": (
            "zaproxy",
            "burpsuite",
            "bloodhound",
            "impacket-scripts",
            "metasploit-framework",
            "ffuf",
        ),
        "passi_qualifie": False,
    }


def evaluer(
    mission: Mission | None = None,
    *,
    hosts: Any = None,
    chemins: list[dict[str, Any]] | None = None,
    execute: bool = False,
    autorisations: dict[str, Any] | None = None,
) -> dict[str, Any]:
    m = mission or Mission()
    return {
        "architecture": evaluer_architecture(m, hosts, chemins),
        "configuration": evaluer_configuration(m, hosts),
        "organisationnel": evaluer_organisationnel(m, hosts),
        "code": evaluer_code(m),
        "intrusion": evaluer_intrusion(m, autorisations=autorisations, execute=execute, chemins=chemins),
    }
