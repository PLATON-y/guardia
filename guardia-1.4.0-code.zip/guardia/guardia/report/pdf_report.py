"""Export PDF du rapport checkup via weasyprint (soft-fail si absent)."""
from __future__ import annotations

import logging
from pathlib import Path

log = logging.getLogger("guardia.report.pdf")

# Polices système fiables (évite fonts embarquées invalides / Firefox blanc)
_FONT_CSS = """
@font-face {
  font-family: "DejaVu Sans";
  src: url("file:///usr/share/fonts/truetype/dejavu/DejaVuSans.ttf");
}
@font-face {
  font-family: "DejaVu Sans";
  font-weight: bold;
  src: url("file:///usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf");
}
body, * {
  font-family: "DejaVu Sans", "Liberation Sans", sans-serif !important;
}
"""


def html_to_pdf(html_path: Path, pdf_path: Path | None = None) -> tuple[Path | None, str]:
    """Convertit un HTML Guardia en PDF.

    Retourne (chemin_pdf | None, message_erreur_ou_vide).
    Soft-fail si weasyprint absent.
    """
    html_path = Path(html_path)
    if pdf_path is None:
        pdf_path = html_path.with_suffix(".pdf")
    else:
        pdf_path = Path(pdf_path)
    try:
        from weasyprint import CSS, HTML  # type: ignore
        from weasyprint.text.fonts import FontConfiguration  # type: ignore
    except ImportError:
        msg = "weasyprint absent — pip install weasyprint (optionnel pour --pdf)"
        log.warning(msg)
        return None, msg
    try:
        pdf_path.parent.mkdir(parents=True, exist_ok=True)
        font_config = FontConfiguration()
        html = HTML(filename=str(html_path), base_url=str(html_path.parent))
        styles = [CSS(string=_FONT_CSS, font_config=font_config)]
        html.write_pdf(str(pdf_path), stylesheets=styles, font_config=font_config)
        log.info("PDF écrit: %s", pdf_path)
        return pdf_path, ""
    except Exception as exc:  # noqa: BLE001
        msg = f"export PDF: {exc}"
        log.error(msg)
        return None, msg
