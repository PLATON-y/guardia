"""Export JSON du checkup — tout ce que le HTML a, plus les blocs moteurs.

Le JSON 0.5.x n'écrivait pas calibrage / programme / recap / journal
(alors que le programme avait bien tourné). Ici on sérialise le résultat
entier, on refuse les types non JSON, et on n'annonce un chemin que si
l'écriture a réussi.
"""
from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from datetime import date, datetime
from enum import Enum
from pathlib import Path
from typing import Any

from guardia import __signature__, __version__
from guardia.core.models import CheckupResult, Mission


def jsonable(obj: Any, depth: int = 0) -> Any:
    """Convertit Findings, Path, Enum, dataclass — jamais un crash silencieux."""
    if depth > 48:
        return str(obj)
    if obj is None or isinstance(obj, (bool, int, float, str)):
        return obj
    if isinstance(obj, bytes):
        try:
            return obj.decode("utf-8")
        except UnicodeDecodeError:
            return obj.hex()
    if isinstance(obj, Enum):
        return obj.value
    if isinstance(obj, Path):
        return str(obj)
    if isinstance(obj, (datetime, date)):
        return obj.isoformat()
    to_dict = getattr(obj, "to_dict", None)
    if callable(to_dict):
        try:
            return jsonable(to_dict(), depth + 1)
        except Exception:  # noqa: BLE001
            pass
    if isinstance(obj, dict):
        out: dict[str, Any] = {}
        for k, v in obj.items():
            out[str(k)] = jsonable(v, depth + 1)
        return out
    if isinstance(obj, (list, tuple, set, frozenset)):
        return [jsonable(x, depth + 1) for x in obj]
    if is_dataclass(obj) and not isinstance(obj, type):
        try:
            return jsonable(asdict(obj), depth + 1)
        except Exception:  # noqa: BLE001
            return str(obj)
    return str(obj)


def _mission_block(mission: Mission) -> dict[str, Any]:
    from guardia.core.identite import operateur_a_signe, operateur_de

    extras = dict(mission.extras or {})
    # jamais un mot de passe dans le JSON client
    for k in list(extras):
        lk = str(k).lower()
        if "pass" in lk or "mot_de_passe" in lk or lk in ("red_pass", "password"):
            extras.pop(k, None)
    return {
        "client": mission.client,
        "personne_commune": mission.personne_commune,
        "type_structure": mission.type_structure,
        "profil_moteur": mission.profil_moteur,
        "profondeur": mission.profondeur,
        "cidr": mission.cidr,
        "mandat_nda_signes": mission.mandat_nda_signes,
        "ton_rapport": mission.ton_rapport,
        "signature": mission.signature,
        "operateur_nom": operateur_de(mission),
        "operateur_signe": operateur_a_signe(mission),
        "extras": jsonable(extras),
    }


def ensure_text_blocks(result: CheckupResult) -> None:
    """Grandes lignes + journal : mêmes que le HTML, avant le dump."""
    if not (result.identite or {}).get("association"):
        try:
            from guardia.core.identite import identite_dict

            result.identite = identite_dict(result.mission)
        except Exception:  # noqa: BLE001
            result.identite = result.identite or {}
    if not (result.recap or {}).get("titre"):
        try:
            from guardia.report.recap import build_grandes_lignes, build_journal

            result.recap = build_grandes_lignes(result)
            if not result.journal:
                result.journal = build_journal(result)
        except Exception:  # noqa: BLE001
            pass


def payload_from_result(result: CheckupResult) -> dict[str, Any]:
    ensure_text_blocks(result)
    mission = result.mission
    return jsonable(
        {
            "mission": _mission_block(mission),
            "meta": {
                "started": result.started,
                "finished": result.finished,
                "iface": result.iface,
                "gateway": result.gateway,
                "cidr": result.cidr,
                "errors": list(result.errors or []),
                "signature": __signature__,
                "version": __version__,
                "timings": result.timings or {},
                "plan": result.plan or {},
                "poste_operateur": getattr(result, "poste_operateur", None) or {},
            },
            "hosts": [h.to_dict() if hasattr(h, "to_dict") else h for h in (result.hosts or [])],
            "website": result.website or {},
            "rgpd": result.rgpd or {},
            "restructure": result.restructure or {},
            "machines": result.machines or {},
            "usages": result.usages or {},
            "direction": result.direction or {},
            "pistes": result.pistes or {},
            "equipe": result.equipe or "blue",
            "regard": result.regard or {},
            "parc": result.parc or "",
            "dossier": result.dossier or {},
            "hygiene": result.hygiene or {},
            "identites": result.identites or {},
            "calibrage": result.calibrage or {},
            "programme": result.programme or {},
            "recap": result.recap or {},
            "journal": result.journal or {},
            "identite": result.identite or {},
            "burp": result.burp or {},
            "autorisation": result.autorisation or {},
            "correlation": result.correlation or {},
            "cve_correlation": getattr(result, "cve_correlation", None) or {},
            "lynis": result.lynis or {},
            "greenbone": result.greenbone or {},
            "trivy": result.trivy or {},
            "orchestre": result.orchestre or {},
            "passi": getattr(result, "passi", None) or {},
            "autorisations": getattr(result, "autorisations", None) or {},
            "adaptatif": getattr(result, "adaptatif", None) or {},
            "passi_alignment": getattr(result, "passi_alignment", None) or {},
            "passi_assessment": getattr(result, "passi_assessment", None) or {},
        }
    )


def dump_checkup(result: CheckupResult, path: Path) -> tuple[bool, str]:
    """Écrit le JSON. True seulement si le fichier est là et non vide."""
    try:
        payload = payload_from_result(result)
        text = json.dumps(payload, ensure_ascii=False, indent=2, default=str)
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(text, encoding="utf-8")
        if not path.is_file() or path.stat().st_size < 2:
            return False, "fichier JSON vide"
        return True, ""
    except Exception as exc:  # noqa: BLE001
        return False, str(exc)
