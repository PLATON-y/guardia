"""Grandes lignes — première page du rapport, pour qui n'est pas technicien.

Si le dirigeant, le chef d'établissement ou le trésorier ne lit que ça,
il doit pouvoir arbitrer. Le détail chirurgical (preuves, ports, commandes)
reste en dessous.
"""
from __future__ import annotations

from typing import Any

from guardia.core.cadre import CP_323, ESS, OUTILS_LECTURE, PROGRAMME, RGPD_32
from guardia.core.identite import VISAGE_DECOUVERT, bloc_signature, operateur_de, user_agent
from guardia.core.models import CheckupResult, Finding, Gravite, Mission, Posture
from guardia.report.direction import _taille, build_direction_brief


def _blob(f: Any) -> str:
    if hasattr(f, "id"):
        return f"{f.id} {f.titre} {getattr(f, 'pourquoi_nuit', '')}".lower()
    if isinstance(f, dict):
        return " ".join(
            str(f.get(k) or "")
            for k in ("id", "titre", "pourquoi", "pourquoi_nuit", "signalement")
        ).lower()
    return str(f).lower()


_METIER: tuple[tuple[tuple[str, ...], str], ...] = (
    (("partage", "smb", "nfs", "admin$", "c$", "share"),
     "Des fichiers de travail sont visibles par trop de monde sur le réseau."),
    (("rdp", "3389", "vnc", "5900", "bureau à distance"),
     "On peut prendre la main sur un écran depuis le réseau interne."),
    (("ot-", "modbus", "opc", "profinet", "ethernet/ip", "s7", "automate"),
     "Un poste de bureau peut parler aux machines d'atelier."),
    (("88", "kerberos", "ldap", "389", "annuaire", "desserte-annuaire"),
     "L'annuaire — celui qui ouvre tout le parc — est joignable trop largement."),
    (("sauvegarde", "backup", "nas", "873"),
     "La sauvegarde est joignable : qui l'écrit peut aussi l'effacer."),
    (("web-", "tls", "cookie", "https"),
     "Le site public montre des défauts de configuration visibles."),
    (("wifi", "invité", "invite", "guest", "vlan"),
     "Le réseau salles / invités n'est peut-être pas vraiment séparé."),
    (("usages-", "session", "élève", "eleve", "salarié"),
     "Une session (élève, salarié, invité) peut atteindre plus que son rôle."),
    (("admin", "5985", "winrm", "ssh", "idrac", "ilo"),
     "L'administration des machines n'est pas cantonnée à un réseau d'admin."),
    (("imprimante", "spool", "9100"),
     "L'impression dessert tout le monde ; un spooler trop ouvert est un relais."),
    (("sql", "postgres", "redis", "3306", "5432", "mongodb"),
     "Une base (clients, élèves, paie) est joignable depuis le réseau métier."),
)


def phrase_metier(obj: Any) -> str:
    b = _blob(obj)
    for keys, phrase in _METIER:
        if any(k in b for k in keys):
            return phrase
    if hasattr(obj, "titre"):
        return str(obj.titre)
    if isinstance(obj, dict):
        return str(obj.get("titre") or "Point d'attention")
    return "Point d'attention sur le réseau autorisé."


def _all_findings(result: CheckupResult) -> list[Finding]:
    out: list[Finding] = []
    for h in result.hosts or []:
        out.extend(h.findings or [])
    return out


def _usages_signales(result: CheckupResult) -> list[str]:
    items = (result.usages or {}).get("items") or []
    out: list[str] = []
    for it in items:
        if not isinstance(it, dict):
            continue
        st = str(it.get("statut") or "")
        if "signalé" in st or st.startswith("non"):
            out.append(phrase_metier(it))
    return out


def compter_gravites(result: CheckupResult) -> dict[str, int]:
    """Compteurs de findings, pas de posture d'hôte.

    Une suite TLS faible = moyen, pas « 0 à risque ».
    """
    out = {"critique": 0, "eleve": 0, "moyen": 0, "basse": 0, "info": 0, "total": 0}
    findings = _all_findings(result)
    for f in findings:
        g = f.gravite if hasattr(f, "gravite") else None
        val = g.value if hasattr(g, "value") else str(g or "info")
        if val == "critique":
            out["critique"] += 1
        elif val == "haute":
            out["eleve"] += 1
        elif val == "moyenne":
            out["moyen"] += 1
        elif val == "basse":
            out["basse"] += 1
        else:
            out["info"] += 1
        out["total"] += 1
    return out


def build_grandes_lignes(result: CheckupResult) -> dict[str, Any]:
    """Page 1 — langage métier, 2 minutes, pas une liste de ports."""
    m: Mission = result.mission
    hosts = result.hosts or []
    n = len(hosts)
    taille = _taille(m, n)
    findings = _all_findings(result)
    hauts = [f for f in findings if f.gravite in (Gravite.CRITIQUE, Gravite.HAUTE)]
    gv = compter_gravites(result)
    n_crit_hotes = sum(1 for h in hosts if h.posture == Posture.CRITIQUE)
    n_risque_hotes = sum(1 for h in hosts if h.posture == Posture.RISQUE)
    usages = result.usages or {}
    n_serv = int((usages.get("compteurs") or {}).get("serveurs") or 0)
    if not n_serv:
        n_serv = sum(1 for h in hosts if (h.kind or "") in ("serveur", "nas", "ot"))

    seen: set[str] = set()
    risques: list[str] = []
    for f in hauts:
        p = phrase_metier(f)
        if p not in seen:
            seen.add(p)
            risques.append(p)
        if len(risques) >= 5:
            break
    for p in _usages_signales(result):
        if p not in seen:
            seen.add(p)
            risques.append(p)
        if len(risques) >= 5:
            break

    if not risques:
        if n == 0:
            risques = [
                "Aucun appareil n'a encore été vu sur le périmètre — "
                "soit le checkup n'a pas tourné, soit le réseau était muet."
            ]
        else:
            risques = [
                "Rien de grave n'est visible sur cet échantillon. "
                "Ça ne prouve pas l'absence de problème hors vue (Wi‑Fi, VLAN, hors CIDR)."
            ]

    actions: list[dict[str, str]] = []
    for f in hauts[:3]:
        etape = (f.remede_etapes or ["Faire le point avec la personne qui tient le parc."])[0]
        actions.append(
            {
                "quoi": phrase_metier(f),
                "faire": etape,
                "qui": f.qui_peut or "la personne habilitée",
                "quand": {
                    "tout_de_suite": "Aujourd'hui",
                    "cette_semaine": "Cette semaine",
                    "plus_tard": "Dès que possible",
                }.get(f.priorite, "Cette semaine"),
            }
        )
    if not actions:
        actions.append(
            {
                "quoi": "Garder ce papier, le relire avec la personne qui tient le parc.",
                "faire": "Confirmer que le périmètre vu est bien tout le réseau utile.",
                "qui": "vous + Echoes of Hackers",
                "quand": "Cette semaine",
            }
        )

    profil = (m.profil_moteur or "").lower()
    typ = (m.type_structure or "").lower()
    if profil == "ecole" or typ in ("ecole", "fac"):
        lecteurs = (
            "Si vous dirigez l'établissement : cette page suffit. "
            "Le détail (ports, preuves, commandes) est pour le référent numérique."
        )
    elif taille == "grande":
        lecteurs = (
            "Si vous dirigez : cette page suffit pour arbitrer. "
            "Le détail chirurgical est pour la DSI / le prestataire."
        )
    else:
        lecteurs = (
            "Si vous n'êtes pas technicien : lisez cette page, ignorez le reste "
            "si vous voulez. Les actions tiennent en trois lignes."
        )

    direction = result.direction or {}
    these = direction.get("these") or build_direction_brief(result).get("these") or ""

    from guardia.core.autorisation import etat as etat_auth, phrase_signature

    auth = getattr(result, "autorisation", None) or {}
    if not auth.get("etat"):
        auth = etat_auth(m)

    return {
        "titre": "Grandes lignes — à lire en 2 minutes",
        "lecteurs": lecteurs,
        "these": these,
        "risques": risques[:5],
        "actions": actions[:3],
        "chiffres": {
            "appareils": n,
            "critique": gv["critique"],
            "eleve": gv["eleve"],
            "moyen": gv["moyen"],
            "info": gv["info"],
            "risque": n_risque_hotes,
            "hotes_critiques": n_crit_hotes,
            "hotes_risque": n_risque_hotes,
            "hauts": len(hauts),
            "desserte": n_serv,
            "taille": taille,
        },
        "mandat": bool(m.mandat_nda_signes),
        "autorisation": auth,
        "phrase_signature": phrase_signature(auth),
        "client": m.client,
        "operateur": operateur_de(m),
        "visage_decouvert": VISAGE_DECOUVERT,
        "signature": bloc_signature(m, date=result.finished),
        "cadre": {
            "cp": CP_323,
            "rgpd32": RGPD_32,
            "ess": ESS,
        },
        "perimetre": [
            f"CIDR de cette visite : {result.cidr or m.cidr or '—'}.",
            "Outils lancés : ceux que le calibrage a trouvés installés, selon les portes vues.",
            "Conservation deux ans. Signatures : uniquement si l'autorisation le dit.",
        ],
        "topo_approx": str((m.extras or {}).get("topo_approx") or "").strip(),
    }


def build_journal(result: CheckupResult) -> dict[str, Any]:
    """Trace opposable : ce qui a été lancé, rien d'autre."""
    t = result.timings or {}
    phases = t.get("timings") or {}
    if isinstance(phases, dict):
        phase_rows = [
            {"phase": str(k), "duree": str(v)}
            for k, v in phases.items()
        ]
    else:
        phase_rows = []
    modules: list[str] = []
    if result.website:
        modules.append("site web (URL du mandat, curl/TLS)")
    if result.rgpd:
        modules.append("signalement RGPD (déclaration, pas un certificat)")
    if result.usages:
        modules.append("usages & droits (portes en lecture)")
    if result.machines:
        modules.append("Ethernet industriel (lecture, pas d'écriture automate)")
    if result.restructure:
        modules.append("restructuration de parc (lecture d'architecture)")
    if result.pistes:
        modules.append("pistes à explorer (catalogue, pas des findings)")
    if result.programme:
        modules.append("outils de la visite (calibrage)")
    if result.calibrage:
        n = (result.calibrage or {}).get("n_lances") or 0
        modules.append(f"calibrage Kali ({n} sonde(s) lancée(s))")
    if result.lynis:
        modules.append(
            "Lynis (poste opérateur — "
            + ("lancé" if (result.lynis or {}).get("lance") else "orchestré, non lancé")
            + ")"
        )
    if result.greenbone:
        gb = result.greenbone or {}
        modules.append(
            "Greenbone / OpenVAS (orchestré, "
            + (gb.get("etat") or ("lancé" if gb.get("lance") else "absent"))
            + ")"
        )
    if result.trivy:
        modules.append(
            "Trivy (poste opérateur — "
            + ("lancé" if (result.trivy or {}).get("lance") else "orchestré, non lancé")
            + ")"
        )
    passi = getattr(result, "passi", None) or {}
    if passi:
        n_b = passi.get("n_briques") or len(passi.get("briques") or [])
        modules.append(
            "offre inspirée PASSI ("
            + (passi.get("statut") or "non exécuté")
            + (f", {n_b} briques" if n_b else "")
            + " — pas un certificat, pas une qualification)"
        )
    authz = getattr(result, "autorisations", None) or {}
    if authz:
        modules.append(
            "autorisations red ("
            + ("liasse complète" if authz.get("complet") else "brouillon")
            + ")"
        )
    if result.correlation:
        modules.append("corrélation (TLS / SMB / RDP groupés)")
    adapt = getattr(result, "adaptatif", None) or {}
    if adapt:
        modules.append(
            "cerveau adaptatif ("
            + (adapt.get("synthese") or "DAG")
            + ")"
        )
    outils = list(OUTILS_LECTURE)
    if result.calibrage and (result.calibrage.get("outils") or []):
        outils = list(result.calibrage.get("outils") or [])
    return {
        "mandat": bool(result.mission.mandat_nda_signes),
        "cidr": result.cidr or result.mission.cidr or "—",
        "debut": result.started or "—",
        "fin": result.finished or "—",
        "elapsed": t.get("elapsed_sec", "—"),
        "phases": phase_rows,
        "modules": modules,
        "outils": outils,
        "programme": PROGRAMME,
        "visage_decouvert": VISAGE_DECOUVERT,
        "user_agent": user_agent(),
        "tronque": t.get("truncated_phases") or t.get("operator_truncated_phases") or "",
    }
