"""Rapport HTML français — lisible, par hôte, remédiations."""
from __future__ import annotations

import html
import logging
from datetime import datetime
from pathlib import Path
from typing import Any

from guardia.core.models import CheckupResult, Gravite, Host, Posture
from guardia.core.texte import strip_ansi

log = logging.getLogger("guardia.report")

POSTURE_LABEL = {
    Posture.OK: ("OK — posture saine", "#1b7f4a"),
    Posture.SURVEILLANCE: ("À surveiller", "#c48a00"),
    Posture.RISQUE: ("À risque", "#c44b00"),
    Posture.CRITIQUE: ("Critique", "#a10000"),
    Posture.INCONNU: ("Inconnu / partiel", "#666"),
}

GRAV_COLOR = {
    Gravite.CRITIQUE: "#a10000",
    Gravite.HAUTE: "#c44b00",
    Gravite.MOYENNE: "#c48a00",
    Gravite.BASSE: "#3a6ea5",
    Gravite.INFO: "#666",
}

KIND_FR = {
    "box": "Box / routeur",
    "router": "Routeur / relais",
    "switch": "Switch (L2)",
    "ap": "Point d'accès Wi‑Fi",
    "pc": "PC / portable",
    "tv": "TV connectée",
    "phone": "Téléphone / tablette",
    "imprimante": "Imprimante",
    "nas": "NAS / stockage",
    "iot": "Objet connecté",
    "console": "Console de jeu",
    "camera": "Caméra / NVR",
    "ot": "Automate / OT",
    "serveur": "Serveur / desserte de parc",
    "inconnu": "Non identifié",
}

# Mention courte couche OSI pour la carte du parc
KIND_OSI = {
    "switch": "L2 — commutation",
    "ap": "L2 — accès radio",
    "box": "L3 — passerelle",
    "router": "L3 — routage / relais",
    "pc": "L4–L7 — poste",
    "nas": "L4–L7 — stockage",
    "imprimante": "L4–L7 — impression",
    "camera": "L4–L7 — vidéo",
    "ot": "L4–L7 — industriel / automate",
    "serveur": "L4–L7 — desserte (fichiers / annuaire / appli)",
    "iot": "L4–L7 — objet",
    "tv": "L4–L7 — média",
    "console": "L4–L7 — jeu",
    "phone": "L4–L7 — mobile",
    "inconnu": "—",
}


def _e(s: object) -> str:
    return html.escape(strip_ansi(s), quote=True)


def _prio_fr(p: str) -> str:
    return {
        "tout_de_suite": "Tout de suite",
        "cette_semaine": "Cette semaine",
        "plus_tard": "Quand vous pourrez",
    }.get(p, p)


def _carte_parc(hosts: list[Host]) -> str:
    """Section HTML « Carte du parc » groupée par kind + mention OSI."""
    if not hosts:
        return "<p class='meta'>Aucun hôte — carte vide.</p>"
    by_kind: dict[str, list[Host]] = {}
    for h in hosts:
        by_kind.setdefault(h.kind or "inconnu", []).append(h)
    # ordre : matos réseau d'abord
    order = ["box", "router", "switch", "ap", "pc", "nas", "imprimante", "camera", "phone", "tv", "console", "iot", "inconnu"]
    keys = [k for k in order if k in by_kind] + sorted(k for k in by_kind if k not in order)
    blocks = []
    for kind in keys:
        label = KIND_FR.get(kind, kind)
        osi = KIND_OSI.get(kind, "—")
        items = "".join(
            f"<li><code>{_e(h.ip)}</code> {_e(h.hostname or '—')} "
            f"<span class='meta'>({_e(h.vendor or 'vendor ?')})</span></li>"
            for h in sorted(by_kind[kind], key=lambda x: x.ip)
        )
        blocks.append(
            f"<div class='parc-group'><h4>{_e(label)} "
            f"<span class='badge' style='background:#3a6ea5'>{_e(osi)}</span> "
            f"<span class='meta'>({len(by_kind[kind])})</span></h4><ul>{items}</ul></div>"
        )
    return (
        "<p class='meta'>Inventaire défensif par type d'équipement "
        "(indices couches OSI — pas une topologie câblée).</p>"
        + "\n".join(blocks)
    )


def _as_finding(obj) -> Any:
    if hasattr(obj, "titre"):
        return obj
    if isinstance(obj, dict) and obj.get("titre"):
        from guardia.core.models import Finding as F, Gravite as G

        try:
            g = G(str(obj.get("gravite") or "info"))
        except ValueError:
            g = G.INFO
        return F(
            id=str(obj.get("id") or ""),
            titre=str(obj.get("titre") or ""),
            pourquoi_nuit=str(obj.get("pourquoi_nuit") or ""),
            preuve=str(obj.get("preuve") or ""),
            remede_etapes=list(obj.get("remede_etapes") or []),
            qui_peut=str(obj.get("qui_peut") or ""),
            priorite=str(obj.get("priorite") or "plus_tard"),
            gravite=g,
            hote=str(obj.get("hote") or ""),
            preuve_repro=str(obj.get("preuve_repro") or ""),
            observation=str(obj.get("observation") or ""),
            commande=str(obj.get("commande") or ""),
            interpretation=str(obj.get("interpretation") or ""),
            statut_auditeur=str(obj.get("statut_auditeur") or "a_investiguer"),
        )
    return None


def _section_restructure(result: CheckupResult) -> str:
    block = result.restructure or {}
    chantiers = block.get("chantiers") or []
    if not chantiers and not block.get("resume"):
        return ""
    items = ""
    for c in chantiers:
        f = _as_finding(c)
        if f:
            items += _finding_block(f)
    stats = block.get("stats") or {}
    st = ""
    if stats:
        st = (
            f"<p class='meta'>{_e(stats.get('hotes', '?'))} hôte(s) · "
            f"inconnus {_e(stats.get('inconnus', 0))} · "
            f"admin {_e(stats.get('admin', 0))} · "
            f"datastores {_e(stats.get('datastores', 0))} · "
            f"OT {_e(stats.get('ot', 0))}</p>"
        )
    return (
        "<section class='card' id='restructure'>"
        "<h2>Où restructurer le parc</h2>"
        f"<p>{_e(block.get('resume') or '')}</p>{st}{items}"
        "<p class='meta'>Lecture d'architecture à partir de l'inventaire — "
        "pas une topologie câblée, pas une certification.</p>"
        "</section>"
    )


def _section_website(result: CheckupResult) -> str:
    block = result.website or {}
    if not block.get("url"):
        return ""
    findings = block.get("findings") or []
    items = ""
    for c in findings:
        f = _as_finding(c)
        if f:
            items += _finding_block(f)
    if not items:
        items = "<p class='meta'>Aucun finding site — page joignable, hygiène visible limitée.</p>"
    sig = block.get("signals") or {}
    tls = block.get("tls") or {}
    meta = (
        f"<p class='meta'>URL {_e(block.get('url'))} · hôte {_e(block.get('host'))} · "
        f"TLS {_e(tls.get('version') or tls.get('error') or '—')} · "
        f"trackers {_e(', '.join(sig.get('trackers') or []) or 'aucun usuel')} · "
        f"CMP {_e(', '.join((sig.get('cmp') or [])[:4]) or 'non observé')}</p>"
    )
    domaine = block.get("domaine") or []
    dom_h = ""
    if domaine:
        rows = "".join(
            f"<li><code>{_e(r.get('nom') or r.get('id'))}</code> "
            f"<span class='meta'>{_e(r.get('etat'))}</span> "
            f"<pre class='meta' style='white-space:pre-wrap'>{_e((r.get('extrait') or '')[:800])}</pre></li>"
            for r in domaine
            if isinstance(r, dict)
        )
        dom_h = f"<h3>Domaine — whois / DNS</h3><ul>{rows}</ul>"
    return (
        "<section class='card' id='site-web'>"
        "<h2>Site web — checkup défensif</h2>"
        "<p class='meta'>URL autorisée par la mission. whois, dig, host, curl / TLS. "
        "Lab : example.test.</p>"
        f"{meta}{dom_h}{items}</section>"
    )


def _section_rgpd(result: CheckupResult) -> str:
    block = result.rgpd or {}
    if not block.get("disclaimer") and not block.get("items"):
        return ""
    c = block.get("compteurs") or {}
    items_html = []
    for it in block.get("items") or []:
        statut = str(it.get("statut") or "")
        color = "#666"
        if "signalé" in statut or statut.startswith("non"):
            color = "#c44b00"
        elif statut.startswith("observ"):
            color = "#1b7f4a"
        elif "déclaré" in statut:
            color = "#3a6ea5"
        elif "confirmer" in statut:
            color = "#c48a00"
        elif "hors" in statut:
            color = "#666"
        steps = "".join(f"<li>{_e(s)}</li>" for s in (it.get("que_faire") or []))
        items_html.append(
            "<article class='card' style='margin:.7rem 0;border-left:4px solid "
            f"{color}'>"
            f"<h4><span class='badge' style='background:{color}'>{_e(statut)}</span> "
            f"{_e(it.get('titre'))}</h4>"
            f"<p class='meta'>Exigence : {_e(it.get('exigence'))}</p>"
            f"<p><strong>Observation :</strong> {_e(it.get('observation'))}</p>"
            f"<p><strong>Signalement :</strong> {_e(it.get('signalement'))}</p>"
            f"<ol>{steps}</ol></article>"
        )
    refs = "".join(f"<li>{_e(x)}</li>" for x in (block.get("controle_selon") or []))
    snapshot = ""
    cfg = block.get("config") or {}
    if cfg:
        try:
            from guardia.engines.rgpd_config import RGPD_FIELDS

            rows = "".join(
                "<tr>"
                f"<th style='text-align:left;color:#9aa7b5;padding:.2rem .4rem;"
                f"border-bottom:1px solid #2a3848'>{_e(f['label'])}</th>"
                f"<td style='padding:.2rem .4rem;border-bottom:1px solid #2a3848'>"
                f"{_e(cfg.get(f['key']) or '—')}</td></tr>"
                for f in RGPD_FIELDS
            )
            snapshot = (
                "<h3>Fiche déclarée (opérateur)</h3>"
                "<p class='meta'>Déclarations, pas des preuves. Un « oui » n'est "
                "pas une conformité, ni un certificat.</p>"
                f"<table style='width:100%;border-collapse:collapse;font-size:.9rem'>"
                f"{rows}</table>"
            )
        except Exception:  # noqa: BLE001
            snapshot = ""
    fiche_note = ""
    if block.get("fiche_vide"):
        fiche_note = (
            "<p class='meta'>Fiche non configurée — les lignes restent « à confirmer ». "
            "UI : bouton « Configurer RGPD » · "
            "CLI : <code>python3 -m guardia rgpd -m mission.yaml</code></p>"
        )
    return (
        "<section class='card' id='rgpd-signalement' "
        "style='border-color:#7a1f1f'>"
        "<h2>Signalement RGPD (sur demande)</h2>"
        f"<p><strong>{_e(block.get('disclaimer') or '')}</strong></p>"
        "<p class='meta'>Pas un certificat. Pas une certification CNIL. "
        "Contrôle selon les exigences listées ci-dessous, puis signalement "
        "de ce qui a été observé / déclaré / non observé / à confirmer avec vous. "
        "« Déclaré » = réponse opérateur, pas une preuve.</p>"
        f"{fiche_note}"
        f"<div class='score'>"
        f"<span class='pill' style='color:#1b7f4a'>{_e(c.get('observes', 0))} observé(s)</span>"
        f"<span class='pill' style='color:#3a6ea5'>{_e(c.get('declares', 0))} déclaré(s) — pas un certificat</span>"
        f"<span class='pill' style='color:#c44b00'>{_e(c.get('signales', 0))} signalé(s)</span>"
        f"<span class='pill' style='color:#c48a00'>{_e(c.get('a_confirmer', 0))} à confirmer</span>"
        f"</div>"
        f"{snapshot}"
        f"{''.join(items_html)}"
        f"<h3>Textes contrôlés selon</h3><ul class='meta'>{refs}</ul>"
        "</section>"
    )


def _section_programme(result: CheckupResult) -> str:
    block = result.programme or {}
    if not block.get("encadre") and not block.get("outils"):
        return ""
    assets = block.get("assets") or {}
    urls = "".join(f"<li><code>{_e(u)}</code></li>" for u in (assets.get("urls") or [])) or (
        "<li class='meta'>Pas d'URL — les outils web restent éteints.</li>"
    )
    cidr = assets.get("cidr") or "—"
    regles = "".join(f"<li>{_e(x)}</li>" for x in (block.get("regles") or []))
    rows = []
    for o in block.get("outils") or []:
        if not isinstance(o, dict):
            continue
        inst = "oui" if o.get("installe") else "non"
        aide = o.get("aide") or o.get("pourquoi") or ""
        rows.append(
            "<tr>"
            f"<td>{_e(o.get('nom'))}</td>"
            f"<td>{inst}</td>"
            f"<td class='meta'>{_e(o.get('pourquoi'))}</td>"
            f"<td class='meta'>{_e(aide)}</td>"
            "</tr>"
        )
    lecture_h = ""
    lect = block.get("lecture") or []
    if lect:
        items = []
        for row in lect:
            if not isinstance(row, dict):
                continue
            if not row.get("lance"):
                items.append(
                    f"<li class='meta'>{_e(row.get('nom'))} — non installé, passé.</li>"
                )
                continue
            extra = (row.get("extrait") or "")[:600]
            items.append(
                f"<li><strong>{_e(row.get('nom'))}</strong> "
                f"<code>{_e(row.get('commande') or '')}</code>"
                f"<pre style='white-space:pre-wrap;font-size:.8rem'>{_e(extra)}</pre></li>"
            )
        lecture_h = (
            "<h3>Lecture ciblée (URL du mandat)</h3>"
            f"<ul>{''.join(items)}</ul>"
        )
    return (
        "<section class='card' id='programme'>"
        "<h2>Outils de cette visite</h2>"
        f"<p>{_e(block.get('analogie') or '')}</p>"
        f"<p class='meta'>Mandat : {_e('oui' if block.get('mandat') else 'non')} · "
        f"CIDR {_e(cidr)}</p>"
        f"<h3>URL du mandat</h3><ul>{urls}</ul>"
        f"<h3>Comment ça tourne</h3><ul class='meta'>{regles}</ul>"
        "<h3>Catalogue de lecture</h3>"
        "<table style='width:100%;border-collapse:collapse;font-size:.88rem'>"
        "<thead><tr>"
        "<th style='text-align:left;padding:.25rem .4rem;border-bottom:1px solid #2a3848'>Outil</th>"
        "<th style='text-align:left;padding:.25rem .4rem;border-bottom:1px solid #2a3848'>Installé</th>"
        "<th style='text-align:left;padding:.25rem .4rem;border-bottom:1px solid #2a3848'>Rôle</th>"
        "<th style='text-align:left;padding:.25rem .4rem;border-bottom:1px solid #2a3848'>Aide</th>"
        "</tr></thead>"
        f"<tbody>{''.join(rows)}</tbody></table>"
        f"{lecture_h}"
        "</section>"
    )


def _section_regard(result: CheckupResult) -> str:
    block = result.regard or {}
    if not block or (getattr(result, "equipe", "blue") != "red"):
        return ""
    chemins = "".join(
        f"<li><strong>{_e(c.get('ordre'))}. {_e(c.get('titre'))}</strong> — {_e(c.get('detail'))}</li>"
        for c in (block.get("chemins") or [])
        if isinstance(c, dict)
    ) or "<li class='meta'>Rien de joignable sans mot de passe vu sur cette visite.</li>"
    att = "".join(
        f"<li><code>{_e(a.get('id'))}</code> — {_e(a.get('nom'))}</li>"
        for a in (block.get("attck") or [])
        if isinstance(a, dict)
    )
    att_h = f"<h3>ATT&CK observé (pas exécuté)</h3><ul class='meta'>{att}</ul>" if att else ""
    cve = "".join(
        f"<li><strong>{_e(x.get('titre'))}</strong> "
        f"<span class='meta'>{_e(x.get('hote'))} — {_e(x.get('note'))}</span></li>"
        for x in (block.get("cve_bannieres") or [])
        if isinstance(x, dict)
    )
    cve_h = f"<h3>Versions / historique public</h3><ul>{cve}</ul>" if cve else ""
    cibles = "".join(f"<li>{_e(t)}</li>" for t in (block.get("cibles") or []))
    return (
        "<section class='card' id='regard'>"
        "<h2>Regard attaquant</h2>"
        f"<p>{_e(block.get('limite') or '')}</p>"
        "<h3>Par où on viserait — on n'entre pas</h3>"
        f"<ol>{chemins}</ol>"
        f"<h3>Ordre de visée</h3><ol>{cibles}</ol>"
        f"{att_h}{cve_h}"
        "</section>"
    )


def _section_hygiene(result: CheckupResult) -> str:
    block = result.hygiene or {}
    items = block.get("items") or []
    if not items:
        return ""
    rows = "".join(
        f"<li><strong>{_e(i.get('titre'))}</strong> "
        f"— <em>{_e(i.get('statut'))}</em>. {_e(i.get('observation'))} "
        f"<span class='meta'>{_e(i.get('source'))}</span></li>"
        for i in items
        if isinstance(i, dict)
    )
    return (
        "<section class='card' id='hygiene'>"
        f"<h2>{_e(block.get('titre') or 'Hygiène ANSSI')}</h2>"
        f"<p>{_e(block.get('limite') or '')}</p>"
        f"<p class='meta'>Parc {_e(block.get('parc'))} — "
        f"{_e(block.get('n_observes'))}/{_e(block.get('n_total'))} observé(s).</p>"
        f"<ul>{rows}</ul>"
        "</section>"
    )


def _section_identites(result: CheckupResult) -> str:
    block = result.identites or {}
    if not block or (getattr(result, "equipe", "blue") != "red"):
        return ""
    portes = "".join(
        f"<li><strong>{_e(p.get('titre'))}</strong> — {_e(p.get('preuve'))} "
        f"<span class='meta'>{_e(p.get('statut'))}</span></li>"
        for p in (block.get("portes") or [])
        if isinstance(p, dict)
    ) or "<li class='meta'>Aucune porte d'identité vue sur cette visite.</li>"
    sso = "".join(f"<li>{_e(s)}</li>" for s in (block.get("sso") or []))
    sso_h = f"<h3>Portail / empreinte SSO</h3><ul class='meta'>{sso}</ul>" if sso else ""
    hors = "".join(f"<li>{_e(x)}</li>" for x in (block.get("hors_visite") or []))
    return (
        "<section class='card' id='identites'>"
        f"<h2>{_e(block.get('titre') or 'Identités')}</h2>"
        f"<p>{_e(block.get('limite') or '')}</p>"
        f"<ul>{portes}</ul>{sso_h}"
        f"<h3>Hors visite</h3><ul class='meta'>{hors}</ul>"
        "</section>"
    )


def _section_dossier(result: CheckupResult) -> str:
    block = result.dossier or {}
    if not block:
        return ""
    pieces = "".join(
        f"<li>{'✓' if p.get('signe') else '○'} {_e(p.get('titre'))}"
        f"{'' if p.get('requis') else ' <span class=meta>(facultatif)</span>'}</li>"
        for p in (block.get("pieces") or [])
        if isinstance(p, dict)
    )
    from guardia.core.dossier import PASSI

    return (
        "<section class='card' id='dossier'>"
        "<h2>Dossier d'audit</h2>"
        f"<p class='meta'>Parc {_e(block.get('parc'))} · niveau {_e(block.get('niveau'))} "
        f"({_e(block.get('niveau_libelle'))}). "
        f"{'Liasse complète.' if block.get('complet') else 'Pièces manquantes : ' + _e(', '.join(block.get('manquantes') or []))}."
        "</p>"
        f"<ul class='meta'>{pieces}</ul>"
        f"<p class='meta'>{_e(PASSI)}</p>"
        "</section>"
    )


def _section_autorisation(result: CheckupResult) -> str:
    from guardia.core.autorisation import etat as etat_auth, phrase_signature

    auth = getattr(result, "autorisation", None) or {}
    if not auth.get("etat"):
        auth = etat_auth(result.mission)
    etat = str(auth.get("etat") or "non_validee")
    color = {"validee": "#1b7f4a", "attestation_operateur": "#c48a00"}.get(etat, "#a10000")
    return (
        "<section class='card' id='autorisation' "
        f"style='border-color:{color}'>"
        "<h2>Autorisation</h2>"
        f"<p><strong>{_e(auth.get('libelle') or '')}</strong></p>"
        f"<pre style='white-space:pre-wrap;font-size:.9rem'>{_e(auth.get('bandeau') or '')}</pre>"
        f"<p class='meta'>{_e(phrase_signature(auth))}</p>"
        "<p class='meta'>Mandat coché : "
        f"{'oui' if auth.get('mandat_coche') else 'non'} · "
        "Attestation opérateur : "
        f"{'oui' if auth.get('attestation_operateur') else 'non'} · "
        "Double signature : "
        f"{'oui' if auth.get('double_signature') else 'non'} · "
        "Modules limités : "
        f"{'oui' if auth.get('modules_limites') else 'non'}</p>"
        "</section>"
    )


def _section_piliers(result: CheckupResult) -> str:
    plan = result.plan or {}
    equipe = getattr(result, "equipe", "blue") or "blue"
    def _on(key: str, extra: bool = False) -> str:
        return "allumé" if (plan.get(key) or extra) else "éteint"

    rows = [
        ("LAN", "Découverte et exposition (nmap, arp-scan, NSE)", _on("lan", True)),
        ("WEB", "URL du mandat (curl, WhatWeb, Nuclei, Nikto)", _on("site_url") if plan.get("site_url") else "éteint"),
        ("TLS", "testssl.sh / sslyze / sslscan / nmap ssl-enum", "selon portes 443"),
        ("RGPD", "Signalement observé / déclaré — pas un certificat", _on("rgpd")),
        ("Architecture", "Restructuration, VLAN, desserte", _on("restructure")),
        ("OT", "Ethernet industriel, lecture, pas d'écriture", _on("machines")),
        ("Red team", "Uniquement sur autorisation spécifique, lecture, pas d'intrusion", "ouvert" if equipe == "red" else "fermé"),
        ("Report engine", "Grandes lignes, technique, preuves, lexique", "toujours"),
        ("Vulnérabilités", "Greenbone / OpenVAS — lecture GMP orchestrée, pas un Full and Fast auto",
         "allumé" if plan.get("greenbone") else "éteint"),
        ("Durcissement", "Lynis — Linux local, pas un scan LAN",
         "allumé" if plan.get("lynis") else "éteint"),
        ("Conteneurs / FS", "Trivy — poste opérateur, pas le CIDR",
         "allumé" if plan.get("trivy") else "éteint"),
        ("Autorisations", "Huit pièces + opérateur / mandat / CIDR — red",
         "allumé" if plan.get("autorisations") else "éteint"),
        ("Offre PASSI", "Cinq domaines inspirés — pas une qualification ANSSI",
         "allumé" if (getattr(result, "passi", None) or {}).get("execute") else "éteint"),
    ]
    lis = "".join(
        f"<li><strong>{_e(n)}</strong> — {_e(d)} "
        f"<span class='badge' style='background:#3a6ea5'>{_e(s)}</span></li>"
        for n, d, s in rows
    )
    return (
        "<section class='card' id='piliers'>"
        "<h2>Moteur Guardia — modules</h2>"
        "<p class='meta'>Un moteur central. Les modules s'allument selon le mandat "
        "et l'état d'autorisation. Pas un lanceur de quarante scanners.</p>"
        f"<ul>{lis}</ul>"
        "</section>"
    )


def _section_pack_autorisations(result: CheckupResult) -> str:
    block = getattr(result, "autorisations", None) or {}
    if not block:
        return ""
    pieces = "".join(
        f"<li>{'✓' if p.get('etat') == 'ok' else '○'} {_e(p.get('titre'))} "
        f"<span class='meta'>{_e(p.get('etat'))}</span></li>"
        for p in (block.get("pieces") or []) + (block.get("extra") or [])
        if isinstance(p, dict)
    )
    manque = "".join(f"<li>{_e(x)}</li>" for x in (block.get("manquantes") or []))
    manque_h = f"<h3>Manque</h3><ul>{manque}</ul>" if manque else ""
    return (
        "<section class='card' id='pack-autorisations'>"
        "<h2>Autorisations (red)</h2>"
        f"<p>{_e(block.get('note') or '')}</p>"
        f"<p class='meta'>Parc {_e(block.get('parc'))} — "
        f"{'liasse complète' if block.get('complet') else 'brouillon'}</p>"
        f"<ul>{pieces}</ul>{manque_h}"
        "</section>"
    )


def _section_passi(result: CheckupResult) -> str:
    block = getattr(result, "passi", None) or {}
    if not block or not block.get("execute"):
        return ""
    execute = bool(block.get("execute"))
    domaines = "".join(
        f"<li><strong>{_e(d.get('domaine_passi'))}</strong> — {_e(d.get('statut'))}. "
        f"{_e(d.get('guardia'))} "
        f"<span class='meta'>{_e(d.get('jouables_aujourd_hui'))} outil(s) utile(s)</span></li>"
        for d in (block.get("domaines") or [])
        if isinstance(d, dict)
    )
    play_rows = []
    for p in block.get("play") or []:
        if not isinstance(p, dict):
            continue
        for a in p.get("actions") or []:
            if not isinstance(a, dict):
                continue
            play_rows.append(
                f"<li><code>{_e(a.get('nom'))}</code> "
                f"<span class='badge' style='background:#3a6ea5'>{_e(a.get('etat'))}</span> "
                f"<span class='meta'>{_e(a.get('why'))}</span></li>"
            )
    play_h = f"<h3>Orchestre</h3><ul>{''.join(play_rows)}</ul>" if play_rows else ""
    briques_h = ""
    b_items = []
    for b in block.get("briques") or []:
        if not isinstance(b, dict):
            continue
        av = ", ".join(
            str(o.get("nom") or "")
            for o in (b.get("outils_avenant") or [])
            if isinstance(o, dict)
        )
        b_items.append(
            f"<li><strong>{_e(b.get('nom'))}</strong> — {_e(b.get('statut'))}. "
            f"{_e(b.get('role'))} "
            f"<span class='meta'>{_e(b.get('jouables_aujourd_hui'))} moteur"
            + (f" · avenant : {_e(av)}" if av else "")
            + "</span></li>"
        )
    if b_items:
        briques_h = (
            "<h3>Six briques — architecture red</h3>"
            "<p class='meta'>Capacités logicielles. Pas une qualification organisationnelle. "
            "ZAP, Burp, BloodHound, Impacket, Metasploit, ffuf : avenant, jamais lancés auto.</p>"
            f"<ul>{''.join(b_items)}</ul>"
        )
    peri = block.get("perimetre") or {}
    peri_h = ""
    if peri:
        excl = ", ".join(str(x) for x in (peri.get("exclusions") or [])[:12]) or "—"
        peri_h = (
            "<h3>Périmètre signé</h3>"
            "<ul>"
            f"<li>CIDR : <code>{_e(peri.get('cidr') or '—')}</code></li>"
            f"<li>URL : <code>{_e(peri.get('url') or '—')}</code></li>"
            f"<li>Fenêtre : {_e(peri.get('fenetre') or '—')}</li>"
            f"<li>Exclusions : {_e(excl)}</li>"
            f"<li>Opérateur : {_e(peri.get('operateur') or '—')} · "
            f"client : {_e(peri.get('client') or '—')}</li>"
            "</ul>"
        )
    traces_h = ""
    t_rows = []
    for t in (block.get("traces") or [])[:40]:
        if not isinstance(t, dict):
            continue
        t_rows.append(
            "<tr>"
            f"<td>{_e(t.get('actif') or '—')}</td>"
            f"<td><code>{_e((t.get('test') or '')[:80])}</code></td>"
            f"<td>{_e(t.get('constat') or '')}</td>"
            f"<td><span class='badge' style='background:#3a6ea5'>{_e(t.get('statut_auditeur'))}</span></td>"
            "</tr>"
        )
    if t_rows:
        traces_h = (
            "<h3>Traçabilité</h3>"
            "<p class='meta'>mission → actif → test → résultat → preuve → constat → reco. "
            "Un finding n'est pas un verdict : validation humaine obligatoire.</p>"
            "<table style='width:100%;border-collapse:collapse;font-size:.88rem'><thead><tr><th>Actif</th><th>Test</th><th>Constat</th><th>Auditeur</th></tr></thead>"
            f"<tbody>{''.join(t_rows)}</tbody></table>"
        )
    qualif = block.get("qualification_organisationnelle") or ""
    cap_h = ""
    caps = "".join(f"<li>{_e(c)}</li>" for c in (block.get("capacites") or []))
    if caps or qualif:
        cap_h = (
            "<h3>Capacités logicielles</h3>"
            f"<ul>{caps}</ul>"
            f"<p class='meta'>{_e(qualif)}</p>"
        )
    apt = block.get("aptitude") or {}
    controles = "".join(f"<li>{_e(c)}</li>" for c in (apt.get("controles") or []))
    apt_h = ""
    if controles:
        apt_h = (
            "<h3>Outil professionnel</h3>"
            f"<p class='meta'>{_e(apt.get('editeur'))} · RNA {_e(apt.get('rna'))} · "
            f"SIREN {_e(apt.get('siren'))} · {_e(apt.get('nature'))}</p>"
            f"<ul>{controles}</ul>"
            f"<p class='meta'>{_e(apt.get('n_utiles_presents'))}/{_e(apt.get('n_utiles'))} "
            "outils utiles présents sur ce poste.</p>"
        )
    kicker = "Mode PASSI exécuté" if execute else "Mode PASSI non exécuté"
    return (
        "<section class='card' id='passi'>"
        f"<h2>{kicker}</h2>"
        f"<p><strong>{_e(block.get('attestation') or block.get('disclaimer') or '')}</strong></p>"
        f"<p class='meta'>{_e(block.get('statut'))}. Pas un certificat. "
        "Prestataire non qualifié PASSI ANSSI.</p>"
        f"<p class='meta'>{_e(block.get('offre') or '')}</p>"
        f"<ul>{domaines}</ul>{briques_h}{peri_h}{play_h}{traces_h}{cap_h}{apt_h}"
        "</section>"
    )


def _table_chaines(assessment: dict) -> str:
    rows = []
    for ch in assessment.get("chaines") or []:
        if not isinstance(ch, dict):
            continue
        if ch.get("validation") == "not_applicable":
            continue
        rows.append(
            "<tr>"
            f"<td>{_e(ch.get('exigence'))}</td>"
            f"<td><code>{_e(ch.get('controle'))}</code></td>"
            f"<td>{_e(ch.get('action'))}</td>"
            f"<td>{_e(ch.get('outil'))}</td>"
            f"<td>{_e(ch.get('resultat'))}</td>"
            f"<td><code>{_e(ch.get('preuve'))}</code></td>"
            f"<td>{_e(ch.get('validation'))}</td>"
            "</tr>"
        )
    if not rows:
        return ""
    return (
        "<h3>Chaîne exigence → preuve → rapport</h3>"
        "<table style='width:100%;border-collapse:collapse;font-size:.82rem'>"
        "<thead><tr><th>Exigence</th><th>Contrôle</th><th>Action</th><th>Outil</th>"
        "<th>Résultat</th><th>Preuve</th><th>Validation</th></tr></thead><tbody>"
        + "".join(rows)
        + "</tbody></table>"
    )


def _section_passi_alignment(result: CheckupResult) -> str:
    assessment = getattr(result, "passi_assessment", None) or {}
    if assessment and (getattr(result, "passi", None) or {}).get("execute"):
        summary = assessment.get("summary") or {}
        rows = []
        for r in assessment.get("controls") or []:
            rows.append(
                "<tr>"
                f"<td><code>{_e(r.get('id'))}</code></td>"
                f"<td>{_e(r.get('ref'))}</td>"
                f"<td>{_e(r.get('activity'))}</td>"
                f"<td>{_e(r.get('title'))}</td>"
                f"<td>{_e(r.get('status'))}</td>"
                f"<td>{_e(r.get('rationale'))}</td>"
                "</tr>"
            )
        return (
            "<section class='card' id='passi-assessment'>"
            "<h2>Dossier d'audit PASSI</h2>"
            f"<p><strong>Contrôles vérifiés : {_e(summary.get('verified'))} / {_e(summary.get('controls'))}</strong></p>"
            f"<p class='meta'>{_e(assessment.get('disclaimer') or '')}</p>"
            f"<p class='meta'>Activités : {_e(', '.join((assessment.get('mission') or {}).get('activities') or []))}</p>"
            f"<p class='meta'>Validations humaines en attente : {_e(summary.get('pending_human'))} · Non couverts : {_e(summary.get('not_covered'))} · Chaînes alimentées : {_e(summary.get('chaines_alimentees'))}</p>"
            + ("<table style='width:100%;border-collapse:collapse;font-size:.84rem'><thead><tr><th>ID</th><th>Réf.</th><th>Activité</th><th>Contrôle</th><th>État</th><th>Pourquoi</th></tr></thead><tbody>" + ''.join(rows) + "</tbody></table>" if rows else "")
            + _table_chaines(assessment)
            + "</section>"
        )
    block = getattr(result, "passi_alignment", None) or {}
    if not block or not (getattr(result, "passi", None) or {}).get("execute"):
        return ""
    summary = block.get("summary") or {}
    rows = []
    for r in (block.get("controls") or []):
        if not isinstance(r, dict):
            continue
        rows.append(
            "<tr>"
            f"<td><code>{_e(r.get('id'))}</code></td>"
            f"<td>{_e(r.get('family'))}</td>"
            f"<td>{_e(r.get('title'))}</td>"
            f"<td>{_e(r.get('status'))}</td>"
            f"<td>{_e(r.get('rationale'))}</td>"
            "</tr>"
        )
    return (
        "<section class='card' id='passi-alignment'>"
        "<h2>Alignement PASSI v2.2</h2>"
        f"<p class='meta'>{_e(block.get('disclaimer') or '')}</p>"
        "<table style='width:100%;border-collapse:collapse;font-size:.84rem'><thead><tr><th>ID</th><th>Famille</th><th>Contrôle</th><th>État</th><th>Pourquoi</th></tr></thead><tbody>" + ''.join(rows) + "</tbody></table>"
        "</section>"
    )


def _section_osi(result: CheckupResult) -> str:
    """Couverture OSI + démonstration d'exposition (vouvoiement)."""
    brain = getattr(result, "adaptatif", None) or {}
    cov = brain.get("osi_couverture") or {}
    if not cov and result.hosts:
        try:
            from guardia.engines.osi_map import couverture_osi

            cov = couverture_osi(
                result.hosts,
                brain.get("evenements") or [],
                iface=result.iface or "",
                gateway=result.gateway or "",
                cidr=result.cidr or "",
                website=result.website or None,
                rgpd=result.rgpd or None,
            )
        except Exception:
            cov = {}
    if not cov:
        return ""
    touched = cov.get("couches_touchees") or []
    gaps = cov.get("lacunes") or []
    badges = "".join(
        f"<span class='badge' style='background:#1b7f4a'>{_e(ly)}</span> "
        for ly in touched
    )
    gap_b = "".join(
        f"<span class='badge' style='background:#666'>{_e(ly)}</span> "
        for ly in gaps
    )
    detail_rows = ""
    for ly, items in (cov.get("detail") or {}).items():
        label = (cov.get("labels") or {}).get(ly, ly)
        detail_rows += (
            f"<li><strong>{_e(ly)}</strong> — {_e(label)} : "
            + ", ".join(_e(x) for x in (items or [])[:8])
            + ("…" if len(items or []) > 8 else "")
            + "</li>"
        )
    return (
        "<section class='card' id='couverture-osi'>"
        "<h2>Couverture OSI</h2>"
        "<p>Nous avons cartographié les couches observées pendant la plage d'audit "
        "(lecture seule). Ceci décrit la couverture d'observation, pas une conformité.</p>"
        f"<p><strong>Touchées :</strong> {badges or '—'}</p>"
        f"<p><strong>Lacunes :</strong> {gap_b or 'aucune dans le périmètre observé'}</p>"
        f"<p class='meta'>{_e(cov.get('resume') or '')}</p>"
        + (f"<ul>{detail_rows}</ul>" if detail_rows else "")
        + f"<p class='meta'>{_e(cov.get('disclaimer') or '')}</p>"
        + "</section>"
    )



def _groq_bloc(block: dict) -> str:
    groq = block.get("llm_groq") or {}
    if not groq:
        return ""
    fiche = groq.get("fiche_explication_client") or groq.get("fiche_explication") or ""
    ann = groq.get("annexe_technicien") or {}
    steps = "".join(
        f"<li>{_e(s)}</li>" for s in (groq.get("procedure_confirmation_lecture") or [])[:12]
    )
    indices = "".join(
        f"<li>{_e(s)}</li>" for s in (ann.get("indices_techniques") or [])[:12]
    )
    statut = groq.get("skipped") or ("ok — " + str(groq.get("model") or "groq"))
    return (
        "<h3>Groq — propositions (à valider)</h3>"
        f"<p class='meta'>{_e(statut)}. Ton technicien. Lecture seule. "
        "Pas d'exploit / PoC. Proposition opérateur / à valider.</p>"
        + (
            "<h4>Fiche client (vouvoiement)</h4>"
            f"<p>{_e(fiche[:1200])}</p>"
            if fiche
            else ""
        )
        + (
            "<h4>Annexe technicien</h4>"
            f"<p><strong>Hypothèse de réalisabilité :</strong> "
            f"{_e((ann.get('hypothese_realisabilite') or '')[:800])}</p>"
            + (f"<p><strong>Indices techniques</strong></p><ul>{indices}</ul>" if indices else "")
            + (
                f"<p><strong>Risque résiduel :</strong> {_e((ann.get('risque_residuel') or '')[:500])}</p>"
                if ann.get("risque_residuel")
                else ""
            )
            if ann
            else ""
        )
        + (f"<h4>Confirmation lecture</h4><ol>{steps}</ol>" if steps else "")
    )



def _section_adaptatif(result: CheckupResult) -> str:
    block = getattr(result, "adaptatif", None) or {}
    if not block:
        return ""
    dec = "".join(
        f"<li><span class='badge' style='background:#3a6ea5'>{_e(d.get('etat'))}</span> "
        f"<code>{_e(d.get('noeud'))}</code> — {_e(d.get('why'))}</li>"
        for d in (block.get("decisions") or [])
        if isinstance(d, dict)
    )
    paths = "".join(
        f"<li>{' → '.join(_e(x) for x in (p.get('etapes') or []))} "
        f"<span class='meta'>hypothèse, pas d'exploit</span></li>"
        for p in (block.get("chemins") or [])
        if isinstance(p, dict)
    )
    portes = "".join(
        f"<li><strong>{_e(g.get('etat'))}</strong> — {_e(g.get('proposition') or g.get('motif') or '')}</li>"
        for g in (block.get("portes") or [])
        if isinstance(g, dict)
    )
    g = block.get("graphe") or {}
    dirs = "".join(
        f"<li><span class='badge' style='background:#3a6ea5'>{_e(d.get('status'))}</span> "
        f"<code>{_e(d.get('id'))}</code> "
        f"<span class='meta'>[{_e(d.get('layer'))}]</span> — "
        f"{_e(d.get('nature_action') or 'démonstration d\'exposition (lecture)')} — "
        f"{_e(d.get('why'))}</li>"
        for d in (block.get("directives_passi_cnil") or [])
        if isinstance(d, dict)
    )
    return (
        "<section class='card' id='cerveau'>"
        "<h2>Décisions d'audit</h2>"
        f"<p><strong>{_e(block.get('synthese') or '')}</strong></p>"
        f"<p class='meta'>{_e(block.get('nature') or '')}</p>"
        "<p>Nous avons frappé à la porte (knock) pendant la plage d'audit : "
        "expositions observables en lecture seule — on voit la réponse, on n'entre pas. "
        "Ceci permettrait d'évaluer l'impact ; pour vous protéger, il faudrait appliquer "
        "les remèdes. Aucune exploitation n'a été exécutée ; aucun payload n'est lancé.</p>"
        f"<p class='meta'>Ouverts { _e(block.get('n_ouverts')) } · "
        f"écartés { _e(block.get('n_ecartes')) } · "
        f"refusés policy { _e(block.get('n_refuses_policy')) } · "
        f"graphe { _e(g.get('n_actifs')) } actif(s) / { _e(g.get('n_services')) } service(s).</p>"
        + (f"<h3>Décisions</h3><ul>{dec}</ul>" if dec else "")
        + (f"<h3>Directives PASSI / CNIL</h3><ul>{dirs}</ul>" if dirs else "")
        + _groq_bloc(block)
        + (f"<h3>Chemins d'exposition</h3><ul>{paths}</ul>" if paths else "")
        + (f"<h3>Portes humaines</h3><ul>{portes}</ul>" if portes else "")
        + "</section>"
    )


def _section_correlation(result: CheckupResult) -> str:
    block = result.correlation or {}
    items = block.get("items") or []
    if not items and not block.get("regle"):
        return ""
    cards = []
    for it in items:
        if not isinstance(it, dict):
            continue
        src = "".join(f"<li>{_e(s)}</li>" for s in (it.get("sources") or []))
        hotes = ", ".join(it.get("hotes") or []) or "—"
        cards.append(
            "<article class='card' style='margin:.7rem 0'>"
            f"<h4>{_e(it.get('titre'))} "
            f"<span class='badge'>{_e(it.get('gravite'))}</span></h4>"
            f"<p class='meta'>{_e(it.get('n'))} observation(s) · {_e(hotes)}</p>"
            f"<p>{_e(it.get('action'))}</p>"
            f"<ul class='meta'>{src}</ul></article>"
        )
    return (
        "<section class='card' id='correlation'>"
        "<h2>Corrélation</h2>"
        f"<p class='meta'>{_e(block.get('regle') or '')}</p>"
        f"<p class='meta'>{_e(block.get('llm') or '')}</p>"
        f"{''.join(cards) or '<p class=meta>Rien à grouper sur cet échantillon.</p>'}"
        "</section>"
    )


def _section_cve(result: CheckupResult) -> str:
    block = getattr(result, "cve_correlation", None) or {}
    if not block:
        return ""
    findings = block.get("findings") or []
    vision = block.get("vision_osi") or {}
    items = ""
    for c in findings[:40]:
        f = _as_finding(c)
        if f:
            items += _finding_block(f)
    if not items and not block.get("n_findings") and not vision:
        # rien à montrer
        if not block.get("orchestre"):
            return ""
    surf = vision.get("surfaces_non_protegees") or []
    surf_h = ""
    if surf:
        rows = "".join(
            f"<li><code>{_e(s.get('hote'))}:{_e(s.get('port'))}</code> "
            f"{_e(s.get('service'))} — {_e(', '.join(s.get('kinds') or []))} "
            f"<span class='meta'>OSI {_e('/'.join(s.get('osi_layers') or []))}</span></li>"
            for s in surf[:30]
            if isinstance(s, dict)
        )
        surf_h = (
            "<h3>Surfaces non protégées (lecture)</h3>"
            f"<ul>{rows or '<li class=meta>Aucune surface flaggée.</li>'}</ul>"
        )
    lacunes = vision.get("lacunes") or (vision.get("couverture") or {}).get("lacunes") or []
    couches = vision.get("couches_touchees") or (vision.get("couverture") or {}).get("couches_touchees") or []
    osi_meta = ""
    if couches or lacunes or vision:
        osi_meta = (
            f"<p class='meta'>OSI touchées : {_e(', '.join(couches) or '—')} · "
            f"Lacunes : {_e(', '.join(lacunes) if lacunes else 'aucune (périmètre observé)')} · "
            f"Surfaces : {_e(vision.get('n_surfaces', len(surf)))} · "
            f"CVE catalogue : {_e(block.get('n_findings', 0))}</p>"
        )
    if not items:
        items = "<p class='meta'>Aucune corrélation CVE sur cet échantillon (catalogue local).</p>"
    return (
        "<section class='card' id='cve-correlation'>"
        "<h2>Corrélation CVE (lecture)</h2>"
        "<p class='meta'>Catalogue local curated — pas de dump NVD. "
        "Hypothèses d'impact + remèdes. Aucune exploitation exécutée.</p>"
        f"{osi_meta}"
        f"<p>{_e(vision.get('resume') or block.get('nature') or '')}</p>"
        f"{surf_h}"
        f"<h3>Findings corrélés</h3>{items}"
        f"<p class='meta'>{_e(block.get('note') or '')}</p>"
        "</section>"
    )


def _section_lynis(result: CheckupResult) -> str:
    block = result.lynis or {}
    if not block:
        return ""
    extra = ""
    if block.get("extrait"):
        extra = (
            "<pre style='white-space:pre-wrap;font-size:.8rem'>"
            f"{_e((block.get('extrait') or '')[-2000:])}</pre>"
        )
    return (
        "<section class='card' id='lynis'>"
        "<h2>Lynis — durcissement local</h2>"
        f"<p>{_e(block.get('invite') or block.get('note') or '')}</p>"
        f"<p class='meta'>Installé : {_e('oui' if block.get('installe') else 'non')} · "
        f"Lancé : {_e('oui' if block.get('lance') else 'non')} · "
        f"Distant : non. Kali : <code>{_e(block.get('install') or 'sudo apt install lynis')}</code></p>"
        f"{extra}"
        "</section>"
    )


def _section_greenbone(result: CheckupResult) -> str:
    block = result.greenbone or {}
    if not block:
        return ""
    extra = ""
    if block.get("extrait"):
        extra = (
            "<pre style='white-space:pre-wrap;font-size:.8rem'>"
            f"{_e((block.get('extrait') or '')[:1800])}</pre>"
        )
    return (
        "<section class='card' id='greenbone'>"
        "<h2>Greenbone / OpenVAS — lecture GMP</h2>"
        f"<p>{_e(block.get('note') or '')}</p>"
        f"<p class='meta'>Présent : {_e('oui' if block.get('installe') else 'non')} · "
        f"Orchestré : oui · Lancé : {_e('oui' if block.get('lance') else 'non')} · "
        f"État : {_e(block.get('etat') or '—')}. "
        f"Kali : <code>{_e(block.get('install') or 'sudo apt install gvm && sudo gvm-setup')}</code></p>"
        f"<p class='meta'>{_e(block.get('invite') or '')}</p>"
        f"{extra}"
        "</section>"
    )


def _section_trivy(result: CheckupResult) -> str:
    block = getattr(result, "trivy", None) or {}
    if not block:
        return ""
    extra = ""
    if block.get("extrait"):
        extra = (
            "<pre style='white-space:pre-wrap;font-size:.8rem'>"
            f"{_e((block.get('extrait') or '')[-2000:])}</pre>"
        )
    return (
        "<section class='card' id='trivy'>"
        "<h2>Trivy — FS opérateur</h2>"
        f"<p>{_e(block.get('note') or block.get('invite') or '')}</p>"
        f"<p class='meta'>Installé : {_e('oui' if block.get('installe') else 'non')} · "
        f"Lancé : {_e('oui' if block.get('lance') else 'non')} · Distant : non. "
        f"Kali : <code>{_e(block.get('install') or 'sudo apt install trivy')}</code></p>"
        f"{extra}"
        "</section>"
    )


def _section_orchestre(result: CheckupResult) -> str:
    block = result.orchestre or {}
    etapes = block.get("etapes") or []
    prevu = block.get("prevu") or []
    if not etapes and not prevu:
        return ""
    plan = "".join(f"<li><code>{_e(x)}</code></li>" for x in prevu) or (
        "<li class='meta'>Plan non annoncé.</li>"
    )
    rows = []
    for e in etapes:
        if not isinstance(e, dict):
            continue
        kind = e.get("type") or ""
        etat = e.get("etat") or ""
        nom = e.get("nom") or e.get("titre") or kind
        cible = e.get("cible") or e.get("why") or ""
        rows.append(
            f"<li><strong>{_e(nom)}</strong> "
            f"<span class='badge'>{_e(etat)}</span> "
            f"<span class='meta'>{_e(cible)}</span></li>"
        )
    body = "".join(rows) or "<li class='meta'>Aucune étape journalisée.</li>"
    return (
        "<section class='card' id='orchestre'>"
        "<h2>Orchestre — ce qui a vraiment tourné</h2>"
        "<p class='meta'>Pas une liste d'appels. Chaque action prévue est jouée, "
        "sautée ou notée absente. Un outil manquant n'arrête rien.</p>"
        f"<p class='meta'>Étapes : {_e(block.get('n', len(etapes)))} · "
        f"jouées : {_e(block.get('joues', 0))} · "
        f"absentes / sautées : {_e(block.get('absents_ou_sautes', 0))}</p>"
        "<h3>Plan annoncé</h3>"
        f"<ul class='meta'>{plan}</ul>"
        "<h3>Journal</h3>"
        f"<ul>{body}</ul>"
        "</section>"
    )


def _section_calibrage(result: CheckupResult) -> str:
    block = result.calibrage or {}
    if not block:
        return ""
    lances = "".join(
        f"<li><strong>{_e(j.get('nom'))}</strong> — {_e(j.get('cible') or j.get('ip') or '')} "
        f"<span class='meta'>{_e((j.get('extrait') or '')[:120])}</span></li>"
        for j in (block.get("lances") or [])[:24]
        if isinstance(j, dict)
    ) or "<li class='meta'>Aucune sonde lancée (outils absents ou parc muet).</li>"
    absents = "".join(f"<li>{_e(x)}</li>" for x in (block.get("absents") or []))
    abs_h = f"<h3>Non installés sur ce Kali (le checkup a continué)</h3><ul class='meta'>{absents}</ul>" if absents else ""
    return (
        "<section class='card' id='calibrage'>"
        "<h2>Calibrage — ce que le parc a allumé</h2>"
        "<p>Le scan initial a vu des portes. Guardia a enchaîné les outils Kali "
        f"présents. <strong>{_e(block.get('n_lances', 0))}</strong> sonde(s), "
        f"<strong>{_e(block.get('n_findings', 0))}</strong> observation(s).</p>"
        f"<ul>{lances}</ul>"
        f"{abs_h}"
        "</section>"
    )


def _section_recap(result: CheckupResult) -> str:
    block = result.recap or {}
    if not block.get("titre"):
        return ""
    c = block.get("chiffres") or {}
    risques = "".join(f"<li>{_e(x)}</li>" for x in (block.get("risques") or []))
    actions = "".join(
        "<li><strong>"
        f"{_e(a.get('quand'))}</strong> — {_e(a.get('quoi'))}<br/>"
        f"<span class='meta'>Faire : {_e(a.get('faire'))} · Qui : {_e(a.get('qui'))}</span></li>"
        for a in (block.get("actions") or [])
        if isinstance(a, dict)
    )
    perim = "".join(f"<li>{_e(x)}</li>" for x in (block.get("perimetre") or []))
    topo = _e(block.get("topo_approx") or "")
    topo_h = (
        f"<h3>Ce qu'on nous a dit en arrivant</h3><p>{topo}</p>"
        if topo
        else ""
    )
    cadre = block.get("cadre") or {}
    auth = block.get("autorisation") or {}
    etat_auth = str(auth.get("etat") or "")
    if etat_auth == "validee":
        auth_color = "#1b7f4a"
        auth_titre = "Autorisation validée"
    elif etat_auth == "attestation_operateur":
        auth_color = "#c48a00"
        auth_titre = "Attestation opérateur — mandat non coché"
    else:
        auth_color = "#a10000"
        auth_titre = "Autorisation non validée"
    bandeau = auth.get("bandeau") or block.get("phrase_signature") or ""
    mandat = (
        "oui, coché dans la mission" if block.get("mandat") else "non coché dans la mission"
    )
    pills = (
        f"<span class='pill'>{_e(c.get('appareils', 0))} appareil(s) vus</span>"
        f"<span class='pill' style='color:#a10000'>{_e(c.get('critique', 0))} critique</span>"
        f"<span class='pill' style='color:#c44b00'>{_e(c.get('eleve', 0))} élevé</span>"
        f"<span class='pill' style='color:#c48a00'>{_e(c.get('moyen', 0))} moyen</span>"
        f"<span class='pill' style='color:#666'>{_e(c.get('info', 0))} information(s)</span>"
    )
    hotes = (
        f"<p class='meta'>Posture des hôtes (autre compteur) : "
        f"{_e(c.get('hotes_critiques', 0))} en critique, "
        f"{_e(c.get('hotes_risque', c.get('risque', 0)))} en risque. "
        "Ce n'est pas la gravité des findings.</p>"
    )
    return (
        "<section class='recap' id='grandes-lignes'>"
        "<p class='kicker'>Page à lire en premier — le reste est technique</p>"
        f"<h2>{_e(block.get('titre') or 'Grandes lignes')}</h2>"
        f"<p class='lead'>{_e(block.get('lecteurs') or '')}</p>"
        f"<p>{_e(block.get('these') or '')}</p>"
        f"<div class='score' style='border-left:4px solid {auth_color};padding-left:.8rem'>"
        f"<span class='pill' style='color:{auth_color}'>{_e(auth_titre)}</span>"
        "</div>"
        f"<p class='meta'>{_e(bandeau)}</p>"
        f"<div class='score'>{pills}</div>"
        f"{hotes}"
        "<h3>Ce qui compte pour vous</h3>"
        f"<ol class='risques'>{risques}</ol>"
        "<h3>Quoi faire — trois lignes</h3>"
        f"<ol>{actions}</ol>"
        f"{topo_h}"
        "<h3>Opérateur identifié</h3>"
        f"<p class='meta'>{_e(block.get('visage_decouvert') or '')}</p>"
        f"<p class='meta'>Opérateur ÉOH : {_e(block.get('operateur') or 'Platon-Y')}.</p>"
        "<h3>Périmètre de cette visite</h3>"
        f"<ul class='meta'>{perim}</ul>"
        "<h3>Cadre</h3>"
        f"<p class='meta'>Mandat / NDA : {_e(mandat)}.</p>"
        f"<p class='meta'>{_e(block.get('phrase_signature') or '')}</p>"
        f"<p class='meta'>{_e(cadre.get('cp') or '')}</p>"
        f"<p class='meta'>{_e(cadre.get('rgpd32') or '')}</p>"
        f"<p class='meta'>{_e(cadre.get('ess') or '')}</p>"
        "</section>"
    )


def _section_journal(result: CheckupResult) -> str:
    block = result.journal or {}
    if not block:
        try:
            from guardia.report.recap import build_journal

            block = build_journal(result)
        except Exception:
            return ""
    phases = "".join(
        f"<li><code>{_e(p.get('phase'))}</code> — {_e(p.get('duree'))}</li>"
        for p in (block.get("phases") or [])
        if isinstance(p, dict)
    ) or "<li class='meta'>Phases non horodatées (rapport partiel).</li>"
    mods = "".join(f"<li>{_e(x)}</li>" for x in (block.get("modules") or [])) or (
        "<li class='meta'>Checkup LAN seul.</li>"
    )
    outils = "".join(f"<li>{_e(x)}</li>" for x in (block.get("outils") or []))
    prog = block.get("programme") or ""
    prog_h = f"<p class='meta'>{_e(prog)}</p>" if prog else ""
    return (
        "<section class='card' id='journal'>"
        "<h2>Journal d'actions — ce qui a été lancé ce jour</h2>"
        "<p class='meta'>Trace signée. Périmètre du mandat.</p>"
        f"<p class='meta'>Mandat coché : {_e('oui' if block.get('mandat') else 'non / —')} · "
        f"CIDR {_e(block.get('cidr'))} · {_e(block.get('debut'))} → {_e(block.get('fin'))} · "
        f"{_e(block.get('elapsed'))}s</p>"
        "<h3>Phases</h3>"
        f"<ul class='meta'>{phases}</ul>"
        "<h3>Modules allumés</h3>"
        f"<ul>{mods}</ul>"
        "<h3>Outils lancés</h3>"
        f"<ul class='meta'>{outils}</ul>"
        f"{prog_h}"
        "</section>"
    )


def _section_direction(result: CheckupResult) -> str:
    block = result.direction or {}
    if not block.get("these"):
        return ""
    c = block.get("chiffres") or {}
    top = "".join(
        f"<li><strong>{_e(t.get('titre'))}</strong> "
        f"<span class='meta'>({_e(t.get('gravite'))} · {_e(t.get('hote'))})</span></li>"
        for t in (block.get("top") or [])
    ) or "<li class='meta'>Pas de finding haute / critique sur l'échantillon visible.</li>"
    nexts = "".join(f"<li>{_e(x)}</li>" for x in (block.get("next_steps") or []))
    return (
        "<section class='card' id='direction' style='border-color:#3a6ea5'>"
        "<h2>Pour la direction</h2>"
        f"<p>{_e(block.get('these') or '')}</p>"
        "<div class='score'>"
        f"<span class='pill'>{_e(c.get('appareils', 0))} appareil(s)</span>"
        f"<span class='pill' style='color:#a10000'>{_e(c.get('critique', 0))} critique</span>"
        f"<span class='pill' style='color:#c44b00'>{_e(c.get('eleve', 0))} élevé</span>"
        f"<span class='pill' style='color:#c48a00'>{_e(c.get('moyen', 0))} moyen</span>"
        f"<span class='pill' style='color:#666'>{_e(c.get('info', 0))} information(s)</span>"
        f"<span class='pill' style='color:#3a6ea5'>{_e(c.get('serveurs_desserte', 0))} desserte</span>"
        "</div>"
        "<h3>À arbitrer d'abord</h3>"
        f"<ol>{top}</ol>"
        "<h3>La suite</h3>"
        f"<ul>{nexts}</ul>"
        f"<p class='meta'>{_e(block.get('ess') or '')}</p>"
        "</section>"
    )


def _section_usages(result: CheckupResult) -> str:
    block = result.usages or {}
    if not block.get("disclaimer") and not block.get("items"):
        return ""
    c = block.get("compteurs") or {}
    items_html = []
    for it in block.get("items") or []:
        statut = str(it.get("statut") or "")
        color = "#666"
        if "signalé" in statut or statut.startswith("non"):
            color = "#c44b00"
        elif statut.startswith("observ"):
            color = "#1b7f4a"
        elif "déclaré" in statut:
            color = "#3a6ea5"
        elif "confirmer" in statut:
            color = "#c48a00"
        steps = "".join(f"<li>{_e(s)}</li>" for s in (it.get("que_faire") or []))
        items_html.append(
            "<article class='card' style='margin:.7rem 0;border-left:4px solid "
            f"{color}'>"
            f"<h4><span class='badge' style='background:{color}'>{_e(statut)}</span> "
            f"{_e(it.get('titre'))}</h4>"
            f"<p class='meta'>Exigence : {_e(it.get('exigence'))}</p>"
            f"<p><strong>Observation :</strong> {_e(it.get('observation'))}</p>"
            f"<p><strong>Lecture :</strong> {_e(it.get('signalement'))}</p>"
            f"<ol>{steps}</ol></article>"
        )
    srv = block.get("serveurs_parc") or []
    srv_html = ""
    if srv:
        rows = "".join(
            "<tr>"
            f"<td>{_e(s.get('ip'))}</td>"
            f"<td>{_e(s.get('hostname') or '—')}</td>"
            f"<td>{_e(', '.join(s.get('roles') or []))}</td>"
            "</tr>"
            for s in srv
        )
        srv_html = (
            "<h3>Machine(s) qui desservent le parc</h3>"
            "<p class='meta'>Un incident ici touche les sessions, fichiers, comptes. "
            "On n'identifie aucun établissement : ce sont des rôles techniques.</p>"
            "<table style='width:100%;border-collapse:collapse;font-size:.9rem'>"
            "<tr><th>IP</th><th>Nom</th><th>Rôles</th></tr>"
            f"{rows}</table>"
        )
    fiche = ""
    if block.get("fiche_vide"):
        fiche = (
            "<p class='meta'>Fiche usages vide — UI : Configurer usages · "
            "CLI : <code>python3 -m guardia usages -m mission.yaml</code></p>"
        )
    return (
        "<section class='card' id='usages-droits' style='border-color:#7a1f1f'>"
        "<h2>Usages & droits — ce que les gens peuvent faire</h2>"
        f"<p><strong>{_e(block.get('disclaimer') or '')}</strong></p>"
        f"{fiche}"
        f"<div class='score'>"
        f"<span class='pill' style='color:#1b7f4a'>{_e(c.get('observes', 0))} observé(s)</span>"
        f"<span class='pill' style='color:#3a6ea5'>{_e(c.get('declares', 0))} déclaré(s)</span>"
        f"<span class='pill' style='color:#c44b00'>{_e(c.get('signales', 0))} signalé(s)</span>"
        f"<span class='pill' style='color:#c48a00'>{_e(c.get('a_confirmer', 0))} à confirmer</span>"
        f"<span class='pill'>{_e(c.get('serveurs', 0))} desserte</span>"
        f"</div>"
        f"{srv_html}"
        f"{''.join(items_html)}"
        "</section>"
    )


def _section_machines(result: CheckupResult) -> str:
    block = result.machines or {}
    if not block:
        return ""
    note = block.get("note") or block.get("can_note") or ""
    n = block.get("hotes_ot", 0)
    extra = ""
    if not block.get("done"):
        extra = "<p class='meta'>Module demandé mais non joué (budget ou nmap).</p>"
    warns = "".join(f"<li>{_e(w)}</li>" for w in (block.get("warns") or []))
    whtml = f"<ul class='meta'>{warns}</ul>" if warns else ""
    ports = ""
    tcp = block.get("ports_tcp") or ""
    udp = block.get("ports_udp") or ""
    if tcp or udp:
        ports = (
            f"<p class='meta'>Sondage Ethernet industriel — TCP {_e(tcp)}"
            + (f" · UDP {_e(udp)}" if udp else "")
            + " (lecture, pas d'écriture automate).</p>"
        )
    return (
        "<section class='card' id='machines-ot'>"
        "<h2>Machines / OT — Ethernet industriel (sur demande)</h2>"
        f"<p class='meta'>{_e(n)} hôte(s) avec protocole d'atelier visible. "
        f"{_e(note)}</p>{ports}{extra}{whtml}"
        "<p class='meta'>Les findings détaillés sont dans les fiches appareils "
        "et le chapitre restructuration. Guardia n'écrit pas sur un automate. "
        "Les grandes machines parlent Modbus TCP, S7, OPC-UA, EtherNet/IP, Profinet — "
        "pas un bus CAN.</p>"
        "</section>"
    )


def _section_pistes(result: CheckupResult) -> str:
    block = result.pistes or {}
    items = block.get("items") or []
    if not items and not block.get("disclaimer"):
        return ""
    c = block.get("compteurs") or {}
    rows = []
    for it in items:
        statut = str(it.get("statut") or "")
        color = "#666"
        if "indices" in statut:
            color = "#c44b00"
        elif "conseil" in statut:
            color = "#3a6ea5"
        elif "déjà" in statut:
            color = "#1b7f4a"
        cmd = it.get("commande") or ""
        cmd_h = f"<p class='meta'><code>{_e(cmd)}</code></p>" if cmd else ""
        src = it.get("source") or "catalogue"
        src_h = " <span class='badge' style='background:#3a6ea5'>veille</span>" if src == "veille" else ""
        rows.append(
            "<article class='card' style='margin:.6rem 0;border-left:4px solid "
            f"{color}'>"
            f"<h4><span class='badge' style='background:{color}'>{_e(statut)}</span> "
            f"{_e(it.get('titre'))}{src_h}</h4>"
            f"<p>{_e(it.get('pourquoi') or '')}</p>"
            f"<p class='meta'>Indices : {_e(it.get('indices') or '—')}</p>"
            f"{cmd_h}</article>"
        )
    return (
        "<section class='card' id='pistes' style='border-color:#3a6ea5'>"
        "<h2>Pistes à explorer — pas des findings</h2>"
        f"<p><strong>{_e(block.get('disclaimer') or '')}</strong></p>"
        f"<p class='meta'>Structure {_e(block.get('structure') or '—')} · "
        f"taille {_e(block.get('taille') or '—')}</p>"
        "<div class='score'>"
        f"<span class='pill'>{_e(c.get('catalogue', len(items)))} catalogue</span>"
        f"<span class='pill' style='color:#c44b00'>{_e(c.get('indices', 0))} indice(s) LAN</span>"
        f"<span class='pill' style='color:#3a6ea5'>{_e(c.get('conseil_llm', 0))} conseil(s) LLM</span>"
        f"<span class='pill'>{_e(c.get('veille', 0))} veille</span>"
        "</div>"
        f"{''.join(rows)}"
        "</section>"
    )


def render(result: CheckupResult, out_path: Path) -> Path:
    """Écrit le rapport HTML et retourne le chemin."""
    try:
        out_path.parent.mkdir(parents=True, exist_ok=True)
        body = _build(result)
        out_path.write_text(body, encoding="utf-8")
        log.info("rapport écrit: %s", out_path)
        return out_path
    except OSError as exc:
        log.error("écriture rapport: %s", exc)
        raise


def _build(result: CheckupResult) -> str:
    m = result.mission
    hosts = result.hosts
    if not (result.direction or {}).get("these"):
        try:
            from guardia.report.direction import build_direction_brief

            result.direction = build_direction_brief(result)
        except Exception:
            pass
    if not (result.identite or {}).get("association"):
        try:
            from guardia.core.identite import identite_dict

            result.identite = identite_dict(result.mission)
        except Exception:
            pass
    if not (result.recap or {}).get("titre"):
        try:
            from guardia.report.recap import build_grandes_lignes, build_journal

            result.recap = build_grandes_lignes(result)
            if not result.journal:
                result.journal = build_journal(result)
        except Exception:
            pass
    if not getattr(result, "autorisation", None):
        try:
            from guardia.core.autorisation import etat as etat_auth

            result.autorisation = etat_auth(result.mission)
        except Exception:
            pass
    if not (getattr(result, "correlation", None) or {}).get("regle"):
        try:
            from guardia.engines.correlation import build_correlation

            result.correlation = build_correlation(result)
        except Exception:
            pass
    if not getattr(result, "greenbone", None):
        try:
            from guardia.engines.greenbone import etat as gvm_etat

            result.greenbone = gvm_etat()
        except Exception:
            pass
    if not getattr(result, "lynis", None):
        try:
            from guardia.engines.lynis import etat as lynis_etat

            result.lynis = lynis_etat()
        except Exception:
            pass
    if not (result.pistes or {}).get("items"):
        try:
            from types import SimpleNamespace

            from guardia.core.orchestrate import want_pistes
            from guardia.engines.pistes import build_pistes

            plan_on = (result.plan or {}).get("pistes")
            if plan_on is None:
                plan_on = want_pistes(
                    SimpleNamespace(pistes=False, no_pistes=False, llm=False),
                    result.mission,
                )
            if plan_on:
                result.pistes = build_pistes(result)
        except Exception:
            pass
    counts = {p: 0 for p in Posture}
    for h in hosts:
        counts[h.posture] = counts.get(h.posture, 0) + 1

    all_findings = [f for h in hosts for f in h.findings]
    all_findings.sort(
        key=lambda f: (
            {"critique": 0, "haute": 1, "moyenne": 2, "basse": 3, "info": 4}.get(
                f.gravite.value, 9
            ),
            f.priorite,
        )
    )
    top = all_findings[:5]

    cards = "\n".join(_host_card(h) for h in hosts)
    top_html = "".join(
        f"<li><strong>{_e(f.titre)}</strong> "
        f"(<span style='color:{GRAV_COLOR.get(f.gravite,'#333')}'>{_e(f.gravite.value)}</span>"
        f" — {_e(f.hote)})</li>"
        for f in top
    ) or "<li>Aucun finding — belle hygiène visible, ou découverte partielle.</li>"

    err_block = ""
    op_ev = (result.timings or {}).get("events") or []
    if (result.timings or {}).get("operator_interrupt") or op_ev:
        lines = []
        for ev in op_ev:
            if isinstance(ev, dict):
                lines.append(
                    f"<li><strong>{_e(ev.get('at',''))}</strong> — "
                    f"phase <code>{_e(ev.get('phase',''))}</code> : {_e(ev.get('note',''))}</li>"
                )
        op_banner = (
            "<section class='errors' style='border-color:#9B1B1B'>"
            "<h2>Arrêt opérateur</h2>"
            "<p>Une ou plusieurs phases ont été stoppées manuellement ; "
            "le checkup a continué et ce rapport reste valable (partiel).</p>"
            f"<ul>{''.join(lines) or '<li>Interruption enregistrée</li>'}</ul>"
            "</section>"
        )
    else:
        op_banner = ""

    audit_findings = []
    for h in result.hosts:
        for f in h.findings:
            if (f.id or "").startswith("audit-"):
                audit_findings.append((h, f))
    if audit_findings or (result.timings or {}).get("timings", {}).get("audit") or (result.mission.extras or {}).get("audit_done"):
        def _audit_li(h, f) -> str:
            rem = ""
            steps = getattr(f, "remede_etapes", None) or []
            if steps:
                rem = " <em>Remède :</em> " + _e(str(steps[0])[:140])
            return (
                f"<li><strong>{_e(f.titre)}</strong> "
                f"(<code>{_e(h.ip)}</code>) — {_e((f.preuve or '')[:160])}"
                f"{rem}</li>"
            )
        items = "".join(_audit_li(h, f) for h, f in audit_findings) or (
            "<li>Passage audit exécuté — pas de finding audit-* supplémentaire.</li>"
        )
        lvl = (result.mission.extras or {}).get("audit_level") or "standard"
        audit_block = (
            "<section class='errors' style='border-color:#C62828' id='audit-warning'>"
            "<h2>Audit warning — Failles d'exposition constatées et remèdes associés</h2>"
            f"<p>Second passage défensif (<strong>niveau {lvl}</strong>) sur les hôtes "
            "flagués du run classique : surface admin, TLS/HTTP/SMB, datastores, "
            "accès distants, etc. Chaque finding ci-dessous décrit l'exposition "
            "<em>et</em> les étapes concrètes pour la contrer. "
            "Pas d'exploit, pas de brute-force, pas de scripts vuln.</p>"
            f"<ul>{items}</ul></section>"
        )
    else:
        audit_block = ""

    err_block = ""
    if result.errors:
        visibles = [
            e
            for e in result.errors
            if "json illisible" not in str(e).lower()
            and "pas d'invention" not in str(e).lower()
            and "catalogue conserv" not in str(e).lower()
            and "sortie illisible" not in str(e).lower()
        ]
        if visibles:
            items = "".join(f"<li>{_e(e)}</li>" for e in visibles)
            err_block = (
                "<section class='errors'><h2>Incidents techniques (non bloquants)</h2>"
                f"<ul>{items}</ul></section>"
            )

    date_fr = result.finished or datetime.now().strftime("%Y-%m-%d %H:%M")
    carte = _carte_parc(hosts)
    recap = _section_recap(result)
    journal = _section_journal(result)
    direction = _section_direction(result)
    usages = _section_usages(result)
    restr = _section_restructure(result)
    site = _section_website(result)
    rgpd = _section_rgpd(result)
    mach = _section_machines(result)
    pistes = _section_pistes(result)
    programme = _section_programme(result)
    calibrage = _section_calibrage(result)
    regard = _section_regard(result)
    hygiene = _section_hygiene(result)
    identites = _section_identites(result)
    dossier = _section_dossier(result)
    autorisation = _section_autorisation(result)
    piliers = _section_piliers(result)
    correlation = _section_correlation(result)
    cve_corr_h = _section_cve(result)
    lynis_h = _section_lynis(result)
    greenbone_h = _section_greenbone(result)
    trivy_h = _section_trivy(result)
    pack_auth_h = _section_pack_autorisations(result)
    passi_h = _section_passi(result)
    passi_alignment_h = _section_passi_alignment(result)
    passi_nav = ""
    if passi_h:
        passi_nav += '  <a href="#passi">PASSI</a>\n'
    if passi_alignment_h:
        passi_nav += '  <a href="#passi-assessment">Dossier PASSI</a>\n'
    osi_h = _section_osi(result)
    cerveau_h = _section_adaptatif(result)
    orchestre_h = _section_orchestre(result)
    try:
        from guardia.report.lexique import html_lexique

        lexique = html_lexique(result)
    except Exception:  # noqa: BLE001
        lexique = ""
    red = (getattr(result, "equipe", "blue") or "blue") == "red"
    po = getattr(result, "poste_operateur", None) or {}
    poste_h = ""
    if po.get("retire") and po.get("resume"):
        poste_h = (
            "<p class='meta'>Poste opérateur hors parc : "
            f"{_e(po.get('resume'))} — {_e(po.get('motif') or 'hors périmètre client')}</p>"
        )
    accent = "#9B1B1B" if red else "#1E4F8A"
    hdr = "linear-gradient(135deg,#2a1010,#4a1818)" if red else "linear-gradient(135deg,#122033,#1a3048)"
    titre_h = "Guardia — regard attaquant" if red else "Guardia — évaluation défensive"
    kicker_c = accent
    legal_extra = (
        " Regard attaquant : lecture seule. Pas d'intrusion, pas d'exploit."
        if red
        else ""
    )
    from guardia.core.autorisation import etat as etat_auth, phrase_signature
    from guardia.core.identite import user_agent as _ua

    auth = getattr(result, "autorisation", None) or {}
    if not auth.get("etat"):
        auth = etat_auth(m)
    phrase_sig = phrase_signature(auth)
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>Guardia — {_e(m.client)}</title>
<style>
:root {{ --bg:#0f1419; --card:#1a222c; --fg:#e8eef4; --muted:#9aa7b5; --accent:{accent}; }}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family: "DejaVu Sans", "Liberation Sans", sans-serif; background:var(--bg); color:var(--fg); line-height:1.45; }}
header {{ padding:2rem 1.5rem; background:{hdr}; border-bottom:1px solid #243447; }}
header h1 {{ margin:0 0 .3rem; font-size:1.6rem; }}
header p {{ margin:.2rem 0; color:var(--muted); }}
main {{ max-width:960px; margin:0 auto; padding:1.5rem; }}
.score {{ display:flex; flex-wrap:wrap; gap:.6rem; margin:1rem 0 1.5rem; }}
.pill {{ padding:.45rem .8rem; border-radius:999px; background:#243040; font-size:.9rem; }}
.card {{ background:var(--card); border:1px solid #2a3848; border-radius:12px; padding:1.1rem 1.2rem; margin:1rem 0; }}
.card h3 {{ margin:0 0 .4rem; }}
.meta {{ color:var(--muted); font-size:.9rem; }}
finding {{ display:block; border-left:4px solid #666; padding:.6rem .8rem; margin:.7rem 0; background:#141b24; border-radius:0 8px 8px 0; }}
finding h4 {{ margin:0 0 .35rem; }}
finding ol {{ margin:.3rem 0 .3rem 1.1rem; }}
.badge {{ display:inline-block; padding:.15rem .5rem; border-radius:6px; font-size:.75rem; font-weight:600; color:#fff; }}
footer {{ text-align:center; color:var(--muted); padding:2rem 1rem; font-size:.85rem; }}
.errors {{ background:#2a1818; border:1px solid #5a3030; border-radius:10px; padding:1rem; }}
.parc-group {{ margin:.8rem 0; }}
.parc-group ul {{ margin:.3rem 0 .3rem 1.1rem; }}
.parc-group h4 {{ margin:.4rem 0; }}
a {{ color:var(--accent); }}
.legal-strip {{ background:#3a1010; color:#f3ebe3; padding:.75rem 1.5rem; font-size:.85rem; line-height:1.4; }}
.recap {{ background:#efe6d8; color:#1a1613; border-radius:12px; padding:1.4rem 1.5rem; margin:0 0 1.6rem; }}
.recap h2 {{ color:{kicker_c}; margin:.2rem 0 .6rem; font-size:1.45rem; }}
.recap h3 {{ margin:1.1rem 0 .4rem; font-size:1.05rem; }}
.recap .meta {{ color:#5a4e46; }}
.recap .lead {{ font-size:1.02rem; }}
.recap .kicker {{ letter-spacing:.14em; text-transform:uppercase; font-size:.72rem; color:{kicker_c}; margin:0; }}
.recap .pill {{ background:#e2d4c4; color:#1a1613; }}
.recap ol.risques li {{ margin:.35rem 0; }}
.sommaire {{ font-size:.9rem; color:var(--muted); }}
.sommaire a {{ margin-right:.8rem; }}
@media print {{
  .legal-strip, header {{ -webkit-print-color-adjust:exact; print-color-adjust:exact; }}
  .recap {{ page-break-after: always; -webkit-print-color-adjust:exact; print-color-adjust:exact; }}
}}
</style>
</head>
<body>
<div class="legal-strip">Art. 323-1 du Code pénal — accès à un système : uniquement avec mandat écrit, daté, périmétré.
Guardia n'opère qu'en lecture, sur le CIDR signé. Pas d'exploit. RGPD art. 32 : tester les mesures, pas délivrer un certificat.
Echoes of Hackers — association & ESS.{legal_extra}</div>
<header>
  <h1>{titre_h}</h1>
  <p><strong>{_e(m.client)}</strong> · destinataire : {_e(m.personne_commune)}</p>
  <p>Profil {_e(m.profil_moteur)} · profondeur {_e(m.profondeur)} · CIDR {_e(result.cidr or m.cidr or "?")}</p>
  <p>Passarelle {_e(result.gateway or "—")} · interface {_e(result.iface or "—")} · {_e(date_fr)}</p>
  {poste_h}
  <p style="margin-top:.8rem">{_e(m.signature)} — association & entreprise de l'ESS · opérateur identifié · évaluation défensive, sans exploit, sans certificat</p>
</header>
<main>
{recap}

<nav class="sommaire card">
  <strong>Sommaire technique</strong> —
  <a href="#grandes-lignes">Grandes lignes</a>
  <a href="#autorisation">Autorisation</a>
  <a href="#piliers">Modules</a>
  <a href="#orchestre">Orchestre</a>
  <a href="#direction">Direction</a>
  <a href="#carte">Carte</a>
  <a href="#correlation">Corrélation</a>
  <a href="#cve-correlation">CVE (lecture)</a>
  <a href="#journal">Journal</a>
  <a href="#pistes">Pistes</a>
  <a href="#calibrage">Calibrage</a>
  <a href="#hygiene">Hygiène</a>
  <a href="#identites">Identités</a>
  <a href="#regard">Regard</a>
  <a href="#dossier">Dossier</a>
  <a href="#pack-autorisations">Autorisations</a>
{passi_nav}  <a href="#couverture-osi">Couverture OSI</a>
  <a href="#cerveau">Cerveau</a>
  <a href="#programme">Outils</a>
  <a href="#lexique">Lexique</a>
</nav>

{autorisation}
{piliers}
{orchestre_h}
{direction}

<section class="card" id="carte">
  <h2>Carte du parc</h2>
  {carte}
</section>

{usages}
{restr}
{hygiene}
{calibrage}
{identites}
{regard}
{dossier}
{pack_auth_h}
{passi_h}
{passi_alignment_h}
{osi_h}
{cerveau_h}
{site}
{rgpd}
{mach}
{pistes}
{programme}
{correlation}
{cve_corr_h}
{lynis_h}
{greenbone_h}
{trivy_h}

<section>
  <h2>Fiches par appareil — détail chirurgical</h2>
  <p class="meta">Observation, commande, interprétation, preuve, <strong>comment faire</strong>. Pour le référent technique — et pour qui doit corriger.</p>
  {cards or "<p class='meta'>Aucun hôte découvert.</p>"}
</section>

{journal}

{err_block}

<section class="card">
  <h3>Timings</h3>
  <p class="meta">{_e((result.timings or {}).get("elapsed_sec", "?"))}s écoulées
    / plafond {_e((result.timings or {}).get("limit_sec", 7200))}s
    · phases : {_e((result.timings or {}).get("timings", {}))}</p>
  <p class="meta">Tronqué : {_e((result.timings or {}).get("truncated_phases") or "—")}
    · Sauté : {_e((result.timings or {}).get("skipped_phases") or "—")}
    · Arrêt opérateur : {_e((result.timings or {}).get("operator_truncated_phases") or "—")}</p>
  {op_banner}
  {audit_block}
</section>

<section class="card">
  <h3>Périmètre de cette visite</h3>
  <p class="meta">Inventaire et exposition visibles le jour J, sur le CIDR (et l'URL) du mandat.
  Chaque finding porte une observation, une commande de lecture, une interprétation et un <strong>comment faire</strong>.
  Les configurations changent : ce papier date d'aujourd'hui.
  {_e(phrase_sig)} Conservé deux ans.</p>
</section>

<section class="card" id="signatures-rapport">
  <h2>Signatures</h2>
  <p>{_e(phrase_sig)}</p>
  <p class="meta">Opérateur identifié. Trafic nominatif.
  User-Agent HTTP : <code>{_e(_ua())}</code>
  · nmap sans decoy, sans IP usurpée.</p>
  <div class="score">
    <span class="pill">Habilité · {_e(m.personne_commune or m.client)}</span>
    <span class="pill">Opérateur ÉOH · {_e(m.operateur_nom or m.signature)}</span>
  </div>
  <p class="meta">RNA W882005217 · SIREN 933496234 · NAF 8020Z · ESS.
  Conservation deux ans sur le poste opérateur.</p>
</section>
{lexique}
</main>
<footer>
  Guardia — Platon-Y / Echoes of Hackers<br/>
  Association & entreprise de l'ESS · opérateur identifié · évaluation défensive non intrusive
</footer>
</body>
</html>
"""


def _host_card(host: Host) -> str:
    label, color = POSTURE_LABEL.get(host.posture, ("?", "#666"))
    kind = KIND_FR.get(host.kind, host.kind)
    ports = ", ".join(
        f"{p.get('port')}/{p.get('name') or p.get('proto') or 'tcp'}"
        for p in host.ports
    ) or "aucun port ouvert détecté (top ports)"
    findings_html = "".join(_finding_block(f) for f in host.findings) or (
        "<p class='meta'>Rien de notable sur les contrôles défensifs.</p>"
    )
    err = ""
    if host.errors:
        err = "<p class='meta'>⚠ " + " · ".join(_e(e) for e in host.errors) + "</p>"
    return f"""
<article class="card">
  <h3>{_e(host.hostname or host.ip)}
    <span class="badge" style="background:{color}">{_e(label)}</span>
  </h3>
  <p class="meta">{_e(kind)} · IP {_e(host.ip)}
    · MAC {_e(host.mac or "—")} · {_e(host.vendor or "")}</p>
  <p class="meta">Ports : {_e(ports)}</p>
  {err}
  {findings_html}
</article>
"""


def _finding_block(f) -> str:
    col = GRAV_COLOR.get(f.gravite, "#666")
    steps = "".join(f"<li>{_e(s)}</li>" for s in f.remede_etapes)
    ind = ""
    if str(getattr(f, "id", "")).startswith("indice") or str(getattr(f, "id", "")).startswith("net-pas-detection"):
        ind = ' <span class="badge" style="background:#3a6ea5">indice / limite</span>'
    try:
        from guardia.engines.preuve_repro import template_client_finding

        tpl = template_client_finding(f, vouvoiement=True)
    except Exception:  # noqa: BLE001
        tpl = {
            "observation": getattr(f, "observation", "") or f.titre or "",
            "preuve_lecture": getattr(f, "commande", "")
            or getattr(f, "preuve_repro", "")
            or getattr(f, "preuve", "")
            or "",
            "impact": f"Ceci permettrait de {(f.pourquoi_nuit or 'une exposition non maîtrisée').strip()}.",
            "protection": "Pour vous protéger, il faudrait appliquer les remèdes indiqués.",
            "note": (
                "Aucune exploitation n'a été exécutée ; démonstration par sollicitation lecture seule."
            ),
        }
    obs = tpl.get("observation") or ""
    cmd = tpl.get("preuve_lecture") or ""
    inter = getattr(f, "interpretation", "") or ""
    statut = getattr(f, "statut_auditeur", "") or "a_investiguer"
    chaine = (
        "<p class='meta'><strong>Observation / preuve lecture :</strong> "
        f"{_e(obs)}</p>"
        + (
            "<p class='meta'><strong>Trace rejouable (knock — voir la réponse, ne pas entrer) :</strong> <code>"
            + _e(cmd)
            + "</code></p>"
            if cmd
            else ""
        )
        + f"<p><strong>{_e(tpl.get('impact') or '')}</strong></p>"
        + f"<p><strong>{_e(tpl.get('protection') or '')}</strong></p>"
        + (
            "<p><strong>Interprétation Guardia :</strong> "
            + _e(inter)
            + "</p>"
            if inter
            else ""
        )
        + f"<p class='meta'>{_e(tpl.get('note') or '')}</p>"
    )
    return f"""
<finding style="border-left-color:{col}">
  <h4><span class="badge" style="background:{col}">{_e(f.gravite.value)}</span>{ind}
    <span class="badge" style="background:#3a6ea5">{_e(statut)}</span>
    {_e(f.titre)}</h4>
  {chaine}
  <p><strong>Pourquoi ça nuit :</strong> {_e(f.pourquoi_nuit)}</p>
  <p><strong>Preuve :</strong> <code>{_e(f.preuve)}</code></p>
  {("<p class='meta'><strong>Démonstration d\'exposition (lecture) — rejouer pendant la plage d\'audit :</strong> <code>" + _e(f.preuve_repro) + "</code></p>") if getattr(f, "preuve_repro", "") else ""}
  <p><strong>Comment faire :</strong></p>
  <ol>{steps}</ol>
  <p class="meta">Qui : {_e(f.qui_peut)} · Priorité : {_e(_prio_fr(f.priorite))} · Gravité : {_e(f.gravite.value)}</p>
</finding>
"""
