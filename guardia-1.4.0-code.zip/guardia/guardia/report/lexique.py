"""Lexique des abréviations — fin de chaque rapport.

Chaque sigle utilisé dans Guardia a une définition en français.
Le rapport n'assume pas que le destinataire lit l'anglais technique.
"""
from __future__ import annotations

from typing import Any

# ordre stable, métier d'abord
ENTREES: tuple[tuple[str, str], ...] = (
    ("ANSSI", "Agence nationale de la sécurité des systèmes d'information (France). Guardia s'inspire de ses guides publics ; elle n'est pas un prestataire PASSI."),
    ("PASSI", "Prestataire d'audit de la sécurité des systèmes d'information, qualifié ANSSI. Guardia n'en est pas un, et ne délivre pas de certificat PASSI."),
    ("CNIL", "Commission nationale de l'informatique et des libertés. Autorité RGPD en France. Guardia ne délivre pas de certificat CNIL."),
    ("RGPD", "Règlement général sur la protection des données. Le volet Guardia est un signalement observé / déclaré, pas une certification."),
    ("DPO", "Délégué à la protection des données (data protection officer)."),
    ("NIS2", "Directive européenne sur la cybersécurité des entités essentielles et importantes. Guardia signale, elle ne classe pas l'organisme."),
    ("ESS", "Économie sociale et solidaire. Echoes of Hackers est association et entreprise de l'ESS."),
    ("ÉOH", "Echoes of Hackers — association et entreprise, opérateur de Guardia."),
    ("NDA", "Accord de confidentialité (non-disclosure agreement)."),
    ("ROE", "Règles d'engagement (rules of engagement) : ce qui est autorisé, jusqu'où, jusqu'à quand."),
    ("CIDR", "Plage d'adresses IP du périmètre (ex. 192.168.1.0/24)."),
    ("LAN", "Réseau local (local area network) — le parc visité."),
    ("IP", "Adresse d'un appareil sur le réseau."),
    ("TLS", "Transport Layer Security — chiffrement des échanges (successeur de SSL)."),
    ("SSL", "Ancien nom du chiffrement web. On dit TLS aujourd'hui."),
    ("HTTPS", "HTTP chiffré par TLS. Port usuel 443."),
    ("HTTP", "Protocole du web, non chiffré. Port usuel 80."),
    ("SMB", "Partage de fichiers Windows / Samba. Ports 139 / 445."),
    ("NFS", "Partage de fichiers Unix. Ports 111 / 2049."),
    ("RDP", "Bureau à distance Windows (Remote Desktop Protocol). Port 3389."),
    ("NLA", "Network Level Authentication — authentification avant session RDP."),
    ("SSH", "Administration distante chiffrée. Port 22."),
    ("LDAP", "Annuaire (Lightweight Directory Access Protocol). Port 389 / 636."),
    ("Kerberos", "Protocole d'authentification de parc (souvent port 88)."),
    ("SNMP", "Supervision d'équipements. Une communauté « public » trop ouverte est une porte."),
    ("DNS", "Résolution de noms. Un transfert de zone ouvert divulgue le plan d'adressage."),
    ("VLAN", "Réseau local virtuel — séparer élèves / métier / admin."),
    ("SSID", "Nom d'un réseau Wi-Fi."),
    ("WAF", "Pare-feu applicatif web (web application firewall)."),
    ("MFA", "Authentification multifactorielle (mot de passe + un second facteur)."),
    ("CVE", "Identifiant public d'une vulnérabilité (Common Vulnerabilities and Exposures). Guardia ne pose une CVE que si une bannière locale le justifie."),
    ("CWE", "Famille de faiblesse (Common Weakness Enumeration), ex. chiffrement trop faible."),
    ("NSE", "Nmap Scripting Engine — scripts de lecture joints à nmap."),
    ("OT", "Operational technology — automates, atelier. Guardia lit, n'écrit pas sur l'automate."),
    ("PLC", "Automate programmable (programmable logic controller)."),
    ("GVM", "Greenbone Vulnerability Management (OpenVAS) — moteur de vulnérabilités. Optionnel, sur invitation."),
    ("OpenVAS", "Scanner de vulnérabilités (cœur de Greenbone). Guardia orchestre la lecture GMP (version, feeds). Un scan Full and Fast reste GSA, hors budget visite."),
    ("Lynis", "Audit de durcissement d'une machine Linux, en local, avec autorisation. Pas un scan réseau."),
    ("Trivy", "Audit de conteneurs, systèmes de fichiers et dépendances. Local, pas un scan LAN."),
    ("ATT&CK", "Catalogue MITRE de techniques d'attaque. Guardia n'en cite que ce qui est observé en lecture, jamais une exécution."),
    ("LLM", "Modèle de langage local. Dans Guardia : reformule les constats déjà établis par le moteur."),
)


def build_lexique(texte: str = "") -> list[dict[str, str]]:
    """Entrées dont le sigle apparaît dans le rapport, plus un noyau toujours présent."""
    blob = (texte or "").upper()
    noyau = {"ANSSI", "PASSI", "RGPD", "CIDR", "TLS", "LAN", "ÉOH", "NDA"}
    out: list[dict[str, str]] = []
    for sigle, defn in ENTREES:
        key = sigle.upper().replace("É", "E")
        if sigle in noyau or sigle.upper() in blob or key in blob or sigle in (texte or ""):
            out.append({"sigle": sigle, "definition": defn})
    # toujours le noyau même si le texte est court
    have = {x["sigle"] for x in out}
    for sigle, defn in ENTREES:
        if sigle in noyau and sigle not in have:
            out.append({"sigle": sigle, "definition": defn})
    return out


def html_lexique(result: Any = None, extra: str = "") -> str:
    from html import escape as _e

    blob = extra
    if result is not None:
        blob += " " + str(getattr(result, "cidr", "") or "")
        rec = getattr(result, "recap", None) or {}
        blob += " " + str(rec.get("these") or "")
        for h in getattr(result, "hosts", None) or []:
            for f in getattr(h, "findings", None) or []:
                blob += " " + str(getattr(f, "titre", "") or "")
                blob += " " + str(getattr(f, "preuve", "") or "")
    items = build_lexique(blob)
    lis = "".join(
        f"<li><strong>{_e(x['sigle'])}</strong> — {_e(x['definition'])}</li>"
        for x in items
    )
    return (
        "<section class='card' id='lexique'>"
        "<h2>Lexique</h2>"
        "<p class='meta'>Chaque abréviation utilisée dans ce rapport.</p>"
        f"<ul class='meta'>{lis}</ul>"
        "</section>"
    )
