"""Page « pour la direction » — langage métier, pas une liste de ports.

Petite PME, grande structure, école : la question n'est pas la même,
le checkup reste le même moteur.
"""
from __future__ import annotations

from typing import Any

from guardia.core.models import CheckupResult, Gravite, Mission, Posture


def _taille(mission: Mission, n_hosts: int) -> str:
    t = str((mission.extras or {}).get("taille_parc") or "").lower()
    if t in ("l", "large", "xl", "centaines", "gros", "grande") or n_hosts >= 40:
        return "grande"
    if t in ("m", "moyenne") or n_hosts >= 12:
        return "moyenne"
    return "petite"


def build_direction_brief(result: CheckupResult) -> dict[str, Any]:
    m = result.mission
    hosts = result.hosts or []
    n = len(hosts)
    taille = _taille(m, n)
    profil = (m.profil_moteur or "").lower()
    typ = (m.type_structure or "").lower()
    ecole = profil == "ecole" or typ == "ecole"
    usages = result.usages or {}
    n_serv = int((usages.get("compteurs") or {}).get("serveurs") or 0)
    if not n_serv:
        n_serv = sum(1 for h in hosts if (h.kind or "") in ("serveur", "nas"))

    findings = [f for h in hosts for f in h.findings]
    hauts = [
        f for f in findings
        if f.gravite in (Gravite.CRITIQUE, Gravite.HAUTE)
    ]
    from guardia.report.recap import compter_gravites

    gv = compter_gravites(result)
    n_crit = gv["critique"]
    n_eleve = gv["eleve"]
    n_moyen = gv["moyen"]
    n_info = gv["info"]
    n_risque_hotes = sum(1 for h in hosts if h.posture == Posture.RISQUE)

    if ecole:
        these = (
            "La question n'est pas seulement de passer les PC en revue. "
            "C'est de savoir ce qu'une session élève ou enseignant peut atteindre "
            "si les droits ne sont pas tenus — et quelle machine dessert les autres. "
            "Un trou sur ce serveur-là n'est pas « une machine de plus »."
        )
    elif taille == "grande":
        these = (
            "Sur un parc de cette taille, l'inventaire seul ne tranche pas. "
            "Il faut la desserte (annuaire, fichiers, impression), la surface latérale, "
            "et une synthèse que la direction peut arbitrer. "
            "Ce checkup éclaire l'exposition visible ; il ne remplace pas un audit PASSI."
        )
    else:
        these = (
            "En petite structure, une machine qui dessert les autres, un partage trop "
            "ouvert ou un RDP à plat suffisent à arrêter l'activité. "
            "On priorise ça, pas une liste infinie de ports."
        )

    top = []
    for f in hauts[:5]:
        top.append(
            {
                "titre": f.titre,
                "gravite": f.gravite.value,
                "hote": f.hote,
            }
        )

    next_steps = [
        "Les trois actions de la semaine : dans les grandes lignes, en tête de rapport.",
        "Le référent IT (ou le prestataire que vous choisissez) applique le « comment faire » de chaque fiche.",
        "ÉOH reste disponible pour une visite de reprise si vous le demandez — une fois suffit souvent.",
    ]
    if ecole:
        next_steps.append("Priorité : serveur de parc et sessions salles, avant le reste.")

    return {
        "audience": "direction",
        "taille": taille,
        "these": these,
        "chiffres": {
            "appareils": n,
            "critique": n_crit,
            "eleve": n_eleve,
            "moyen": n_moyen,
            "info": n_info,
            "risque": n_risque_hotes,
            "hauts": len(hauts),
            "findings_hauts": len(hauts),
            "desserte": n_serv,
            "serveurs_desserte": n_serv,
        },
        "top": top,
        "next_steps": next_steps,
        "ecole": ecole,
        "ess": (
            "Echoes of Hackers — association et entreprise de l'ESS. "
            "Mandat + NDA. Données locales opérateur. Rapport signé."
        ),
    }

