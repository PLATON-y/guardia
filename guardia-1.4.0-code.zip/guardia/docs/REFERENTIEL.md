# Référentiel juridique Guardia / Echoes of Hackers

Pas un avis d'avocat. Relu avec le cadre de l'association.
Le PDF ne transforme pas une opération illégale en opération légale.
Ce qui protège : autorisation du titulaire + périmètre + durée + opérateur
identifié + règles d'engagement + exclusions + traçabilité + arrêt +
données + rapport + conservation.

## Vocabulaire

Guardia — plateforme d'audit et d'aide à la remédiation en cybersécurité.

- **Blue team** : analyse défensive, lecture seule.
- **Red team (regard)** : mêmes faits, chemins d'attaque *vus*. Pas d'intrusion.
- **Red team (test, niveaux 2-3)** : documents prévus. Le moteur **refuse** de les exécuter. Pas avant.

Deux parcs seulement :

- **Personnel** — particulier, foyer. À quelques appareils près, tous identiques.
- **Professionnel** — tout le reste (entreprise, association, collectivité, école, caserne, atelier…). Le type exact est **dans les documents** de la mission.

Pas de « lab » côté client. La machine Kali est celle de l'opérateur ÉOH.

Pas un audit PASSI. Pas un certificat ANSSI, CNIL, NIS2.

## Textes

- Code pénal art. 323-1, 323-2, 323-3. Art. **323-3-1** (motif légitime, recherche / sécurité informatique).
- RGPD art. 32 (tester) et art. 28 (sous-traitance si données personnelles).
- Recommandations publiques ANSSI : hygiène TPE/PME, essentiels mobiles, PA-022 administration, PA-054 nomadisme, fiche d'autorisation des tests d'intrusion (PASSI — on s'en inspire, on ne s'en réclame pas).
- NIS2 : obligations à venir pour une partie des organismes. Guardia **signale**, il ne certifie pas.

## Huit pièces

Générées : `python3 -m guardia dossier -m MISSION --generer`

1. Convention d'audit
2. Autorisation expresse de test (cibles, exclusions, dates, IP de provenance)
3. Rules of Engagement (niveaux 0 à 3, interdits)
4. Autorisation spécifique Red team (case expresse)
5. Annexe RGPD / sous-traitance
6. Charte de confidentialité opérateur
7. Procédure d'arrêt d'urgence
8. Notice rapport + conservation (deux ans) + hashes SHA-256

Personnel : mandat foyer + NDA existants tiennent lieu des pièces 1 et 2.
Professionnel : la liasse, plus le type de structure **écrit** sur les pièces.

## Verrou Red

```
SI mandat ET (personnel OU dossier hors pièce 04)
ET mot de passe opérateur
ALORS regard (niveau 0) = ouvert
SINON regard = fermé

SI niveau ≥ 2
ALORS le moteur refuse — documents seulement
```

Pas de bouton « passer outre ».

## LLM

Local, sur la machine opérateur. Les données ne partent pas chez un tiers.
API externe : Red interdit tant que l'annexe de traitement n'est pas validée.

## Rapport

Constat / preuve / risque / impact / recommandation / priorité.
Correction : réalisée, en cours, planifiée, non corrigée, risque accepté.
Assistance ÉOH selon moyens, pas une obligation de remédier.

Phrase fixe : voir `PASSI` dans `guardia/core/dossier.py`.
