# Alignement PASSI v2.2

Guardia intègre une matrice interne d'alignement avec le référentiel PASSI v2.2 de l'ANSSI et la trame d'évaluation v1.2.

La matrice couvre les cinq activités publiquement décrites par l'ANSSI : audit organisationnel et physique, audit d'architecture, audit de configuration, audit de code source et tests d'intrusion. Le site de l'ANSSI précise aussi que PASSI qualifie des services et couvre des exigences relatives au prestataire, à son personnel et au déroulement des audits.

Guardia ne délivre pas de qualification PASSI et ses identifiants `G-PASSI-*` sont des identifiants internes au logiciel. La matrice mesure la capacité opérationnelle de Guardia sur une mission donnée : ce qui est couvert, partiel, soumis à une validation humaine, non applicable ou non couvert.

## Ce que produit la matrice

- couverture du cadrage et des autorisations ;
- couverture de chacune des cinq activités ;
- état des preuves et de la traçabilité ;
- points nécessitant une validation humaine ;
- limites et éléments non couverts ;
- score de couverture calculé depuis l'état réel de la mission.

## Principe

Une absence de preuve n'est pas une conformité. Une capacité préparée n'est pas une qualification. Un test intrusif reste soumis au périmètre, à la fiche d'autorisation et aux règles d'engagement.

Source officielle : https://cyber.gouv.fr/offre-de-service/solutions-certifiees-et-qualifiees/comprendre-levaluation-de-securite/qualification-de-produit-et-services/referentiels-qualification/
