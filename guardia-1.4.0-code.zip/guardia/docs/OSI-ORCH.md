# Couverture OSI et orchestrateur PASSI / CNIL

Guardia 1.2.8 étiquette les observations par couches OSI (L1–L7) et, lorsque le mandat est validé et que `passi` / `rgpd` sont demandés, pousse des **directives** ordonnées pour enrichir le dossier d’appui PASSI et le signalement RGPD.

## Ce que ce n’est pas

- **Pas** une qualification ANSSI / PASSI.
- **Pas** un certificat de conformité CNIL / RGPD.
- **Pas** d’exploit, **pas** de payload, **pas** de Metasploit automatique.
- Pendant la plage d’audit (« temps de charge »), Guardia **démontre** qu’une exposition est réelle et qu’un scénario est *réalisable* en **lecture seule** (commande rejouable). Ensuite : remèdes / restructuration — jamais une procédure d’attaque.

## Couverture OSI

Module : `guardia/engines/osi_map.py`.

| Couche | Ce que Guardia peut voir (défensif) |
|--------|-------------------------------------|
| L1 | Interface locale (`netinfo`) |
| L2 | MAC / vendor / ARP / NetBIOS / mDNS / AP |
| L3 | CIDR, passerelle, multi-gateway hints |
| L4 | Ports / transport (`services`) |
| L5–L7 | Bannières, TLS, HTTP, SMB (noms), OT lecture |

Les hôtes et événements cerveau portent `osi_layers`. Le rapport HTML / le JSON cerveau exposent **Couverture OSI** (touchées / lacunes).

## Directives PASSI / CNIL

Module : `guardia/cerveau/directives_passi_cnil.py` (appelé depuis `adaptatif.raisonner`).

Chaque directive : `id`, `layer`, `passi_activity?`, `cnil_theme?`, `outil`, `precondition`, `status` (`proposed|opened|blocked|done`), `nature_action` :

- `démonstration d'exposition (lecture)` — ouvert pendant la plage d’audit ;
- `exploitation (bloquée — avenant + validation humaine)` — jamais auto.

Outils réutilisés : `web_audit`, `rgpd_signal`, `passi_*`, `hygiene`, `audit_pass`, `machines` (OT lecture).

## Lancer

```bash
# Prévisualisation cerveau (zéro scan si pas d’hôtes) — OSI + directives
python3 -m guardia cerveau -m missions/exemple-passi-complet.yaml

# Run avec dossier PASSI + signalement RGPD (mandat requis ou --yes en labo)
python3 -m guardia run -m missions/exemple-passi-complet.yaml --passi --rgpd --yes
# ou full options
python3 -m guardia run -m missions/exemple-full.yaml --yes
```

URL de démo préremplie dans les missions exemples : `https://pctamalou.fr`.

## Preuve / repro

`preuve_repro` attache à chaque finding d'exposition une commande **lecture seule** rejouable (knock : voir la réponse, ne pas entrer). Template client (vouvoiement) :

- observation / preuve lecture ;
- « Ceci permettrait de … » (impact hypothèse, pas d'étapes d'exploit) ;
- « Pour vous protéger, il faudrait … » (remèdes) ;
- note : aucune exploitation n'a été exécutée ; démonstration par sollicitation lecture seule.

Helpers : `template_client_finding` / `phrase_impact` / `phrase_protection` dans `preuve_repro.py`.
La reine (`SYSTEM_PROMPT` / `annexe_technicien`) reprend le même vocabulaire knock-not-enter.

## Catalogue (candidats déjà prévus)

Le programme / policy listent déjà notamment **nmap** (découverte, -sV, scripts SMB/TLS/HTTP lecture) et **nuclei** (tags info/tech/tls, derrière policy URL). L’orchestrateur ne les invente pas : il les ouvre si préconditions et budget le permettent, ou signale l’absence d’outil sans planter.


## Groq optionnel (directives + fiche)

```bash
export GROQ_API_KEY=...          # uniquement via l'environnement — jamais dans git/yaml
# ou : mkdir -p ~/.config/guardia && printf 'GROQ_API_KEY=...\n' > ./queen_decide
# (les lanceurs sourcent ce fichier ; le code Python ne le lit pas directement)
export GROQ_MODEL=qwen/qwen3-32b # ou le modèle que vous choisissez
export GROQ_ORG=pctamalou

python3 -m guardia cerveau -m missions/exemple-passi-complet.yaml --llm-groq
# YAML : llm_groq: true
```

Module : `guardia/engines/llm_groq_directives.py`.  
Produit : directives + **fiche client** (vouvoiement) + **annexe technicien** (hypothèse de réalisabilité, indices techniques, risque résiduel) + procédure de **confirmation lecture**. Jamais « comment exploiter » / PoC / payload / Metasploit.  
Marquage obligatoire : « proposition opérateur / à valider ».  
Si la clé a été exposée (chat, ticket…) : **faites-la tourner** ; Guardia ne stocke aucune clé.
Le GGUF local reste le polish principal (`--llm`).

## Vision large L1–L7 (full / audit-full) — 1.2.8

Helpers : `surfaces_non_protegees`, `vision_osi_full`, `next_layer_propositions_full`
dans `guardia/engines/osi_map.py`.

Quand `--full` ou `audit_full` : Guardia vise une **lecture maximale** sur les
surfaces exposées (clairtext, admin, TLS faible, SMB, OT, datastores visibles),
corrélée au catalogue CVE local. Les lacunes OSI restent listées.

Ce n'est **pas** une authentification forcée, **pas** une entrée système.
