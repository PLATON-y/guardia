# Outils de la visite — lecture seule

Guardia lance les outils Kali **passifs** installés, selon les portes
vues par nmap. Aide : `python3 -m guardia outil list`.

| Porte / cible | Outil | Aide |
|---|---|---|
| CIDR | nmap -sV | toujours au checkup |
| LAN | arp-scan, nbtscan, avahi-browse | calibré une fois |
| 445 | smbclient -L, smb-enum-shares, smb-security-mode | noms de partages |
| 389 | ldapsearch rootDSE | pas de dump |
| 161 | snmpget public | communauté public |
| 22 | ssh-audit | algorithmes |
| 3389 | rdp-enum-encryption | NLA |
| 21 / 25 | ftp-anon, smtp-open-relay | portes ouvertes |
| 111 / 2049 | rpcinfo, showmount | NFS |
| 443 / HTTP | testssl, sslscan, whatweb, nuclei info, nikto Tuning 1, wpscan passif | URL du mandat |

Inventaire de la machine : `python3 -m guardia inventaire`

```
python3 -m guardia outil list
python3 -m guardia run -m missions/exemple-pme.yaml --yes
```
