# Porte Red Team (Guardia) — gate UI & attestation

## Ce que c'est

Une **porte humaine** (human-in-the-loop) avant d'allumer des moteurs **déjà présents**
et **défensifs** (audit full, inventaire all-ports, RGPD signalement, dossier PASSI,
lecture OT, audit web headers/TLS, hygiène SMB lecture).

Ce n'est **pas** :

- de l'exploitation, Metasploit, Cobalt, Mimikatz, EternalBlue ;
- du C2, brute-force, auto-compromise ;
- de l'évasion IPS/IDS ou des playbooks « comment passer la sécurité » ;
- un bypass d'autorisation écrite.

## Déverrouillage UI

1. Bouton **Red team** → mot de passe opérateur.
2. Premier lancement : définir le mot de passe (écrit en `~/.config/guardia/red.pass`
   comme `salt$hash` = SHA-256(salt+password), chmod 600). Alternativement :
   - env `GUARDIA_RED_PASSWORD_HASH` (hash nu 64 hex ou `salt$hash`) ;
   - `queen_decide` : `RED_TEAM_PASSWORD_HASH=…` (fichier local, jamais en git).
3. Cocher **Mode Red Team (avancé)** (désactivé tant que le mot de passe n'est pas OK).
4. Pour chaque action : cocher **Demander / activer** **et** **Document signé validé**
   (l'opérateur atteste que le ROE / avenant signé couvre l'action).
5. Demander sans document signé → **refus** (messagebox), pas de flag CLI.

Session : le déverrouillage vaut pour la session UI uniquement.

## CLI / YAML

```bash
python3 -m guardia run -m missions/exemple.yaml --equipe red \
  --red-pass '…' --red-team --red-ok \
  --red-actions-signed audit_full,rgpd,inventaire_all_ports
```

Ou dans la mission YAML :

```yaml
equipe: red
red_team: true
red_actions_signed:
  - audit_full
  - web_profond
  - smb_hygiene
  - rgpd
  - passi
  - ot_lecture
  - inventaire_all_ports
```

`--red-team` sans `--red-ok` / `GUARDIA_RED_OK=1` / liste YAML signée → rien d'avancé
n'est allumé. Le journal note chaque action ouverte seulement si signée.

## Mapping défensif (uniquement)

| Action gate              | Moteur existant                          |
|--------------------------|------------------------------------------|
| `audit_full`             | `--audit-full` / extras `audit_full`     |
| `web_profond`            | `--site` (headers/TLS lecture)           |
| `smb_hygiene`            | `--calibrage` (hygiène lecture)          |
| `rgpd`                   | `--rgpd` (signalement, pas certificat)   |
| `passi`                  | `--passi` (dossier, pas qualification)   |
| `ot_lecture`             | `--machines`                             |
| `inventaire_all_ports`   | `--all-ports`                            |

## Règle produit

Autorisation écrite obligatoire. Document signé (avenant / ROE) avant toute action
avancée. Guardia reste un orchestrateur d'**audit défensif en lecture**.


## Knock-not-enter (alignement rapport)

Même en mode Red Team avancé (moteurs défensifs derrière la porte humaine), le rapport
reste : **frapper → voir la réponse → ne pas entrer**. Aucun Metasploit, aucun payload
runner, aucune demi-exploitation. Voir `PREUVE-DEFENSIVE.md` et le template
`Ceci permettrait de…` / `Pour vous protéger, il faudrait…`.

## CVE / full OSI (1.2.8)

La porte Red allume des moteurs **défensifs** déjà présents. La corrélation CVE catalogue local et la vision OSI lecture max suivent `--audit-full` / actions signées `audit_full` / `smb_hygiene` — toujours sans exploit.
