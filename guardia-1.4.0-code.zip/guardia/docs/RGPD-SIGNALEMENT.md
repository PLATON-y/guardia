# Signalement RGPD — sur demande

Guardia **contrôle selon les exigences RGPD** (UE 2016/679), la loi
Informatique et Libertés, la LCEN (mentions légales) et les
recommandations CNIL (cookies / consentement, y compris multi-terminaux 2026).

Ensuite il **signale** ce qui a été :

- **observé** (vu sur le site / le LAN)
- **déclaré** (réponse opérateur dans la fiche — **pas une preuve**)
- **non observé** (signalé)
- **à confirmer avec vous** (registre, sous-traitants, durées, NIS2…)

## Ce que ce n’est pas

- **Pas un certificat** de conformité
- **Pas une certification** CNIL / DPO / PASSI
- **Pas un tampon** « RGPD OK »
- **Pas autre chose** qu’un signalement établi **sur demande**

Un « oui » dans la fiche n’est **pas** une conformité. C’est une déclaration.

## Configurer la fiche (obligatoire pour sortir du « à confirmer »)

Questions posées au responsable de traitement, écrites dans le YAML
(`rgpd: true` + `rgpd_config`) :

| Champ | Sens |
|---|---|
| `responsable` | Qui décide des finalités |
| `contact_droits` | E-mail d’exercice des droits |
| `dpo_designe` | oui / non / inconnu |
| `registre_tenu` | Registre art. 30 |
| `registre_violations` | Journal art. 33.5 |
| `procedure_72h` | Circuit notification CNIL |
| `sous_traitants` | Hébergeur, mail, analytics… |
| `contrats_art28` | Contrats avec ces sous-traitants |
| `transferts_hors_ue` | Données hors UE / EEE |
| `durees_ecrites` | Durées de conservation écrites |
| `mineurs` | Traitement d’élèves / mineurs |
| `nis2_concerne` | Auto-déclaration, pas un classement |
| `refus_aussi_simple` | Bandeau cookies (vu dans le navigateur) |

### UI Tk

1. Charger la mission
2. Cocher **Signalement RGPD**
3. **Configurer RGPD…** → enregistrer la fiche
4. Run checkup

Nouvelle mission : bouton **Configurer la fiche RGPD…** dans le popup.

### CLI

```bash
# Afficher sans modifier
python3 -m guardia rgpd -m missions/exemple-audit.yaml --show

# Questionnaire (Entrée = garder la valeur actuelle)
python3 -m guardia rgpd -m missions/exemple-audit.yaml --edit

# Interactif (demande confirmation)
python3 -m guardia rgpd -m missions/exemple-audit.yaml
```

Le wizard (`python3 -m guardia wizard`) pose les mêmes questions si le
signalement RGPD est demandé.

## Comment l’allumer

```bash
python3 -m guardia run -m missions/exemple-audit.yaml --yes --site --rgpd
# --site sans URL → https://example.test (exemple non résolutif)
# --audit-full allume aussi le volet RGPD ; --no-rgpd le coupe
```

Le chapitre apparaît dans le rapport HTML / PDF / JSON sous
**« Signalement RGPD (sur demande) »**, avec le snapshot de la fiche
déclarée et les compteurs observé / déclaré / signalé / à confirmer.

Sans fiche, le rapport le dit clairement : *Fiche RGPD non configurée*.
