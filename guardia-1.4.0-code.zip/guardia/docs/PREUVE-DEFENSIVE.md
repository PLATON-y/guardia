# Preuve défensive — montrer la porte

Echoes of Hackers **build**. On ne script-kiddie pas.

Une faille dans un rapport Guardia doit pouvoir se **refaire** avec une
commande de lecture, sur le périmètre mandaté.

## Règle

Chaque finding haute / critique vise une **preuve courte** (ce qui a été
vu) + éventuellement une **preuve reproductible** (commande lecture seule).

La commande tient dans le rapport pour le prestataire / la DSI.

## Outils de la visite

- Empreinte ports / versions (`nmap -sV`)
- Scripts nmap : http-title, ssl-cert, smb-security-mode,
  smb-enum-shares (noms), nfs-showmount, ldap-rootdse, ftp-anon,
  http-headers, ssh-hostkey, ssl-enum-ciphers
- En-têtes HTTP, TLS handshake (curl, testssl, sslscan, whatweb)
- Nuclei tech/info/tls, nikto Tuning 1, wpscan passif — si HTTP vu
- Fiches déclarations (RGPD, usages)

Aide : `python3 -m guardia outil list`
Inventaire : `python3 -m guardia inventaire`


## Knock — voir la réponse, ne pas entrer

Doctrine produit (rapport client, vouvoiement) :

1. **Observation / preuve lecture** — réponse ou trace rejouable (pas d'entrée).
2. **« Ceci permettrait de … »** — hypothèse d'impact, sans étapes d'exploit.
3. **« Pour vous protéger, il faudrait … »** — remèdes / durcissement.
4. **Note** — aucune exploitation n'a été exécutée ; démonstration par sollicitation lecture seule.

Le payload **ne se lance pas**. La preuve sert aux techniciens agréés pour re-vérifier.
Le programme laisse une **piste d'audit autorisée** (journal de mission).

Helpers : `guardia.engines.preuve_repro.template_client_finding`, `phrase_impact`, `phrase_protection`.

## Corrélation CVE (lecture) — 1.2.8

Catalogue local `guardia/rules/cve_catalog.yaml` (~27 entrées high-signal).
Moteur : `guardia/engines/cve_correlate.py`.

```bash
python3 -m guardia run -m missions/exemple-full.yaml --cve --yes
python3 -m guardia run -m missions/exemple-full.yaml --no-cve --yes   # couper
```

Auto-ON si `--audit` / `--audit-full` / `--full` / `--passi` ou YAML `cve: true`.
Findings : observation + « Ceci permettrait de… » + « Pour vous protéger… » + note aucune exploitation.
Références : pages publiques NVD / ANSSI / CERT-FR uniquement. Pas de dump NVD, pas d'exploit.

## Vision OSI full (lecture max)

En `--full` / `audit_full` : couverture L1–L7, surfaces non protégées observées,
directives de lecture sûres (TLS, SMB hygiene, headers, OT lecture, CVE).
**Lecture full accès** = profondeur de lecture sur surfaces exposées — jamais un bypass d'auth ni une entrée.
