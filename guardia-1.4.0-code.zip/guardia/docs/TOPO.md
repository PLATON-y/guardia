# Guardia — ce que le produit fait

Produit Kali (CLI + Tk) · Platon-Y / Echoes of Hackers
Association déclarée, ESS (RNA W882005217 · SIREN 933496234 · NAF 8020Z)
Une seule machine opérateur. Mandat avant tout. Opérateur identifié.

Guardia est un moteur d'orchestration d'audit défensif. Pas un simulateur PASSI.
Les capacités logicielles ne sont pas une qualification organisationnelle.

## 1. Ce que c'est

Sur un périmètre signé, Guardia observe, décide, teste le pertinent, conserve
les preuves et remet un rapport. Lecture. Pas d'exploit.

## 2. Doctrine

- Mandat habilité + NDA avant tout checkup.
- Lecture seule. Pas d'exploit, pas de dump, pas de brute.
- RGPD = signalement, jamais un certificat.
- Findings = preuve locale reproductible. Validation humaine.
- Opérateur identifié. Trafic nominatif.
- Conservation deux ans.
- Avenant offensif jamais lancé automatiquement.

## 3. Comment il décide

Mandat → périmètre → découverte → graphe d'actifs → observation → décision
→ test pertinent → preuves → corrélation → validation → rapport.

Une précondition absente écarte la branche. Un outil absent n'arrête rien.
Un budget saturé arrête d'empiler. ZAP, BloodHound, Impacket, Metasploit, ffuf :
avenant, jamais auto.

## 4. Capacités

Découverte LAN, ports prioritaires, empreinte, TLS, web lecture, SMB noms,
RDP surface, OT lecture, Lynis opérateur, Greenbone lecture GMP.
Avenant documenté, moteur inerte.

## 5. Rapport

1. Grandes lignes (métier)
2. Décisions (joué / écarté / refusé / absent)
3. Graphe d'actifs
4. Preuves
5. Findings corrélés + comment faire
6. Chemins d'exposition (hypothèses)
7. Journal + hashes

## 6. Commandes

- `python3 -m guardia about`
- `python3 -m guardia cerveau -m missions/exemple-standard.yaml`
- `python3 -m guardia run -m missions/exemple-standard.yaml --cidr 192.168.1.0/24`
- `python3 -m guardia passi -m FILE`
- `python3 -m guardia ui`
