# Guardia — Checkup universel

**Signé :** Platon-Y pour Echoes of Hackers  
**Idée :** tout ce qui est branché sur le LAN autorisé → on le voit → on dit s’il est **dans une posture saine** ou **à risque** → on explique comment corriger.

Ce n’est pas un antivirus. Ce n’est pas un pentest d’exploitation.  
C’est un **bilan d’hygiène / d’exposition** le plus large possible *dans le mandat*.

## Promesse (honnête)

| On fait | On ne fait pas |
|---------|----------------|
| Inventaire de *tout* hôte joignable sur le CIDR signé | Promettre « zéro faille » |
| Classer chaque appareil : OK / à surveiller / à risque / critique | Exploiter une faille |
| Vérifier ce qui est *exposé* et *mal configuré de façon visible* | Lire le contenu privé des disques |
| Expliquer + donner le mode d’emploi pour corriger | Scanner hors périmètre |
| Adapter le langage (foyer / PME / école / asso) | Remplacer un PASSI ANSSI |

## Universel = grilles de contrôle

Pour **chaque** équipement trouvé, Guardia tente (selon profondeur) :

### A. Identité
- Est-il vivant sur le réseau ?
- Nom / constructeur / type probable (PC, TV, console, imprimante, NAS, caméra, téléphone, box…)
- Adresse, dernière vue

### B. Surface d’exposition
- Ports / services ouverts sur le LAN
- Interfaces d’admin web détectables
- Partages / protocoles fragiles annoncés
- Versions / bannières *quand elles se présentent*

### C. Posture « sécurisé ou non » (score simple)
Pour chaque appareil : **vert / orange / rouge** (+ motif en français).

Critères typiques (défensifs) :
- services d’admin ouverts sans besoin évident
- protocoles obsolètes visibles
- IoT / TV / console sur le même LAN que des postes « sensibles » (réseau plat)
- imprimante / NAS avec services trop ouverts
- box / Wi‑Fi : indices d’absence d’invité / d’isolement (si observables)

### D. Remédiation obligatoire
Chaque rouge/orange → étapes « comment résoudre » + qui peut le faire.

## Couverture par monde

- **Particulier / parc maison :** box, Wi‑Fi, PC, téléphones, TV, console, IoT, caméras
- **PME / parc entreprise :** postes, serveurs, NAS, imprimantes, Wi‑Fi invité, IoT métier
- **École / parc scolaire :** segmentation élèves/admin, comptes partagés, IoT classe, serveurs pédagogiques
- **Association / organisme :** comme PME, ton « adhérents / bénévoles »

Le wizard choisit le monde ; le moteur applique **toutes** les grilles pertinentes + celles universelles.

## Livrable « checkup »

1. **Vue d’ensemble** : X appareils, Y à risque, top actions
2. **Carte du foyer / du parc** (liste humaine)
3. **Fiche par appareil** : sécurisé ? pourquoi ? que faire ?
4. **Annexe courte** pour le technicien
5. Signature : *Guardia — Platon-Y / Echoes of Hackers*

## Limite claire (pour rester crédibles)

« Universel » = on **cherche partout sur le périmètre autorisé**, pas qu’on connaît l’univers entier de la cybersécurité.  
Les connaissances évoluent : le rapport date le jour J.
