# Dossier d’audit PASSI — Guardia

Guardia fournit un workflow d’appui à une prestation d’audit structurée autour des cinq activités publiques du référentiel PASSI v2.2 : organisationnel et physique, architecture, configuration, code source et tests d’intrusion. Le référentiel ANSSI précise également des exigences générales sur les objectifs, critères, périmètre, méthode, échantillonnage, prérequis, traçabilité et réunions de cadrage.

## Principe

Le produit ne transforme pas une série de scans en « conformité PASSI ». Une mission PASSI possède un état de dossier : contrôles vérifiés, preuves présentes, validations humaines attendues, éléments non couverts et prochaines actions.

## Entrées

Le fichier YAML peut contenir : périmètre, activités, méthode, échantillonnage, pièces d’architecture, éléments de configuration, corpus de code, entretiens/organisation, profil d’intrusion et règles d’arrêt.

## Preuve

Les contrôles sont calculés à partir de données structurées de mission et des résultats courants. Une preuve détectée sur un contrôle nécessitant un jugement humain reste `pending_human` tant que la validation n’est pas enregistrée.

## Export

`python3 -m guardia passi -m missions/exemple-passi-complet.yaml --markdown --export rapports/passi-demo`

L’export contient `passi-assessment.json`, `passi-assessment.md` et `MANIFEST-PASSI.sha256`.

## Limites

Le logiciel outille la préparation, l’exécution technique autorisée, la preuve, la traçabilité et la restitution. La qualification PASSI reste une qualification de service portant sur le prestataire, son personnel et le déroulement des audits ; Guardia ne constitue ni qualification ni certificat ANSSI.
