# Opérateur identifié

Echoes of Hackers ne se cache pas. On se présente, ou l'on nous appelle.
On va sur le lieu. Tout le monde signe — **y compris l'opérateur ÉOH**.

## Pourquoi

Art. 323-1 CP : le caractère frauduleux disparaît avec un mandat écrit.
Le mandat du client ne suffit pas à « disparaître » côté opérateur : on
paraphe aussi. C'est un **accord direct**, pas un scan anonyme.

## Ce que ça change

1. **Attestation opérateur** — Platon-Y (ou l'opérateur du jour) paraphe
   que le checkup se fait sous ce mandat, sur ce CIDR, à visage découvert.
2. **User-Agent HTTP** — `Guardia/x.y (Echoes of Hackers; … ; a visage decouvert)`.
   Les journaux du site du mandat voient qui a frappé.
3. **nmap honnête** — pas de decoy (`-D`), pas d'IP usurpée, pas d'idle
   scan, pas de fragmentation. Guardia refuse ces flags.
4. **Rapport** — double paraphe : habilité (client) + opérateur ÉOH.
   RNA W882005217, SIREN 933496234.

## Commandes

```
python3 -m guardia identite
python3 -m guardia identite -m missions/exemple-pme.yaml
```

YAML mission :

```yaml
operateur_nom: Platon-Y
operateur_signe: true
```

Le wizard coche `operateur_signe` en même temps que le mandat.

## Trouver une faille, expliquer comment faire

Les outils (nmap, curl, testssl, calibrage Kali) servent à **montrer**
une exposition et à **écrire les étapes** pour la corriger.
Aide : `python3 -m guardia outil list`

