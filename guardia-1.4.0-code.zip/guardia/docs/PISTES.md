# Pistes à explorer — pas des findings

Le polish LLM **reformule** ce qui est déjà vu. Il n'invente pas de faille.

Les **pistes** sont un catalogue, filtré par type de structure (foyer / PME /
école / organisme / fac / industrie…) et par taille. Une piste dit *où
regarder ensuite*. Elle n'a pas de gravité, pas de preuve d'incident.

## Allumage

Auto : profil PME / école, `taille_parc: grande`, ou `--llm`.
Force : `--pistes`. Coupe : `--no-pistes`. YAML : `pistes: true`.

## Veille (veille externe)

1. Coller `modeles/veille-pistes.yaml` dans une conversation Grok **hors
   build**.
2. Rapporter le YAML `pistes:` dans `modeles/veille-pistes.yaml` (ou
   `.json` si PyYAML absent).
3. Relancer le checkup : les nouvelles familles apparaissent comme pistes
   (badge « veille »).

Extra par mission : `pistes_extra:` (liste) dans le YAML de mission.

## LLM

Si `--llm` : le modèle local priorise le catalogue + la veille. Sur une
**grande** structure, il peut ajouter **au plus 3** conseils hors catalogue,
commande `nmap` / `curl` lecture seule.

Le 3B local **ne surfe pas**. La recherche de nouvelles familles se fait
avec veille externe, puis revient en veille.

Les pistes ne deviennent jamais des findings.

Voir aussi `docs/PREUVE-DEFENSIVE.md` et `modeles/veille-pistes.yaml`.
