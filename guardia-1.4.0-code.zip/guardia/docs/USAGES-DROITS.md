# Usages & droits — ce que les gens peuvent faire

Guardia ne remplace pas un admin assis derrière chaque session.
**Inventorier les machines** reste utile. **Ça ne tranche pas** la question
que se posent les structures (école, fac, PME, plus grande) :

> Qu’est-ce qu’une session (élève, enseignant, salarié) peut atteindre
> si les droits ne sont pas tenus ? Et **quelle machine dessert les autres** ?

Un trou sur ce serveur-là n’est pas « une machine de plus ».

## Ce que c’est

- Une **fiche** de déclarations (comptes nominatifs, admin local, VLAN,
  serveur de desserte, départs)
- Une **observation lecture-seule des portes** : noms de partages SMB,
  exports NFS, rootDSE LDAP, FTP anonyme
- Un chapitre rapport **Pour la direction** (langage métier)
- Des **preuves reproductibles** : la commande pour *montrer* la porte

On **montre la porte**.

## Comment l’allumer

Auto pour le profil **école**. Sinon :

```bash
python3 -m guardia usages -m missions/exemple-ecole.yaml --show
python3 -m guardia usages -m missions/exemple-ecole.yaml --edit
python3 -m guardia run -m missions/exemple-ecole.yaml --yes --usages
# Couper même en école :
python3 -m guardia run -m missions/exemple-ecole.yaml --yes --no-usages
```

UI : **Configurer usages…**

## Doctrine preuve

La plus-value : **démontrer une exposition** de façon reproductible et honnête.

| Porte | Commande | Aide |
|---------|----------|------|
| Partages SMB (noms) | `nmap --script smb-enum-shares` | Calibré si 445 |
| Exports NFS | `showmount -e` | Calibré si 111/2049 |
| Annuaire | `ldapsearch rootDSE` | Calibré si 389 |
| FTP anonyme | `nmap --script ftp-anon` | Calibré si 21 |

Catalogue : `python3 -m guardia outil list`

Voir `docs/PREUVE-DEFENSIVE.md` et `modeles/avenant-observation-portes.txt`.
