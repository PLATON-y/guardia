# Cadre légal — Guardia

Pas un avis d'avocat. Rappel opérateur.

## On opère avec autorisation

- **Code pénal art. 323-1 et s.** : l'accès frauduleux à un STAD est un
  délit. Le mandat écrit, daté, signé par une personne **habilitée**,
  avec périmètre (CIDR, URL, dates), fait disparaître le caractère
  frauduleux. Sans mandat, Guardia s'arrête.
- **RGPD art. 32** : l'organisme doit *tester, analyser et évaluer*
  régulièrement les mesures de sécurité. Le checkup y contribue.
  **Il ne délivre pas de certificat**, ni une « conformité ».
- **ESS** (loi n° 2014-856) : association + entreprise, finalité
  sociale (protéger les structures), gouvernance associative.
- **À visage découvert** : l'opérateur ÉOH paraphe aussi
  (`docs/IDENTITE.md`). User-Agent Guardia, pas de decoy nmap.

## Ce que le rapport met en premier

Les **grandes lignes** : langage métier, 2 minutes, pour qui n'est pas
technicien. Le détail (preuves, ports, commandes de lecture) suit.

## Outils de la visite

Lecture seule. Guardia lance les sondes passives installées.

Aide : `python3 -m guardia outil list`

Red team : le regard (niveau 0) est un **contrat**. Mot de passe opérateur
+ liasse (`python3 -m guardia dossier`). L'intrusion (niveaux 2-3) : documents
prévus, moteur inerte. Pas avant. Pas un audit PASSI.

Deux parcs : **personnel** (foyer) et **professionnel** (le type s'écrit
sur les pièces). Pas de « lab » côté client.

```
python3 -m guardia dossier -m mission.yaml --generer
python3 -m guardia run -m mission.yaml --yes --site
```
