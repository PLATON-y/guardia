# Guardia — commandes (1.3.1)

Guide démarrage opérateur (HTML) : `../guardia_lisez-moi.html`.


Guardia s’utilise depuis la racine du projet. Toute mission qui observe un périmètre doit disposer d’un mandat et d’un périmètre autorisé.

## Commandes principales

```bash
python3 -m guardia about
python3 -m guardia identite
python3 -m guardia wizard
python3 -m guardia cerveau -m missions/exemple-standard.yaml
python3 -m guardia run -m missions/exemple-standard.yaml --cidr 192.168.1.0/24
python3 -m guardia ui
```

## Diagnostic et capacités

```bash
python3 -m guardia inventaire
python3 -m guardia programme
python3 -m guardia outil list
python3 -m guardia liens
```

`inventaire` indique les outils présents sur le poste opérateur. Leur absence n’arrête pas une mission. `programme` expose les capacités prévues. `outil` donne le catalogue de lecture et les informations d’installation. `liens` vérifie les lanceurs et chemins de l’installation.

## Modules complémentaires

```bash
python3 -m guardia rgpd -m missions/exemple-standard.yaml
python3 -m guardia usages -m missions/exemple-ecole.yaml
python3 -m guardia passi -m missions/exemple-red.yaml
python3 -m guardia dossier -m missions/exemple-red.yaml
```

Les modules complémentaires restent soumis aux paramètres de mission. Le module RGPD produit un signalement ou une fiche déclarative ; il ne délivre pas de certificat. Le mode inspiré PASSI décrit des capacités logicielles et ne constitue pas une qualification.

## Exemples YAML

| Besoin | Fichier |
|---|---|
| foyer / particulier | `missions/exemple-foyer.yaml` |
| PME | `missions/exemple-pme.yaml` |
| école | `missions/exemple-ecole.yaml` |
| association | `missions/exemple-association.yaml` |
| collectivité | `missions/exemple-collectivite.yaml` |
| industrie / OT | `missions/exemple-industrie.yaml` |
| audit complet | `missions/exemple-full.yaml` |
| capacités red encadrées | `missions/exemple-red.yaml` |

## Options de mission

Le schéma de mission peut contenir notamment :

```yaml
guardia: 1.0
mission:
  id: audit-demo
  client: Structure Exemple
  profil_moteur: pme
  profondeur: standard
  scope:
    cidr: [192.168.1.0/24]
    urls: [https://example.test]
    exclusions: [exploitation, dump_annuaire, brute_force]

authorization:
  network_scan: true
  service_detection: true
  web_readonly: true
  intrusive_testing: false
  exploitation: false

profile:
  id: standard
  modes: [discovery, network, web, configuration, correlation]
```

## LLM

Groq optionnel (`--llm-groq` / `llm_groq: true`) : directives + fiche + confirmation lecture. Clé **uniquement** `GROQ_API_KEY` (env). Les lanceurs sourcent `./queen_decide` (ou `$GUARDIA_QUEEN_DECIDE`) s'il existe — copie depuis `queen_decide.example`. Sans clé → stub local. Jamais de clé dans git/yaml.


Au lancement de `run`, `ui`, `cerveau`, `passi` et `lab`, Guardia vérifie qu’une capacité d’explication est ouverte.

```bash
python3 -m guardia llm
```

Il sonde `127.0.0.1:2443` (port opérateur), puis `18111`, Ollama `11434`. S’il trouve un GGUF (`../guardia-models/*.gguf`) et `llama-server`, il démarre le serveur. Sinon : garde locale (reformule, n’invente aucune preuve).

`GUARDIA_LLM_URL=http://127.0.0.1:2443` force l’URL. `--llm-url` aussi.

### Bootstrap GGUF (1.3.1)

Si `models/cybersec-assistant-3b-Q4_K_M.gguf` est absent au démarrage (`ui`, `llm`, `run`/`cerveau` avec start) :

1. indiquer un `.gguf` existant (symlink/copie dans `models/`) ;
2. télécharger via wget (~1,8 Go) depuis le catalogue HuggingFace ;
3. continuer avec la garde locale seule.

```bash
# non-interactif / CI
export GUARDIA_LLM_MODEL=/chemin/vers/modele.gguf
# ou
mkdir -p models && wget -c -O models/cybersec-assistant-3b-Q4_K_M.gguf \
  "${GUARDIA_GGUF_URL:-https://huggingface.co/AYI-NEDJIMI/CyberSec-Assistant-3B-GGUF/resolve/main/cybersec-assistant-3b-Q4_K_M.gguf}"
```

Voir `models/LIRE.txt`. Module : `guardia.engines.llm_bootstrap`.


## Labs adaptatifs

```bash
python3 -m guardia lab
python3 -m guardia lab --id https-only
```

Hôtes synthétiques, zéro paquet réseau. Le cerveau ouvre, écarte ou bloque selon les observations.

## Sorties

Le rapport final peut produire HTML, JSON et PDF lorsqu’un générateur PDF est disponible. Les décisions de l’orchestrateur indiquent ce qui a été joué, écarté, bloqué, indisponible ou repris.

## Couverture OSI + directives PASSI/CNIL

Voir `docs/OSI-ORCH.md`. Aperçu :

```bash
python3 -m guardia cerveau -m missions/exemple-passi-complet.yaml
python3 -m guardia cerveau -m missions/exemple-passi-complet.yaml --llm-groq
python3 -m guardia run -m missions/exemple-passi-complet.yaml --passi --rgpd --yes
```

PASSI = dossier d’appui (pas une qualification). RGPD = signalement (pas un certificat). Démonstration d’exposition en lecture pendant la plage d’audit — pas d’exploit client. Candidats catalogue déjà présents : nmap, nuclei (selon préconditions / policy).

## Dossier PASSI v2.2

```bash
python3 -m guardia passi -m missions/exemple-passi-complet.yaml --markdown
python3 -m guardia passi -m missions/exemple-passi-complet.yaml --export rapports/passi-demo
```

Le dossier distingue contrôles vérifiés, validations humaines en attente, non-applicables et non-couverts. La chaîne exigence → preuve → rapport est jointe. Ce n’est ni une qualification ni une certification ANSSI.

## Porte Red Team (1.2.8+)

Voir `docs/RED-TEAM-GATE.md`. Exemple :

```bash
python3 -m guardia run -m missions/exemple-red.yaml --equipe red --red-team --red-ok \
  --red-actions-signed audit_full,rgpd --yes
```

## Queen (Groq)

```bash
python3 -m guardia queen
python3 -m guardia llm
```
Vérifie `queen_decide` + API Groq (comme `llm` pour le local). Sans clé → KO explicite.

## Corrélation CVE + vision OSI full (1.2.8)

```bash
# Auto en full / audit-full / passi
python3 -m guardia run -m missions/exemple-full.yaml --yes
python3 -m guardia run -m missions/exemple-passi.yaml --passi --cve --yes
python3 -m guardia run -m missions/exemple-standard.yaml --cve --cidr 192.168.1.0/24 --yes
python3 -m guardia run -m missions/exemple-full.yaml --no-cve --yes
```

YAML : `cve: true` (défaut conseillé pour exemple-full / passi).  
Rapport HTML : section « Corrélation CVE (lecture) » + surfaces non protégées / lacunes OSI.
Tests sans réseau : `python3 -m unittest tests.test_cve_correlate -v`

## Firefox neutre + Nouveau client (1.3.1)

Profil Firefox ESR `neutre` pour ouvrir les rapports HTML et le hub documents à signer (OPSEC opérateur).

```bash
# Créer profil + raccourci Bureau (firefox-neutre.desktop)
./scripts/install-firefox-neutre.sh
# ou depuis Python
python3 -c 'from guardia.core.firefox_neutre import ensure_neutre_profile; print(ensure_neutre_profile())'

# Hub documents (vouvoiement, fiche client, Blue/Red)
# modeles/a-signer/nouveau-client.html
# UI : bouton rond « Nouveau client » → Firefox neutre / lien file:// / wizard Nouvelle mission
python3 modeles/build_a_signer.py   # régénère hub + index
```

HTML : toujours `firefox-esr -P neutre --no-remote` en priorité. PDF : Okular puis Firefox neutre.
