# Checkup des liens — machine unique ÉOH

Guardia ne tourne que sur **la** machine Echoes of Hackers. Au démarrage
(UI) et via `python3 -m guardia liens`, on vérifie que les *liens*
locaux tiennent : dossiers, lanceurs, Thunar, Firefox ESR, Okular, nmap, Tk.

## Pourquoi

Dans le premier zip, « Ouvrir rapports/ » et l'HTML/PDF marchaient.
Si l'UI est lancée **en root** (nmap SYN), Thunar / xdg-open meurent tout
de suite : pas de bus D-Bus de session. L'ancien code faisait `Popen` et
disait succès dès que le binaire existait.

## Ce que fait le checkup

- Racine, `missions/`, `rapports/`, `modeles/`, `docs/`
- Bit **+x** sur `lancer-ui.sh`, `lancer-cli.sh`, `bin/guardia` (rétabli si le zip l'a perdu)
- `python3`, `tkinter`, `nmap`
- `thunar` / `exo-open` / `xdg-open` / `firefox-esr` / `okular`
- DISPLAY / WAYLAND, bus D-Bus, `SUDO_USER` si root

## Ouverture

En root, Guardia relance Thunar / Firefox **sous l'utilisateur de session**
(`runuser -u $SUDO_USER`) avec `DISPLAY` + `DBUS_SESSION_BUS_ADDRESS`.
On ne déclare succès que si le helper tient ~0,5 s ou sort 0.

```bash
cd ~/Bureau/guardia
python3 -m guardia liens
./lancer-ui.sh          # depuis la session bureau, pas sudo pur
```

Si KO : lancer l'UI depuis le bureau (pas `sudo -i`), ou `sudo -E` en gardant
`SUDO_USER` / `DISPLAY`.

## Firefox profil neutre (1.2.9)

Les HTML (rapports, hub `nouveau-client.html`) s’ouvrent via `firefox-esr -P neutre --no-remote`. Installation : `./scripts/install-firefox-neutre.sh` (module `guardia.core.firefox_neutre`).
