#!/usr/bin/env bash
# Installe le profil Firefox ESR « neutre » + raccourci Bureau pour Guardia / ÉOH.
# Usage : ./scripts/install-firefox-neutre.sh
#         python3 -c 'from guardia.core.firefox_neutre import ensure_neutre_profile; print(ensure_neutre_profile())'
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$ROOT"

if ! command -v firefox-esr >/dev/null 2>&1 && ! command -v firefox >/dev/null 2>&1; then
  echo "KO : firefox-esr absent. Sous Debian/Kali : sudo apt install firefox-esr" >&2
  exit 1
fi

export PYTHONPATH="${ROOT}${PYTHONPATH:+:$PYTHONPATH}"
python3 - <<'PY'
from guardia.core.firefox_neutre import ensure_neutre_profile, status_line
rep = ensure_neutre_profile(create_desktop=True)
print(status_line())
print("detail:", rep.get("detail"))
print("desktop:", rep.get("desktop"))
raise SystemExit(0 if rep.get("ok") else 1)
PY
