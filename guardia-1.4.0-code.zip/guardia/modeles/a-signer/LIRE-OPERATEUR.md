# Notes opérateur (ne pas joindre au client)

- **Tone client** : tous les PDF / HTML client sont en **vouvoiement professionnel** (vous/votre).
- HTML : lecture / envoi mail — ouvrir avec **Firefox ESR profil neutre**.
- PDF : impression ou signature électronique (Okular puis Firefox neutre).
- Régénérer : `python3 modeles/build_a_signer.py`
- Flyer A3 paysage : `flyer-guardia.pdf`
- Identité visuelle fournie par le dossier opérateur (`assets/`)
- Logo ÉOH : `assets/echoes-of-hackers.png` (fourni)
- Mandat audit full : `mandat-audit-full.html` / `.pdf` (catalogue capacités + remèdes)
- **Avenant post-audit** : `avenant-post-audit-detail.html` / `.pdf`
  (risques, reconnaissance client, suites optionnelles lab/lecture URL — à la demande, 2 exemplaires)
- Identité ÉOH pré-remplie via `EOH_ID` / `eoh_header_html()` dans `build_a_signer.py`
  (RNA W882005217, SIREN 933496234, siège Lamarche ; lieu d’intervention distinct possible)
- Checkup full options : `missions/exemple-full.yaml` ; CLI `--audit-full` pour audit niveau full
- Intent produit : démontrer expositions + remèdes dans le rapport (défensif)
- Suites outils offensifs = **optionnelles**, annexe signée, jamais silencieuses, plages = audit existant
- **Hub Nouveau client** : `nouveau-client.html` (fiche + Blue/Red + stub YAML)
- Firefox neutre : `scripts/install-firefox-neutre.sh` / `python3 -m guardia firefox-neutre`
