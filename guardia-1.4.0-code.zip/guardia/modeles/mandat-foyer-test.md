# Accord foyer — test Guardia (réseau domestique)

> Rédaction client : vouvoiement. Siège ÉOH à Lamarche ; lieu d’intervention distinct possible.

**ÉOH** — Echoes of Hackers · RNA W882005217 · SIREN 933496234 · Président Jonathan Ducros (Platon-Y)  
Siège : 3 Rue Saint-Henry, Apt 41, Étage 1, 88320 Lamarche  
Lieu d’intervention (si différent) : _________________

Nous, occupants du foyer, autorisons un **contrôle défensif** Guardia sur le **réseau local domestique** (pas Internet public hors box), afin de cartographier les équipements (PC, TV, console, téléphonie, IoT…) et de recevoir un rapport d’hygiène compréhensible.

- Pas d’exploitation de failles.
- Pas de recherche de virus (sauf complément antimalware expressément coché ailleurs).
- Arrêt immédiat sur demande d’un occupant.

Profil : **maison**

Date : __________  
Signatures (adultes du foyer) : __________ / __________  
Pour ÉOH : Jonathan Ducros, Président __________  
