"""Hub HTML Nouveau client — pack documents par service (Blue / Red)."""
from __future__ import annotations

# Imported from build_a_signer at call time to avoid circular init issues.


def build_nouveau_client() -> str:
    from build_a_signer import (  # type: ignore
        EOH_ID,
        alink,
        eoh_header_html,
        page,
    )

    e = EOH_ID
    body = f"""
{eoh_header_html(show_intervention=False, client_block=True)}
<p>Bienvenue. Cette page regroupe les documents à signer pour une mission
de contrôle défensif avec <strong>{e["denomination"]}</strong>.
Tous les textes client sont rédigés en <strong>vouvoiement professionnel</strong>.</p>
<p class="meta-note">Ouvrez ce hub dans <strong>Firefox ESR — profil neutre</strong>
(<code>firefox-esr -P neutre --no-remote</code>). Aucun exploit n’est proposé :
lecture, constat, remèdes.</p>

<nav class="hub-nav no-print" aria-label="Sections">
  <a href="#fiche-client">Fiche client</a>
  <a href="#blue">Blue — checkup</a>
  <a href="#foyer">Foyer</a>
  <a href="#pme">PME</a>
  <a href="#ecole">École</a>
  <a href="#audit-full">Audit full</a>
  <a href="#nda">NDA</a>
  <a href="#presentation">Présentation</a>
  <a href="#red" class="redish">Red — avenants</a>
  <a href="#export" class="redish">Export YAML</a>
</nav>

<div class="note-box no-print">
  <strong>Enregistrer une copie</strong> — remplissez les champs ci-dessous,
  puis utilisez <em>Fichier → Enregistrer sous…</em> (ou Ctrl+S) pour conserver
  le HTML rempli dans <code>rapports/</code>, ou cliquez
  <strong>Télécharger stub mission YAML</strong> pour un extrait importable plus tard
  dans Guardia (Nouvelle mission / YAML). L’impression PDF reste disponible
  (Ctrl+P).
</div>

<section id="fiche-client" class="card">
  <h2>Fiche client (champs remplissables)</h2>
  <p>Identité ÉOH déjà préremplie ci-dessus. Complétez votre côté :</p>
  <div class="form-grid" id="client-form">
    <label>Raison sociale / nom
      <input type="text" id="c_nom" name="client_nom" placeholder="Votre structure ou nom"/>
    </label>
    <label>Type de structure
      <select id="c_type" name="client_type">
        <option value="foyer">Foyer / particulier</option>
        <option value="pme">PME / entreprise</option>
        <option value="ecole">École / organisme</option>
        <option value="association">Association</option>
        <option value="collectivite">Collectivité</option>
        <option value="autre">Autre</option>
      </select>
    </label>
    <label>Contact (nom)
      <input type="text" id="c_contact" name="contact_nom" placeholder="Prénom Nom"/>
    </label>
    <label>Qualité / fonction
      <input type="text" id="c_qualite" name="contact_qualite" placeholder="Dirigeant, RSI…"/>
    </label>
    <label>E-mail
      <input type="email" id="c_email" name="contact_email" placeholder="vous@exemple.fr"/>
    </label>
    <label>Téléphone
      <input type="tel" id="c_tel" name="contact_tel" placeholder="+33…"/>
    </label>
    <label class="full">Adresse du lieu d’intervention
      <input type="text" id="c_adresse" name="adresse" placeholder="Adresse complète"/>
    </label>
    <label>CIDR / plage autorisée
      <input type="text" id="c_cidr" name="cidr" placeholder="192.168.1.0/24"/>
    </label>
    <label>Dates envisagées
      <input type="text" id="c_dates" name="dates" placeholder="ex. 20–22/09/2026"/>
    </label>
    <label class="full">Notes / exclusions
      <textarea id="c_notes" name="notes" placeholder="Équipements exclus, contraintes, DPO…"></textarea>
    </label>
  </div>
  <div class="toolbar no-print" id="export">
    <button type="button" onclick="window.print()">Imprimer / PDF</button>
    <button type="button" class="secondary" onclick="saveLocal()">Mémoriser (navigateur)</button>
    <button type="button" class="secondary" onclick="downloadYaml()">Télécharger stub mission YAML</button>
    <button type="button" class="secondary" onclick="downloadJson()">Télécharger JSON fiche</button>
  </div>
  <p class="meta-note">Astuce : après enregistrement HTML dans <code>rapports/</code>,
  l’opérateur peut coller le YAML stub dans une nouvelle mission Guardia.</p>
</section>

<div class="section-blue" id="blue">
  <h2><span class="pill-blue">BLUE</span> Checkup classique — documents de base</h2>
  <p>Parcours standard : présentation, mandat ROE, confidentialité.
  Aucune capacité avancée / red sans avenant signé.</p>

  <div class="cards">
    <div class="card" id="presentation">
      <h2>Présentation — notre démarche</h2>
      <p>Ce que nous faisons pour votre foyer, votre association, votre PME ou votre école,
      sans jargon technique.</p>
      <p>{alink("presentation-demarche.html")} · {alink("presentation-demarche.pdf", "PDF")}</p>
    </div>
    <div class="card" id="nda">
      <h2>Confidentialité mutuelle (NDA)</h2>
      <p>Engagement réciproque, données personnelles, cadre légal.</p>
      <p>{alink("clause-confidentialite-mutuelle.html")} · {alink("clause-confidentialite-mutuelle.pdf", "PDF")}</p>
    </div>
    <div class="card">
      <h2>Mandat / autorisation (ROE)</h2>
      <p>Périmètre, dates, interdits — à signer avant toute observation.</p>
      <p>{alink("mandat-roe-eoh.html")} · {alink("mandat-roe-eoh.pdf", "PDF")}</p>
    </div>
  </div>

  <h3 id="foyer">Foyer / particulier</h3>
  <ul class="doc-list">
    <li><span class="svc">Pack foyer</span>
      {alink("mandat-roe-eoh.html", "Mandat ROE")} ·
      {alink("clause-confidentialite-mutuelle.html", "NDA")} ·
      {alink("presentation-demarche.html", "Présentation")} ·
      {alink("mandat-foyer-test.html", "Mandat foyer (test)")}</li>
  </ul>

  <h3 id="pme">PME / entreprise</h3>
  <ul class="doc-list">
    <li><span class="svc">Pack PME</span>
      {alink("mandat-roe-eoh.html", "Mandat ROE")} ·
      {alink("clause-confidentialite-mutuelle.html", "NDA")} ·
      {alink("presentation-demarche.html", "Présentation")} ·
      {alink("mandat-audit-full.html", "Option audit full")}</li>
  </ul>

  <h3 id="ecole">École / organisme</h3>
  <ul class="doc-list">
    <li><span class="svc">Pack école</span>
      {alink("mandat-roe-eoh.html", "Mandat ROE")} ·
      {alink("clause-confidentialite-mutuelle.html", "NDA")} ·
      {alink("presentation-demarche.html", "Présentation")}
      — attention particulière aux mineurs / données scolaires (signalement RGPD si demandé).</li>
  </ul>

  <h3 id="audit-full">Audit full (catalogue défensif)</h3>
  <ul class="doc-list">
    <li><span class="svc">Audit full</span>
      {alink("mandat-audit-full.html")} · {alink("mandat-audit-full.pdf", "PDF")}
      — expositions constatées et remèdes, <strong>sans exploit</strong>. Complète ROE + NDA.</li>
  </ul>
</div>

<div class="section-red" id="red">
  <h2><span class="pill-red">RED</span> Documents avancés — avenants (porte signée)</h2>
  <p>Ces pièces ouvrent des suites <em>optionnelles</em> et encadrées après audit.
  Elles exigent un document signé (porte Red Team Guardia). Toujours défensif :
  pas d’exploit client, pas d’action silencieuse.</p>
  <ul class="doc-list">
    <li><span class="svc">Avenant post-audit</span>
      {alink("avenant-post-audit-detail.html")} · {alink("avenant-post-audit-detail.pdf", "PDF")}
      — risques, reconnaissance, suites lab / lecture URL à votre demande.</li>
    <li><span class="svc">Prérequis</span>
      Mandat ROE + NDA + (selon mission) mandat audit full déjà signés.</li>
  </ul>
  <p class="meta-note">Flyers opérateur (hors signature) :
  {alink("flyer-guardia.html", "flyer-guardia")} ·
  {alink("flyer-a3-pctamalou.html", "flyer A3 pctamalou")}.</p>
</div>

<p style="margin-top:1.4em">Sommaire historique : {alink("index.html", "index.html")} ·
Sites : {alink("https://pctamalou.fr", "pctamalou.fr")}
· {alink("https://e-of-h.fr", "e-of-h.fr")} · {e["email"]}</p>

<script>
(function () {{
  const KEY = "guardia_nouveau_client_fiche";
  const ids = ["c_nom","c_type","c_contact","c_qualite","c_email","c_tel","c_adresse","c_cidr","c_dates","c_notes"];
  function read() {{
    const o = {{}};
    ids.forEach(id => {{ const el = document.getElementById(id); if (el) o[id] = el.value; }});
    return o;
  }}
  function write(o) {{
    if (!o) return;
    ids.forEach(id => {{ const el = document.getElementById(id); if (el && o[id] != null) el.value = o[id]; }});
  }}
  try {{ write(JSON.parse(localStorage.getItem(KEY) || "null")); }} catch (e) {{}}
  window.saveLocal = function () {{
    try {{
      localStorage.setItem(KEY, JSON.stringify(read()));
      alert("Fiche mémorisée dans ce navigateur (localStorage).");
    }} catch (e) {{ alert("Impossible de mémoriser : " + e); }}
  }};
  window.downloadJson = function () {{
    const blob = new Blob([JSON.stringify(read(), null, 2)], {{type: "application/json"}});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "guardia-fiche-client.json";
    a.click();
  }};
  window.downloadYaml = function () {{
    const d = read();
    const slug = (d.c_nom || "client").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, "") || "client";
    const typ = d.c_type || "foyer";
    const profil = (typ === "pme") ? "pme" : (typ === "ecole" ? "ecole" : "maison");
    const yaml = [
      "guardia: 1.0",
      "mission:",
      "  id: " + slug,
      "  client: " + JSON.stringify(d.c_nom || ""),
      "  profil_moteur: " + profil,
      "  profondeur: standard",
      "  contact_nom: " + JSON.stringify(d.c_contact || ""),
      "  contact_qualite: " + JSON.stringify(d.c_qualite || ""),
      "  contact_email: " + JSON.stringify(d.c_email || ""),
      "  contact_tel: " + JSON.stringify(d.c_tel || ""),
      "  adresse_intervention: " + JSON.stringify(d.c_adresse || ""),
      "  dates_prevues: " + JSON.stringify(d.c_dates || ""),
      "  notes: " + JSON.stringify(d.c_notes || ""),
      "  scope:",
      "    cidr: [" + (d.c_cidr ? JSON.stringify(d.c_cidr) : "") + "]",
      "    exclusions: [exploitation, dump_annuaire, brute_force]",
      "authorization:",
      "  network_scan: true",
      "  service_detection: true",
      "  web_readonly: true",
      "  intrusive_testing: false",
      "  exploitation: false",
      "# Stub généré depuis modeles/a-signer/nouveau-client.html — à compléter / importer.",
      ""
    ].join("\\n");
    const blob = new Blob([yaml], {{type: "text/yaml"}});
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = "mission-" + slug + "-stub.yaml";
    a.click();
  }};
}})();
</script>
"""
    return page(
        "Nouveau client — pack documents",
        "Echoes of Hackers — hub signature & services",
        "Hub client",
        body,
    )
