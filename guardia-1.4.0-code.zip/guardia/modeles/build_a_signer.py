#!/usr/bin/env python3
"""Génère HTML + PDF : docs à signer (client), présentation mission, flyer A3."""
from __future__ import annotations

import subprocess
import sys
from pathlib import Path
import sys as _sys

# Permet l'import du catalogue Guardia depuis modeles/
_ROOT = Path(__file__).resolve().parents[1]
if str(_ROOT) not in _sys.path:
    _sys.path.insert(0, str(_ROOT))

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "a-signer"
ASSETS = OUT / "assets"

LEGAL_BOX = """
<div class="legal-box">
  <strong>À ajouter si nécessaire</strong> — mentions complémentaires, annexes,
  listes d’équipements exclus, durée de conservation des artefacts, contacts DPO,
  ou clauses particulières convenues entre les parties.<br/><br/>
  <strong>À faire valoir pour ce que de droit.</strong>
</div>
"""

EOH_ID = {
    "denomination": "Echoes of Hackers (ÉOH)",
    "forme": "Association déclarée",
    "fondee": "13/09/2024",
    "reception": "17/09/2024 (sous-préfecture de Neufchâteau)",
    "rna": "W882005217",
    "siren": "933496234",
    "siret": "93349623400016",
    "naf": "8020Z — activités liées aux systèmes de sécurité",
    "siege": "3 Rue Saint-Henry, Appartement 41, Étage 1, 88320 Lamarche (Vosges)",
    "email": "admin@e-of-h.fr",
    "sites": "e-of-h.fr / pctamalou.fr",
    "president": "Jonathan Ducros",
    "alias": "Platon-Y",
    "qualite_signataire": "Président / responsable de publication",
}

CSS = """
:root {
  --ink: #1a1a1a;
  --muted: #555;
  --line: #d8d8d8;
  --accent: #1b4f72;
  --bg: #fafbfc;
  --card: #fff;
}
* { box-sizing: border-box; }
body {
  margin: 0;
  font-family: "Segoe UI", system-ui, sans-serif;
  color: var(--ink);
  background: var(--bg);
  line-height: 1.55;
  font-size: 11pt;
}
.wrap { max-width: 820px; margin: 0 auto; padding: 28px 22px 48px; }
header.brand {
  border-bottom: 3px solid var(--accent);
  padding-bottom: 14px;
  margin-bottom: 22px;
  display: flex;
  gap: 16px;
  align-items: center;
}
header.brand img.logo {
  height: 56px;
  width: auto;
}
header.brand img.logo.eoh {
  height: 64px;
  border-radius: 50%;
}
header.brand .titles { flex: 1; }
header.brand h1 {
  margin: 0 0 4px;
  font-size: 1.45rem;
  color: var(--accent);
}
header.brand .sub { color: var(--muted); font-size: 0.95rem; }
.badge {
  display: inline-block;
  background: #e8f1f8;
  color: var(--accent);
  font-size: 0.75rem;
  font-weight: 600;
  padding: 3px 10px;
  border-radius: 999px;
  margin-top: 8px;
}
h2 {
  color: var(--accent);
  font-size: 1.1rem;
  margin: 1.4em 0 0.5em;
  border-bottom: 1px solid var(--line);
  padding-bottom: 4px;
}
h3 { font-size: 1rem; margin: 1.1em 0 0.4em; }
p, li { margin: 0.4em 0; }
ul, ol { padding-left: 1.2em; }
.blank {
  border-bottom: 1px dotted #888;
  display: inline-block;
  min-width: 12em;
  height: 1.1em;
  vertical-align: bottom;
}
.checks label { display: block; margin: 0.25em 0; }
.sig {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 18px;
  margin-top: 28px;
}
.sig .box {
  border: 1px solid var(--line);
  border-radius: 8px;
  padding: 14px;
  background: var(--card);
  min-height: 140px;
}
.sig .box h3 { margin-top: 0; color: var(--accent); font-size: 0.95rem; }
.sig .line { margin-top: 28px; border-bottom: 1px solid #333; height: 2.2em; }
.paraphe {
  margin-top: 18px;
  font-size: 0.85rem;
  color: var(--muted);
}
.legal-box {
  margin-top: 28px;
  border: 2px solid var(--accent);
  border-radius: 8px;
  padding: 14px 16px;
  background: #f0f6fb;
  font-size: 0.92rem;
}
footer {
  margin-top: 28px;
  padding-top: 12px;
  border-top: 1px solid var(--line);
  font-size: 0.8rem;
  color: var(--muted);
}
.cards { display: grid; gap: 14px; margin-top: 18px; }
.card {
  background: #fff;
  border: 1px solid var(--line);
  border-radius: 10px;
  padding: 16px 18px;
}
.card h2 { margin: 0 0 6px; border: 0; font-size: 1.05rem; }
.grid2 {
  display: grid;
  grid-template-columns: 1fr 1fr;
  gap: 14px;
}
.eoh-id {
  background: #f0f6fb;
  border: 1px solid #c5d6e6;
  border-radius: 8px;
  padding: 12px 14px;
  margin: 0 0 1.2em;
  font-size: 0.92rem;
}
.meta-note { color: var(--muted); font-size: 0.9rem; }
@media print {
  body { background: #fff; font-size: 10.5pt; }
  .wrap { max-width: none; padding: 0; }
  .sig .box, .card, .legal-box, .eoh-id { break-inside: avoid; }
  .no-print { display: none !important; }
}
@page { size: A4; margin: 16mm 14mm; }
.hub-nav {
  display: flex; flex-wrap: wrap; gap: 8px; margin: 0 0 1.2em;
}
.hub-nav a {
  text-decoration: none; font-size: 0.85rem; font-weight: 600;
  padding: 6px 12px; border-radius: 999px; border: 1px solid var(--line);
  background: #fff; color: var(--accent);
}
.hub-nav a:hover { background: #e8f1f8; }
.hub-nav a.redish { color: #8b1a1a; border-color: #e0b4b4; background: #fdf6f6; }
.section-blue {
  border-left: 4px solid #1b4f72; padding-left: 14px; margin: 1.6em 0;
}
.section-red {
  border-left: 4px solid #8b1a1a; padding-left: 14px; margin: 1.6em 0;
  background: #fffafa; border-radius: 0 8px 8px 0; padding: 12px 14px;
}
.pill-blue, .pill-red {
  display: inline-block; font-size: 0.72rem; font-weight: 700;
  padding: 2px 9px; border-radius: 999px; letter-spacing: 0.03em;
}
.pill-blue { background: #e8f1f8; color: #1b4f72; }
.pill-red { background: #f5e0e0; color: #8b1a1a; }
.form-grid {
  display: grid; grid-template-columns: 1fr 1fr; gap: 10px 14px;
  margin: 12px 0 8px;
}
.form-grid label {
  display: flex; flex-direction: column; gap: 4px;
  font-size: 0.88rem; color: var(--muted);
}
.form-grid label.full { grid-column: 1 / -1; }
.form-grid input, .form-grid select, .form-grid textarea {
  font: inherit; color: var(--ink); padding: 7px 9px;
  border: 1px solid #c5d0da; border-radius: 6px; background: #fff;
}
.form-grid textarea { min-height: 64px; resize: vertical; }
.toolbar {
  display: flex; flex-wrap: wrap; gap: 8px; margin: 12px 0 4px;
}
.toolbar button, .toolbar a.btn {
  cursor: pointer; font: inherit; font-weight: 600; font-size: 0.88rem;
  padding: 8px 14px; border-radius: 8px; border: 1px solid var(--accent);
  background: var(--accent); color: #fff; text-decoration: none;
}
.toolbar button.secondary, .toolbar a.btn.secondary {
  background: #fff; color: var(--accent);
}
.note-box {
  background: #fff8e6; border: 1px solid #e6d49a; border-radius: 8px;
  padding: 10px 12px; font-size: 0.9rem; margin: 10px 0 16px;
}
.doc-list { list-style: none; padding: 0; margin: 8px 0 0; }
.doc-list li {
  padding: 8px 0; border-bottom: 1px solid var(--line);
  display: flex; flex-wrap: wrap; gap: 8px; align-items: baseline;
}
.doc-list li:last-child { border-bottom: 0; }
.doc-list .svc { font-weight: 600; color: var(--ink); min-width: 9em; }
@media (max-width: 640px) {
  .form-grid { grid-template-columns: 1fr; }
}
"""


def alink(href: str, label: str | None = None) -> str:
    """Lien ouvrant un nouvel onglet."""
    lab = label or href
    return f'<a href="{href}" target="_blank" rel="noopener noreferrer">{lab}</a>'


def blank(n: int = 18) -> str:
    return f'<span class="blank" style="min-width:{n}em"></span>'


def eoh_header_html(*, show_intervention: bool = True, client_block: bool = False) -> str:
    """Bloc identité ÉOH pré-rempli (+ lieu d’intervention / client optionnels)."""
    e = EOH_ID
    parts = [
        f"""<div class="eoh-id">
  <strong>{e["denomination"]}</strong> — {e["forme"]}<br/>
  Fondée le {e["fondee"]} · réception {e["reception"]}<br/>
  RNA&nbsp;: {e["rna"]} · SIREN&nbsp;: {e["siren"]} · SIRET siège&nbsp;: {e["siret"]}<br/>
  NAF&nbsp;: {e["naf"]}<br/>
  <strong>Siège social (fixe)</strong> : {e["siege"]}<br/>
  Contact&nbsp;: {e["email"]} · sites {e["sites"]}<br/>
  <strong>{e["qualite_signataire"]}</strong> : {e["president"]}
  (alias {e["alias"]})
</div>"""
    ]
    if client_block:
        parts.append(
            f"""<h3>Identité client / structure</h3>
<p>Nom ou raison sociale : {blank(28)}<br/>
Signataire habilité : {blank(20)} &nbsp; Qualité : {blank(14)}<br/>
Coordonnées : {blank(28)}</p>"""
        )
    if show_intervention:
        parts.append(
            f"""<p><strong>Lieu d’intervention</strong>
(si différent du siège social — adresse du site client / audit)&nbsp;:<br/>
{blank(36)}</p>
<p class="meta-note">Le siège social reste à Lamarche&nbsp;; le lieu d’intervention / audit peut être distinct.</p>"""
        )
    return "\n".join(parts)


# Alias documenté pour imports / docs
EOH_HEADER_HTML = eoh_header_html


def page(
    title: str,
    subtitle: str,
    badge: str,
    body: str,
    *,
    logo: str = "pctamalou-favicon-lg.png",
) -> str:
    logos = []
    for src, alt, cls in (
        (logo, "pctamalou.fr", "logo"),
        ("echoes-of-hackers-sm.png", "Echoes of Hackers", "logo eoh"),
    ):
        if (ASSETS / src).is_file():
            logos.append(f'<img class="{cls}" src="assets/{src}" alt="{alt}"/>')
    logo_tag = "".join(logos)
    e = EOH_ID
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>{title} — Echoes of Hackers</title>
<style>{CSS}</style>
</head>
<body>
<div class="wrap">
<header class="brand">
  {logo_tag}
  <div class="titles">
    <h1>{title}</h1>
    <div class="sub">{subtitle}</div>
    <div class="badge">{badge}</div>
  </div>
</header>
{body}
{LEGAL_BOX}
<footer>
  {e["denomination"]} · RNA {e["rna"]} · SIREN {e["siren"]} · Guardia ·
  <a href="https://pctamalou.fr" target="_blank" rel="noopener noreferrer">pctamalou.fr</a>
  · {e["email"]} · Document type — droit français · vouvoiement professionnel
</footer>
</div>
</body>
</html>
"""


def _sig_eoh_client() -> str:
    e = EOH_ID
    return f"""
<div class="sig">
  <div class="box">
    <h3>Signature — Client / Audité</h3>
    <div>Nom : {blank(14)}</div>
    <div>Qualité : {blank(14)}</div>
    <div class="line"></div>
  </div>
  <div class="box">
    <h3>Signature — Echoes of Hackers</h3>
    <div>{e["president"]}, {e["qualite_signataire"]}</div>
    <div>Alias {e["alias"]}</div>
    <div class="line"></div>
  </div>
</div>
<p class="paraphe">Paraphe de chaque page recommandée. Un exemplaire signé pour chaque partie.</p>
"""


def build_mandat_roe() -> str:
    body = f"""
{eoh_header_html(show_intervention=True)}
<h2>1. Parties</h2>
<p><strong>Auditeur / association :</strong> {EOH_ID["denomination"]}
(pré-rempli ci-dessus)<br/>
Opérateur mission : {blank(22)}</p>
<p><strong>Entité auditée</strong> (adhérent / foyer / structure) : {blank(28)}</p>
<p><strong>Signataire habilité :</strong> {blank(20)}
&nbsp; Qualité : {blank(14)}</p>

<h2>2. Objet</h2>
<p>Mission d’<strong>audit défensif</strong> du réseau local : cartographie des équipements
et identification de <strong>lacunes d’hygiène / d’exposition</strong>,
<strong>sans</strong> exploitation de failles.</p>
<div class="checks">
  <p><strong>Périmètre antivirus / antimalware :</strong></p>
  <label>☐ <strong>Sans</strong> — checkup réseau local uniquement (inventaire / exposition). Pas de scan malware.</label>
  <label>☐ <strong>Avec complément</strong> — en plus du checkup LAN, scan(s) antimalware ponctuel(s)
    sur postes désignés, via outils <em>gratuits officiels</em> (ex. Microsoft Safety Scanner / Defender,
    Kaspersky KVRT, ESET Online Scanner, ClamAV si Linux), lancés avec votre accord et droits adaptés.
    Guardia n’est pas un antivirus permanent ni un SOC.</label>
</div>
<p>Postes concernés par le complément (si coché) : <span class="blank" style="min-width:28em"></span></p>

<h2>3. Périmètre autorisé</h2>
<ul>
  <li>Plage(s) IP / CIDR : {blank(24)}</li>
  <li>Sites / VLAN concernés : {blank(24)}</li>
  <li>Exclusions explicites : {blank(22)}</li>
  <li>Fenêtre horaire : du {blank(10)} au {blank(10)} (heures : {blank(10)})</li>
</ul>
<div class="checks">
  <p>Profil de mission :</p>
  <label>☐ foyer / maison &nbsp; ☐ PME &nbsp; ☐ association &nbsp; ☐ école / organisme</label>
</div>

<h2>4. Interdits</h2>
<p>Exploitation, déni de service volontaire, accès à des comptes non fournis,
contrôles hors périmètre, conservation abusive de données personnelles hors rapport utile.</p>

<h2>5. Contacts urgence</h2>
<ul>
  <li>Côté audité : {blank(16)} / tél. {blank(12)}</li>
  <li>Côté ÉOH : {blank(16)} / tél. {blank(12)}</li>
  <li>Mot d’ordre d’arrêt immédiat : {blank(18)}</li>
</ul>

<h2>6. Livrable</h2>
<p>Rapport clair : synthèse, détail par équipement, actions recommandées.
Conservation des données de contrôle sur le poste opérateur ÉOH, transmission selon votre accord.</p>

<h2>7. Consentement</h2>
<p>Le signataire déclare être habilité à autoriser ces contrôles et
<strong>autorise expressément</strong> Echoes of Hackers à les réaliser dans les limites ci-dessus.</p>
<p>Date : {blank(12)} &nbsp; Lieu : {blank(14)}</p>
{_sig_eoh_client()}
"""
    return page(
        "Mandat / Rules of Engagement",
        "Echoes of Hackers — mission défensive réseau local",
        "Autorisation écrite",
        body,
    )


def build_nda() -> str:
    body = f"""
{eoh_header_html(show_intervention=True)}
<h2>1. Parties</h2>
<p><strong>« ÉOH » / « l’Auditeur »</strong><br/>
{EOH_ID["denomination"]} (pré-rempli ci-dessus)<br/>
Contact : {EOH_ID["email"]} · opérateur mission : {blank(18)}</p>
<p><strong>« le Signataire » / « l’Audité »</strong><br/>
Nom ou raison sociale : {blank(28)}<br/>
Qualité : {blank(22)}</p>
<div class="checks">
  <label>☐ particulier / foyer</label>
  <label>☐ entreprise / PME</label>
  <label>☐ association</label>
  <label>☐ établissement scolaire / organisme</label>
  <label>☐ autre : {blank(18)}</label>
</div>

<h2>2. Objet (rappel)</h2>
<p>Contrôle <strong>défensif</strong> du réseau local autorisé : inventaire des équipements,
lacunes d’hygiène / d’exposition, rapport compréhensible.
Pas d’exploitation de failles. Pas d’exhaustivité absolue garantie.
Le mandat / ROE signé séparément fixe le périmètre.</p>
<div class="checks">
  <p>Selon le mandat coché :</p>
  <label>☐ Mission <strong>sans</strong> scan antimalware (réseau local uniquement).</label>
  <label>☐ Mission <strong>avec</strong> complément antimalware ponctuel
    (outils gratuits officiels sur postes listés au mandat).</label>
</div>

<h2>3. Destinataire du rapport</h2>
<p>Résultats destinés au Signataire et/ou à la personne commune :</p>
<p>Nom / fonction : {blank(22)}<br/>Coordonnées : {blank(24)}</p>
<p>Toute autre diffusion : accord écrit du Signataire, sauf obligation légale.</p>

<h2>4. Confidentialité mutuelle</h2>
<h3>4.1 ÉOH</h3>
<ul>
  <li>Confidentialité des informations de mission ;</li>
  <li>pas de divulgation hors personnes autorisées ;</li>
  <li>usage limité à la mission et au suivi convenu ;</li>
  <li>conservation raisonnable puis effacement / archivage selon accord
      (durée max. recommandée : {blank(6)} mois).</li>
</ul>
<h3>4.2 Signataire</h3>
<ul>
  <li>pas de diffusion publique du rapport brut facilitant une attaque ;</li>
  <li>information d’ÉOH en cas de fuite constatée ;</li>
  <li>pas de présentation comme certification officielle non obtenue.</li>
</ul>
<h3>4.3 Exceptions</h3>
<p>Déjà public sans faute ; obligation légale / judiciaire ; accord écrit préalable.</p>

<h2>5. Données personnelles (RGPD)</h2>
<p>Rappel RGPD et loi Informatique et Libertés. Données incidentes possibles
(noms d’hôtes, adresses MAC, identifiants réseau). Minimisation ; pas de revente ;
pas de transfert hors UE sans garanties. Contact droits : {EOH_ID["email"]}
/ {blank(12)}.</p>

<h2>6. Cadre pénal (information)</h2>
<p>Code pénal art. 323-1 et s. — action hors mandat / hors périmètre peut être illicite.
Le présent engagement complète le mandat ; il ne le remplace pas.</p>

<h2>7. Responsabilité</h2>
<ul>
  <li>Obligation de moyens pour ÉOH.</li>
  <li>Choix de remédiation à votre charge (Signataire).</li>
  <li>Pas de garantie d’absence totale de failles après mission.</li>
</ul>

<h2>8. Durée</h2>
<p>Confidentialité pendant la mission et {blank(4)} années après (recommandé 3 à 5 ans).</p>

<h2>9. Remise du rapport</h2>
<div class="checks">
  <label>☐ Signataire &nbsp; ☐ personne commune &nbsp; ☐ les deux</label>
  <label>☐ fichier chiffré &nbsp; ☐ main propre &nbsp; ☐ autre : {blank(12)}</label>
</div>

<h2>10. Signatures</h2>
<p>Fait à {blank(14)} , le ____ / ____ / ________</p>
{_sig_eoh_client()}
"""
    return page(
        "Confidentialité mutuelle",
        "Echoes of Hackers ↔ Signataire",
        "Engagement réciproque",
        body,
    )


def build_presentation() -> str:
    """Doc client : ce qu'on fait, sans dévoiler l'outil."""
    body = f"""
{eoh_header_html(show_intervention=False)}
<p>Echoes of Hackers propose un <strong>contrôle défensif de votre réseau local</strong>
(foyer, association, PME, école…). L’objectif : voir clairement ce qui est branché,
ce qui est exposé inutilement, et <strong>comment corriger</strong> — en français simple.</p>
<p class="meta-note">ÉOH peut fournir sur demande des références et sa présence LinkedIn
(followers / sociétés qui suivent) — sans inventaire de logos clients dans le présent document.</p>

<h2>Ce que nous faisons</h2>
<ul>
  <li>Inventaire des équipements présents sur le périmètre que vous avez autorisé.</li>
  <li>Repérage des pratiques à risque (services ouverts, équipements mal isolés, etc.).</li>
  <li>Rapport lisible : une fiche par appareil, gravité simple, gestes concrets.</li>
  <li>Échange sur les priorités : corriger seuls, avec ÉOH, ou avec un prestataire.</li>
</ul>

<h2>Deux formules possibles</h2>
<div class="grid2">
  <div class="card">
    <h2>Sans antivirus</h2>
    <p>Checkup du réseau local uniquement : inventaire, expositions, rapport clair.
    Pas de scan malware sur les postes.</p>
  </div>
  <div class="card">
    <h2>Avec complément antimalware</h2>
    <p>Le même checkup LAN, <strong>plus</strong> un scan ponctuel sur les PC convenus,
    avec un outil <strong>gratuit officiel</strong> (Microsoft, Kaspersky KVRT, ESET Online, ClamAV…).
    Ce n’est pas un antivirus installé en permanence, ni une garantie « zéro virus ».</p>
  </div>
</div>

<h2>Ce que nous ne faisons pas</h2>
<ul>
  <li>Pas d’exploitation de failles, pas de « preuve d’attaque » automatique.</li>
  <li>Pas de centre SOC / surveillance 24/7.</li>
  <li>Pas de scan hors du réseau / des postes que vous avez signés.</li>
  <li>Pas de promesse magique : on améliore l’hygiène, on ne certifie pas l’invulnérabilité.</li>
</ul>

<h2>Selon votre situation</h2>
<div class="grid2">
  <div class="card">
    <h2>Foyer</h2>
    <p>Box, Wi‑Fi, TV, consoles, téléphones, objets connectés.
    Nous visons la clarté pour votre foyer : qui est sur le réseau, quoi isoler,
    mots de passe / réseau invité.</p>
  </div>
  <div class="card">
    <h2>Association</h2>
    <p>Bénévoles, partages, imprimantes, parfois petit serveur.
    Nous aidons à limiter les expositions et à documenter pour le bureau.</p>
  </div>
  <div class="card">
    <h2>PME</h2>
    <p>Postes, NAS, Wi‑Fi invité, accès distants.
    Rapport orienté actions métier + annexe un peu plus technique si besoin.</p>
  </div>
  <div class="card">
    <h2>École / organisme</h2>
    <p>Parc élèves / admin, équipements pédagogiques.
    Accent sur la <strong>segmentation</strong> et les comptes partagés — sans perturber le quotidien.</p>
  </div>
</div>

<h2>Déroulement type</h2>
<ol>
  <li>Échange et cadrage (qui, quoi, urgences).</li>
  <li>Signature du mandat (+ confidentialité).</li>
  <li>Contrôle sur le périmètre autorisé, aux horaires convenus
      (siège social ≠ lieu d’intervention possible).</li>
  <li>Remise du rapport à la personne désignée.</li>
  <li>Option : accompagnement léger pour les premiers correctifs ;
      sur demande, notice post-audit (risques &amp; suites optionnelles).</li>
</ol>

<h2>Vos garanties</h2>
<ul>
  <li>Autorisation écrite avant tout contrôle.</li>
  <li>Confidentialité mutuelle.</li>
  <li>Données traitées avec mesure (RGPD).</li>
  <li>Arrêt immédiat sur mot d’ordre convenu.</li>
</ul>

<p style="margin-top:1.2em">Contact / infos : <strong>{alink("https://pctamalou.fr", "pctamalou.fr")}</strong>
· {alink("https://e-of-h.fr", "e-of-h.fr")} · {EOH_ID["email"]}</p>
"""
    return page(
        "Notre démarche",
        "Contrôle défensif de réseau local — Echoes of Hackers",
        "Présentation adhérent / client",
        body,
    )


def build_mandat_audit_full() -> str:
    """Mandat signé — passage audit full (catalogue exhaustif, défensif)."""
    try:
        from guardia.engines.audit_catalog import catalog_as_html_items, AUDIT_CATALOG
        items = catalog_as_html_items("full")
        n = len(AUDIT_CATALOG)
    except Exception as exc:  # noqa: BLE001
        items = f"<li>(catalogue indisponible à la génération : {exc})</li>"
        n = 0
    body = f"""
{eoh_header_html(show_intervention=True)}
<h2>1. Parties</h2>
<p><strong>Auditeur / association :</strong> {EOH_ID["denomination"]} —
{EOH_ID["president"]} ({EOH_ID["alias"]})<br/>
Opérateur : {blank(22)}</p>
<p><strong>Entité auditée</strong> : {blank(28)}</p>
<p><strong>Signataire habilité :</strong> {blank(20)} &nbsp; Qualité : {blank(14)}</p>

<h2>2. Objet — mandat « audit full »</h2>
<p>Ce document autorise un <strong>passage audit full</strong> Guardia, en complément
du checkup classique. Objectif produit : <strong>démontrer les failles d’exposition</strong>
constatées sur le réseau local autorisé, et vous remettre un rapport où chaque finding
inclut des <strong>remèdes concrets</strong> (comment contrer).</p>
<p>Déroulement :</p>
<ol>
  <li><strong>Run classique</strong> — découverte défensive + règles d’hygiène.</li>
  <li><strong>Passage audit</strong> (niveau <code>full</code>) — approfondissement
      borné (ports admin élargis, scripts nmap <em>informatifs</em> uniquement).</li>
  <li><strong>Rapport</strong> — section « Audit warning — failles d’exposition
      constatées et remèdes associés ».</li>
</ol>
<p>CLI : <code>--audit-full</code> (implique <code>--audit</code>).
YAML : <code>audit_full: true</code> ou <code>audit: full</code>.</p>

<h2>3. Catalogue des capacités ({n} entrées)</h2>
<p>Chaque capacité ci-dessous est citée précisément : ce qui est fait,
ce qui n’est <strong>pas</strong> fait, et ce qui apparaît dans le rapport
(faiblesse + remède).</p>
<ul>
{items}
</ul>

<h2>4. Interdits (clause no-exploit)</h2>
<ul>
  <li>Aucune exploitation de vulnérabilité.</li>
  <li>Aucun brute-force, credential stuffing, ni malware.</li>
  <li>Aucun script nmap catégorie <code>vuln</code> / exploit.</li>
  <li>Pas de contrôle hors CIDR / hors fenêtre autorisée.</li>
</ul>

<h2>5. Articulation avec les autres documents</h2>
<p>Ce mandat <strong>complète</strong> (ne remplace pas) :</p>
<ul>
  <li>le {alink("mandat-roe-eoh.html", "Mandat / ROE ÉOH")} ;</li>
  <li>la {alink("clause-confidentialite-mutuelle.html", "clause de confidentialité mutuelle (NDA)")} ;</li>
  <li>le cas échéant, l’{alink("avenant-post-audit-detail.html", "avenant / notice post-audit")}.</li>
</ul>
<p>Périmètre CIDR, exclusions et contacts d’urgence restent ceux du ROE signé.</p>

<h2>6. Livrable</h2>
<p>Rapport Guardia (HTML ± PDF) : synthèse, findings <code>audit-*</code> avec
preuves courtes et <strong>remede_etapes</strong> actionnables, inventaires INFO
(TLS, SSH hostkey, headers) le cas échéant.</p>

<h2>7. Consentement</h2>
<p>Le signataire déclare être habilité et <strong>autorise expressément</strong>
Echoes of Hackers / {EOH_ID["alias"]} à réaliser le passage audit full dans les limites
ci-dessus et du ROE.</p>
<p>Date : {blank(12)}</p>
{_sig_eoh_client()}
"""
    return page(
        "Mandat audit full Guardia",
        "Echoes of Hackers / Platon-Y — expositions + remèdes (défensif)",
        "Autorisation audit full",
        body,
    )


def build_avenant_post_audit_detail() -> str:
    """Notice / avenant post-audit — risques, non-responsabilité, suites optionnelles."""
    e = EOH_ID
    body = f"""
{eoh_header_html(show_intervention=True, client_block=True)}

<h2>1. Référence de mission</h2>
<p>Référence mission Guardia : {blank(22)}<br/>
Date(s) de l’audit : {blank(18)}<br/>
Documents déjà signés : ☐ ROE &nbsp; ☐ NDA &nbsp; ☐ Mandat audit full &nbsp; ☐ Autre {blank(10)}</p>

<h2>2. Objet</h2>
<p>Le présent document est fourni <strong>à votre demande, après un audit</strong>, afin de
détailer par écrit les <strong>risques et enjeux</strong> constatés ou liés à un audit de
cybersécurité, et de cadrer d’éventuelles <strong>suites optionnelles</strong>.
Il ne remplace pas le rapport technique ni le mandat / ROE.</p>

<h2>3. Nature du checkup Guardia</h2>
<ul>
  <li>Contrôle <strong>défensif</strong> du périmètre autorisé (inventaire, expositions,
      hygiène) — <strong>sans exploitation</strong> de vulnérabilités dans le checkup classique.</li>
  <li><strong>Non exhaustif</strong> : l’absence de finding ne signifie pas l’absence de faille.</li>
  <li>Ce n’est <strong>pas une garantie</strong> d’absence de compromission passée ou future,
      ni une certification officielle (PASSI / ANSSI ou autre).</li>
  <li>Le périmètre peut inclure votre <strong>réseau local (LAN)</strong>, et le cas échéant
      votre <strong>site web / applications web</strong> et autres services <strong>explicitement
      listés</strong> dans le mandat ou en annexe.</li>
</ul>

<h2>4. Remise du rapport — vos responsabilités</h2>
<p>Le rapport présente des findings et des <strong>remèdes recommandés</strong>.
<strong>Vous restez responsable</strong> de la lecture, de la priorisation et de la mise en œuvre
des correctifs (par vos soins, un prestataire, ou ÉOH si un avenant distinct le prévoit).
ÉOH agit en obligation de moyens dans le cadre signé.</p>

<h2>5. Reconnaissance client — compréhension et limitation</h2>
<p>En signant, <strong>vous reconnaissez</strong> :</p>
<ul>
  <li>avoir <strong>lu et compris</strong> les risques et enjeux exposés dans le rapport et
      dans le présent document (caractère non exhaustif compris) ;</li>
  <li>que les failles ou expositions relevées étaient, sauf preuve contraire,
      <strong>préexistantes</strong> à la mission ou hors de la maîtrise exclusive d’ÉOH ;</li>
  <li>que vous <strong>ne tiendrez pas rigueur</strong> à l’opérateur de service ni à
      l’association Echoes of Hackers pour : (i) les dommages liés aux failles préexistantes
      constatées ; (ii) vos décisions de remédiation, de report ou d’absence de suite ;
      (iii) un incident ultérieur <strong>hors périmètre</strong> ou postérieur à la fenêtre
      d’audit, dès lors qu’ÉOH a agi dans le cadre du mandat et sans faute lourde ou dol ;</li>
  <li>que le présent alinéa constitue une <strong>reconnaissance / limitation raisonnable</strong>
      de responsabilité au regard du droit applicable, et non une exonération absolue
      en cas de faute lourde ou de dol.</li>
</ul>

<h2>6. Suites optionnelles orchestrées (annexe — cases à cocher)</h2>
<p><strong>Uniquement si coché et signé</strong>. Ces suites ne sont jamais silencieuses :
elles forment une phase <strong>optionnelle</strong>, distincte du checkup classique non-exploit,
sous <strong>orchestration étroite</strong>, sur <strong>actifs vous appartenant ou que vous avez
expressément autorisés</strong>, <strong>bornée aux plages horaires de l’audit existant</strong>,
<strong>sans dépassement possible du programme écrit</strong> (interdiction de scope creep).</p>
<div class="checks">
  <label>☐ <strong>Lab type Metasploitable</strong> (ou équivalent) — environnement
    <em>contrôlé / isolé</em> pour pédagogie et démonstration de scénarios, hors production
    sauf accord écrit contraire listé en annexe.</label>
  <label>☐ <strong>Lecture URL du mandat</strong> — curl / TLS / empreinte HTTP
    sur le(s) hôte(s) / URL listé(s) ci-dessous.</label>
  <label>☐ <strong>Autres suites d’outils</strong> sous orchestration étroite
    (à nommer) : {blank(28)}</label>
  <label>☐ <strong>Aucune suite optionnelle</strong> — checkup / audit défensif seulement.</label>
</div>
<p><strong>Périmètres possibles (à cocher / préciser) :</strong></p>
<div class="checks">
  <label>☐ LAN déjà audité (CIDR / VLAN) : {blank(22)}</label>
  <label>☐ Site web / applications web du client (URL / FQDN) : {blank(24)}</label>
  <label>☐ Autres services listés en annexe : {blank(22)}</label>
</div>
<p class="meta-note">Toute action hors cibles autorisées, hors plage horaire, ou non écrite
au programme est interdite. Arrêt immédiat sur votre demande ou mot d’ordre ROE.</p>

<h2>7. Rappel ROE / NDA</h2>
<ul>
  <li>Cibles autorisées uniquement — pas d’Internet tiers non listé.</li>
  <li>Arrêt immédiat sur demande ; traces conservées selon accord.</li>
  <li>Confidentialité mutuelle (NDA) demeure applicable.</li>
  <li>Pas de brute-force / malware hors annexe expressément signée et cadrée.</li>
</ul>

<h2>8. Conservation</h2>
<p>Le présent avenant est établi en <strong>deux exemplaires</strong> :
<strong>un pour le client</strong>, <strong>un pour ÉOH</strong>. Les deux parties
conservent leur exemplaire signé.</p>
<p>Durée de conservation convenue : {blank(6)} mois / années
(à remplir ; recommandé : alignée sur le NDA).</p>

<h2>9. Signatures</h2>
<p>Fait à {blank(14)} , le ____ / ____ / ________</p>
<div class="sig">
  <div class="box">
    <h3>Pour le client</h3>
    <div>Nom : {blank(14)}</div>
    <div>Qualité : {blank(14)}</div>
    <div>« Lu et compris — risques &amp; suites »</div>
    <div class="line"></div>
  </div>
  <div class="box">
    <h3>Pour Echoes of Hackers</h3>
    <div>{e["president"]}</div>
    <div>{e["qualite_signataire"]} (alias {e["alias"]})</div>
    <div class="line"></div>
  </div>
</div>
<p class="paraphe">Paraphe de chaque page recommandée. À faire valoir pour ce que de droit.</p>
"""
    return page(
        "Avenant / notice post-audit — compréhension des risques, suites optionnelles et non-responsabilité",
        "Echoes of Hackers — document remis à la demande du client après audit",
        "À signer & conserver (2 exemplaires)",
        body,
    )


def build_index() -> str:
    """Sommaire client — sans consignes opérateur."""
    body = f"""
{eoh_header_html(show_intervention=False)}
<p>Documents relatifs à une mission de contrôle défensif Echoes of Hackers.
Rédaction client en <strong>vouvoiement professionnel</strong>.</p>
<p><strong>Hub opérateur</strong> : {alink("nouveau-client.html", "nouveau-client.html")}
— pack par service (foyer / PME / école / audit full / red), fiche client remplissable.</p>
<div class="cards">
  <div class="card">
    <h2>Présentation — notre démarche</h2>
    <p>Ce que nous faisons (foyer, association, PME, école), sans jargon technique.</p>
    <p>{alink("presentation-demarche.html")} · {alink("presentation-demarche.pdf", "PDF")}</p>
  </div>
  <div class="card">
    <h2>Mandat / autorisation</h2>
    <p>Périmètre, dates, interdits — à signer avant la mission.</p>
    <p>{alink("mandat-roe-eoh.html")} · {alink("mandat-roe-eoh.pdf", "PDF")}</p>
  </div>
  <div class="card">
    <h2>Confidentialité mutuelle</h2>
    <p>Engagement réciproque, données personnelles, cadre légal.</p>
    <p>{alink("clause-confidentialite-mutuelle.html")} · {alink("clause-confidentialite-mutuelle.pdf", "PDF")}</p>
  </div>
  <div class="card">
    <h2>Mandat audit full</h2>
    <p>Passage audit full Guardia : catalogue des capacités, expositions constatées
    et remèdes — sans exploit. Complète le ROE + NDA.</p>
    <p>{alink("mandat-audit-full.html")} · {alink("mandat-audit-full.pdf", "PDF")}</p>
  </div>
  <div class="card">
    <h2>Avenant / notice post-audit</h2>
    <p>À votre demande après audit : compréhension des risques, suites optionnelles
    orchestrées (lab / lecture URL), reconnaissance et conservation bilatérale.</p>
    <p>{alink("avenant-post-audit-detail.html")} · {alink("avenant-post-audit-detail.pdf", "PDF")}</p>
  </div>
</div>
<p style="margin-top:1.2em">Sites : {alink("https://pctamalou.fr", "pctamalou.fr")}
· {alink("https://e-of-h.fr", "e-of-h.fr")} · {EOH_ID["email"]}</p>
"""
    return page(
        "Dossier mission",
        "Echoes of Hackers — documents joints",
        "Pack client",
        body,
    )


FLYER_CSS = """
* { box-sizing: border-box; }
html, body { margin: 0; padding: 0; }
body {
  font-family: "Segoe UI", system-ui, sans-serif;
  color: #122033;
  background: #0b1c2c;
}
.sheet {
  width: 420mm;
  min-height: 297mm;
  margin: 0 auto;
  background: linear-gradient(145deg, #0b1c2c 0%, #143d5c 45%, #1b4f72 100%);
  color: #f5f8fb;
  padding: 18mm 20mm;
  display: grid;
  grid-template-rows: auto 1fr auto;
  gap: 12mm;
}
.top {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: 16px;
}
.top img.logo { height: 42mm; width: auto; }
.top img.eoh { height: 36mm; width: auto; border-radius: 50%; background: #0b1c2c; }
.hero h1 {
  font-size: 38pt;
  line-height: 1.05;
  margin: 0 0 8px;
  font-weight: 800;
  letter-spacing: -0.02em;
}
.hero .tag {
  font-size: 16pt;
  opacity: 0.9;
  max-width: 280mm;
}
.cols {
  display: grid;
  grid-template-columns: 1.2fr 1fr;
  gap: 12mm;
  align-items: stretch;
}
.panel {
  background: rgba(255,255,255,0.08);
  border: 1px solid rgba(255,255,255,0.18);
  border-radius: 8px;
  padding: 10mm;
}
.panel h2 {
  margin: 0 0 6mm;
  font-size: 18pt;
  color: #9fd0ff;
}
.panel ul { margin: 0; padding-left: 6mm; font-size: 13pt; }
.panel li { margin: 3mm 0; }
.bigurl {
  font-size: 28pt;
  font-weight: 800;
  letter-spacing: 0.02em;
}
.foot {
  display: flex;
  justify-content: space-between;
  align-items: end;
  border-top: 1px solid rgba(255,255,255,0.25);
  padding-top: 6mm;
  font-size: 11pt;
  opacity: 0.9;
}
@page { size: A3 landscape; margin: 0; }
@media print {
  body { background: #fff; }
  .sheet { margin: 0; box-shadow: none; }
}
"""


def build_flyer_a3() -> str:
    e = EOH_ID
    return f"""<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="utf-8"/>
<title>Flyer A3 — pctamalou.fr / Echoes of Hackers</title>
<style>{FLYER_CSS}</style>
</head>
<body>
<div class="sheet">
  <div class="top">
    <img class="logo" src="assets/pctamalou-favicon-lg.png" alt="pctamalou.fr"/>
    <img class="eoh" src="assets/echoes-of-hackers-flyer.png" alt="Echoes of Hackers"/>
  </div>
  <div class="hero">
    <h1>Nous regardons votre réseau local.<br/>Nous vous expliquons. Vous corrigez.</h1>
    <p class="tag">Contrôle défensif pour foyers, associations, PME et écoles —
    inventaire, risques d’hygiène, rapport clair. Pas d’exploit. Pas de magie.</p>
  </div>
  <div class="cols">
    <div class="panel">
      <h2>Au programme (grandes lignes)</h2>
      <ul>
        <li>Ce qui est branché sur <em>votre</em> réseau autorisé</li>
        <li>Ce qui est trop exposé — en français courant</li>
        <li>Des gestes concrets, priorisés</li>
        <li>Cadre écrit : mandat + confidentialité</li>
      </ul>
    </div>
    <div class="panel">
      <h2>Echoes of Hackers</h2>
      <p style="font-size:13pt;margin:0 0 4mm">Association déclarée · RNA {e["rna"]}</p>
      <p style="font-size:12pt;margin:0 0 8mm;opacity:0.9">SIREN {e["siren"]} · {e["president"]} ({e["alias"]})</p>
      <div class="bigurl"><a href="https://pctamalou.fr" target="_blank" rel="noopener noreferrer" style="color:inherit;text-decoration:none">pctamalou.fr</a></div>
      <p style="margin-top:8mm;font-size:12pt;opacity:0.85">{e["email"]} · e-of-h.fr</p>
    </div>
  </div>
  <div class="foot">
    <div>Pas d’antivirus · Pas d’attaque · Autorisation écrite obligatoire</div>
    <div>À faire valoir pour ce que de droit</div>
  </div>
</div>
</body>
</html>
"""


def pdf(html_name: str, pdf_name: str | None = None) -> None:
    src = OUT / html_name
    dst = OUT / (pdf_name or html_name.replace(".html", ".pdf"))
    subprocess.run(["weasyprint", str(src), str(dst)], check=True, capture_output=True, text=True)
    print("PDF", dst.name)


def main() -> int:
    OUT.mkdir(parents=True, exist_ok=True)
    ASSETS.mkdir(parents=True, exist_ok=True)

    docs = {
        "index.html": build_index(),
        "nouveau-client.html": __import__("nouveau_client_hub", fromlist=["build_nouveau_client"]).build_nouveau_client(),
        "mandat-roe-eoh.html": build_mandat_roe(),
        "mandat-audit-full.html": build_mandat_audit_full(),
        "clause-confidentialite-mutuelle.html": build_nda(),
        "presentation-demarche.html": build_presentation(),
        "avenant-post-audit-detail.html": build_avenant_post_audit_detail(),
        "flyer-guardia.html": build_flyer_a3(),
    }
    for name, html in docs.items():
        (OUT / name).write_text(html, encoding="utf-8")
        print("HTML", name)

    # Operator-only note (not client-facing)
    (OUT / "LIRE-OPERATEUR.md").write_text(
        """# Notes opérateur (ne pas joindre au client)

- **Tone client** : tous les PDF / HTML client sont en **vouvoiement professionnel** (vous/votre).
- HTML : lecture / envoi mail.
- PDF : impression ou signature électronique.
- Régénérer : `python3 modeles/build_a_signer.py`
- Flyer A3 paysage : `flyer-guardia.pdf`
- Identité visuelle fournie par le dossier opérateur (`assets/`)
- Logo ÉOH : `assets/echoes-of-hackers.png` (fourni)
- Mandat audit full : `mandat-audit-full.html` / `.pdf` (catalogue capacités + remèdes)
- **Avenant post-audit** : `avenant-post-audit-detail.html` / `.pdf`
  (risques, reconnaissance client, suites optionnelles lab/lecture URL — à la demande, 2 exemplaires)
- Identité ÉOH pré-remplie via `EOH_ID` / `eoh_header_html()` dans `build_a_signer.py`
  (RNA W882005217, SIREN 933496234, siège Lamarche ; lieu d’intervention distinct possible)
- Checkup full options : `missions/exemple-full.yaml` ; CLI `--audit-full` pour audit niveau full
- Intent produit : démontrer expositions + remèdes dans le rapport (défensif)
- Suites outils offensifs = **optionnelles**, annexe signée, jamais silencieuses, plages = audit existant
- **Hub Nouveau client** : `nouveau-client.html` (fiche + Blue/Red + stub YAML)
- Firefox neutre : `scripts/install-firefox-neutre.sh` / `guardia.core.firefox_neutre`
""",
        encoding="utf-8",
    )

    try:
        for stem in (
            "index",
            "mandat-roe-eoh",
            "mandat-audit-full",
            "clause-confidentialite-mutuelle",
            "presentation-demarche",
            "avenant-post-audit-detail",
            "flyer-guardia",
        ):
            pdf(f"{stem}.html")
    except (OSError, subprocess.CalledProcessError) as exc:
        print("PDF error:", exc, file=sys.stderr)
        return 1

    print("OUT", OUT)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
