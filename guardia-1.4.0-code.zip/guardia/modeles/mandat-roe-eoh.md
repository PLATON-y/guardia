# Mandat / Rules of Engagement — Guardia (Echoes of Hackers)

> Modèle à adapter. À faire signer **avant** tout scan.  
> Ne remplace pas un avis d’avocat. Cadre indicatif art. 323-1 et s. Code pénal.  
> **Rédaction client : vouvoiement professionnel.**  
> Version HTML/PDF générée : `python3 modeles/build_a_signer.py` (pré-remplit ÉOH).

## Identité ÉOH (pré-remplie)

- **Dénomination :** Echoes of Hackers (ÉOH) — Association déclarée
- **Fondée :** 13/09/2024 ; réception sous-préfecture Neufchâteau 17/09/2024
- **RNA :** W882005217 · **SIREN :** 933496234 · **SIRET siège :** 93349623400016
- **NAF :** 8020Z (activités liées aux systèmes de sécurité)
- **Siège social (fixe) :** 3 Rue Saint-Henry, Appartement 41, Étage 1, 88320 Lamarche (Vosges)
- **Contact :** admin@e-of-h.fr · e-of-h.fr / example.test
- **Président / responsable de publication :** Jonathan Ducros (alias Platon-Y)
- **Lieu d’intervention** (si différent du siège — adresse site client / audit) : _________________

## Parties

- **Auditeur / association :** Echoes of Hackers (ÉOH), opérateur : _________________
- **Entité auditée (adhérent / foyer / structure) :** _________________
- **Signataire habilité :** _________________ (qualité : _________________)

## Objet

Mission d’**audit défensif** du réseau local (outil Guardia) : cartographie des équipements et identification de **lacunes d’hygiène / d’exposition**, **sans** recherche de virus/malware et **sans** exploitation de failles.

## Périmètre autorisé

- Plage(s) IP / CIDR : _________________
- Sites / VLAN concernés : _________________
- Exclusions explicites (ne pas toucher) : _________________
- Fenêtre horaire : du __________ au __________ (heures : __________)
- Profil Guardia : ☐ maison  ☐ pme  ☐ ecole

## Interdits

Exploitation, déni de service volontaire, accès à des comptes non fournis, scan hors périmètre, conservation abusive de données personnelles hors rapport utile.

## Contacts urgence

- Côté audité : _________________ / tél. __________
- Côté ÉOH : _________________ / tél. __________
- Mot d’ordre d’arrêt immédiat : _________________

## Livrable

Rapport Guardia (synthèse claire + détail par équipement + actions recommandées). Données de scan conservées sur le poste opérateur ÉOH, transmises selon votre accord.

## Consentement

Le signataire déclare être habilité à autoriser ces contrôles sur les systèmes listés et **autorise expressément** Echoes of Hackers à les réaliser dans les limites ci-dessus.

Date : __________  
Signature audité : __________  
Signature ÉOH (Jonathan Ducros, Président) : __________  
